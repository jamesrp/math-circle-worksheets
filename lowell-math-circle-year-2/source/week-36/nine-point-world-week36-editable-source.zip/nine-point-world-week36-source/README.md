# Week 36 Making threes editable source

## Current release: October 4, 2026 fresh-review revision

The guide now gives first routes, readiness-dependent continuation and return visits; original mathematical investigations are retained. On October 23, 2026 the student pages became problem files and the review card's shoulds and clear coulds were made (v3): see `review/card-shoulds-2026-10-23.md`, checked by `review/verify_card_shoulds_2026_10_23.py`. A critic's follow-up the same day changed only the guide: its straight-line warning names every printed nine-tile grid.

**Kid-fit revision, November 6, 2026 (v4).** A kid-fit pilot revised the student pages and James approved adopting them: partners or a third player check the threes, K-1 Problem 1 has tile-size answer boxes and the middle-tile problem comes before the most-tiles search, Grades 2-3 gets split boards and a game page, and Grades 4-5 Problem 5 is a refereed game. The guide was updated to match (version 4, still 6 pages). See `review/kid-fit-2026-11-06.md`, checked by `review/verify_kid_fit_2026_11_06.py`. Unpiloted.

This is an unpiloted theme library, not a fixed meeting schedule. Select a manageable first route in the guide and return for further investigations. Preserve the full Grades 4–5 material. Prerequisites, launch, materials, hints and theorem-first mathematical overview are in the separate adult guide. Physical fit, demonstrations and classroom timing have not been tested.

**Pages-first wording, November 17, 2026 (v5).** An adult cold read led to wording-only changes saying where tiles go, how to mark chosen tiles (counters) and how to record splits and threes (one colour per three); the guide changed only its footer. See the week README.

Current pages: **K–1 5; Grades 2–3 5; Grades 4–5 5; adult guide 6** (v5). Print selected student pages single-sided on US Letter at Actual Size / 100%.

## Rebuild outside the project

Extract the complete ZIP. Install Python 3 with `requirements.txt`, a normal TeX Live distribution providing pdfLaTeX/TikZ/Helvetica, and Poppler's `pdftoppm` where used by the existing checks. Matching guide fonts and licenses are included; the root build selects package-local fonts in earlier packages. No project checkout or original workspace path is needed.

    python3 -m pip install -r requirements.txt
    python3 build.py
    python3 verify_revision.py

The current verifier compares paper geometry and every 100-dpi rendered page against `reference-pdfs/`; timestamps may differ. It permits only specifically audited full-page font/hyphenation alternatives for unchanged student PDFs. See `review/fresh-review-rebuild.md` for actual results. The original strict verifier (`verify_rebuild.py` or `verify.py`) is retained and rejects those alternatives. The corpus report explicitly records any pre-existing small TeX font-metric differences for unchanged student bands; their current print/reference PDFs stay byte-identical. For Weeks 24 and 35, the detailed student-stage record is `review/student-reviser-fresh-review.md`. The corpus release report records those differences explicitly rather than calling them pixel-identical.

The student pages are stored as problem files (since October 23, 2026): in the portable ZIP they are in `problem-files/` (`week.toml`, `figures.py`, `problems/*.md`) with the tools in `problem-files/tools/`; in the repository they are in the week folder that holds `editable/`. Edit the problem files; `src/regenerate.py` writes `src/*.tex` from them and the build runs it first, then `src/student_checks.py` (the old builder's exact checks). `problem-files/tools/build.py problem-files --out <folder>` also builds the menu and route packets. Edit the existing guide source under `facilitator-src/`. Where present, `facilitator-src/route-note.json` holds the concise starting/return update; the root build regenerates the guide before appending it exactly once. Do not run the appender alone against an already appended guide. Build intermediates belong in a separate working copy; inspect changed pages before updating references.

The current reference manifest is `review/reference-manifest.json`; revision evidence is `review/fresh-review-2026-10-04.md`. Older review files and `review/README-before-fresh-review-2026-10-04.md` describe their dated versions. Prior releases are archived outside the current package in the project.

## Use and rights

Original worksheet prose, diagrams and builders are provided for the organizer's use and adaptation. Preserve source attribution. Third-party books and articles retain their rights and are not redistributed here. Included fonts retain their licenses. No broader third-party license is implied. Routine adult reading or recording is allowed; children should retain the mathematical choices.
