# Week 39 revised student source

Revised and unpiloted. Run `bash build.sh` using Python 3, pdfLaTeX, TikZ, Latin Modern, AMS fonts, and Poppler. Portable build scripts use the caller's environment. Output is three four-page student PDFs and QA images one directory above this folder.

The fixed road map is never erased. Use a pawn and ordered road-step records; an adult may record, and the youngest children replay rather than transcribe letter strings. The visual example shows four directed mini-map step tiles, removal of the adjacent B→C→B pair, and replay of the two surviving steps. A real tabletop trial of large physical tiles or adult recording with the exact child group remains unperformed. All recording needs to preserve the actual edge and its direction, including on hypothetical parallel-road maps. Staying at the initial vertex is the empty journey.

`check_math.py` checks all listed routes and bounded constructions independently of the drawing code, as well as all tree walks through ten steps. New K–1 ring constructions have five reduced home results for eight steps and four reduced A-to-C results for six steps. These are finite checks; the arbitrary-length unique-reduction and tree claims require the mathematical explanation, not extrapolation from enumeration. No stack algorithm or general solution method is printed for students.
