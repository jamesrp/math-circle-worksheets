# Week 37 conditional revised student packet

K–1 and grades 2–3: four pages each. Grades 4–5: five pages. Student pages only. Draft and unpiloted.

## Required physical gate before use

**The required physical pretest has NOT been performed. Do not use these pages with children until an adult has supplied the intended rigid regular tetrahedral models and completed the following physical checks with those actual models. Digital verification is not a substitute. If the models or this pretest cannot be supplied, defer the topic.**

The adult must compare vertex categories and positions, ignoring the direction of printed letters or marker mountings. The adult must build the four-distinct-label mirror pair, successfully align a true copy by an allowed rigid motion, check the orientation certificate from the exact viewing direction below, and successfully align the two-equal-label example. The later facilitator guide must repeat this gate prominently. No physical trial or classroom success is claimed by this draft.

Use safe preassembled rigid regular tetrahedral frames with 80–100 mm edges. Supply at least six frames per table, ideally two per child, and clip-on markers in four distinct colors with letters A, B, C, D as redundant identifiers. Have duplicate labels for relabeling. Use a shatter-resistant mirror and non-slip tray. No pointed sticks, exposed wire, bendable model arms, or paper-only substitute is suitable for the youngest packet.

## Rebuild and diagram convention

Run `bash build.sh` with Python 3, a standard pdfLaTeX/TikZ installation and Poppler. Source `.tex` files are generated from the problem files by `regenerate.py` (see the week's README) and may also be compiled directly; `student_checks.py` writes `mathematical-checks.json`. All model drawings are original, mathematically derived orthographic projections of a regular tetrahedron. Their solid outside triangle is the front face; the three dashed edges run to the far vertex behind that face. The shaded vertex circles are markers rather than spherical model parts. Letters remain readable in grayscale and are category labels only. Each merge trial resets to the original four-distinct-label mirror pair. Rotation counts identify moves with the same resulting vertex destinations, regardless of motion history.

For each perspective frame, labels are listed in the order [apex, lower left, lower right, far vertex]. The successful-turn example is ABCD → ADBC. It is a 120-degree rotation about the axis from A through the center of the opposite face. The mirror pair is ABCD versus ACBD. The repeated-label example changes D to C, giving ABCC versus ACBC; these match by a proper rotation. It deliberately does not collapse into two identical fixed-position pictures.

For the upper view, A is nearest the eye and the child looks straight toward the center of opposite face BCD. The original model projects to B at lower left, C at lower right, D at top, with A in front at the center. Viewed consistently this way, the cyclic order is preserved under all allowed alignments fixing A; a mirror reverses it. Looking from the opposite side would reverse the certificate and invalidate a comparison. The page gives a matched perspective-to-view example before children use two blank view diagrams to record their pair.

## Digital checks and limits

`mathematical-checks.json` records 12 proper tetrahedral rotations obtained from exact integer coordinates and determinants. It checks the successful-copy example, distinguishes the four-label mirror pair, confirms the repeated-label match, and checks all six choices of two labels to merge. These finite checks verify the intended mathematical configurations, not model rigidity, marker attachment, visual occlusion in the actual kit, or classroom usability.

Sources: Richard Schwartz, Rotations of the Tetrahedron, https://www.math.brown.edu/reschwar/MFS/handout3.pdf ; OpenStax Organic Chemistry 5.1, https://openstax.org/books/organic-chemistry/pages/5-1-enantiomers-and-the-tetrahedral-carbon . This is a geometry investigation. The student pages do not require permutation parity or chemical vocabulary.

All 13 student pages rendered and inspected at writer stage. The physical gate remains outstanding.
