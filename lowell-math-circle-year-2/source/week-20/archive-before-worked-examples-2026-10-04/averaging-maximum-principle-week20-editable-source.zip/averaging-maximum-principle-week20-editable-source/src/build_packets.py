from pathlib import Path
import sympy as sp

ROOT=Path(__file__).resolve().parent
checks=[]
class Packet:
    def __init__(self, filename, level, packet, young=False):
        self.filename,self.level,self.packet,self.young=filename,level,packet,young
        self.s=[r'''\documentclass[12pt,letterpaper]{article}
\usepackage[letterpaper,margin=0in]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage{tikz}
\usetikzlibrary{calc}
\pdfmapfile{+lm.map}
\pagestyle{empty}
\hyphenpenalty=10000
\exhyphenpenalty=10000
\setlength{\parindent}{0pt}
\begin{document}''']
        self.page=0
        self.g=0
    def txt(self,x,y,t,size=15,width=7.18):
        self.s.append(r'\node[anchor=north west,inner sep=0pt,align=left,text width='+str(width)+r'in,font=\fontsize{'+str(size)+'}{'+str(size+4)+r'}\selectfont] at ('+str(x)+','+str(y)+') {'+t+'};')
    def start(self,prompt,rules=None):
        if self.page: self.s.append(r'\end{tikzpicture}\newpage')
        self.page+=1
        self.s.append(r'\noindent\begin{tikzpicture}[remember picture,overlay,x=1in,y=1in,shift={(current page.south west)}]')
        self.txt(.64,10.48,rf'Week 20 / Averaging / {self.level}',13)
        self.s.append(r'\draw[line width=.5pt] (.64,10.13)--(7.86,10.13);')
        self.txt(.64,.48,f'Bellingham Math Circle / Week 20 / {self.packet}',9.5)
        self.s.append(r'\node[anchor=north east,inner sep=0pt,font=\fontsize{9.5}{12}\selectfont] at (7.86,.48) {'+str(self.page)+'};')
        y=9.86
        if rules:
            self.txt(.64,y,rules,12.5)
            y=8.73 if self.young else 8.68
        self.txt(.64,y,r'\textbf{Problem '+str(self.page)+':} '+prompt,16 if self.young else 14.5)
    def graph(self,nodes,edges,size=None,check=True,record=False):
        # Nodes: name, x, y, fixed, value. Dimensions are physical inches.
        size=size or (1.19 if self.young else .68)
        self.g+=1
        pref=f'g{self.g}'
        vals={n[0]:n[4] for n in nodes if n[3] and n[4] is not None}
        if check and vals:
            ns=[n[0] for n in nodes]
            unknown=[n for n in ns if n not in vals]
            syms=dict(zip(unknown,sp.symbols('x:'+str(len(unknown)))))
            eq=[]
            for n in unknown:
                adj=[b if a==n else a for a,b in edges if n in (a,b)]
                eq.append(len(adj)*syms[n]-sum(vals.get(v,syms.get(v)) for v in adj))
            sol=sp.solve(eq,list(syms.values()))
            checks.append((self.filename,self.page,dict(vals),{n:str(sol.get(v,'free')) for n,v in syms.items()}))
        for name,x,y,fixed,val in nodes:
            shape='rectangle' if fixed else 'circle'
            contents='' if val is None else str(val)
            if self.young and not record and val is not None:
                contents=''
            self.s.append(r'\node[draw,fill=white,'+shape+',line width=1.05pt,minimum size='+str(size)+r'in,inner sep=0pt,font=\fontsize{'+('12' if record else '23' if self.young else '19')+r'}{25}\selectfont] ('+pref+name+') at ('+str(x)+','+str(y)+') {'+contents+'};')
            if self.young and not record and val is not None:
                self.s.append(r'\node[font=\fontsize{23}{26}\selectfont] at ('+str(x)+','+str(y+.20)+') {'+str(val)+'};')
                for k in range(val):
                    cols=min(val,3)
                    dx=(k%3-(cols-1)/2)*.18
                    dy=-.15-(k//3)*.16
                    self.s.append(r'\fill ('+str(x+dx)+','+str(y+dy)+') circle[radius=.038in];')
        for a,b in edges:
            self.s.append(r'\draw[line width=1.15pt] ('+pref+a+')--('+pref+b+');')
    def path(self,ys,ends,internals=2,small=False):
        count=internals+2
        xs=[1.4+i*(5.7/(count-1)) for i in range(count)]
        nodes=[(str(i),x,ys,i in (0,count-1),ends[0] if i==0 else ends[1] if i==count-1 else None) for i,x in enumerate(xs)]
        self.graph(nodes,[(str(i),str(i+1)) for i in range(count-1)],size=.68 if small else None)
    def finish(self):
        self.s.append(r'\end{tikzpicture}\null\end{document}')
        (ROOT/(self.filename+'.tex')).write_text('\n'.join(self.s))

K=Packet('k-1','K--1','GA20-K-v2',True)
K.start('Make the circle stacks on all four boards.',
    "Squares keep their stacks. A circle holds one equal share of the stacks joined to it. Make one equal pile for each joined shape, including empty shapes. Every circle must work at once. Use spare cubes for sharing.")
for x,y,a,b in [(2.25,6.28,0,2),(6.25,6.28,2,4),(2.25,3.17,0,4),(6.25,3.17,2,6)]:
    K.graph([('a',x-.72,y+1.3,True,a),('b',x+.72,y+1.3,True,b),('c',x,y,False,None)],[('a','c'),('b','c')])
K.start('Make all the circle stacks. Both circles on a board must work at the same time.')
for y,ends in [(8.0,(0,3)),(6.17,(3,0)),(4.34,(0,6)),(2.51,(6,0))]: K.path(y,ends)
K.start('Put 2 cubes in the circle and use 0 to 3 cubes in each square. Find every way that works.')
K.graph([('a',4.25,8.45,True,None),('b',2.90,6.20,True,None),('c',5.60,6.20,True,None),('u',4.25,6.95,False,2)],[('a','u'),('b','u'),('c','u')],check=False)
for y in [4.25,2.45]:
    for x in [1.30,2.775,4.25,5.725,7.20]:
        K.graph([('a',x,y+.60,True,None),('b',x-.45,y-.35,True,None),('c',x+.45,y-.35,True,None),('u',x,y,False,2)],[('a','u'),('b','u'),('c','u')],size=.42,check=False,record=True)
K.start('Use three different cards to fill the squares and circle. Find every way that works.')
for i in range(5):
    x=2.05+1.1*i
    K.s.append(r'\node[draw,minimum width=.65in,minimum height=.85in,font=\fontsize{23}{26}\selectfont] at ('+str(x)+',8.15) {'+str(i)+'};')
K.graph([('a',2.05,6.05,True,None),('u',4.25,6.05,False,None),('b',6.45,6.05,True,None)],[('a','u'),('u','b')],check=False)
for y in [4.6,3.5,2.4,1.3]:
    for x in [2.15,6.35]:
        K.graph([('a',x-.88,y,True,None),('u',x,y,False,None),('b',x+.88,y,True,None)],[('a','u'),('u','b')],size=.48,check=False,record=True)
K.start('Can you make a 5-cube circle on either board while every circle works? Show why it can or cannot be done.')
K.path(7.65,(0,3)); K.path(4.25,(1,4))
K.start('Fill the circles. Can any circle have a different number of cubes from its square?')
K.graph([('a',4.25,8.1,True,2),('u',2.9,6.3,False,None),('v',5.6,6.3,False,None)],[('a','u'),('a','v'),('u','v')])
K.graph([('a',2.95,4.1,True,3),('u',5.55,4.1,False,None),('v',5.55,1.9,False,None),('w',2.95,1.9,False,None)],[('a','u'),('u','v'),('v','w'),('w','a')])
K.start('Use 0 to 5 cubes in each circle. Find every way to make each board work.')
K.graph([('a',2.30,8.2,False,None),('u',1.25,6.6,False,None),('v',3.35,6.6,False,None)],[('a','u'),('a','v'),('u','v')],check=False)
for y in [8.05,6.95,5.85]:
    for x in [5.15,6.95]:
        K.graph([('a',x,y+.35,False,None),('u',x-.39,y-.25,False,None),('v',x+.39,y-.25,False,None)],[('a','u'),('a','v'),('u','v')],size=.42,check=False,record=True)
K.graph([(str(i),1.4+1.9*i,4.55,False,None) for i in range(4)],[(str(i),str(i+1)) for i in range(3)],check=False)
for y in [3.0,2.1,1.2]:
    for x in [.95,4.95]:
        K.graph([(str(i),x+.8*i,y,False,None) for i in range(4)],[(str(i),str(i+1)) for i in range(3)],size=.42,check=False,record=True)
K.finish()

rules='Add the numbers joined to a circle and divide by how many numbers you added. The answer must equal the circle\'s number. Squares keep their numbers. Every circle must work at the same time.'

def star(p,x,y,vals,r=.98):
    import math
    angles={2:[180,0],3:[90,210,330],4:[0,90,180,270]}[len(vals)]
    ns=[('u',x,y,False,None)]+[(str(i),x+r*math.cos(math.radians(a)),y+r*math.sin(math.radians(a)),True,v) for i,(a,v) in enumerate(zip(angles,vals))]
    p.graph(ns,[('u',str(i)) for i in range(len(vals))])

def tree(p,x,y,vals):
    # Leaves A and C meet u; u joins v; v joins B.
    p.graph([('a',x-1.6,y+.8,True,vals[0]),('c',x-1.6,y-.8,True,vals[1]),('u',x-.2,y,False,None),('v',x+1.1,y,False,None),('b',x+2.4,y,True,vals[2])],[('a','u'),('c','u'),('u','v'),('v','b')])

def diamond(p,x,y,a,b,tie=False):
    ns=[('a',x-2.3,y,True,a),('b',x+2.3,y,True,b),('u',x,y+1.,False,None),('v',x,y-1.,False,None)]
    es=[('a','u'),('a','v'),('b','u'),('b','v')]
    if tie: es+=[('u','v')]
    p.graph(ns,es)

M=Packet('grades-2-3','Grades 2--3','GA20-23-v1')
M.start('Fill the circles. Then change one square number on each board so that its circle number grows by 2.',rules)
star(M,2.25,6.6,[1,7],1.1);star(M,6.1,6.6,[0,3,9],1.13)
star(M,2.25,3.45,[2,8],1.1);star(M,6.1,3.45,[2,5,8],1.13)
M.start('Fill every circle so that all circles on a board work at once.')
M.path(8.25,(0,9));M.path(6.4,(2,11));M.path(4.55,(3,3));tree(M,3.65,2.25,(0,6,8))
M.start('Can you fill either board so that some circle is bigger than every square on its board? Make a filling that works, or explain why there is none.')
M.path(7.7,(1,9),3);diamond(M,4.25,4.0,2,8,True)
M.start('Fill all the circles. Can a circle match the biggest square on its board? Can a circle match the smallest square on its board?')
M.graph([('a',1.15,7.4,True,0),('u',2.7,7.4,False,None),('b',4.25,7.4,True,6),('v',5.8,7.4,False,None),('w',7.35,7.4,False,None)],[('a','u'),('u','b'),('b','v'),('v','w')])
M.graph([('v',1.15,4.0,False,None),('w',2.7,4.0,False,None),('a',4.25,4.0,True,0),('u',5.8,4.0,False,None),('b',7.35,4.0,True,6)],[('v','w'),('w','a'),('a','u'),('u','b')])
M.start('Fill each board. Can any board have a different filling with the same square numbers? Find one, or explain why it cannot.')
M.path(8.0,(3,12));tree(M,3.65,5.6,(1,7,9));diamond(M,4.25,2.4,4,10)
M.start('Use whole numbers from 0 to 5. Find every filling for each board, and explain how you know none are missing.')
M.graph([('a',2.85,8.05,False,None),('b',5.65,8.05,False,None),('c',5.65,5.95,False,None),('d',2.85,5.95,False,None)],[('a','b'),('b','c'),('c','d'),('d','a')],check=False)
M.graph([('a',1.4,3.25,False,None),('b',4.25,3.25,False,None),('c',7.1,3.25,False,None)],[('a','b'),('b','c')],check=False)
M.finish()

O=Packet('grades-4-5','Grades 4--5','GA20-45-v2')
O.start('Fill all the circles. Try to find a second filling for each board while keeping its square numbers.',rules)
O.path(7.25,(0,15),2);tree(O,3.65,5.2,(0,8,9));diamond(O,4.25,2.55,2,14,True)
O.start('Can either board have a circle number of 13 or more while all circles follow the rule? Find a filling, or explain why none can work.')
O.graph([('a',1.3,7.6,True,0),('u',2.85,7.6,False,None),('v',4.4,7.6,False,None),('b',5.95,7.6,True,6),('w',4.4,5.9,False,None),('z',6.25,5.9,False,None),('c',7.35,4.55,True,11)], [('a','u'),('u','v'),('v','b'),('v','w'),('w','z'),('z','v'),('z','c')])
diamond(O,4.25,2.65,2,10,True)
O.start('A board has finitely many shapes and lines. Every shape can reach a square along the lines. Explain why no circle number can be below the smallest square number it can reach or above the largest one. Your explanation must work for every such board.')
# A concrete branching example to work on, without encoding a proof path.
O.graph([('a',1.1,6.25,True,0),('u',2.6,6.25,False,None),('v',4.15,6.25,False,None),('w',5.7,6.25,False,None),('b',7.25,6.25,True,12),('c',4.15,4.65,True,6),('t',4.15,7.8,False,None)], [('a','u'),('u','v'),('v','w'),('w','b'),('v','c'),('u','t'),('t','w')])
O.start('Fill the circles. Which circles can equal the largest square number on their own board? Explain what makes the two boards different.')
O.graph([('a',1.15,7.6,True,0),('u',2.7,7.6,False,None),('b',4.25,7.6,True,8),('v',5.8,7.6,False,None),('w',7.35,7.6,False,None)],[('a','u'),('u','b'),('b','v'),('v','w')])
O.graph([('a',1.3,4.3,True,0),('u',3.25,4.3,False,None),('v',5.2,4.3,False,None),('b',7.15,4.3,True,12),('w',5.2,2.55,False,None)],[('a','u'),('u','v'),('v','b'),('v','w')])
O.start('Can the same board, with the same square numbers, have two different fillings that both follow the rule? Explain your answer for every finite board where each shape can reach a square.')
# Identical boards invite attempts without giving a comparison method.
for y in [7.1,3.5]:
    O.graph([('a',1.2,y,True,0),('u',2.7,y,False,None),('v',4.4,y+.75,False,None),('w',4.4,y-.75,False,None),('b',6.15,y+.75,True,16),('c',6.15,y-.75,True,8)], [('a','u'),('u','v'),('u','w'),('v','w'),('v','b'),('w','c')])
O.start('Use whole numbers from 0 to 4. Find every filling of the upper board and of the lower board. How many fillings does each board have? Explain why none are missing.')
O.graph([('a',4.25,8.0,False,None),('b',2.8,6.05,False,None),('c',5.7,6.05,False,None)],[('a','b'),('b','c'),('c','a')],check=False)
O.s.append(r'\draw[rounded corners=.18in,line width=.7pt,dashed] (.68,2.65) rectangle (7.82,4.35);')
O.graph([('a',1.2,3.5,False,None),('b',3.0,3.5,False,None),('c',5.5,3.5,False,None),('d',7.3,3.5,False,None)],[('a','b'),('c','d')],check=False)
O.start('Which boards can you fill with whole numbers? Fill the other boards using the fraction cards.')
O.path(8.15,(0,1),1);O.path(6.65,(0,3),2);O.path(5.15,(0,2),1);O.path(3.65,(0,1),2)
for x,n,d in [(2.15,1,2),(4.25,1,3),(6.35,2,3)]:
    O.s.append(r'\draw[line width=.65pt] ('+str(x-.78)+r',1.15) rectangle ('+str(x+.78)+',2.3);')
    for i in range(d):
        left=x-.6+1.2*i/d; right=x-.6+1.2*(i+1)/d
        O.s.append(r'\draw[fill='+('black!30' if i<n else 'white')+'] ('+str(left)+',1.82) rectangle ('+str(right)+',2.08);')
    O.s.append(r'\node[font=\fontsize{18}{22}\selectfont] at ('+str(x)+r',1.48) {$\frac{'+str(n)+'}{'+str(d)+'}$};')
O.finish()
(ROOT/'checked-values.txt').write_text('\n'.join(str(c) for c in checks)+'\n')
print('Generated',K.page,M.page,O.page,'pages.')
for c in checks: print(c)
