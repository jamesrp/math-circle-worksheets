# Week 35 Footprint borders editable source

## Card shoulds and coulds, October 23, 2026

The review card's deferred shoulds and clear coulds and the second card run's extra shoulds are made in the problem files, the guide source and the kit's checker; `review/card-fixes-2026-10-23.md` lists each change and `review/verify_card_fixes_2026_10_23.py [build-folder]` checks them in the built PDFs (default: this folder). The packets are W35-k-1-v4, W35-grades-2-3-v4 and W35-grades-4-5-v4; the guide's `build_guide.py` draws the five witnesses on page 4 from the same motif. The table kit did not change. Unpiloted.

Current pages: **K–1 5; Grades 2–3 4; Grades 4–5 5; adult guide 8; table kit 1**.

## Problem files, October 23, 2026

The student pages are now stored as problem files, one per problem, in `problem-files/` (in the repository: `lowell-math-circle-year-2/source/week-35/`): `week.toml`, `figures.py` (the old builder's drawing code, the glide demonstration and the page template) and `problems/*.md`, with each band's wording inside them. The conversion changed no wording or figure: the regenerated LaTeX matches the old `src/build_packets.py` byte for byte. `src/regenerate.py` writes the student LaTeX from the problem files, and `src/check_motif.py` keeps the old builder's motif check, which writes `src/mathematical-checks.json` for the kit. `problem-files/tools/build.py` also builds first-route and return packets, a one-page problem menu and a key arranged by problem. Edit student problems in `problem-files/problems/*.md` (figures and the page template in `problem-files/figures.py`); `src/build.sh` regenerates `src/*.tex` from them, so do not edit the TeX by hand. To build every view: `python3 problem-files/tools/build.py problem-files --out views`. The old builder is archived in the project.

## Table kit, October 23, 2026

`materials/build_materials.py` builds `materials.pdf` (reference copy in `reference-pdfs/`; print copy `week-35-materials.pdf`): one US Letter page to print on card stock at 100%, one sheet per table. Each half is a set of 24 footprint cards, 29 by 26 mm, for one pair or trio: 12 cards of A and 12 of A's mirror over a horizontal line, each with the notched F outline at 26 mm wide and its direction arrow. The outline comes from `src/mathematical-checks.json`, the student pages' motif (written by `src/check_motif.py`). Turning a card gives the other two forms. The page has a 10 cm scale check and a per-table print count. `materials/verify_materials.py` measures every card and reads each outline back vertex by vertex, and checks that the guide's witness borders (six, and since the card fixes also G at 4 and 8 cm) fit the cards; `build.py` runs both. The guide's page 2 now names the kit, says recipe positions are card centres, and counts cutting time; no other guide page and no student page changed. A clean rebuild from the extracted ZIP reproduces the guide and the kit with exact 100-dpi pixels; with TeX Live 2023 the unchanged student packets rebuild with identical text and drawings but small font-rendering pixel differences outside the audited allowances, and their print and reference copies are unchanged. The previous guide and ZIP are archived in the project. The kit is physically unrehearsed.

Current pages: **K–1 5; Grades 2–3 4; Grades 4–5 4; adult guide 7; table kit 1**.

## Introduction-audit follow-up

Grades 2–3 and 4–5 are v3: the glide visual appears on page 2 immediately before the first glide task. Both 6 cm working strips remain. K–1 stays v2. The guide packet identifiers are synchronized. Poppler is optional for preview images; the PDF build does not require it. All revisions remain unpiloted; material handling has not been rehearsed. Older release descriptions below are historical.

## Current release: October 4, 2026 fresh-review revision

The guide now gives first routes, readiness-dependent continuation and return visits; original mathematical investigations are retained. K–1 adds one-border slide matching before the six retained tasks. The original glide convention precedes first glide use. Existing working-strip dimensions and older packets remain.

This is an unpiloted theme library, not a fixed meeting schedule. Select a manageable first route in the guide and return for further investigations. Preserve the full Grades 4–5 material. Prerequisites, launch, materials, hints and theorem-first mathematical overview are in the separate adult guide. Physical fit, demonstrations and classroom timing have not been tested.

Current pages: **K–1 5; Grades 2–3 4; Grades 4–5 4; adult guide 7**. Print selected student pages single-sided on US Letter at Actual Size / 100%.

## Rebuild outside the project

Extract the complete ZIP. Install Python 3 with `requirements.txt`, a normal TeX Live distribution providing pdfLaTeX/TikZ/Helvetica, and Poppler's `pdftoppm` where used by the existing checks. Matching guide fonts and licenses are included; the root build selects package-local fonts in earlier packages. No project checkout or original workspace path is needed.

    python3 -m pip install -r requirements.txt
    python3 build.py
    python3 verify_revision.py

The current verifier compares paper geometry and every 100-dpi rendered page against `reference-pdfs/`; timestamps may differ. It permits only specifically audited full-page font/hyphenation alternatives for unchanged student PDFs. See `review/fresh-review-rebuild.md` for actual results. The original strict verifier (`verify_rebuild.py` or `verify.py`) is retained and rejects those alternatives. The corpus report explicitly records any pre-existing small TeX font-metric differences for unchanged student bands; their current print/reference PDFs stay byte-identical. For Weeks 24 and 35, the detailed student-stage record is `review/student-reviser-fresh-review.md`. The corpus release report records those differences explicitly rather than calling them pixel-identical.

Edit student problems in `problem-files/problems/*.md` (see "Problem files" above); `src/*.tex` is generated from them. Edit the existing guide source under `facilitator-src/`. Where present, `facilitator-src/route-note.json` holds the concise starting/return update; the root build regenerates the guide before appending it exactly once. Do not run the appender alone against an already appended guide. Build intermediates belong in a separate working copy; inspect changed pages before updating references.

The current reference manifest is `review/reference-manifest.json`; revision evidence is `review/fresh-review-2026-10-04.md`. Older review files and `review/README-before-fresh-review-2026-10-04.md` describe their dated versions. Prior releases are archived outside the current package in the project.

## Use and rights

Original worksheet prose, diagrams and builders are provided for the organizer's use and adaptation. Preserve source attribution. Third-party books and articles retain their rights and are not redistributed here. Included fonts retain their licenses. No broader third-party license is implied. Routine adult reading or recording is allowed; children should retain the mathematical choices.
