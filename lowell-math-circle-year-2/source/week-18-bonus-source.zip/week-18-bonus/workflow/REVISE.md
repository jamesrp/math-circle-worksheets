Task-specific encore scope (user instruction overrides the generic three-band output paths below):
For Week 18, produce ONE shared selected-band bonus companion, with at least three genuinely distinct investigations matching the outline. Output draft/bonus.pdf, sources draft/src/; reviser outputs final/bonus.pdf, sources final/src/. Ignore references below to three mandatory band PDFs. Select honest grade/readiness coverage; the adult guide will supply the route. Student header: Week 18 / <topic> encore / Grades <appropriate range>. Footer: Bellingham Math Circle / Week 18 / W18-BON-v1. Consecutive Problem N labels. A problem's requested action must be explicit. Printed suitable bands may be stated compactly in problem text if distinct from the overall coverage. Do not force young versions. No base packet, guide, global index or workflow-template edits. No uploads or publication. Material remains unpiloted. Your ONLY stage is the stage named in this file.
Build using /Library/TeX/texbin/pdflatex (portable scripts should find pdflatex on PATH or documented PDFLATEX override). Python with PyMuPDF/ReportLab/Pillow is /Users/jamespfeiffer/math-circle/tmp/encore-18-34-venv/bin/python. Render helper /Users/jamespfeiffer/math-circle/tmp/encore-18-34/tools/render.py supports --out and contact sheets. Portable sources must build without absolute project paths. No physical fit or rehearsal claim is permitted.
Writer: Choose actual investigations yourself, check they differ from base exclusions. Include all student working diagrams and light records. Prefer 3-5 pages per week, enough space over arbitrary compactness; no automatic page target. Record complete draft answers and assumptions separately at draft/answer-notes.md to support the adult guide, not on student pages. Keep PDF/source build and writer notes inside the run.
Critic: review draft/bonus.pdf and write review.md only. Math critic: independently verify every task and represented example in draft/bonus.pdf, write review-math.md plus executable independent-check.py and checks.json in the run; do not edit writer content. Reviser: copy draft/src into final/src, address both reviews, build final/bonus.pdf, render/inspect EVERY final page, and write final/revision-notes.md and final/answer-notes.md with corrected answers and assumptions. Do not write adult guide.

You are revising a worksheet packet for an elementary math circle.

Files in your run folder /Users/jamespfeiffer/math-circle/tmp/worksheet-runs/week-18-bonus-v1:
- PROMPT.md: the instructions the packet's author was given (activity outline, session context, the organizer's standard for student pages, and technical notes). Read it first.
- draft/k-1.pdf, draft/grades-2-3.pdf, draft/grades-4-5.pdf: the author's draft.
- draft/src/: the sources that build the draft.
- review.md: a reviewer's review of the draft. If review-math.md exists, it is a second review focused on correctness.

You are the revision stage of the worksheet workflow: do the revision yourself and do not start the workflow again.

Revise the packet to address the review. Copy draft/src/ to final/src/, edit the copy, and build the three PDFs at exactly these paths:

  /Users/jamespfeiffer/math-circle/tmp/worksheet-runs/week-18-bonus-v1/final/k-1.pdf
  /Users/jamespfeiffer/math-circle/tmp/worksheet-runs/week-18-bonus-v1/final/grades-2-3.pdf
  /Users/jamespfeiffer/math-circle/tmp/worksheet-runs/week-18-bonus-v1/final/grades-4-5.pdf

Before you finish, render every page of the rebuilt PDFs to images and look at each one to check that the diagrams are correct and nothing overflows or overlaps. Reply with the three PDF paths and their page counts, in under 80 words.
