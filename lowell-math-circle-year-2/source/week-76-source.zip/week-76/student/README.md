# Week 76: Substitution strips

One shared four-page Grades 3–5 student prototype. Packet ID: F76-35-v2.

## Prerequisites and materials

Children need to read short A/B strings, preserve left-to-right order and work with a partner. The late questions ask for impossibility explanations; the infinite-tail question needs readiness for abstract reasoning and may need an adult. Grade labels are approximate. There is no K–1 or separate Grades 2–3 edition.

For each pair, provide a kit of 36 letter tiles (18 A, 18 B) cut from week-76-materials.pdf, or two-colour counters lettered A and B on their two faces, and two separate table rows, plus four divider markers and pencils. Distinguish tiles by letters as well as any color. Separately handled counters should be at least 15 mm wide. The printed 7–10 mm cells are pencil diagrams, not counter-fitting mats. Long physical strips extend onto the table. Reuse the older row's counters only after the new row has been checked. Children do no cutting, and no exact-fit pieces are required.

## Build

Requires Python 3.11+ (standard library only) and a normal TeX Live installation with pdfLaTeX, TikZ/PGF, geometry, fancyhdr and Latin Modern fonts.

From this directory:

    python3 check_math.py
    python3 build.py --out /path/to/output

The source is the problem files (`../problem-files/` in the portable ZIP, `lowell-math-circle-year-2/source/week-76/` in the repository); `build.py` first runs `regenerate.py`, which writes `students.tex` from them. Edit the problem files, not `students.tex`. The builder creates students.pdf in the requested directory, checks the finite examples and rejects overfull TeX boxes. It creates and removes temporary build files inside the output directory. On failure it leaves build-error.log. The source folder is portable and contains no external images, borrowed text, workflow prompts or downloaded resources.

## Checks and limits

check_math.py verifies every fixed diagram string, whole-row histories, crop examples (including a lone tile at each end) and both genuinely possible alignments of the short ambiguous crop. Its exact factor-language computation checks all three- and five-letter factors and the two finite witnesses against the repeating strips. Passing these checks is not a proof of infinite nonperiodicity.

Print single-sided on US Letter at 100%. The four pages were compiled, rendered and visually checked at 130 dpi, with no overlaps or clipping found. The resulting PDF is under 100 KB. Physical handling, timing, adult support needs and classroom use remain untested. The abstract final question is an optional stopping point by readiness, not an expectation that every child complete an infinite proof.
