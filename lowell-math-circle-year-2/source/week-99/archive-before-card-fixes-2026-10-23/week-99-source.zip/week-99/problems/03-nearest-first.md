+++
id = "w99.nearest-first"
title = "Does the shortest delivery first always work?"
grades = ["2-3", "4-5"]
route = "first"
page = "new"
kernel = "Making the shortest delivery first can fail: 0, 3 to 2, 5 costs 6 that way and 4 by matching in order."
+++

## text
\portraitpage
\promptstyle{10.0}{7.2in}{12.8}{15.87}

## prompt [2-3]
A delivery takes one counter that has not yet been delivered all the way to one target place that has not yet been filled. Once delivered, that counter stays there. Try this rule: always make the shortest remaining delivery. If deliveries tie, choose either. For each pair, can another plan use less work?

## prompt [4-5]
A delivery takes one counter that has not yet been delivered all the way to one target place that has not yet been filled. Once delivered, that counter stays there. A rule says to make the shortest remaining delivery each time. Test this rule on both pairs. Does it always give the least work? Can tied choices change the result?

## text [2-3]
\node[anchor=north west,inner sep=0pt,align=left,text width=0.8in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (0.65,8.06) {start};
\draw[black!45,line width=.45pt,] (1.96,7.94) -- (2.24,7.94);
\draw[black!45,line width=.45pt,] (3.0600000000000005,7.94) -- (3.34,7.94);
\draw[black!45,line width=.45pt,] (4.16,7.94) -- (4.44,7.94);
\draw[black!45,line width=.45pt,] (5.260000000000001,7.94) -- (5.54,7.94);
\draw[black!45,line width=.45pt,] (6.36,7.94) -- (6.64,7.94);
\draw[line width=.65pt,rounded corners=3pt] (1.1400000000000001,7.655) rectangle (1.96,8.225);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (1.3900000000000001,7.585) {0};
\draw[line width=.7pt,fill=black!80] (1.55,7.94) circle (0.065);
\draw[line width=.65pt,rounded corners=3pt] (2.24,7.655) rectangle (3.0600000000000005,8.225);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (2.49,7.585) {1};
\draw[line width=.65pt,rounded corners=3pt] (3.34,7.655) rectangle (4.16,8.225);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (3.59,7.585) {2};
\draw[line width=.65pt,rounded corners=3pt] (4.44,7.655) rectangle (5.260000000000001,8.225);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (4.69,7.585) {3};
\draw[line width=.7pt,fill=black!80] (4.8500000000000005,7.94) circle (0.065);
\draw[line width=.65pt,rounded corners=3pt] (5.54,7.655) rectangle (6.36,8.225);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (5.79,7.585) {4};
\draw[line width=.65pt,rounded corners=3pt] (6.64,7.655) rectangle (7.46,8.225);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (6.89,7.585) {5};
\node[anchor=north west,inner sep=0pt,align=left,text width=0.8in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (0.65,7.130000000000001) {target\\picture};
\draw[black!45,line width=.45pt,] (1.96,7.010000000000001) -- (2.24,7.010000000000001);
\draw[black!45,line width=.45pt,] (3.0600000000000005,7.010000000000001) -- (3.34,7.010000000000001);
\draw[black!45,line width=.45pt,] (4.16,7.010000000000001) -- (4.44,7.010000000000001);
\draw[black!45,line width=.45pt,] (5.260000000000001,7.010000000000001) -- (5.54,7.010000000000001);
\draw[black!45,line width=.45pt,] (6.36,7.010000000000001) -- (6.64,7.010000000000001);
\draw[line width=.65pt,rounded corners=3pt] (1.1400000000000001,6.7250000000000005) rectangle (1.96,7.295000000000001);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (1.3900000000000001,6.655) {0};
\draw[line width=.65pt,rounded corners=3pt] (2.24,6.7250000000000005) rectangle (3.0600000000000005,7.295000000000001);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (2.49,6.655) {1};
\draw[line width=.65pt,rounded corners=3pt] (3.34,6.7250000000000005) rectangle (4.16,7.295000000000001);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (3.59,6.655) {2};
\draw[line width=.7pt,fill=white] (3.75,7.010000000000001) circle (0.065);
\draw[line width=.65pt,rounded corners=3pt] (4.44,6.7250000000000005) rectangle (5.260000000000001,7.295000000000001);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (4.69,6.655) {3};
\draw[line width=.65pt,rounded corners=3pt] (5.54,6.7250000000000005) rectangle (6.36,7.295000000000001);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (5.79,6.655) {4};
\draw[line width=.65pt,rounded corners=3pt] (6.64,6.7250000000000005) rectangle (7.46,7.295000000000001);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (6.89,6.655) {5};
\draw[line width=.7pt,fill=white] (7.05,7.010000000000001) circle (0.065);
\draw[black!35,line width=.45pt,] (0.75,6.34) -- (7.65,6.34);
\draw[black!35,line width=.45pt,] (0.75,5.95) -- (7.65,5.95);
\node[anchor=north west,inner sep=0pt,align=left,text width=0.8in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (0.65,4.82) {start};
\draw[black!45,line width=.45pt,] (1.96,4.7) -- (2.24,4.7);
\draw[black!45,line width=.45pt,] (3.0600000000000005,4.7) -- (3.34,4.7);
\draw[black!45,line width=.45pt,] (4.16,4.7) -- (4.44,4.7);
\draw[black!45,line width=.45pt,] (5.260000000000001,4.7) -- (5.54,4.7);
\draw[black!45,line width=.45pt,] (6.36,4.7) -- (6.64,4.7);
\draw[line width=.65pt,rounded corners=3pt] (1.1400000000000001,4.415) rectangle (1.96,4.985);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (1.3900000000000001,4.345) {0};
\draw[line width=.7pt,fill=black!80] (1.55,4.7) circle (0.065);
\draw[line width=.65pt,rounded corners=3pt] (2.24,4.415) rectangle (3.0600000000000005,4.985);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (2.49,4.345) {1};
\draw[line width=.65pt,rounded corners=3pt] (3.34,4.415) rectangle (4.16,4.985);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (3.59,4.345) {2};
\draw[line width=.65pt,rounded corners=3pt] (4.44,4.415) rectangle (5.260000000000001,4.985);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (4.69,4.345) {3};
\draw[line width=.65pt,rounded corners=3pt] (5.54,4.415) rectangle (6.36,4.985);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (5.79,4.345) {4};
\draw[line width=.7pt,fill=black!80] (5.95,4.7) circle (0.065);
\draw[line width=.65pt,rounded corners=3pt] (6.64,4.415) rectangle (7.46,4.985);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (6.89,4.345) {5};
\node[anchor=north west,inner sep=0pt,align=left,text width=0.8in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (0.65,3.89) {target\\picture};
\draw[black!45,line width=.45pt,] (1.96,3.77) -- (2.24,3.77);
\draw[black!45,line width=.45pt,] (3.0600000000000005,3.77) -- (3.34,3.77);
\draw[black!45,line width=.45pt,] (4.16,3.77) -- (4.44,3.77);
\draw[black!45,line width=.45pt,] (5.260000000000001,3.77) -- (5.54,3.77);
\draw[black!45,line width=.45pt,] (6.36,3.77) -- (6.64,3.77);
\draw[line width=.65pt,rounded corners=3pt] (1.1400000000000001,3.485) rectangle (1.96,4.055);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (1.3900000000000001,3.415) {0};
\draw[line width=.65pt,rounded corners=3pt] (2.24,3.485) rectangle (3.0600000000000005,4.055);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (2.49,3.415) {1};
\draw[line width=.65pt,rounded corners=3pt] (3.34,3.485) rectangle (4.16,4.055);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (3.59,3.415) {2};
\draw[line width=.7pt,fill=white] (3.75,3.77) circle (0.065);
\draw[line width=.65pt,rounded corners=3pt] (4.44,3.485) rectangle (5.260000000000001,4.055);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (4.69,3.415) {3};
\draw[line width=.65pt,rounded corners=3pt] (5.54,3.485) rectangle (6.36,4.055);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (5.79,3.415) {4};
\draw[line width=.65pt,rounded corners=3pt] (6.64,3.485) rectangle (7.46,4.055);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (6.89,3.415) {5};
\draw[line width=.7pt,fill=white] (7.05,3.77) circle (0.065);
\draw[black!35,line width=.45pt,] (0.75,3.1) -- (7.65,3.1);
\draw[black!35,line width=.45pt,] (0.75,2.71) -- (7.65,2.71);
\draw[black!35,line width=.45pt,] (0.75,1.98) -- (7.65,1.98);
\draw[black!35,line width=.45pt,] (0.75,1.46) -- (7.65,1.46);

## text [4-5]
\node[anchor=north west,inner sep=0pt,align=left,text width=0.8in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (0.65,8.06) {start};
\draw[black!45,line width=.45pt,] (1.96,7.94) -- (2.24,7.94);
\draw[black!45,line width=.45pt,] (3.0600000000000005,7.94) -- (3.34,7.94);
\draw[black!45,line width=.45pt,] (4.16,7.94) -- (4.44,7.94);
\draw[black!45,line width=.45pt,] (5.260000000000001,7.94) -- (5.54,7.94);
\draw[black!45,line width=.45pt,] (6.36,7.94) -- (6.64,7.94);
\draw[line width=.65pt,rounded corners=3pt] (1.1400000000000001,7.655) rectangle (1.96,8.225);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (1.3900000000000001,7.585) {0};
\draw[line width=.7pt,fill=black!80] (1.55,7.94) circle (0.065);
\draw[line width=.65pt,rounded corners=3pt] (2.24,7.655) rectangle (3.0600000000000005,8.225);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (2.49,7.585) {1};
\draw[line width=.65pt,rounded corners=3pt] (3.34,7.655) rectangle (4.16,8.225);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (3.59,7.585) {2};
\draw[line width=.65pt,rounded corners=3pt] (4.44,7.655) rectangle (5.260000000000001,8.225);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (4.69,7.585) {3};
\draw[line width=.7pt,fill=black!80] (4.8500000000000005,7.94) circle (0.065);
\draw[line width=.65pt,rounded corners=3pt] (5.54,7.655) rectangle (6.36,8.225);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (5.79,7.585) {4};
\draw[line width=.65pt,rounded corners=3pt] (6.64,7.655) rectangle (7.46,8.225);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (6.89,7.585) {5};
\node[anchor=north west,inner sep=0pt,align=left,text width=0.8in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (0.65,7.130000000000001) {target\\picture};
\draw[black!45,line width=.45pt,] (1.96,7.010000000000001) -- (2.24,7.010000000000001);
\draw[black!45,line width=.45pt,] (3.0600000000000005,7.010000000000001) -- (3.34,7.010000000000001);
\draw[black!45,line width=.45pt,] (4.16,7.010000000000001) -- (4.44,7.010000000000001);
\draw[black!45,line width=.45pt,] (5.260000000000001,7.010000000000001) -- (5.54,7.010000000000001);
\draw[black!45,line width=.45pt,] (6.36,7.010000000000001) -- (6.64,7.010000000000001);
\draw[line width=.65pt,rounded corners=3pt] (1.1400000000000001,6.7250000000000005) rectangle (1.96,7.295000000000001);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (1.3900000000000001,6.655) {0};
\draw[line width=.65pt,rounded corners=3pt] (2.24,6.7250000000000005) rectangle (3.0600000000000005,7.295000000000001);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (2.49,6.655) {1};
\draw[line width=.65pt,rounded corners=3pt] (3.34,6.7250000000000005) rectangle (4.16,7.295000000000001);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (3.59,6.655) {2};
\draw[line width=.7pt,fill=white] (3.75,7.010000000000001) circle (0.065);
\draw[line width=.65pt,rounded corners=3pt] (4.44,6.7250000000000005) rectangle (5.260000000000001,7.295000000000001);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (4.69,6.655) {3};
\draw[line width=.65pt,rounded corners=3pt] (5.54,6.7250000000000005) rectangle (6.36,7.295000000000001);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (5.79,6.655) {4};
\draw[line width=.65pt,rounded corners=3pt] (6.64,6.7250000000000005) rectangle (7.46,7.295000000000001);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (6.89,6.655) {5};
\draw[line width=.7pt,fill=white] (7.05,7.010000000000001) circle (0.065);
\draw[black!35,line width=.45pt,] (0.75,6.34) -- (7.65,6.34);
\draw[black!35,line width=.45pt,] (0.75,5.95) -- (7.65,5.95);
\node[anchor=north west,inner sep=0pt,align=left,text width=0.8in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (0.65,4.82) {start};
\draw[black!45,line width=.45pt,] (1.96,4.7) -- (2.24,4.7);
\draw[black!45,line width=.45pt,] (3.0600000000000005,4.7) -- (3.34,4.7);
\draw[black!45,line width=.45pt,] (4.16,4.7) -- (4.44,4.7);
\draw[black!45,line width=.45pt,] (5.260000000000001,4.7) -- (5.54,4.7);
\draw[black!45,line width=.45pt,] (6.36,4.7) -- (6.64,4.7);
\draw[line width=.65pt,rounded corners=3pt] (1.1400000000000001,4.415) rectangle (1.96,4.985);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (1.3900000000000001,4.345) {0};
\draw[line width=.7pt,fill=black!80] (1.55,4.7) circle (0.065);
\draw[line width=.65pt,rounded corners=3pt] (2.24,4.415) rectangle (3.0600000000000005,4.985);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (2.49,4.345) {1};
\draw[line width=.65pt,rounded corners=3pt] (3.34,4.415) rectangle (4.16,4.985);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (3.59,4.345) {2};
\draw[line width=.65pt,rounded corners=3pt] (4.44,4.415) rectangle (5.260000000000001,4.985);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (4.69,4.345) {3};
\draw[line width=.65pt,rounded corners=3pt] (5.54,4.415) rectangle (6.36,4.985);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (5.79,4.345) {4};
\draw[line width=.7pt,fill=black!80] (5.95,4.7) circle (0.065);
\draw[line width=.65pt,rounded corners=3pt] (6.64,4.415) rectangle (7.46,4.985);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (6.89,4.345) {5};
\node[anchor=north west,inner sep=0pt,align=left,text width=0.8in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (0.65,3.89) {target\\picture};
\draw[black!45,line width=.45pt,] (1.96,3.77) -- (2.24,3.77);
\draw[black!45,line width=.45pt,] (3.0600000000000005,3.77) -- (3.34,3.77);
\draw[black!45,line width=.45pt,] (4.16,3.77) -- (4.44,3.77);
\draw[black!45,line width=.45pt,] (5.260000000000001,3.77) -- (5.54,3.77);
\draw[black!45,line width=.45pt,] (6.36,3.77) -- (6.64,3.77);
\draw[line width=.65pt,rounded corners=3pt] (1.1400000000000001,3.485) rectangle (1.96,4.055);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (1.3900000000000001,3.415) {0};
\draw[line width=.65pt,rounded corners=3pt] (2.24,3.485) rectangle (3.0600000000000005,4.055);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (2.49,3.415) {1};
\draw[line width=.65pt,rounded corners=3pt] (3.34,3.485) rectangle (4.16,4.055);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (3.59,3.415) {2};
\draw[line width=.65pt,rounded corners=3pt] (4.44,3.485) rectangle (5.260000000000001,4.055);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (4.69,3.415) {3};
\draw[line width=.7pt,fill=white] (4.8500000000000005,3.77) circle (0.065);
\draw[line width=.65pt,rounded corners=3pt] (5.54,3.485) rectangle (6.36,4.055);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (5.79,3.415) {4};
\draw[line width=.65pt,rounded corners=3pt] (6.64,3.485) rectangle (7.46,4.055);
\node[anchor=north west,inner sep=0pt,align=center,text width=0.32in,font=\sffamily\fontsize{10}{12.4}\selectfont] at (6.89,3.415) {5};
\draw[line width=.7pt,fill=white] (7.05,3.77) circle (0.065);
\draw[black!35,line width=.45pt,] (0.75,3.1) -- (7.65,3.1);
\draw[black!35,line width=.45pt,] (0.75,2.71) -- (7.65,2.71);
\draw[black!35,line width=.45pt,] (0.75,1.98) -- (7.65,1.98);
\draw[black!35,line width=.45pt,] (0.75,1.46) -- (7.65,1.46);
