#!/usr/bin/env python3
"""Verification for the square-grid problems of the Week 1 tiling bank.

Counts exact tilings of small square-grid regions by dominoes, L-trominoes and
straight trominoes, and checks the coloring facts quoted in bank.md.
Run:  python3 verify_square.py
"""
from functools import lru_cache

# ---------- pieces (as lists of (r,c) offsets, all rotations/reflections) ----------
DOMINO = [((0, 0), (0, 1)), ((0, 0), (1, 0))]
L_TROM = [((0, 0), (1, 0), (0, 1)), ((0, 0), (0, 1), (1, 1)),
          ((0, 0), (1, 0), (1, 1)), ((0, 1), (1, 0), (1, 1))]
I_TROM = [((0, 0), (0, 1), (0, 2)), ((0, 0), (1, 0), (2, 0))]


def rect(m, n):
    return frozenset((r, c) for r in range(m) for c in range(n))


def count_tilings(cells, pieces):
    """Number of ways to tile the region `cells` exactly with copies of `pieces`."""
    cells = frozenset(cells)

    @lru_cache(maxsize=None)
    def go(rem):
        if not rem:
            return 1
        cell = min(rem)              # first uncovered cell (row-major)
        total = 0
        for shape in pieces:
            for anchor in shape:     # which square of the piece sits on `cell`
                placed = frozenset((cell[0] + dr - anchor[0], cell[1] + dc - anchor[1]) for dr, dc in shape)
                if placed <= rem:
                    total += go(rem - placed)
        return total
    return go(cells)


def tileable(cells, pieces):
    return count_tilings(cells, pieces) > 0


def color(cell):
    return (cell[0] + cell[1]) % 2      # 0 = dark, 1 = light


def report(name, value):
    print(f"{name}: {value}")


if __name__ == "__main__":
    print("== dominoes: rectangles ==")
    for n in range(1, 8):
        report(f"2x{n}", count_tilings(rect(2, n), DOMINO))
    for m, n in [(3, 2), (3, 3), (3, 4), (3, 6), (4, 4), (4, 5), (5, 5), (6, 6)]:
        report(f"{m}x{n}", count_tilings(rect(m, n), DOMINO))

    print("\n== dominoes: 3x3 minus one cell (1-indexed rows, cols) ==")
    for r in range(3):
        row = []
        for c in range(3):
            row.append(count_tilings(rect(3, 3) - {(r, c)}, DOMINO))
        print("  ", row)
    print("  dark cells (r+c even) of 3x3:", sum(1 for x in rect(3, 3) if color(x) == 0), "light:", sum(1 for x in rect(3, 3) if color(x) == 1))

    print("\n== dominoes: 5x5 minus one cell ==")
    for r in range(5):
        row = []
        for c in range(5):
            row.append(count_tilings(rect(5, 5) - {(r, c)}, DOMINO))
        print("  ", row)

    print("\n== dominoes: 4x4 minus two cells: tileable iff colors differ? ==")
    ok = True
    cnt = {True: 0, False: 0}
    for a in sorted(rect(4, 4)):
        for b in sorted(rect(4, 4)):
            if a < b:
                t = tileable(rect(4, 4) - {a, b}, DOMINO)
                cnt[t] += 1
                if t != (color(a) != color(b)):
                    ok = False
                    print("  exception:", a, b, t)
    report("  rule holds for all 120 pairs", ok)
    report("  tileable pairs / untileable pairs", (cnt[True], cnt[False]))
    report("  4x4 minus opposite corners (0,0),(3,3)", count_tilings(rect(4, 4) - {(0, 0), (3, 3)}, DOMINO))
    report("  4x4 minus adjacent corners (0,0),(0,3)", count_tilings(rect(4, 4) - {(0, 0), (0, 3)}, DOMINO))
    report("  4x4 minus (0,0),(1,1)", count_tilings(rect(4, 4) - {(0, 0), (1, 1)}, DOMINO))
    report("  4x4 minus (0,0),(0,1)", count_tilings(rect(4, 4) - {(0, 0), (0, 1)}, DOMINO))
    report("  4x4 minus (0,0),(2,3)", count_tilings(rect(4, 4) - {(0, 0), (2, 3)}, DOMINO))
    report("  4x4 minus (1,1),(2,2)", count_tilings(rect(4, 4) - {(1, 1), (2, 2)}, DOMINO))
    report("  4x4 minus (1,1),(1,2)", count_tilings(rect(4, 4) - {(1, 1), (1, 2)}, DOMINO))

    print("\n== dominoes: 6x6 minus two cells (rule check) ==")
    ok = True
    for a in sorted(rect(6, 6)):
        for b in sorted(rect(6, 6)):
            if a < b and tileable(rect(6, 6) - {a, b}, DOMINO) != (color(a) != color(b)):
                ok = False
    report("  6x6: tileable iff colors differ, all pairs", ok)
    report("  8x8 minus opposite corners", count_tilings(rect(8, 8) - {(0, 0), (7, 7)}, DOMINO))

    print("\n== dominoes: balanced but untileable shapes (8 cells each) ==")
    I_shape = {(0, 0), (0, 1), (0, 2), (1, 1), (2, 1), (3, 0), (3, 1), (3, 2)}   # bar, stem of 2, bar
    C_shape = {(0, 0), (0, 1), (0, 2), (1, 0), (2, 0), (3, 0), (3, 1), (3, 2)}   # bar, side of 2, bar
    H_shape = {(0, 0), (1, 0), (2, 0), (1, 1), (0, 2), (1, 2), (2, 2), (3, 1)}   # not used, sanity
    for name, s in [("I-shape (bar-stem-bar)", I_shape), ("C-shape (bar-side-bar)", C_shape)]:
        d = sum(1 for x in s if color(x) == 0)
        report(f"  {name}: dark {d}, light {len(s)-d}, tilings", count_tilings(frozenset(s), DOMINO))
    T_hex = {(0, 0), (0, 1), (0, 2), (1, 1), (2, 1), (3, 1)}     # T bar of 3, stem of 3
    d = sum(1 for x in T_hex if color(x) == 0)
    report(f"  T-hexomino: dark {d}, light {len(T_hex)-d}, tilings", count_tilings(frozenset(T_hex), DOMINO))
    plus = {(1, 0), (1, 1), (1, 2), (0, 1), (2, 1)}
    report("  plus pentomino (5 cells)", count_tilings(frozenset(plus), DOMINO))

    print("\n== L-trominoes: rectangles ==")
    for m, n in [(2, 3), (3, 2), (3, 3), (2, 6), (3, 4), (3, 5), (3, 6), (4, 6), (5, 6), (6, 6), (5, 9)]:
        report(f"{m}x{n}", count_tilings(rect(m, n), L_TROM))

    print("\n== L-trominoes: 2^n x 2^n minus one cell ==")
    report("2x2 minus corner", count_tilings(rect(2, 2) - {(0, 0)}, L_TROM))
    for r in range(4):
        print("  4x4 minus cell, row", r, [count_tilings(rect(4, 4) - {(r, c)}, L_TROM) for c in range(4)])
    report("8x8 minus corner: tileable", tileable(rect(8, 8) - {(0, 0)}, L_TROM))
    report("8x8 minus (3,3): tileable", tileable(rect(8, 8) - {(3, 3)}, L_TROM))

    print("\n== L-trominoes: 3x3, 5x5, 7x7 minus one cell ==")
    for n in (3, 5, 7):
        print(f"  {n}x{n}:")
        for r in range(n):
            print("   ", [count_tilings(rect(n, n) - {(r, c)}, L_TROM) for c in range(n)])

    print("\n== straight trominoes ==")
    for n in range(1, 8):
        report(f"3x{n}", count_tilings(rect(3, n), I_TROM))
    for r in range(4):
        print("  4x4 minus cell, row", r, [count_tilings(rect(4, 4) - {(r, c)}, I_TROM) for c in range(4)])
    for r in range(5):
        print("  5x5 minus cell, row", r, [count_tilings(rect(5, 5) - {(r, c)}, I_TROM) for c in range(5)])
    # 3-colouring counts used in the argument
    for n in (4, 5):
        cnt = [0, 0, 0]
        for (r, c) in rect(n, n):
            cnt[(r + c) % 3] += 1
        report(f"  {n}x{n} diagonal 3-colouring counts (r+c mod 3)", cnt)

    print("\n== L-trominoes and dominoes together (mixed) on 3x3, 5x5 ==")
    report("3x3 by dominoes+L (need one L and three dominoes)", count_tilings(rect(3, 3), DOMINO + L_TROM))
