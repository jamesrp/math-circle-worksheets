You are the copy editor for a finished K–5 math-circle packet in `/home/claude/genlab/runs/T/W06/s1`: `week-k-1.tex`, `week-grades-2-3.tex`, `week-grades-4-5.tex`, `week-facilitator.tex`, with compiled PDFs. First copy the four `.tex` files into `/home/claude/genlab/runs/T/W06/s1/before-copyedit/`.

The pages must follow the page and register rules in this guidance:

## What a student page is

A student page is a tool for doing, not a text to read. It contains only the running header (week, topic, level), the footer, and numbered problems written as `Problem N: ...` in ordinary sentences, plus the diagrams, grids, boards and recording space the child actually needs. Everything else lives in the facilitator guide.

Each problem tells the child exactly what to do with the materials and where to record it: what to build, place, move, cut, count, draw, compare, or write, and in which board or blank. The rules of the activity are stated inside the problem text, briefly, the first time they are needed. A child, or an adult reading aloud, should never have to guess the task from a title, a hint of a theme, or a label.

Write in plain, short, direct sentences with concrete nouns and numbers ("Use only blue rhombi. Fill boards A to D. Mark each board you could not fill."). Mention characters or a small story only when the problem needs something to talk about; the child's interest comes from the puzzle and the materials.

## Do not put these on student pages

Page titles or teaser questions above the problems; section headings, labels or boxes such as "Warm-up", "Challenge", "Go further", "Bonus", "Rules", "Think about it", "Fun fact"; Name/Date lines; sentences of encouragement or praise; exclamation marks; emoji or clip-art; instructions addressed to the adult; explanations of the mathematics or the answer; a "reflection" question that could be answered without having done the problem.

## Enough work, concrete work

A table has about forty minutes of working time and must not run out of things to do. Give each idea several purposeful, contrasting instances — boards that can and cannot be filled, starts that end differently, sizes 2, 3, 4, 5 — with a separate diagram or blank for each, rather than one example followed by a question. Each new instance should reveal a distinction or extend a pattern, not repeat a procedure. Plan for the fast table: the last problems on each level should still be real problems, and the facilitator guide should say what to offer next.

Order every sequence as act → record → compare → explain. The child does something with the materials, records what happened in a space made for it, looks at several results side by side, and only then is asked why. Put "How do you know for sure?" style follow-ups in the facilitator guide when they would interrupt the printed task. Introduce a new representation (a table, a code, a coloring, a map of states) only after the child has met the question it answers, and give that representation its own concrete problems.

K–1 is not the easy version. No reading and little writing are required, but the mathematics must be real: the same kind of question (Can it be done? Which ones can? What always happens? How many?) with bigger pieces, fewer cells, and the adult reading aloud and scribing. The K–1 pages should keep three young children and one adult busy for the hour, with large, clear diagrams that match the physical pieces in size.

Ask for explanations in forms a child can produce: point to the picture, show a table or list of all cases, describe a strategy, give one counterexample, or say why the same reason works again on a bigger case. Do not ask a child to state a general rule with a variable in it.

## Mathematics

Extract from the outline the questions a mathematician would recognize as the real ones (existence, impossibility, invariants, optimality, completeness, reconfiguration, counting) and make the problems concrete instances of exactly those questions, so that the mathematician at the table can push toward the argument. Every stated fact and every answer in the facilitator guide must be correct; check small cases by hand or by code before printing them. Choose instance sizes so that the interesting phenomenon appears within the children's reach (a pattern that breaks by the third or fourth case is better than one that never breaks).

## Facilitator guide

Materials with counts; a two-minute whole-group launch built around the one concrete action everyone will use; the order of problems per table with rough timings; complete answers and complete arguments for every problem (an adult should not have to work anything out during the hour); hints in the order to give them; what to do when a table stalls or finishes; and one short section on the mathematics behind the session for the two mathematicians, including where it leads (undergraduate or research topics). This is the only place for commentary, encouragement scripts, and teaching notes.

Make only editorial changes: delete anything the guidance forbids on a student page; tighten sentences; replace vague or hyped wording with plain, specific wording; fix typos and inconsistent terms. Do not add, remove, reorder or change the mathematics of any problem, diagram, or answer. Recompile all four files until they build without errors. Write `/home/claude/genlab/runs/T/W06/s1/copyedits.md` listing each change in one line.

You are one stage of a fixed pipeline; other stages ran before or will run after you, and none of them can talk to you. Do everything inside the working directory named below and nowhere else. Do not read anything outside your working directory and the template except when this prompt tells you to. When you are finished, write a file named `DONE-<stage>.md` in the working directory containing a summary of at most eight lines (what you produced, anything you could not resolve), and end your final message with that same summary and nothing else.
Stage name: `copyeditor`.
