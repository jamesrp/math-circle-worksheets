#!/usr/bin/env python3
"""Verification for the pattern-block (triangular-grid) problems of the Week 1 tiling bank.

Triangles live on the triangular lattice.  Lattice point (i, j) is the Cartesian point
(i + j/2, j*sqrt(3)/2).  up(i,j) has vertices (i,j),(i+1,j),(i,j+1); down(i,j) has
vertices (i+1,j),(i,j+1),(i+1,j+1).  Pieces (all in unit triangles):
  green = 1, blue rhombus = 2, red trapezoid = 3, purple chevron = 4, yellow hexagon = 6.
Run:  python3 verify_pattern_blocks.py
"""
from functools import lru_cache
from itertools import combinations
import math

# ---------------- triangles ----------------
def verts(t):
    i, j, o = t
    if o == 'u':
        return ((i, j), (i + 1, j), (i, j + 1))
    return ((i + 1, j), (i, j + 1), (i + 1, j + 1))


def tri_from_verts(vs):
    """Identify the triangle from its 3 lattice vertices."""
    vs = sorted(vs)
    (a, b, c) = vs
    # up: (i,j),(i,j+1),(i+1,j) sorted -> (i,j),(i,j+1),(i+1,j)
    if a[0] == b[0] and c[0] == a[0] + 1 and b[1] == a[1] + 1 and c[1] == a[1]:
        return (a[0], a[1], 'u')
    # down: (i,j+1),(i+1,j),(i+1,j+1) sorted -> (i,j+1),(i+1,j),(i+1,j+1)
    if b[0] == a[0] + 1 and c[0] == a[0] + 1 and a[1] == b[1] + 1 and c[1] == a[1]:
        return (a[0], b[1], 'd')
    raise ValueError(vs)


def cart(p):
    i, j = p
    return (i + j / 2.0, j * math.sqrt(3) / 2.0)


def centroid(t):
    vs = [cart(v) for v in verts(t)]
    return (sum(v[0] for v in vs) / 3.0, sum(v[1] for v in vs) / 3.0)


def around(v):
    """The six triangles around lattice vertex v, in counterclockwise order."""
    i, j = v
    return [(i, j, 'u'), (i - 1, j, 'd'), (i - 1, j, 'u'), (i - 1, j - 1, 'd'), (i, j - 1, 'u'), (i, j - 1, 'd')]


def neighbours(t):
    i, j, o = t
    if o == 'u':
        return [(i, j, 'd'), (i - 1, j, 'd'), (i, j - 1, 'd')]
    return [(i, j, 'u'), (i + 1, j, 'u'), (i, j + 1, 'u')]


# ---------------- pieces ----------------
def normalize(shape):
    shape = sorted(shape)
    i0, j0, _ = shape[0]
    return tuple(sorted((i - i0, j - j0, o) for i, j, o in shape))


def consecutive(k):
    """All k-consecutive runs of the 6 triangles around the origin, as normalized shapes."""
    ring = around((0, 0))
    out = set()
    for s in range(6):
        out.add(normalize([ring[(s + m) % 6] for m in range(k)]))
    return out


PIECES = {
    'green': {normalize([(0, 0, 'u')]), normalize([(0, 0, 'd')])},
    'blue': consecutive(2),
    'red': consecutive(3),
    'purple': consecutive(4),
    'yellow': consecutive(6),
}
SIZE = {'green': 1, 'blue': 2, 'red': 3, 'purple': 4, 'yellow': 6}
assert len(PIECES['blue']) == 3 and len(PIECES['red']) == 6 and len(PIECES['purple']) == 6 and len(PIECES['yellow']) == 1


def placements_covering(cell, kinds):
    """All (kind, frozenset(triangles)) placements that cover `cell`."""
    out = []
    seen = set()
    for kind in kinds:
        for shape in PIECES[kind]:
            for (i, j, o) in shape:
                if o != cell[2]:
                    continue
                di, dj = cell[0] - i, cell[1] - j
                placed = frozenset((a + di, b + dj, c) for a, b, c in shape)
                if (kind, placed) not in seen:
                    seen.add((kind, placed))
                    out.append((kind, placed))
    return out


# ---------------- regions ----------------
def point_in_convex(p, poly):
    """p, poly in Cartesian coordinates; poly counterclockwise; boundary counts as inside."""
    n = len(poly)
    for k in range(n):
        ax, ay = poly[k]
        bx, by = poly[(k + 1) % n]
        if (bx - ax) * (p[1] - ay) - (by - ay) * (p[0] - ax) < -1e-9:
            return False
    return True


def region_from_polygon(lattice_poly):
    poly = [cart(v) for v in lattice_poly]
    xs = [v[0] for v in lattice_poly] + [v[0] for v in lattice_poly]
    lo = min(min(v) for v in lattice_poly) - 2
    hi = max(max(v) for v in lattice_poly) + 2
    cells = set()
    for i in range(lo, hi + 1):
        for j in range(lo, hi + 1):
            for o in 'ud':
                t = (i, j, o)
                if all(point_in_convex(cart(v), poly) for v in verts(t)):
                    cells.add(t)
    return frozenset(cells)


def triangle_up(n, corner=(0, 0)):
    a, b = corner
    return region_from_polygon([(a, b), (a + n, b), (a, b + n)])


def triangle_down(n, bottom=(0, 0)):
    a, b = bottom                      # bottom vertex; the other corners are up-left and up-right
    return region_from_polygon([(a, b), (a, b + n), (a - n, b + n)])


def hexagon(n):
    return region_from_polygon([(n, 0), (0, n), (-n, n), (-n, 0), (0, -n), (n, -n)])


def parallelogram(a, b):
    return region_from_polygon([(0, 0), (a, 0), (a, b), (0, b)])


def trapezoid(n):
    """Half of the side-n hexagon: long base 2n, short base n, height n."""
    return region_from_polygon([(0, 0), (2 * n, 0), (n, n), (0, n)])


def ups_downs(cells):
    u = sum(1 for t in cells if t[2] == 'u')
    return u, len(cells) - u


# ---------------- exact cover ----------------
def enumerate_tilings(cells, kinds, limit=None):
    """Yield tilings as frozensets of (kind, frozenset(triangles))."""
    cells = frozenset(cells)
    order = sorted(cells, key=lambda t: (centroid(t)[1], centroid(t)[0]))
    rank = {t: k for k, t in enumerate(order)}

    def go(rem, acc):
        if not rem:
            yield frozenset(acc)
            return
        cell = min(rem, key=lambda t: rank[t])
        for kind, placed in placements_covering(cell, kinds):
            if placed <= rem:
                acc.append((kind, placed))
                yield from go(rem - placed, acc)
                acc.pop()
    yield from go(cells, [])


def count_tilings(cells, kinds):
    cells = frozenset(cells)
    order = sorted(cells, key=lambda t: (centroid(t)[1], centroid(t)[0]))
    rank = {t: k for k, t in enumerate(order)}

    @lru_cache(maxsize=None)
    def go(rem):
        if not rem:
            return 1
        cell = min(rem, key=lambda t: rank[t])
        total = 0
        for kind, placed in placements_covering(cell, kinds):
            if placed <= rem:
                total += go(rem - placed)
        return total
    return go(cells)


# ---------------- symmetries (for counting "different" ways) ----------------
def rot60(p):
    i, j = p
    return (-j, i + j)


def refl(p):
    i, j = p
    return (i + j, -j)


def apply_to_tiling(tiling, f):
    out = []
    for kind, placed in tiling:
        out.append((kind, frozenset(tri_from_verts([f(v) for v in verts(t)]) for t in placed)))
    return frozenset(out)


def hex_symmetries(with_reflection):
    fs = []
    for k in range(6):
        def rk(p, k=k):
            for _ in range(k):
                p = rot60(p)
            return p
        fs.append(rk)
        if with_reflection:
            fs.append(lambda p, rk=rk: rk(refl(p)))
    return fs


def tri_symmetries(n, with_reflection):
    """Symmetries of the up-triangle with corners (0,0),(n,0),(0,n)."""
    def r120(p):
        i, j = p
        return (n - i - j, i)

    def swap(p):
        return (p[1], p[0])
    fs = []
    for k in range(3):
        def rk(p, k=k):
            for _ in range(k):
                p = r120(p)
            return p
        fs.append(rk)
        if with_reflection:
            fs.append(lambda p, rk=rk: rk(swap(p)))
    return fs


def classes(tilings, syms):
    seen = set()
    reps = []
    for t in tilings:
        key = frozenset(apply_to_tiling(t, f) for f in syms)
        if key not in seen:
            seen.add(key)
            reps.append(t)
    return reps


def piece_counts(t):
    c = {}
    for kind, _ in t:
        c[kind] = c.get(kind, 0) + 1
    return c


def describe_counts(tilings):
    from collections import Counter
    cnt = Counter()
    for t in tilings:
        pc = piece_counts(t)
        cnt[tuple(sorted(pc.items()))] += 1
    return cnt


def blue_orientations(t):
    """For a blue-only tiling: how many rhombi of each of the 3 orientations."""
    from collections import Counter
    c = Counter()
    for kind, placed in t:
        if kind == 'blue':
            c[normalize(placed)] += 1
    return tuple(sorted(c.values()))


def report(name, value):
    print(f"{name}: {value}")


ALL = ['green', 'blue', 'red', 'yellow']

if __name__ == "__main__":
    H1, H2 = hexagon(1), hexagon(2)
    T2, T3, T4, T5 = triangle_up(2), triangle_up(3), triangle_up(4), triangle_up(5)
    P12, P13, P22, P23 = parallelogram(1, 2), parallelogram(1, 3), parallelogram(2, 2), parallelogram(2, 3)
    TR1, TR2 = trapezoid(1), trapezoid(2)
    # bowtie: up side-2 triangle with apex (0,2) and a down side-2 triangle hanging from ... share apex
    BOW = triangle_up(2) | triangle_down(2, bottom=(0, 2))
    RING = H2 - H1
    regions = [("hexagon side 1", H1), ("hexagon side 2", H2), ("triangle side 2", T2), ("triangle side 3", T3),
               ("triangle side 4", T4), ("triangle side 5", T5), ("parallelogram 1x2", P12), ("parallelogram 1x3", P13),
               ("parallelogram 2x2", P22), ("parallelogram 2x3", P23), ("trapezoid (red)", TR1), ("trapezoid side 2", TR2),
               ("bowtie (two side-2 triangles at a vertex)", BOW), ("ring = hex2 minus hex1", RING)]

    print("== region sizes: triangles, (up, down) ==")
    for name, R in regions:
        print(f"  {name}: {len(R)} triangles, up/down = {ups_downs(R)}")

    print("\n== blue-only (lozenge) tilings ==")
    for name, R in regions:
        n = count_tilings(R, ['blue'])
        print(f"  {name}: {n}")
    print("  hexagon side 3 (MacMahon 980):", count_tilings(hexagon(3), ['blue']))

    print("\n== orientation invariant in blue-only tilings ==")
    for name, R in [("hexagon side 1", H1), ("hexagon side 2", H2), ("parallelogram 2x2", P22), ("parallelogram 2x3", P23), ("trapezoid side 2", TR2)]:
        seen = set(blue_orientations(t) for t in enumerate_tilings(R, ['blue']))
        print(f"  {name}: orientation multisets seen = {sorted(seen)}")

    print("\n== red-only, green-only, yellow-only, purple-only ==")
    for name, R in regions:
        print(f"  {name}: red {count_tilings(R, ['red'])}, yellow {count_tilings(R, ['yellow'])}, purple {count_tilings(R, ['purple'])}, green {count_tilings(R, ['green'])}")

    print("\n== all four standard pieces: number of tilings ==")
    for name, R in [("hexagon side 1", H1), ("triangle side 2", T2), ("triangle side 3", T3), ("trapezoid (red)", TR1),
                    ("parallelogram 1x2", P12), ("parallelogram 2x2", P22), ("trapezoid side 2", TR2), ("triangle side 4", T4), ("hexagon side 2", H2)]:
        print(f"  {name}: {count_tilings(R, ALL)}")

    print("\n== hexagon side 1 with all pieces: breakdown ==")
    tl = list(enumerate_tilings(H1, ALL))
    print("  total as placed:", len(tl))
    for k, v in sorted(describe_counts(tl).items()):
        print("   ", dict(k), "->", v)
    print("  up to rotation:", len(classes(tl, hex_symmetries(False))))
    print("  up to rotation and reflection:", len(classes(tl, hex_symmetries(True))))
    print("  by number of pieces:", sorted(((sum(piece_counts(t).values()), 1) for t in tl)) and
          {k: sum(1 for t in tl if sum(piece_counts(t).values()) == k) for k in range(1, 7)})
    # with the purple chevron allowed too
    print("  with purple allowed as well, as placed:", count_tilings(H1, ALL + ['purple']))

    print("\n== triangle side 2 with all pieces: breakdown ==")
    tl = list(enumerate_tilings(T2, ALL))
    print("  total as placed:", len(tl))
    for k, v in sorted(describe_counts(tl).items()):
        print("   ", dict(k), "->", v)
    print("  up to rotation:", len(classes(tl, tri_symmetries(2, False))), " up to rot+refl:", len(classes(tl, tri_symmetries(2, True))))

    print("\n== triangle side 3 with all pieces: breakdown ==")
    tl = list(enumerate_tilings(T3, ALL))
    print("  total as placed:", len(tl))
    for k, v in sorted(describe_counts(tl).items()):
        print("   ", dict(k), "->", v)
    print("  up to rotation:", len(classes(tl, tri_symmetries(3, False))), " up to rot+refl:", len(classes(tl, tri_symmetries(3, True))))
    print("  fewest pieces:", min(sum(piece_counts(t).values()) for t in tl), " most:", max(sum(piece_counts(t).values()) for t in tl))

    print("\n== fewest / most pieces with all pieces ==")
    for name, R in [("hexagon side 1", H1), ("triangle side 2", T2), ("triangle side 3", T3), ("triangle side 4", T4),
                    ("trapezoid side 2", TR2), ("parallelogram 2x2", P22), ("hexagon side 2", H2)]:
        best = None
        best_counts = None
        for t in enumerate_tilings(R, ALL):
            k = sum(piece_counts(t).values())
            if best is None or k < best:
                best, best_counts = k, piece_counts(t)
        print(f"  {name}: fewest pieces = {best} (e.g. {best_counts}); most = {len(R)} (all green)")

    print("\n== hexagon side 2: which piece-count vectors are possible (yellow,red,blue,green) with fewest pieces ==")
    from collections import Counter
    c = Counter()
    for t in enumerate_tilings(H2, ALL):
        pc = piece_counts(t)
        c[(pc.get('yellow', 0), pc.get('red', 0), pc.get('blue', 0), pc.get('green', 0))] += 1
    small = sorted(c.items(), key=lambda kv: sum(kv[0]))[:12]
    for k, v in small:
        print("   ", k, "pieces:", sum(k), "count:", v)
    print("  max yellows in any tiling:", max(k[0] for k in c))

    print("\n== triangle side 2..5: blue-only tileable? and up/down counts ==")
    for n in range(2, 6):
        R = triangle_up(n)
        print(f"  side {n}: up/down {ups_downs(R)}, blue tilings {count_tilings(R, ['blue'])}, red tilings {count_tilings(R, ['red'])}")

    print("\n== hexagon side 2 by 3 yellows + 3 blues: count; by yellows+reds only ==")
    print("  yellow+blue:", count_tilings(H2, ['yellow', 'blue']), " yellow+red:", count_tilings(H2, ['yellow', 'red']), " red only:", count_tilings(H2, ['red']))
    print("  hex2 blue+red:", count_tilings(H2, ['blue', 'red']))

    print("\n== chevron facts ==")
    print("  hexagon side 1 by purple+blue:", count_tilings(H1, ['purple', 'blue']), " purple+green:", count_tilings(H1, ['purple', 'green']))
    print("  triangle side 2 by purple:", count_tilings(T2, ['purple']))
    print("  parallelogram 2x2 by purple:", count_tilings(P22, ['purple']), " hexagon side 2 by purple:", count_tilings(H2, ['purple']))
