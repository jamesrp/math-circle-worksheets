Make an activity packet for a one-hour math circle session for grades K–5, where the kids work with each other and with professional mathematicians guiding them. The organizer's high-level activity outline is given below.

The group: ten children (two kindergartners and a first grader / four third graders / two fourth graders and a fifth grader) and three adults (the organizer, a math PhD; a second mathematician; one parent who is not a mathematician). One adult is anchored to each of three tables: K–1, grades 2–3 (the third graders sit here), grades 4–5. Session shape: a few minutes of free handling of the materials, a short whole-group launch, table work for most of the hour, a brief share at the end. The children have done math circle before; the older ones have seen simple games and puzzles, but nothing from this theme.

Deliverables — LaTeX sources that compile with `pdflatex -interaction=nonstopmode` (TikZ is available) to US Letter PDFs, written into the working directory named at the end of this message:

- `week-k-1.tex` — student pages for the K–1 table (no independent reading required; the adult reads aloud)
- `week-grades-2-3.tex` — student pages for the grades 2–3 table
- `week-grades-4-5.tex` — student pages for the grades 4–5 table
- `week-facilitator.tex` — one facilitator guide for the three adults: materials and preparation, the whole-group launch, what each table does in what order, complete answers and arguments for every problem, hints, and what to do when a table stalls or finishes early

Call it Week 1. Compile all four files until they build without errors, and look at the rendered pages (`pdftoppm -r 60 -png file.pdf out`) to check that diagrams and spacing came out as intended. Do not leave stray files other than the four `.tex` sources and their PDFs (plus any `.tex` files you `\input`).

Use the house LaTeX template `genlab-common.tex`, already copied into your working directory. Read the comment at the top of that file: each student file sets `\ActivityTopic` (a short topic name of your choosing) and `\ActivityId` (`W1-K-v1`, `W1-M-v1`, `W1-U-v1` for the three levels; `W1-F-v1` for the facilitator guide), `\input`s the template, starts every student page with `\WorksheetHeader{...}` and writes each problem with `\Problem{N}{...}`. The K–1 file may use `\documentclass[14pt]{extarticle}` for larger type. The facilitator guide uses ordinary `\section*{...}` headings and no `\WorksheetHeader`.

Follow this guidance for the packet:

## What a student page is

A student page is a tool for doing, not a text to read. It contains only the running header (week, topic, level), the footer, and numbered problems written as `Problem N: ...` in ordinary sentences, plus the diagrams, grids, boards and recording space the child actually needs. Everything else lives in the facilitator guide.

Each problem tells the child exactly what to do with the materials and where to record it: what to build, place, move, cut, count, draw, compare, or write, and in which board or blank. The rules of the activity are stated inside the problem text, briefly, the first time they are needed. A child, or an adult reading aloud, should never have to guess the task from a title, a hint of a theme, or a label.

Write in plain, short, direct sentences with concrete nouns and numbers ("Use only blue rhombi. Fill boards A to D. Mark each board you could not fill."). Mention characters or a small story only when the problem needs something to talk about; the child's interest comes from the puzzle and the materials.

## Do not put these on student pages

Page titles or teaser questions above the problems; section headings, labels or boxes such as "Warm-up", "Challenge", "Go further", "Bonus", "Rules", "Think about it", "Fun fact"; Name/Date lines; sentences of encouragement or praise; exclamation marks; emoji or clip-art; instructions addressed to the adult; explanations of the mathematics or the answer; a "reflection" question that could be answered without having done the problem.

## Enough work, concrete work

A table has about forty minutes of working time and must not run out of things to do. Give each idea several purposeful, contrasting instances — boards that can and cannot be filled, starts that end differently, sizes 2, 3, 4, 5 — with a separate diagram or blank for each, rather than one example followed by a question. Each new instance should reveal a distinction or extend a pattern, not repeat a procedure. Plan for the fast table: the last problems on each level should still be real problems, and the facilitator guide should say what to offer next.

Order every sequence as act → record → compare → explain. The child does something with the materials, records what happened in a space made for it, looks at several results side by side, and only then is asked why. Put "How do you know for sure?" style follow-ups in the facilitator guide when they would interrupt the printed task. Introduce a new representation (a table, a code, a coloring, a map of states) only after the child has met the question it answers, and give that representation its own concrete problems.

K–1 is not the easy version. No reading and little writing are required, but the mathematics must be real: the same kind of question (Can it be done? Which ones can? What always happens? How many?) with bigger pieces, fewer cells, and the adult reading aloud and scribing. The K–1 pages should keep three young children and one adult busy for the hour, with large, clear diagrams that match the physical pieces in size.

Ask for explanations in forms a child can produce: point to the picture, show a table or list of all cases, describe a strategy, give one counterexample, or say why the same reason works again on a bigger case. Do not ask a child to state a general rule with a variable in it.

## Mathematics

Extract from the outline the questions a mathematician would recognize as the real ones (existence, impossibility, invariants, optimality, completeness, reconfiguration, counting) and make the problems concrete instances of exactly those questions, so that the mathematician at the table can push toward the argument. Every stated fact and every answer in the facilitator guide must be correct; check small cases by hand or by code before printing them. Choose instance sizes so that the interesting phenomenon appears within the children's reach (a pattern that breaks by the third or fourth case is better than one that never breaks).

## Facilitator guide

Materials with counts; a two-minute whole-group launch built around the one concrete action everyone will use; the order of problems per table with rough timings; complete answers and complete arguments for every problem (an adult should not have to work anything out during the hour); hints in the order to give them; what to do when a table stalls or finishes; and one short section on the mathematics behind the session for the two mathematicians, including where it leads (undergraduate or research topics). This is the only place for commentary, encouragement scripts, and teaching notes.

High-level activity outline from the organizer:

Theme: tilings.

Two things in tilings I know are cool: the L-tromino can tile any 2^n × 2^n board with one square removed (a clean induction), and the checkerboard with two diagonally opposite corners removed cannot be tiled by dominoes (a coloring argument — the two removed squares have the same color, so the counts no longer match). Both come from the first weeks of an undergraduate discrete math or combinatorics course, and they open onto real research: tilings as perfect matchings, coloring and other invariants, and the fact that "can this region be tiled?" is hard in general. Feel free to bring in other tiling results you know at that level or above if they extract better for children.

Materials on hand: a large set of pattern blocks (1-inch-edge green triangles, blue rhombi, red trapezoids, yellow hexagons, plus purple chevrons that are exactly two blue rhombi joined, and a few nonstandard pieces), printed outlines/grids at true 1-inch scale, square-grid paper, and scissors for cutting paper dominoes or trominoes.

Working directory: `/home/claude/genlab/runs/T/W02/s1` — write the four `.tex` files and their PDFs there.

You are one stage of a fixed pipeline; other stages ran before or will run after you, and none of them can talk to you. Do everything inside the working directory named below and nowhere else. Do not read anything outside your working directory and the template except when this prompt tells you to. When you are finished, write a file named `DONE-<stage>.md` in the working directory containing a summary of at most eight lines (what you produced, anything you could not resolve), and end your final message with that same summary and nothing else.
Stage name: `writer`.
