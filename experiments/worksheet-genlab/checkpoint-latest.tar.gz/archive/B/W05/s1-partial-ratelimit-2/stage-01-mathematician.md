You are a research mathematician preparing the mathematical groundwork for a K–5 math-circle session. A colleague will write the student pages and the facilitator guide from your dossier and will not have time to re-derive anything, so what you write must be correct and concrete.

The session request is:

Make an activity packet for a one-hour math circle session for grades K–5, where the kids work with each other and with professional mathematicians guiding them. The organizer's high-level activity outline is given below.

The group: ten children (two kindergartners and a first grader / four third graders / two fourth graders and a fifth grader) and three adults (the organizer, a math PhD; a second mathematician; one parent who is not a mathematician). One adult is anchored to each of three tables: K–1, grades 2–3 (the third graders sit here), grades 4–5. Session shape: a few minutes of free handling of the materials, a short whole-group launch, table work for most of the hour, a brief share at the end. The children have done math circle before; the older ones have seen simple games and puzzles, but nothing from this theme.

Deliverables — LaTeX sources that compile with `pdflatex -interaction=nonstopmode` (TikZ is available) to US Letter PDFs, written into the working directory named at the end of this message:

- `week-k-1.tex` — student pages for the K–1 table (no independent reading required; the adult reads aloud)
- `week-grades-2-3.tex` — student pages for the grades 2–3 table
- `week-grades-4-5.tex` — student pages for the grades 4–5 table
- `week-facilitator.tex` — one facilitator guide for the three adults: materials and preparation, the whole-group launch, what each table does in what order, complete answers and arguments for every problem, hints, and what to do when a table stalls or finishes early

Call it Week 1. Compile all four files until they build without errors, and look at the rendered pages (`pdftoppm -r 60 -png file.pdf out`) to check that diagrams and spacing came out as intended. Do not leave stray files other than the four `.tex` sources and their PDFs (plus any `.tex` files you `\input`).

High-level activity outline from the organizer:

Theme: Bulgarian solitaire.

Counters sit in piles. A move takes one counter from every pile and puts all of those counters together as a new pile (piles that hit zero disappear). Brandt (1982) proved that if the number of counters is a triangular number 1 + 2 + ... + k, then no matter how you start you always end at the staircase (k, k−1, ..., 1), which is a fixed point; for other numbers of counters the game falls into a cycle instead. Later work bounds how many moves the staircase takes (at most k² − k, Igusa; Etienne), describes the cycles that occur for non-triangular numbers, identifies "Garden of Eden" states that no state leads to, and connects everything to partitions and Young diagrams. I like it because it is a deterministic dynamical system children can run by hand with counters, the triangular numbers keep coming back, and "does every start end in the same place?" is a real theorem with a real proof.

Materials on hand: lots of counters (also playing cards), paper for recording.

Write `/home/claude/genlab/runs/B/W05/s1/dossier.md` (aim for 1,500–3,000 words plus data) with these sections:

1. The real questions. Which questions in this theme would a mathematician recognize as the genuine ones (existence, impossibility, invariants, optimality, completeness, reconfiguration, counting, dynamics)? For each, the undergraduate or research idea behind it and the elementary version of the argument, as it could be made with objects or drawings.
2. Instances. For each level (K–1 with no reading, grades 2–3, grades 4–5), a ladder of concrete instances: the exact board, sizes, starting configuration or numbers; what the child does with the materials; what they will find; the answer; and why that instance is there (what distinction or pattern it reveals). Choose sizes so that the interesting phenomenon shows up within reach — a pattern that breaks by the third or fourth case, a first impossible case that comes right after possible ones, an instance small enough to list all cases. Give at least six instances per level and mark which are the core sequence and which are reserves for a fast table.
3. Verified data. Compute every answer you state with a short program (write it in the working directory and run it) or by an exhaustive hand check; include the small-case tables the writer can print in the guide.
4. Arguments children can give. For each level, the explanation forms within reach (a table of all cases, a coloring or pairing shown on the picture, a counterexample, "the same reason again on a bigger one") and the exact wording an adult could use to draw it out.
5. Pitfalls. Rules that are easy to state wrongly, ambiguous cases, common errors in answers, and physical/logistical traps (piece sizes, grid sizes, time to draw).
6. Where it leads. A short section for the two mathematicians: the theorems, papers, or courses this connects to.

Do not write the worksheets themselves.

You are one stage of a fixed pipeline; other stages ran before or will run after you, and none of them can talk to you. Do everything inside the working directory named below and nowhere else. Do not read anything outside your working directory and the template except when this prompt tells you to. When you are finished, write a file named `DONE-<stage>.md` in the working directory containing a summary of at most eight lines (what you produced, anything you could not resolve), and end your final message with that same summary and nothing else.
Stage name: `mathematician`.
