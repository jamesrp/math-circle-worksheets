#!/usr/bin/env python3
"""Exhaustive small-case data for Bulgarian solitaire (Week 1 dossier).

State = partition of n, written as a tuple of pile sizes in decreasing order.
Move  = take one counter from every pile, form a new pile from them, drop empty piles.

Run:  python3 bulgarian_solitaire.py            (prints every table used in dossier.md)
      python3 bulgarian_solitaire.py 12         (full state table for n = 12 only)
"""
import sys
from collections import defaultdict, Counter
from math import gcd, comb

# ---------------------------------------------------------------- basics

def partitions(n, maxpart=None):
    """All partitions of n as decreasing tuples, largest first, in reverse-lexicographic order."""
    if maxpart is None:
        maxpart = n
    if n == 0:
        yield ()
        return
    for first in range(min(n, maxpart), 0, -1):
        for rest in partitions(n - first, first):
            yield (first,) + rest


def move(p):
    m = len(p)
    new = [x - 1 for x in p if x > 1] + [m]
    return tuple(sorted(new, reverse=True))


def fmt(p):
    return "-".join(str(x) for x in p) if p else "(empty)"


def tri(k):
    return k * (k + 1) // 2


def k_and_r(n):
    """n = T_k + r with 0 <= r <= k."""
    k = 0
    while tri(k + 1) <= n:
        k += 1
    return k, n - tri(k)


def predecessors_by_rule(p):
    """Undo the move: pick a pile of size s that was 'the new pile'; it must satisfy s >= (#piles - 1).
    The predecessor is: the other piles each +1, plus (s - (#piles - 1)) piles of size 1."""
    m = len(p)
    preds = set()
    for s in set(p):
        if s >= m - 1:
            rest = list(p)
            rest.remove(s)
            q = [x + 1 for x in rest] + [1] * (s - (m - 1))
            preds.add(tuple(sorted(q, reverse=True)))
    return preds


def potential(p):
    """S(p) = sum over cells (i,j) of the Young diagram (rows = piles, largest first) of i + j - 1."""
    return sum(i + j - 1 for i, part in enumerate(p, 1) for j in range(1, part + 1))


def s_min(n):
    k, r = k_and_r(n)
    return sum(d * d for d in range(1, k + 1)) + r * (k + 1)


def is_epsilon_form(p, n):
    k, r = k_and_r(n)
    q = list(p) + [0] * (k + 2 - len(p))
    if len(p) > k + 1:
        return False
    return all(q[i] - (k - i) in (0, 1) for i in range(k + 1))


def epsilon_vector(p, n):
    k, r = k_and_r(n)
    q = list(p) + [0] * (k + 1 - len(p))
    return tuple(q[i] - (k - i) for i in range(k + 1))

# ---------------------------------------------------------------- analysis of one n

class Game:
    def __init__(self, n):
        self.n = n
        self.states = list(partitions(n))
        self.nxt = {s: move(s) for s in self.states}
        self.pred = defaultdict(set)
        for s, t in self.nxt.items():
            self.pred[t].add(s)
        # cycles: iterate until repeat
        self.cycle_of = {}       # state -> cycle index
        self.cycles = []         # list of lists (in move order)
        on_cycle = set()
        for s in self.states:
            if s in self.cycle_of:
                continue
            seen = {}
            cur = s
            path = []
            while cur not in seen and cur not in self.cycle_of:
                seen[cur] = len(path)
                path.append(cur)
                cur = self.nxt[cur]
            if cur in self.cycle_of:
                cid = self.cycle_of[cur]
            else:
                start = seen[cur]
                cyc = path[start:]
                cid = len(self.cycles)
                self.cycles.append(cyc)
                for c in cyc:
                    on_cycle.add(c)
            for p_ in path:
                self.cycle_of[p_] = cid
        self.on_cycle = on_cycle
        # transient length: moves until first cycle state
        self.tlen = {}
        for s in self.states:
            t, cur = 0, s
            while cur not in on_cycle:
                cur = self.nxt[cur]
                t += 1
            self.tlen[s] = t
        self.goe = [s for s in self.states if not self.pred[s]]

    def trajectory(self, s):
        out = [s]
        seen = {s}
        cur = s
        while True:
            cur = self.nxt[cur]
            if cur in seen:
                out.append(cur)
                return out
            seen.add(cur)
            out.append(cur)

# ---------------------------------------------------------------- checks of the theory

def check_theory(nmax):
    print(f"\n## Theory checks for n = 1..{nmax}")
    ok = True
    for n in range(1, nmax + 1):
        g = Game(n)
        k, r = k_and_r(n)
        # (1) cycle states == epsilon-form states; count C(k+1, r)
        eps = {s for s in g.states if is_epsilon_form(s, n)}
        if eps != g.on_cycle or len(eps) != comb(k + 1, r):
            ok = False
            print("FAIL cycle-state characterization at n =", n)
        # (2) move on epsilon vectors is the cyclic shift (last entry moves to the front)
        for s in g.on_cycle:
            e = epsilon_vector(s, n)
            e2 = epsilon_vector(g.nxt[s], n)
            if e2 != (e[-1],) + e[:-1]:
                ok = False
                print("FAIL rotation at", n, s)
        # (3) predecessor rule
        for s in g.states:
            if predecessors_by_rule(s) != g.pred[s]:
                ok = False
                print("FAIL predecessor rule at", n, s)
        # (4) Garden of Eden iff largest part <= (#piles) - 2
        for s in g.states:
            if (len(g.pred[s]) == 0) != (s[0] <= len(s) - 2):
                ok = False
                print("FAIL GoE rule at", n, s)
        # (5) potential S never increases; strictly decreases iff largest >= #piles + 2; minimum iff eps-form
        for s in g.states:
            d = potential(g.nxt[s]) - potential(s)
            if d > 0 or (d == 0) != (s[0] <= len(s) + 1):
                ok = False
                print("FAIL potential at", n, s, d)
            if (potential(s) == s_min(n)) != (s in eps):
                ok = False
                print("FAIL S_min at", n, s)
        # (6) number of cycles = number of binary necklaces of length k+1 with r ones
        L = k + 1
        neck = sum(phi(d) * comb(L // d, r // d) for d in range(1, L + 1) if L % d == 0 and r % d == 0) // L
        if neck != len(g.cycles):
            ok = False
            print("FAIL necklace count at", n)
        # (7) GoE count formula: sum_{j>=1} (-1)^(j+1) p(n - 3 T_j)
        form = 0
        j = 1
        while n - 3 * tri(j) >= 0:
            form += (-1) ** (j + 1) * num_partitions(n - 3 * tri(j))
            j += 1
        if form != len(g.goe):
            ok = False
            print("FAIL GoE count formula at n =", n, form, len(g.goe))
    print("all checks passed" if ok else "SOME CHECK FAILED")


def phi(d):
    return sum(1 for x in range(1, d + 1) if gcd(x, d) == 1)


_pcache = {0: 1}
def num_partitions(n):
    if n in _pcache:
        return _pcache[n]
    # Euler's pentagonal recurrence
    total = 0
    j = 1
    while True:
        g1 = j * (3 * j - 1) // 2
        g2 = j * (3 * j + 1) // 2
        if g1 > n:
            break
        sign = 1 if j % 2 == 1 else -1
        total += sign * num_partitions(n - g1)
        if g2 <= n:
            total += sign * num_partitions(n - g2)
        j += 1
    _pcache[n] = total
    return total

# ---------------------------------------------------------------- report

def summary_table(nmax):
    print(f"\n## Table A: summary for n = 1..{nmax}")
    print("| n | k, r | #starts p(n) | cycles (lengths) | cycle states | #Garden-of-Eden | longest road (moves to reach cycle) | starts achieving it |")
    print("|---|---|---|---|---|---|---|---|")
    for n in range(1, nmax + 1):
        g = Game(n)
        k, r = k_and_r(n)
        lens = sorted((len(c) for c in g.cycles), reverse=True)
        cyc = "; ".join(" > ".join(fmt(s) for s in c) for c in g.cycles)
        mx = max(g.tlen.values())
        arg = [s for s in g.states if g.tlen[s] == mx]
        print(f"| {n} | {k}, {r} | {len(g.states)} | {len(g.cycles)} ({', '.join(map(str, lens))}) | {cyc} | {len(g.goe)} | {mx} | {', '.join(fmt(s) for s in arg)} |")


def full_table(n):
    g = Game(n)
    k, r = k_and_r(n)
    print(f"\n## Table: all {len(g.states)} starts for n = {n}  (k = {k}, r = {r}; {len(g.cycles)} cycle(s))")
    print("| start | next | moves to reach cycle | cycle entered (first cycle state) | #ways to arrive here (predecessors) |")
    print("|---|---|---|---|---|")
    for s in g.states:
        cur = s
        while cur not in g.on_cycle:
            cur = g.nxt[cur]
        preds = sorted(g.pred[s], reverse=True)
        pstr = ", ".join(fmt(p) for p in preds) if preds else "none (Garden of Eden)"
        star = " (cycle)" if s in g.on_cycle else ""
        print(f"| {fmt(s)}{star} | {fmt(g.nxt[s])} | {g.tlen[s]} | {fmt(cur)} | {len(preds)}: {pstr} |")


def basins(n):
    g = Game(n)
    print(f"\n## Basins for n = {n}")
    for i, c in enumerate(g.cycles):
        members = [s for s in g.states if g.cycle_of[s] == i]
        print(f"cycle {i+1} (length {len(c)}): {' > '.join(fmt(s) for s in c)} > ...")
        print(f"  basin size {len(members)}: " + ", ".join(fmt(s) for s in members))


def trajectories(n, starts):
    g = Game(n)
    print(f"\n## Trajectories for n = {n}")
    for s in starts:
        s = tuple(sorted(s, reverse=True))
        tr = g.trajectory(s)
        # number of moves to reach cycle
        print(f"{fmt(s)}: " + " > ".join(fmt(x) for x in tr) + f"   [{g.tlen[s]} moves to reach the cycle/fixed point; then repeats]")


def triangular_report(kmax):
    print("\n## Table F: triangular n = T_k, moves to the fixed point")
    print("| k | n | #starts | max moves | bound k^2-k | starts achieving max | one pile (n) takes | all ones takes | #starts by moves 0,1,2,... |")
    print("|---|---|---|---|---|---|---|---|---|")
    for k in range(1, kmax + 1):
        n = tri(k)
        g = Game(n)
        assert len(g.cycles) == 1 and len(g.cycles[0]) == 1
        mx = max(g.tlen.values())
        arg = [s for s in g.states if g.tlen[s] == mx]
        hist = Counter(g.tlen.values())
        h = ",".join(str(hist[i]) for i in range(mx + 1))
        one = g.tlen[(n,)]
        ones = g.tlen[tuple([1] * n)]
        print(f"| {k} | {n} | {len(g.states)} | {mx} | {k*k-k} | {', '.join(fmt(s) for s in arg[:6])}{' ...' if len(arg) > 6 else ''} | {one} | {ones} | {h} |")


def moves_table_triangular(n, cols=3):
    g = Game(n)
    print(f"\n## Table: moves to the fixed point for every start with n = {n}")
    items = sorted(g.states, key=lambda s: (-g.tlen[s], s), reverse=False)
    items = sorted(g.states, key=lambda s: (g.tlen[s], [-x for x in s]))
    print("| start | moves | start | moves | start | moves |")
    print("|---|---|---|---|---|---|")
    row = []
    for s in items:
        row.append(f"{fmt(s)} | {g.tlen[s]}")
        if len(row) == cols:
            print("| " + " | ".join(row) + " |")
            row = []
    if row:
        while len(row) < cols:
            row.append(" | ")
        print("| " + " | ".join(row) + " |")


def cycle_catalog(nmax):
    print(f"\n## Table I: cycle catalog by n = T_k + r (number of cycles = binary necklaces of length k+1 with r black beads)")
    print("| n | k+1 seats | r extras | cycle states C(k+1,r) | #cycles | cycle lengths | representative states (one per cycle) |")
    print("|---|---|---|---|---|---|---|")
    for n in range(1, nmax + 1):
        g = Game(n)
        k, r = k_and_r(n)
        lens = [len(c) for c in g.cycles]
        reps = "; ".join(fmt(c[0]) for c in g.cycles)
        print(f"| {n} | {k+1} | {r} | {comb(k+1, r)} | {len(g.cycles)} | {', '.join(map(str, lens))} | {reps} |")


def goe_table(nmax):
    print(f"\n## Table H: Garden-of-Eden states (no predecessor) for n = 1..{nmax}")
    print("| n | #GoE | GoE states |")
    print("|---|---|---|")
    for n in range(1, nmax + 1):
        g = Game(n)
        print(f"| {n} | {len(g.goe)} | {', '.join(fmt(s) for s in g.goe)} |")


def one_pile_report(nmax):
    """From a single pile (n), with n = T_k + r: the cycle is entered after T_{k-1} + max(r-1, 0) moves,
    and (for r >= 1) the first repeated state appears at move n exactly; for r = 0 the state stops
    changing after T_{k-1} moves (repeat seen at move T_{k-1} + 1). From all ones: one move more."""
    print(f"\n## Table G: starting from one pile of n (and from n single counters)")
    print("| n | k, r | moves from (n) to reach the cycle | predicted T(k-1)+max(r-1,0) | move at which the first repeat is seen, from (n) | from all ones: reach cycle / first repeat |")
    print("|---|---|---|---|---|---|")
    ok = True
    for n in range(1, nmax + 1):
        g = Game(n)
        k, r = k_and_r(n)
        t = g.tlen[(n,)]
        pred = tri(k - 1) + max(r - 1, 0)
        cyc_len = len(g.cycles[g.cycle_of[(n,)]])
        rep = t + cyc_len
        t1 = g.tlen[tuple([1] * n)]
        rep1 = t1 + len(g.cycles[g.cycle_of[tuple([1] * n)]])
        if t != pred or (r >= 1 and rep != n) or (r == 0 and rep != tri(k - 1) + 1) or (n >= 3 and t1 != t + 1):
            ok = False
        print(f"| {n} | {k}, {r} | {t} | {pred} | {rep} | {t1} / {rep1} |")
    print("one-pile pattern holds for all n listed" if ok else "ONE-PILE PATTERN FAILS")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        full_table(int(sys.argv[1]))
        sys.exit()
    check_theory(24)
    one_pile_report(30)
    summary_table(21)
    for n in (3, 4, 5, 6, 7, 8, 9):
        full_table(n)
    basins(8)
    basins(12)
    trajectories(6, [(6,), (1,)*6, (3, 3), (2, 2, 1, 1), (4, 1, 1), (2, 2, 2), (5, 1), (4, 2), (3, 1, 1, 1), (2, 1, 1, 1, 1), (3, 2, 1)])
    trajectories(10, [(10,), (1,)*10, (5, 5), (3, 3, 2, 1, 1), (2, 2, 2, 2, 1, 1), (4, 4, 2), (7, 3), (3, 3, 3, 1), (2,)*5, (6, 4), (9, 1)])
    trajectories(15, [(15,), (1,)*15, (5, 5, 5), (3, 3, 3, 3, 3), (8, 7), (4, 4, 3, 2, 1, 1), (14, 1), (7, 7, 1)])
    trajectories(8, [(8,), (4, 4), (2, 2, 2, 2), (6, 1, 1), (1,)*8, (5, 3), (3, 3, 2), (7, 1), (4, 2, 2), (2, 2, 2, 1, 1)])
    trajectories(7, [(7,), (1,)*7, (4, 3), (2, 2, 2, 1)])
    trajectories(12, [(12,), (6, 6), (4, 4, 4), (3, 3, 3, 3), (1,)*12])
    trajectories(17, [(6, 4, 3, 3, 1), (17,), (5, 5, 5, 2)])
    triangular_report(9)
    moves_table_triangular(10)
    cycle_catalog(28)
    goe_table(12)
    print("\n## p(n) for n = 1..21:", [num_partitions(n) for n in range(1, 22)])
