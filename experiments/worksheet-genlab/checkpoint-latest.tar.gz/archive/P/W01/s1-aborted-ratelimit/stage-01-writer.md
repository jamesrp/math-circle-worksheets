Make an activity packet for a one-hour math circle session for grades K–5, where the kids work with each other and with professional mathematicians guiding them. The organizer's high-level activity outline is given below.

The group: ten children (two kindergartners and a first grader / four third graders / two fourth graders and a fifth grader) and three adults (the organizer, a math PhD; a second mathematician; one parent who is not a mathematician). One adult is anchored to each of three tables: K–1, grades 2–3 (the third graders sit here), grades 4–5. Session shape: a few minutes of free handling of the materials, a short whole-group launch, table work for most of the hour, a brief share at the end. The children have done math circle before; the older ones have seen simple games and puzzles, but nothing from this theme.

Deliverables — LaTeX sources that compile with `pdflatex -interaction=nonstopmode` (TikZ is available) to US Letter PDFs, written into the working directory named at the end of this message:

- `week-k-1.tex` — student pages for the K–1 table (no independent reading required; the adult reads aloud)
- `week-grades-2-3.tex` — student pages for the grades 2–3 table
- `week-grades-4-5.tex` — student pages for the grades 4–5 table
- `week-facilitator.tex` — one facilitator guide for the three adults: materials and preparation, the whole-group launch, what each table does in what order, complete answers and arguments for every problem, hints, and what to do when a table stalls or finishes early

Call it Week 1. Compile all four files until they build without errors, and look at the rendered pages (`pdftoppm -r 60 -png file.pdf out`) to check that diagrams and spacing came out as intended. Do not leave stray files other than the four `.tex` sources and their PDFs (plus any `.tex` files you `\input`).

High-level activity outline from the organizer:

Theme: jumping-peg games (the peg solitaire family).

The thing I find cool: Conway's Soldiers. Pegs start on the squares below a horizontal line on an infinite grid. A move is a checkers-style jump: a peg hops over an orthogonally adjacent peg into the empty square beyond, and the jumped peg is removed. You can get a peg to the fourth row above the line, but never to the fifth — and the proof assigns every square a weight (a power of the golden ratio, arranged so that a jump never increases the total weight) and shows the target square alone is worth as much as the entire infinite army. It is a monovariant / potential-function argument of the kind taught in an undergraduate combinatorics course (see Aigner's "Moving into the desert with Fibonacci", or the treatment in Berlekamp–Conway–Guy). Related things worth knowing: one-dimensional versions on a strip, peg solitaire on graphs and "pagoda functions" as certificates of impossibility, and the minimum number of pegs needed to reach each row (2, 4, 8, 20).

Materials on hand: plenty of counters/pennies, printed square grids at any size, a couple of checkers sets, paper for recording.

Working directory: `/home/claude/genlab/runs/P/W01/s1` — write the four `.tex` files and their PDFs there.

You are one stage of a fixed pipeline; other stages ran before or will run after you, and none of them can talk to you. Do everything inside the working directory named below and nowhere else. Do not read anything outside your working directory and the template except when this prompt tells you to. When you are finished, write a file named `DONE-<stage>.md` in the working directory containing a summary of at most eight lines (what you produced, anything you could not resolve), and end your final message with that same summary and nothing else.
Stage name: `writer`.
