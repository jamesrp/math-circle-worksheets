#!/usr/bin/env python3
"""Conway's soldiers on the square grid, verified.

Coordinates: (x, y); the army lives on y <= 0; the target is (0, h).
A move: a peg at C jumps over the orthogonal neighbour B into the empty
square A beyond; B is removed.

Potential (Conway): weight of square s = sigma^dist(s, target),
sigma = (sqrt5 - 1)/2, dist = Manhattan distance.  A jump never raises the
total.  We keep weights EXACTLY as a + b*sigma with sigma^2 = 1 - sigma.

Part 1: minimum armies for levels 1..4 (reverse search + potential pruning),
        and the proof that 19 men cannot reach level 4.
Part 2: the potential of the whole half-plane for level 5 is exactly 1,
        and the finite Fibonacci version (deficit 2K+5).
Part 3: how high a full w x h block of men can send a peg (forward search).
Part 4: small 2-D solitaire boards: solvable from which single hole?
Run: python3 verify_2d.py
"""
import sys
from itertools import combinations
sys.setrecursionlimit(10000)

SIG = (5 ** 0.5 - 1) / 2

# ---- exact arithmetic in Z[sigma] ------------------------------------
def sig_pow(n):
    a, b = 1, 0                     # sigma^0 = 1
    for _ in range(n):
        a, b = b, a - b             # (a + b s) * s = b + (a - b) s
    return a, b

def val(ab):
    return ab[0] + ab[1] * SIG

def add(p, q):
    return p[0] + q[0], p[1] + q[1]

def sub(p, q):
    return p[0] - q[0], p[1] - q[1]

POW = [sig_pow(n) for n in range(80)]

def weight(s, target):
    d = abs(s[0] - target[0]) + abs(s[1] - target[1])
    return POW[d]

def potential(state, target):
    p = (0, 0)
    for s in state:
        p = add(p, weight(s, target))
    return p

def half_plane_squares_by_distance(h, dmax):
    """all (x,y) with y <= 0 and dist to (0,h) == d, for d <= dmax"""
    out = {}
    for d in range(h, dmax + 1):
        lst = []
        for y in range(0, -(d - h) - 1, -1):
            r = d - (h - y)
            xs = {r, -r}
            for x in sorted(xs):
                lst.append((x, y))
        out[d] = lst
    return out

def max_potential(h, m):
    """largest potential an m-man army in the half-plane can have."""
    byd = half_plane_squares_by_distance(h, h + m + 2)
    tot, left = (0, 0), m
    for d in sorted(byd):
        take = min(left, len(byd[d]))
        for _ in range(take):
            tot = add(tot, POW[d])
        left -= take
        if left == 0:
            break
    return tot

DIRS = [(1, 0), (-1, 0), (0, 1), (0, -1)]

def unjumps(state):
    for (x, y) in state:
        for dx, dy in DIRS:
            b = (x + dx, y + dy)
            c = (x + 2 * dx, y + 2 * dy)
            if b not in state and c not in state:
                yield (x, y), b, c

def canon(state):
    m = frozenset((-x, y) for x, y in state)
    return min(tuple(sorted(state)), tuple(sorted(m)))

def find_army(h, m, cbound, want_all=False, limit=1):
    """Reverse search: from {target} apply <= m-1 un-jumps and land entirely
    in y <= 0.  cbound[y] = lower bound on un-jumps still needed for one peg
    at height y (0 for y <= 0).  Returns list of (army, reverse_moves)."""
    target = (0, h)
    budget = m - 1
    maxpot = max_potential(h, m)
    sols = []
    best = {}

    def lb(state):
        return sum(cbound.get(y, 0) for (_, y) in state if y > 0)

    def rec(state, used, moves):
        if len(sols) >= limit and not want_all:
            return
        if all(y <= 0 for (_, y) in state):
            sols.append((frozenset(state), list(moves)))
            return
        rem = budget - used
        if rem <= 0 or lb(state) > rem:
            return
        key = canon(state)
        if best.get(key, 99) <= used:
            return
        best[key] = used
        for a, b, c in unjumps(state):
            ns = (state - {a}) | {b, c}
            p = potential(ns, target)
            if val(p) > val(maxpot) + 1e-9:
                continue
            moves.append((a, b, c))
            rec(ns, used + 1, moves)
            moves.pop()
            if len(sols) >= limit and not want_all:
                return

    rec(frozenset([target]), 0, [])
    return sols

def forward_moves(state, only_conserving=None):
    """yield (from C, over B, to A, newstate).  If only_conserving is a
    target, only yield jumps toward it (distance pattern d+2, d+1 -> d)."""
    for (x, y) in state:
        for dx, dy in DIRS:
            b = (x + dx, y + dy)
            a = (x + 2 * dx, y + 2 * dy)
            if b in state and a not in state:
                if only_conserving is not None:
                    t = only_conserving
                    dc = abs(x - t[0]) + abs(y - t[1])
                    da = abs(a[0] - t[0]) + abs(a[1] - t[1])
                    if da != dc - 2:
                        continue
                yield (x, y), b, a, (state - {(x, y), b}) | {a}

def replay(army, moves_forward):
    """check a forward move list from an army; return final state or None"""
    st = frozenset(army)
    for c, b, a in moves_forward:
        if c not in st or b not in st or a in st:
            return None
        if not (abs(c[0] - a[0]) + abs(c[1] - a[1]) == 2 and
                (b[0] * 2 == c[0] + a[0]) and (b[1] * 2 == c[1] + a[1])):
            return None
        st = (st - {c, b}) | {a}
    return st

def show(army, h, moves=None, label=""):
    xs = [x for x, _ in army]
    ys = [y for _, y in army]
    x0, x1 = min(xs + [0]), max(xs + [0])
    y0, y1 = min(ys), h
    print(f"  {label}{len(army)} men, target (0,{h}); rows y={y1}..{y0}, "
          f"columns x={x0}..{x1}   ('*' target, 'o' man, '.' empty)")
    for y in range(y1, y0 - 1, -1):
        row = ""
        for x in range(x0, x1 + 1):
            if (x, y) == (0, h):
                row += "* "
            elif (x, y) in army:
                row += "o "
            else:
                row += ". "
        print(f"    y={y:3d} | {row}" + ("  <- line" if y == 0 else ""))
    if moves:
        print("    moves (jumper -> over -> lands):")
        for i, (c, b, a) in enumerate(moves, 1):
            print(f"      {i:2d}. {c} over {b} to {a}")

# ====================================================================
print("=== Part 1: minimum armies ===")
print("sigma =", SIG, "; check sigma^2 + sigma = 1:", abs(SIG * SIG + SIG - 1) < 1e-12)
for h in range(1, 6):
    for m in range(1, 25):
        mp = max_potential(h, m)
        if val(mp) >= 1 - 1e-9:
            print(f"level {h}: the {m} heaviest half-plane squares weigh "
                  f"{val(mp):.6f} (exact {mp[0]} + {mp[1]} sigma); "
                  f"fewer than {m} men weigh < 1 => at least {m} men needed")
            break
print()

cb = {}
armies = {}
for h in (1, 2, 3):
    m = {1: 2, 2: 4, 3: 8}[h]
    sols = find_army(h, m, cb, limit=1)
    assert sols, f"no {m}-man army for level {h}?"
    army, rmoves = sols[0]
    fwd = [(c, b, a) for (a, b, c) in reversed(rmoves)]
    final = replay(army, fwd)
    assert final == frozenset([(0, h)]), final
    armies[h] = (army, fwd)
    cb[h] = m - 1
    show(army, h, fwd, label=f"LEVEL {h}: ")
    # count ALL minimal armies (up to mirror) for the table
    allsols = find_army(h, m, cb, want_all=True, limit=10 ** 9)
    distinct = {canon(a) for a, _ in allsols}
    print(f"    distinct {m}-man armies for level {h} (up to mirror): {len(distinct)}")
    for a in sorted(distinct):
        print("      ", list(a))
    print()

# --- 19 men cannot reach level 4 ------------------------------------
print("Level 4 with 19 men: potential of the 19 heaviest squares is exactly",
      max_potential(4, 19), "= 1, so a 19-man army needs ALL of the 16 squares")
print("at distance <= 7 plus 3 of the 9 at distance 8, and every jump must be a")
print("jump toward the target (the only potential-conserving jump).")
byd = half_plane_squares_by_distance(4, 8)
core = [s for d in range(4, 8) for s in byd[d]]
assert len(core) == 16
ring = byd[8]
assert len(ring) == 9
target = (0, 4)
reached = False
tested = 0
seen_start = set()
total_states = 0
for extra in combinations(ring, 3):
    start = frozenset(core + list(extra))
    if canon(start) in seen_start:
        continue
    seen_start.add(canon(start))
    tested += 1
    assert potential(start, target) == (1, 0)
    stack = [start]
    seen = {start}
    while stack:
        st = stack.pop()
        if target in st:
            reached = True
        for *_, ns in forward_moves(st, only_conserving=target):
            if ns not in seen:
                seen.add(ns)
                stack.append(ns)
    total_states += len(seen)
print(f"  tested {tested} starting armies (84 up to mirror symmetry), "
      f"{total_states} positions in all; target reached: {reached}")
print()

# --- a 20-man army for level 4 ---------------------------------------
cb[4] = 19
sols = find_army(4, 20, cb, limit=1)
assert sols, "no 20-man army found"
army, rmoves = sols[0]
fwd = [(c, b, a) for (a, b, c) in reversed(rmoves)]
final = replay(army, fwd)
assert final == frozenset([(0, 4)]), final
show(army, 4, fwd, label="LEVEL 4: ")
print(f"    potential of this army (target (0,4)): {val(potential(army,(0,4))):.6f}")
print()

# ====================================================================
print("=== Part 2: level 5 and the weight map ===")
# infinite half-plane, target (0,5): sum over rows of sigma^(5-y) * (1 + 2 sigma/(1-sigma))
tot = 0.0
for y in range(0, -400, -1):
    for x in range(-400, 401):
        tot += SIG ** (abs(x) + 5 - y)
print(f"  numeric sum of sigma^dist over a 801x400 chunk of the half-plane: {tot:.9f}")
print("  exact: each row y<=0 contributes sigma^(2 - y)... total sigma^2/(1-sigma) = 1")
print("  row y=0 alone:", sum(SIG ** (abs(x) + 5) for x in range(-400, 401)),
      "= sigma^2 =", SIG ** 2)

FIB = [0, 1]
while len(FIB) < 60:
    FIB.append(FIB[-1] + FIB[-2])
print("  Fibonacci diamond: target weight F_N, square at distance d weighs F_(N-d);")
print("  army = half-plane squares with d <= N; K = N - 5.")
print("  N  K  army squares  army sum  F_N  deficit  2K+5")
ok = True
for N in range(5, 36):
    K = N - 5
    ssum = sum((2 * mm + 1) * FIB[K - mm] for mm in range(0, K + 1))
    nsq = sum(2 * mm + 1 for mm in range(0, K + 1))
    ok &= (FIB[N] - ssum == 2 * K + 5)
    if N in (5, 6, 7, 8, 9, 10, 12, 15, 20, 30, 35):
        print(f"  {N:2d} {K:2d} {nsq:5d}       {ssum:9d} {FIB[N]:9d} {FIB[N]-ssum:6d} {2*K+5:5d}")
print("  deficit == 2K+5 for all N in 5..35:", ok)

# Fibonacci rule check on the diamond board of radius N around the target
def fib_rule_ok(N):
    """every jump on the diamond {dist <= N} keeps or lowers sum of F_(N-d)"""
    t = (0, 0)
    sq = [(x, y) for x in range(-N, N + 1) for y in range(-N, N + 1)
          if abs(x) + abs(y) <= N]
    S = set(sq)
    W = {s: FIB[N - abs(s[0]) - abs(s[1])] for s in sq}
    for (x, y) in sq:
        for dx, dy in DIRS:
            b = (x + dx, y + dy)
            a = (x + 2 * dx, y + 2 * dy)
            if b in S and a in S:
                if W[a] > W[(x, y)] + W[b]:
                    return False
    return True
print("  jump rule (F_(N-d) never increases) holds on diamonds N=5..20:",
      all(fib_rule_ok(N) for N in range(5, 21)))

# printable weight map for N = 10 (target (0,5)), rows 5 .. -5
N = 10
print(f"  Weight map, N={N}: rows y=5 (target) down to y=-5, columns x=-5..5,")
print("  entries F_(N - dist); blanks are outside the diamond (dist > N)")
for y in range(5, -6, -1):
    row = []
    for x in range(-5, 6):
        d = abs(x) + abs(5 - y)
        row.append(f"{FIB[N-d]:3d}" if d <= N else "  .")
    print(f"   y={y:2d} |" + "".join(row) + ("   <- line" if y == 0 else ""))
army_sum = sum(FIB[N - (abs(x) + 5 - y)] for x in range(-N, N + 1)
               for y in range(0, -N, -1) if abs(x) + 5 - y <= N)
print(f"  sum over the {sum(2*m+1 for m in range(0, N-4))} army squares = {army_sum};"
      f" target = F_{N} = {FIB[N]}")
print()

# ====================================================================
print("=== Part 3: full w x h blocks of men: highest row reached ===")
def block_max_level(w, hgt, cap=3_000_000):
    start = frozenset((x, y) for x in range(w) for y in range(0, -hgt, -1))
    seen = {start}
    stack = [start]
    best = 0
    while stack:
        st = stack.pop()
        for *_, ns in forward_moves(st):
            if ns not in seen:
                seen.add(ns)
                stack.append(ns)
                top = max(y for _, y in ns)
                if top > best:
                    best = top
                if len(seen) > cap:
                    return best, len(seen), False
    return best, len(seen), True

for (w, hgt) in [(2, 1), (3, 1), (4, 1), (1, 3), (2, 2), (3, 2), (2, 3), (4, 2),
                 (3, 3), (5, 2), (4, 3), (3, 4), (5, 3), (4, 4), (6, 3), (5, 4)]:
    best, n, complete = block_max_level(w, hgt)
    print(f"  block {w} wide x {hgt} deep ({w*hgt} men): highest row {best}; "
          f"{n} positions explored{'' if complete else ' (CAPPED, lower bound only)'}")
print()

# ====================================================================
print("=== Part 4: small 2-D solitaire boards, one hole -> one peg? ===")
def board_solvable(squares):
    S = frozenset(squares)
    res = {}
    for hole in sorted(S):
        start = S - {hole}
        seen = {start}
        stack = [start]
        finals = set()
        while stack:
            st = stack.pop()
            if len(st) == 1:
                finals |= st
            for (x, y) in st:
                for dx, dy in DIRS:
                    b = (x + dx, y + dy)
                    a = (x + 2 * dx, y + 2 * dy)
                    if b in st and a in S and a not in st:
                        ns = (st - {(x, y), b}) | {a}
                        if ns not in seen:
                            seen.add(ns)
                            stack.append(ns)
        res[hole] = sorted(finals)
    return res

def rect(w, hgt):
    return [(x, y) for x in range(w) for y in range(hgt)]

shapes = {
    "1x3": rect(3, 1), "2x2": rect(2, 2), "2x3": rect(3, 2), "L-tromino": [(0,0),(1,0),(0,1)],
    "T-tetromino": [(0,0),(1,0),(2,0),(1,1)], "plus (5)": [(1,0),(0,1),(1,1),(2,1),(1,2)],
    "2x4": rect(4, 2), "3x3": rect(3, 3), "3x4": rect(4, 3), "2x5": rect(5, 2),
    "4x4": rect(4, 4), "3x5": rect(5, 3), "4x5": rect(5, 4), "2x6": rect(6, 2),
    "3x3 plus one below middle": rect(3, 3) + [(1, -1)],
    "3x3 plus one at each side (cross 13)": rect(3, 3) + [(1, -1), (1, 3), (-1, 1), (3, 1)],
    "3x3 minus a corner (8)": [s for s in rect(3, 3) if s != (2, 2)],
    "2x3 plus one (7) 'P'": rect(3, 2) + [(0, 2)],
    "4x3 minus corners (10)": [s for s in rect(4, 3) if s not in [(0,0),(3,0),(0,2),(3,2)]],
    "diamond 13 (radius 2)": [(x, y) for x in range(-2, 3) for y in range(-2, 3) if abs(x)+abs(y) <= 2],
    "4x4 minus corners (12)": [s for s in rect(4, 4) if s not in [(0,0),(3,0),(0,3),(3,3)]],
}
for name, sq in shapes.items():
    res = board_solvable(sq)
    good = {h: f for h, f in res.items() if f}
    if good:
        desc = "; ".join(f"hole {h} -> last peg at {f}" for h, f in good.items())
    else:
        desc = "NOT solvable from any hole"
    print(f"  {name} ({len(sq)} squares): {desc}")
