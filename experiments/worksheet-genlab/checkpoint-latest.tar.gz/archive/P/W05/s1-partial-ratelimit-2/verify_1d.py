#!/usr/bin/env python3
"""One-dimensional peg games, exhaustively.

Part A: solitaire on a strip 1..n, all pegs but one hole; can we reach ONE peg?
        For each n and hole: solvable?, where the last peg can end, and the
        size of the full game tree (all cases a child could list).
Part B: 1-D 'soldiers': k pegs on squares 1..k of a long strip, jumps in both
        directions; how far right can any peg ever get?  All reachable
        configurations are listed for small k (case tables) and the
        Fibonacci weight identity is checked on every reachable jump.
Run:  python3 verify_1d.py
"""
from functools import lru_cache
from itertools import count

# ---------------------------------------------------------------- Part A
def moves_1d(pegs, n):
    """pegs: frozenset of occupied squares in 1..n.  Yield (from, over, to, new)."""
    for p in pegs:
        for d in (1, -1):
            o, t = p + d, p + 2 * d
            if 1 <= t <= n and o in pegs and t not in pegs:
                yield p, o, t, (pegs - {p, o}) | {t}

def analyse_solitaire(n, hole):
    start = frozenset(range(1, n + 1)) - {hole}
    finals = set()          # squares where a single last peg can end
    seen = {}
    stack = [start]
    while stack:
        s = stack.pop()
        if s in seen:
            continue
        seen[s] = True
        if len(s) == 1:
            finals |= s
        for *_, t in moves_1d(s, n):
            if t not in seen:
                stack.append(t)
    return finals, len(seen)

def tree_size(n, hole):
    """number of nodes in the full game tree (sequences, not positions) and
    number of distinct leaves; small enough to draw for n <= 6."""
    start = frozenset(range(1, n + 1)) - {hole}
    nodes = 0
    stuck = []
    def rec(s):
        nonlocal nodes
        nodes += 1
        ms = list(moves_1d(s, n))
        if not ms:
            stuck.append(len(s))
        for *_, t in ms:
            rec(t)
    rec(start)
    return nodes, stuck

print("=== Part A: 1-D solitaire, strip 1..n, one hole, goal one peg ===")
print("n | holes that work -> where last peg may end | positions reachable")
solv = {}
for n in range(1, 13):
    row = []
    for hole in range(1, n + 1):
        finals, npos = analyse_solitaire(n, hole)
        if finals:
            row.append(f"hole {hole} -> ends at {sorted(finals)}")
    solv[n] = row
    print(f"{n:2d} | " + ("; ".join(row) if row else "NONE"))
print()
print("Game trees (all move sequences) for the small strips a child can draw:")
for n in (3, 4, 5, 6):
    for hole in range(1, n // 2 + 1 + (n % 2)):
        nodes, stuck = tree_size(n, hole)
        print(f"  1x{n}, hole at {hole}: {nodes} positions in the tree, "
              f"dead ends leave {sorted(set(stuck))} pegs "
              f"(min {min(stuck)})")
print()

# explicit move list for the solvable 1x6 cases, for the guide
def one_solution(n, hole):
    start = frozenset(range(1, n + 1)) - {hole}
    path = []
    def rec(s):
        if len(s) == 1:
            return True
        for f, o, t, ns in moves_1d(s, n):
            path.append((f, o, t))
            if rec(ns):
                return True
            path.pop()
        return False
    ok = rec(start)
    return path if ok else None

for n in (3, 4, 6, 7, 9, 10):
    for hole in range(1, n + 1):
        sol = one_solution(n, hole)
        if sol:
            print(f"  1x{n} hole {hole}: " +
                  ", ".join(f"{f}>{o}>{t}" for f, o, t in sol) +
                  f"  (last peg at {sol[-1][2]})")
print()

# ---------------------------------------------------------------- Part B
def soldiers_1d(k, room=6):
    """k pegs on 1..k, strip 1-room .. k+room; explore everything."""
    lo, hi = 1 - room, k + room
    start = frozenset(range(1, k + 1))
    seen = {start}
    stack = [start]
    best = k
    while stack:
        s = stack.pop()
        best = max(best, max(s))
        for p in s:
            for d in (1, -1):
                o, t = p + d, p + 2 * d
                if lo <= t <= hi and o in s and t not in s:
                    ns = (s - {p, o}) | {t}
                    if ns not in seen:
                        seen.add(ns)
                        stack.append(ns)
    return best, seen

FIB = [0, 1]
while len(FIB) < 40:
    FIB.append(FIB[-1] + FIB[-2])

print("=== Part B: 1-D soldiers, k pegs on squares 1..k, jumps both ways ===")
print("k | farthest square any peg ever reaches | reachable positions | "
      "Fib weight of start (sum F_1..F_k) | F_(k+2) = weight of square k+2")
for k in range(1, 9):
    best, seen = soldiers_1d(k)
    w = sum(FIB[i] for i in range(1, k + 1))
    print(f"{k} | {best} | {len(seen)} | {w} | {FIB[k+2]}")
print()
print("All reachable positions for k = 3 and k = 4 (pegs listed by square):")
for k in (3, 4):
    best, seen = soldiers_1d(k)
    for s in sorted(seen, key=lambda s: (len(s), sorted(s)), reverse=True):
        print(f"  k={k}: {sorted(s)}")
print()

# Fibonacci weight check on every jump reachable from k=1..8:
# weight(square x) = F_x  (F_1 = 1, F_2 = 1, F_3 = 2, ...), for x >= 1;
# we extend to x <= 0 by the recurrence backwards: F_0=0, F_-1=1, F_-2=-1...
# so we only assert the rule on jumps whose three squares are >= 1.
def F(x):
    if x >= 0:
        return FIB[x]
    # negafibonacci
    return (-1) ** (1 - x) * FIB[-x]

bad = 0
for k in range(2, 9):
    best, seen = soldiers_1d(k)
    for s in seen:
        for p in s:
            for d in (1, -1):
                o, t = p + d, p + 2 * d
                if min(p, o, t) >= 1 and o in s and t not in s:
                    before = F(p) + F(o)
                    after = F(t)
                    if d == 1 and after != before:
                        bad += 1
                    if d == -1 and after >= before:
                        bad += 1
print("Fibonacci-weight rule (right jump keeps total, left jump lowers it):",
      "violations =", bad)
print("F_1+...+F_k = F_(k+2) - 1 for k=1..12:",
      all(sum(FIB[1:k + 1]) == FIB[k + 2] - 1 for k in range(1, 13)))
