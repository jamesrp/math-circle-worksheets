#!/usr/bin/env python3
"""Verification for the one-dimensional (strip) problems in bank.md.

A strip has cells 1..L.  A peg jumps over an orthogonally adjacent peg into the
empty cell directly beyond it (staying on the strip); the jumped peg is removed.
Positions are frozensets of occupied cells.
"""
from functools import lru_cache
from itertools import combinations

def moves(pos, L):
    out = []
    for a in pos:
        for d in (-1, 1):
            b, c = a + d, a + 2 * d
            if 1 <= c <= L and b in pos and c not in pos:
                out.append((a, b, c))
    return out

def apply(pos, m):
    a, b, c = m
    return (pos - {a, b}) | {c}

def reach(pos, L):
    """All positions reachable from pos (including pos)."""
    seen = {pos}
    stack = [pos]
    while stack:
        p = stack.pop()
        for m in moves(p, L):
            q = apply(p, m)
            if q not in seen:
                seen.add(q)
                stack.append(q)
    return seen

def stuck_positions(pos, L):
    return {p for p in reach(pos, L) if not moves(p, L)}

def summary(pos, L):
    st = stuck_positions(pos, L)
    counts = sorted({len(p) for p in st})
    singles = sorted(next(iter(p)) for p in st if len(p) == 1)
    return counts, singles

def solution(pos, L, goal=lambda p: len(p) == 1):
    """One move sequence reaching a goal position, by DFS."""
    seen = set()
    def dfs(p, path):
        if goal(p):
            return path
        if p in seen:
            return None
        seen.add(p)
        for m in moves(p, L):
            r = dfs(apply(p, m), path + [m])
            if r is not None:
                return r
        return None
    return dfs(pos, [])

def fmt(pos, L):
    return "".join("o" if i in pos else "." for i in range(1, L + 1))

print("=== 1. Strip solitaire: leftover counts and single-peg finishes ===")
cases = [
    (3, {1, 2}), (4, {1, 2, 3}), (4, {1, 2, 4}), (4, {1, 3, 4}), (4, {2, 3, 4}),
    (5, {1, 2, 3, 4}), (5, {1, 2, 3, 5}), (5, {1, 2, 4, 5}), (5, {1, 3, 4, 5}), (5, {2, 3, 4, 5}),
    (6, {1, 2, 4, 6}), (6, {1, 2, 4, 5}), (6, {1, 2, 3, 5}), (6, {1, 3, 4, 6}), (6, {2, 3, 5, 6}),
    (6, {1, 2, 3, 4, 5}), (6, {1, 2, 3, 4, 6}), (6, {1, 2, 3, 5, 6}), (6, {1, 2, 4, 5, 6}), (6, {1, 3, 4, 5, 6}), (6, {2, 3, 4, 5, 6}),
    (7, {1, 2, 3, 5, 6, 7}), (7, {1, 2, 4, 5, 6, 7}), (7, {1, 2, 3, 4, 5, 6}), (7, {1, 2, 3, 4, 6, 7}),
    (8, {1, 2, 3, 4, 5, 6, 7}), (8, {1, 2, 3, 5, 6, 7, 8}), (8, {1, 2, 3, 4, 6, 7, 8}),
]
for L, pos in cases:
    pos = frozenset(pos)
    counts, singles = summary(pos, L)
    sol = solution(pos, L)
    print(f"L={L} {fmt(pos, L)}  stuck-with counts={counts}  single-peg cells={singles}  "
          f"one solution={sol}")

print()
print("=== 1b. All 4-peg starts on a 6-strip that can end with one peg ===")
L = 6
for pos in combinations(range(1, L + 1), 4):
    pos = frozenset(pos)
    counts, singles = summary(pos, L)
    if 1 in counts:
        print(f"  {fmt(pos, L)} -> single peg at {singles}; solution {solution(pos, L)}")
print("  (all other 4-peg starts on the 6-strip cannot reach one peg)")
print("=== 1c. All 3-peg starts on a 5-strip ===")
L = 5
for pos in combinations(range(1, L + 1), 3):
    pos = frozenset(pos)
    counts, singles = summary(pos, L)
    print(f"  {fmt(pos, L)} -> leftover counts {counts}; single at {singles}")

print()
print("=== 1d. 'Full strip minus one hole': can it end with one peg? ===")
for L in range(3, 10):
    res = []
    for hole in range(1, L + 1):
        pos = frozenset(set(range(1, L + 1)) - {hole})
        counts, singles = summary(pos, L)
        res.append((hole, min(counts), singles))
    print(f"  L={L}: (hole, fewest leftover, single-peg cells) = {res}")

print()
print("=== 1e. Three-colouring parity check on the strip ===")
def colour_parities(pos):
    cnt = [0, 0, 0]
    for x in pos:
        cnt[x % 3] += 1
    return tuple(c % 2 for c in cnt)
bad = 0
L = 8
for k in range(1, 8):
    for pos in combinations(range(1, L + 1), k):
        pos = frozenset(pos)
        par = colour_parities(pos)
        if par in [(0, 0, 0), (1, 1, 1)]:
            counts, singles = summary(pos, L)
            if 1 in counts:
                bad += 1
print(f"  starts with all three colour-counts of equal parity that still reach one peg (L=8, k<=7): {bad} (expect 0)")

print()
print("=== 2. The 1-D army: pegs in cells 1..n, how far right can a peg get? ===")
for n in range(1, 11):
    L = n + 6
    pos = frozenset(range(1, n + 1))
    best = max(max(p) for p in reach(pos, L))
    print(f"  n={n}: farthest cell ever occupied = {best} (line is after cell {n}; so {best - n} past the line)")

print()
print("=== 2b. Fibonacci weights on a strip: sums of the army versus the flag ===")
fib = [0, 1]
while len(fib) < 20:
    fib.append(fib[-1] + fib[-2])
for n in range(2, 9):
    # flag at distance 0 has weight F_{n+3}; army occupies distances 2..n+1
    m = n + 3
    flag = fib[m]
    army = [fib[m - d] for d in range(2, n + 2)]
    print(f"  army of {n}: flag={flag}, army weights={army}, sum={sum(army)}  (flag - sum = {flag - sum(army)})")

print()
print("=== 2c. Weight never increases under any jump (strip of 9, flag at cell 9, weights F) ===")
L = 9
w = {cell: fib[L + 2 - (L - cell)] for cell in range(1, L + 1)}  # cell 9 -> F_11? no: distance d=9-cell -> F_{m-d}
m = 11
w = {cell: fib[m - (L - cell)] for cell in range(1, L + 1)}
print("  weights by cell:", [w[c] for c in range(1, L + 1)])
viol = 0
for k in range(2, 6):
    for pos in combinations(range(1, L + 1), k):
        pos = frozenset(pos)
        before = sum(w[c] for c in pos)
        for mv in moves(pos, L):
            after = sum(w[c] for c in apply(pos, mv))
            if after > before:
                viol += 1
print(f"  violations found: {viol} (expect 0)")
