#!/usr/bin/env python3
"""Verification for the small-board solitaire problems in bank.md.

A board is a set of cells (x, y).  A jump moves a peg from a over an adjacent
occupied b into the empty c beyond, where a, b, c are three cells in a row
(orthogonal), and removes the peg at b.  Graph boards are handled by listing
the allowed (a, b, c) triples explicitly.
"""
from collections import deque
from itertools import combinations

def rect(w, h):
    return [(x, y) for y in range(h) for x in range(w)]

def triples_grid(cells):
    idx = {c: i for i, c in enumerate(cells)}
    tr = []
    for (x, y) in cells:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            b, c = (x + dx, y + dy), (x + 2 * dx, y + 2 * dy)
            if b in idx and c in idx:
                tr.append((idx[(x, y)], idx[b], idx[c]))
    return tr

def analyse(n, triples, start):
    """start: bitmask.  Returns (min leftover, set of single-peg finishing cells,
    number of reachable positions, set of possible leftover counts)."""
    seen = {start}
    dq = deque([start])
    stuck_counts = set()
    singles = set()
    while dq:
        p = dq.popleft()
        moved = False
        for a, b, c in triples:
            if (p >> a) & 1 and (p >> b) & 1 and not (p >> c) & 1:
                moved = True
                q = (p & ~(1 << a) & ~(1 << b)) | (1 << c)
                if q not in seen:
                    seen.add(q)
                    dq.append(q)
        if not moved:
            k = bin(p).count("1")
            stuck_counts.add(k)
            if k == 1:
                singles.add(p.bit_length() - 1)
    return min(stuck_counts), singles, len(seen), stuck_counts

def solve_path(n, triples, start, goal_pred):
    """A move sequence (list of (a,b,c) cell indices) to a position satisfying goal_pred."""
    parent = {start: None}
    dq = deque([start])
    while dq:
        p = dq.popleft()
        if goal_pred(p):
            path = []
            while parent[p] is not None:
                q, m = parent[p]
                path.append(m)
                p = q
            return path[::-1]
        for a, b, c in triples:
            if (p >> a) & 1 and (p >> b) & 1 and not (p >> c) & 1:
                q = (p & ~(1 << a) & ~(1 << b)) | (1 << c)
                if q not in parent:
                    parent[q] = (p, (a, b, c))
                    dq.append(q)
    return None

def report_board(name, cells, holes=None):
    n = len(cells)
    tr = triples_grid(cells)
    full = (1 << n) - 1
    print(f"--- {name}: {n} cells ---")
    holes = holes if holes is not None else cells
    for h in holes:
        start = full & ~(1 << cells.index(h))
        mn, singles, nreach, counts = analyse(n, tr, start)
        sc = sorted(cells[i] for i in singles)
        print(f"  hole {h}: fewest leftover {mn}; possible leftovers {sorted(counts)}; single-peg finish cells {sc}; reachable positions {nreach}")

print("=== 3. Rectangular boards, full minus one hole ===")
report_board("2x2", rect(2, 2), holes=[(0, 0)])
report_board("2x3", rect(3, 2), holes=[(0, 0), (1, 0)])
report_board("2x4", rect(4, 2), holes=[(0, 0), (1, 0)])
report_board("2x5", rect(5, 2), holes=[(0, 0), (1, 0), (2, 0)])
report_board("2x6", rect(6, 2), holes=[(0, 0), (1, 0), (2, 0)])
report_board("3x3", rect(3, 3), holes=[(0, 0), (1, 0), (1, 1)])
report_board("3x4", rect(4, 3), holes=[(0, 0), (1, 0), (0, 1), (1, 1)])
report_board("3x5", rect(5, 3), holes=[(0, 0), (1, 0), (2, 0), (0, 1), (1, 1), (2, 1)])
report_board("4x4", rect(4, 4), holes=[(0, 0), (1, 0), (1, 1)])

print()
print("=== 3b. 3x3 board: a few other starts ===")
cells = rect(3, 3)
tr = triples_grid(cells)
def mask(cs):
    return sum(1 << cells.index(c) for c in cs)
starts = {
    "3x3 with two holes: centre and a corner": [(1, 0), (2, 0), (0, 1), (2, 1), (0, 2), (1, 2), (2, 2)],
    "3x3 with two holes: centre and an edge": [(0, 0), (2, 0), (0, 1), (2, 1), (0, 2), (1, 2), (2, 2)],
    "3x3 with two holes: two opposite corners": [(1, 0), (2, 0), (0, 1), (1, 1), (2, 1), (0, 2), (1, 2)],
    "3x3 with two holes: two adjacent corners": [(0, 1), (1, 1), (2, 1), (0, 2), (1, 2), (2, 2), (1, 0)],
    "3x3 plus sign (5 pegs) hole at arm": [(1, 1), (0, 1), (2, 1), (1, 2)],
    "3x3 X shape (5 pegs) full": [(0, 0), (2, 0), (1, 1), (0, 2), (2, 2)],
    "3x3 ring (8 pegs, centre empty)": [(0, 0), (1, 0), (2, 0), (0, 1), (2, 1), (0, 2), (1, 2), (2, 2)],
}
for name, cs in starts.items():
    mn, singles, nreach, counts = analyse(9, tr, mask(cs))
    print(f"  {name}: fewest leftover {mn}; leftovers {sorted(counts)}; single at {sorted(cells[i] for i in singles)}")
    p = solve_path(9, tr, mask(cs), lambda p: bin(p).count('1') == mn)
    print(f"      one best line of play: {[(cells[a], cells[b], cells[c]) for a, b, c in p]}")

print()
print("=== 3c. Best lines of play for the boards we print ===")
def show(name, cells, hole):
    n = len(cells); tr = triples_grid(cells)
    start = ((1 << n) - 1) & ~(1 << cells.index(hole))
    mn, singles, nreach, counts = analyse(n, tr, start)
    p = solve_path(n, tr, start, lambda p: bin(p).count('1') == mn)
    print(f"  {name}, hole {hole}: fewest leftover {mn}; a best line: {[(cells[a], cells[b], cells[c]) for a, b, c in p]}")
show("2x3", rect(3, 2), (0, 0))
show("2x3", rect(3, 2), (1, 0))
show("2x4", rect(4, 2), (1, 0))
show("2x4", rect(4, 2), (0, 0))
show("2x5", rect(5, 2), (1, 0))
show("3x3", rect(3, 3), (0, 0))
show("3x3", rect(3, 3), (1, 0))
show("3x4", rect(4, 3), (1, 1))
show("3x4", rect(4, 3), (0, 0))
show("3x4", rect(4, 3), (1, 0))
show("4x4", rect(4, 4), (1, 1))
show("4x4", rect(4, 4), (0, 0))

print()
print("=== 3d. Pentomino / small shape boards, every hole ===")
shapes = {
    "T (3 across, stem of 2 below middle)": [(0, 0), (1, 0), (2, 0), (1, 1), (1, 2)],
    "plus (5 cells)": [(1, 0), (0, 1), (1, 1), (2, 1), (1, 2)],
    "L (3 down, 3 across sharing corner)": [(0, 0), (0, 1), (0, 2), (1, 2), (2, 2)],
    "3x3 plus four arms (13 cells)": rect(3, 3) + [(1, -1), (1, 3), (-1, 1), (3, 1)],
    "3x3 plus two opposite arms (11 cells)": rect(3, 3) + [(1, -1), (1, 3)],
    "H (7 cells)": [(0, 0), (0, 1), (0, 2), (1, 1), (2, 0), (2, 1), (2, 2)],
    "staircase 6": [(0, 0), (1, 0), (2, 0), (1, 1), (2, 1), (2, 2)],
}
for name, cells in shapes.items():
    report_board(name, cells)

print()
print("=== 4. Peg solitaire on graphs (dots and lines) ===")
def triples_graph(nv, edges):
    adj = {v: set() for v in range(nv)}
    for u, v in edges:
        adj[u].add(v); adj[v].add(u)
    tr = []
    for a in range(nv):
        for b in adj[a]:
            for c in adj[b]:
                if c != a:
                    tr.append((a, b, c))
    return tr
def report_graph(name, nv, edges):
    tr = triples_graph(nv, edges)
    full = (1 << nv) - 1
    res = []
    for h in range(nv):
        mn, singles, nreach, counts = analyse(nv, tr, full & ~(1 << h))
        res.append((h, mn, sorted(singles)))
    print(f"  {name}: (hole, fewest leftover, single-finish vertices) = {res}")
def cycle(n): return n, [(i, (i + 1) % n) for i in range(n)]
def path(n): return n, [(i, i + 1) for i in range(n - 1)]
def star(n): return n + 1, [(0, i) for i in range(1, n + 1)]
def complete(n): return n, [(i, j) for i in range(n) for j in range(i + 1, n)]
for n in range(3, 9):
    report_graph(f"cycle C{n}", *cycle(n))
for n in range(3, 8):
    report_graph(f"star with {n} leaves", *star(n))
report_graph("K4", *complete(4))
report_graph("K5", *complete(5))
report_graph("bowtie (two triangles sharing a vertex)", 5, [(0, 1), (1, 2), (2, 0), (0, 3), (3, 4), (4, 0)])
report_graph("house (square + roof)", 5, [(0, 1), (1, 2), (2, 3), (3, 0), (0, 4), (1, 4)])
report_graph("cube Q3", 8, [(0, 1), (1, 2), (2, 3), (3, 0), (4, 5), (5, 6), (6, 7), (7, 4), (0, 4), (1, 5), (2, 6), (3, 7)])
report_graph("K_{2,3}", 5, [(0, 2), (0, 3), (0, 4), (1, 2), (1, 3), (1, 4)])
report_graph("triangle with a tail (4 vertices)", 4, [(0, 1), (1, 2), (2, 0), (2, 3)])
report_graph("C4 with a diagonal", 4, [(0, 1), (1, 2), (2, 3), (3, 0), (0, 2)])
report_graph("C6 with one long diagonal", 6, [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 0), (0, 3)])
report_graph("hexagon with centre (wheel W6)", 7, [(i, (i % 6) + 1) for i in range(1, 7)] + [(0, i) for i in range(1, 7)])

print()
print("=== 5. Counting facts: number of jumps equals pegs removed ===")
cells = rect(3, 3); tr = triples_grid(cells)
start = ((1 << 9) - 1) & ~(1 << cells.index((0, 0)))
mn = analyse(9, tr, start)[0]
p = solve_path(9, tr, start, lambda p: bin(p).count('1') == mn)
print(f"  3x3 hole at corner: 8 pegs, best line has {len(p)} jumps and leaves {8 - len(p)} pegs (fewest leftover {mn})")
