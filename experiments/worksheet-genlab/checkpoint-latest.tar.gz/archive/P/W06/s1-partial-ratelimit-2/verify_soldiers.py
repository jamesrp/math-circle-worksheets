#!/usr/bin/env python3
"""Verification for the Conway's Soldiers problems in bank.md (rows 1-3, weights).

Coordinates: (x, y).  The line runs between row 0 and row 1; the army starts
in rows y <= 0.  A jump moves a peg two cells orthogonally over an adjacent
peg into an empty cell; the jumped peg is removed.  Target for row r: (0, r).

Part A: exact weight sums in Z[sigma], sigma = (sqrt5 - 1)/2, sigma^2 = 1 - sigma.
Part B: integer Fibonacci weights as printed for children (finite board).
Part C: exhaustive reverse search for the minimum army for rows 1, 2, 3.
Part D (in verify_row4.py): a 20-peg army for row 4, and why 19 cannot work.
"""
import sys
from collections import deque
from itertools import combinations

sys.setrecursionlimit(10000)

# ---------- Part A: exact arithmetic in Z[sigma] ----------
class Zs:
    """a + b*sigma with integer a, b; sigma^2 = 1 - sigma."""
    def __init__(self, a, b=0):
        self.a, self.b = a, b
    def __add__(self, o):
        return Zs(self.a + o.a, self.b + o.b)
    def __mul__(self, o):
        # (a + b s)(c + d s) = ac + (ad + bc) s + bd s^2 = ac + bd + (ad + bc - bd) s
        return Zs(self.a * o.a + self.b * o.b, self.a * o.b + self.b * o.a - self.b * o.b)
    def value(self):
        return self.a + self.b * (5 ** 0.5 - 1) / 2
    def __repr__(self):
        return f"{self.a} + {self.b}*sigma  (~{self.value():.6f})"

def sigma_pow(k):
    r = Zs(1)
    for _ in range(k):
        r = r * Zs(0, 1)
    return r

print("=== A. Golden-ratio weights: sum of the k best cells below the line, target row r ===")
def cells_below_sorted(r, radius=12):
    cells = [(x, y) for x in range(-radius, radius + 1) for y in range(-radius, 1)]
    cells.sort(key=lambda c: abs(c[0]) + (r - c[1]))
    return cells
for r in range(1, 6):
    cells = cells_below_sorted(r)
    for k in [1, 2, 3, 4, 7, 8, 18, 19, 20]:
        tot = Zs(0)
        for (x, y) in cells[:k]:
            tot = tot + sigma_pow(abs(x) + (r - y))
        print(f"  row {r}, best {k:2d} cells: {tot}")
    print()
print("  Distances of the best cells for row 4 (Manhattan distance to (0,4)):",
      [abs(x) + (4 - y) for (x, y) in cells_below_sorted(4)[:20]])
print("  Whole half-plane, target row 5: sum over d>=5 of (2d-9) sigma^d = 1 exactly (classical);")
tot = 0.0
s = (5 ** 0.5 - 1) / 2
for d in range(5, 400):
    tot += (2 * d - 9) * s ** d
print(f"  numerically the sum to d<400 is {tot:.12f}")

# ---------- Part B: integer Fibonacci weights on the printed boards ----------
print()
print("=== B. Integer Fibonacci weights on a finite board ===")
fib = [0, 1]
while len(fib) < 40:
    fib.append(fib[-1] + fib[-2])

def check_board(cols, rows, target, m):
    """Cells x in cols, y in rows.  Weight = F_{m - d}, d = Manhattan distance to target.
    Checks every jump is weight-non-increasing; returns the best-k sums below the line."""
    cells = [(x, y) for x in cols for y in rows]
    dmax = max(abs(x - target[0]) + abs(y - target[1]) for (x, y) in cells)
    assert dmax <= m - 1, "weights would hit F_0"
    w = {c: fib[m - (abs(c[0] - target[0]) + abs(c[1] - target[1]))] for c in cells}
    cs = set(cells)
    viol = 0
    for (x, y) in cells:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            b, c = (x + dx, y + dy), (x + 2 * dx, y + 2 * dy)
            if b in cs and c in cs:
                if w[c] > w[(x, y)] + w[b]:
                    viol += 1
    below = sorted((w[c] for c in cells if c[1] <= 0), reverse=True)
    return w, viol, below

w, viol, below = check_board(range(-2, 3), range(-2, 3), (0, 2), 7)
print(f"  Row-2 board 5 wide, rows -2..2, target (0,2), flag weight F_7={fib[7]}: jump violations {viol}; "
      f"best 3 below line sum {sum(below[:3])} = {below[:3]}; best 4 sum {sum(below[:4])}")
w, viol, below = check_board(range(-2, 3), range(-2, 4), (0, 3), 8)
print(f"  Row-3 board 5 wide, rows -2..3, target (0,3), flag weight F_8={fib[8]}: jump violations {viol}; "
      f"best 7 below line sum {sum(below[:7])} = {below[:7]}; best 8 sum {sum(below[:8])}")
w, viol, below = check_board(range(-3, 4), range(-3, 4), (0, 3), 10)
print(f"  Row-3 board 7 wide, rows -3..3, target (0,3), flag weight F_10={fib[10]}: jump violations {viol}; "
      f"best 7 below line sum {sum(below[:7])}; best 8 sum {sum(below[:8])}")
print("  Row-3 board 5 wide weights, printed by row (top row = row 3):")
for y in range(3, -3, -1):
    print("    ", [w2 for w2 in (check_board(range(-2, 3), range(-2, 4), (0, 3), 8)[0][(x, y)] for x in range(-2, 3))])

# ---------- Part C: exhaustive reverse search for rows 1..3 ----------
print()
print("=== C. Minimum armies for rows 1, 2, 3 by exhaustive reverse search ===")
DIRS = ((1, 0), (-1, 0), (0, 1), (0, -1))

def reverse_moves(S):
    """Yield states obtained by un-jumping one peg of S."""
    for (x, y) in S:
        for dx, dy in DIRS:
            b, a = (x - dx, y - dy), (x - 2 * dx, y - 2 * dy)
            if a not in S and b not in S:
                yield (S - {(x, y)}) | {a, b}

def canonical(S):
    m = frozenset((-x, y) for (x, y) in S)
    return min(S, m, key=lambda t: sorted(t))

def all_armies(r, maxpegs):
    """All armies of at most maxpegs pegs, all below the line, from which (0,r) is reachable
    (with the target's column fixed at 0).  Exhaustive within maxpegs."""
    start = frozenset([(0, r)])
    seen = {canonical(start)}
    frontier = [start]
    found = {}
    for depth in range(1, maxpegs):
        nxt = []
        for S in frontier:
            for T in reverse_moves(S):
                c = canonical(T)
                if c in seen:
                    continue
                seen.add(c)
                nxt.append(T)
                if all(y <= 0 for (_, y) in T):
                    found.setdefault(len(T), []).append(c)
        frontier = nxt
    return found, len(seen)

for r, maxp in [(1, 4), (2, 6), (3, 9)]:
    found, n = all_armies(r, maxp)
    ks = sorted(found)
    print(f"  row {r}: searched all reverse sequences up to {maxp - 1} un-jumps ({n} states); "
          f"army sizes that work: {ks}; minimum = {ks[0] if ks else None}")
    if ks:
        k = ks[0]
        arm = sorted({canonical(a) for a in found[k]}, key=lambda t: sorted(t))
        print(f"    number of distinct minimum armies (up to mirror): {len(arm)}")
        for a in arm[:6]:
            print("     ", sorted(a, key=lambda c: (-c[1], c[0])))

# forward play to produce an explicit move list
def forward_solve(army, target):
    """BFS forward from army until a peg sits on target.  Returns move list."""
    start = frozenset(army)
    parent = {start: None}
    dq = deque([start])
    while dq:
        S = dq.popleft()
        if target in S:
            path = []
            while parent[S] is not None:
                P, m = parent[S]
                path.append(m)
                S = P
            return path[::-1]
        for (x, y) in S:
            for dx, dy in DIRS:
                b, c = (x + dx, y + dy), (x + 2 * dx, y + 2 * dy)
                if b in S and c not in S:
                    T = (S - {(x, y), b}) | {c}
                    if T not in parent:
                        parent[T] = (S, ((x, y), b, c))
                        dq.append(T)
    return None

print()
print("=== C2. Explicit solutions (forward play) ===")
L_army = [(0, 0), (0, -1), (1, 0), (2, 0)]
print("  row 2 with 4 pegs", L_army, "->", forward_solve(L_army, (0, 2)))
found3, _ = all_armies(3, 9)
army8 = sorted(found3[8][0], key=lambda c: (-c[1], c[0]))
print("  row 3 with 8 pegs", army8, "->", forward_solve(army8, (0, 3)))
# a second, different 8-army if there is one
arm8 = sorted({canonical(a) for a in found3[8]}, key=lambda t: sorted(t))
for a in arm8[1:3]:
    a = sorted(a, key=lambda c: (-c[1], c[0]))
    print("  another 8-army", a, "->", forward_solve(a, (0, 3)))

def simulate(army, moves, target):
    S = set(army)
    for (a, b, c) in moves:
        assert a in S and b in S and c not in S, (a, b, c)
        assert abs(a[0] - b[0]) + abs(a[1] - b[1]) == 1 and (2 * b[0] - a[0], 2 * b[1] - a[1]) == c
        S -= {a, b}; S.add(c)
    return target in S

# Part D (row 4) lives in verify_row4.py, which imports this module.
