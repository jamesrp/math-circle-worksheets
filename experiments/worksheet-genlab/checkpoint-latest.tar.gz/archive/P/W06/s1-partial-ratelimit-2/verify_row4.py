#!/usr/bin/env python3
"""Conway's Soldiers, row 4: find a 20-peg army and show that 19 pegs cannot work.

Weights: a cell at Manhattan distance d from the target (0,4) has weight sigma^d,
sigma = (sqrt5-1)/2, sigma^2 + sigma = 1.  A jump toward the target (cells at
distances d+2, d+1, d) keeps the total weight; every other jump strictly lowers it.
verify_soldiers.py (Part A) computed exactly, for cells below the line:
    best 18 cells: 1 - sigma^8 < 1        -> 18 pegs impossible
    best 19 cells: exactly 1              -> checked exhaustively below (D2)
    best 20 cells: 1 + sigma^8
D1 searches for a 20-peg army whose whole play is toward-only (weight exactly 1
throughout).  D0 enumerates the possible shapes (how many cells at each distance)
of a 20-cell army of weight exactly 1; from it we read off tail bounds that are
monotone in the reverse search and prune it hard.
"""
import sys, time
from collections import deque
from itertools import combinations
sys.setrecursionlimit(20000)

T = (0, 4)
def dist(c):
    return abs(c[0] - T[0]) + abs(c[1] - T[1])
S5 = 5 ** 0.5
SIG = (S5 - 1) / 2

# ---------- exact arithmetic a + b*sigma ----------
def zadd(p, q): return (p[0] + q[0], p[1] + q[1])
def zmul(p, q): return (p[0] * q[0] + p[1] * q[1], p[0] * q[1] + p[1] * q[0] - p[1] * q[1])
def zpow(k):
    r = (1, 0)
    for _ in range(k): r = zmul(r, (0, 1))
    return r
SP = [zpow(k) for k in range(40)]

print("=== D0. Shapes of a 20-cell army below the line with weight exactly 1 ===")
# number of cells below the line at distance d from (0,4): d=4 ->1, then 3,5,7,... (2d-7)
count_at = {d: (2 * d - 7) for d in range(4, 30)}
shapes = []
def rec(d, left, w, chosen):
    if left == 0:
        if w == (1, 0):
            shapes.append(dict(chosen))
        return
    if d > 16:
        return
    # max possible additional weight with `left` cells all at distance d: left*sigma^d; need w + that >= 1
    if w[0] + w[1] * SIG + left * SIG ** d < 1 - 1e-9:
        return
    for n in range(min(left, count_at[d]), -1, -1):
        ww = w
        for _ in range(n): ww = zadd(ww, SP[d])
        if ww[0] + ww[1] * SIG > 1 + 1e-9:
            continue
        if n: chosen[d] = n
        rec(d + 1, left - n, ww, chosen)
        if n: del chosen[d]
rec(4, 20, (0, 0), {})
for s in shapes:
    print("  cells per distance:", s)
tails = {}
for k in range(4, 14):
    tails[k] = max(sum(n * SIG ** d for d, n in s.items() if d >= k) for s in shapes)
print("  tail bounds W(d>=k) for the reverse search:", {k: round(v, 6) for k, v in tails.items()})

# ---------- board encoding ----------
XMAX, YMIN = 6, -6
cells = [(x, y) for y in range(YMIN, 4) for x in range(-XMAX, XMAX + 1) if dist((x, y)) <= 10] + [T]
idx = {c: i for i, c in enumerate(cells)}
bit = {c: 1 << i for i, c in enumerate(cells)}
NB = len(cells)
wt = [SIG ** dist(c) for c in cells]
dcell = [dist(c) for c in cells]
above = [1 if c[1] >= 1 else 0 for c in cells]
fneed = [{1: 1, 2: 2, 3: 4, 4: 7}.get(c[1], 0) if c[1] >= 1 else 0 for c in cells]

# toward un-jumps: for a peg at c, (a, b) two cells farther, both must be empty
UNJ = [[] for _ in range(NB)]
for c in cells:
    x, y = c
    dirs = [(0, -1)]
    if x >= 0: dirs.append((1, 0))
    if x <= 0: dirs.append((-1, 0))
    for dx, dy in dirs:
        b, a = (x + dx, y + dy), (x + 2 * dx, y + 2 * dy)
        if a in idx and b in idx and dist(a) == dist(c) + 2:
            UNJ[idx[c]].append((bit[a] | bit[b]))
MIRROR = [idx[(-c[0], c[1])] for c in cells]

def bits_of(S):
    out = []
    while S:
        lsb = S & -S
        out.append(lsb.bit_length() - 1)
        S ^= lsb
    return out

def stats(S):
    """returns (npegs, need, tail7, tail8, tail9, tail10)"""
    n = need = 0
    t = [0.0] * 14
    for i in bits_of(S):
        n += 1; need += fneed[i]
        t[dcell[i]] += wt[i]
    tail = {}
    acc = 0.0
    for k in range(13, 3, -1):
        acc += t[k]; tail[k] = acc
    return n, need, tail

EPS = 1e-9
def ok_state(S):
    n, need, tail = stats(S)
    if n > 20 or need > 20 - n:
        return False
    for k in range(7, 14):
        if tail[k] > tails.get(k, 0.0) + EPS:
            return False
    return True

def find_army(limit_states=40_000_000):
    start = bit[T]
    visited = {start}
    sol = []
    def dfs(S):
        if not (S & ABOVE):
            sol.append(S); return True
        if len(visited) > limit_states:
            return False
        for i in bits_of(S):
            for ab in UNJ[i]:
                if S & ab:
                    continue
                R = (S ^ (1 << i)) | ab
                if R in visited:
                    continue
                visited.add(R)
                if ok_state(R) and dfs(R):
                    return True
        return False
    dfs(start)
    return sol, len(visited)
ABOVE = sum(bit[c] for c in cells if c[1] >= 1)

DIRS = ((1, 0), (-1, 0), (0, 1), (0, -1))
def forward_solve(army, target, toward_only=False):
    start = frozenset(army)
    parent = {start: None}
    dq = deque([start]); n = 0
    while dq:
        S = dq.popleft(); n += 1
        if target in S:
            path = []
            while parent[S] is not None:
                P, m = parent[S]; path.append(m); S = P
            return path[::-1], n
        for a in S:
            for dx, dy in DIRS:
                b, c = (a[0] + dx, a[1] + dy), (a[0] + 2 * dx, a[1] + 2 * dy)
                if b in S and c not in S and c[1] <= target[1]:
                    if toward_only and dist(c) != dist(a) - 2:
                        continue
                    R = (S - {a, b}) | {c}
                    if R not in parent:
                        parent[R] = (S, (a, b, c)); dq.append(R)
    return None, n

def simulate(army, moves, target):
    S = set(army)
    for (a, b, c) in moves:
        assert a in S and b in S and c not in S, (a, b, c)
        assert abs(a[0] - b[0]) + abs(a[1] - b[1]) == 1 and (2 * b[0] - a[0], 2 * b[1] - a[1]) == c
        S -= {a, b}; S.add(c)
    return target in S, S

def picture(S):
    xs = [x for x, y in S]; ys = [y for x, y in S]
    rows = []
    for y in range(max(0, max(ys)), min(ys) - 1, -1):
        rows.append("    row %2d: " % y + " ".join("o" if (x, y) in S else "." for x in range(min(xs), max(xs) + 1)))
    return "\n".join(rows)

if __name__ == "__main__":
    print()
    print("=== D1. Toward-only reverse search for a 20-peg army reaching (0,4) ===")
    t0 = time.time()
    sol, nvis = find_army()
    print(f"  visited {nvis} states in {time.time() - t0:.1f}s")
    if not sol:
        print("  none found within the state limit")
    else:
        army_set = {cells[i] for i in bits_of(sol[0])}
        army = sorted(army_set, key=lambda c: (-c[1], c[0]))
        print(f"  army of {len(army)} pegs:", army)
        print(picture(army_set))
        moves, n = forward_solve(army, T)
        ok, final = simulate(army, moves, T)
        print(f"  forward BFS explored {n} states; move list (from, over, to):")
        for i, m in enumerate(moves, 1):
            print(f"    {i:2d}. {m[0]} over {m[1]} to {m[2]}")
        print(f"  simulation reaches (0,4): {ok}; pegs left at the end: {sorted(final)}")
        print("  columns used:", min(x for x, y in army), "to", max(x for x, y in army), "; rows", min(y for x, y in army), "to 0")
        print("  cells per distance:", {d: sum(1 for c in army if dist(c) == d) for d in sorted({dist(c) for c in army})})

    print()
    print("=== D2. 19 pegs cannot reach row 4 ===")
    below = [(x, y) for x in range(-12, 13) for y in range(-12, 1)]
    closest16 = [c for c in below if dist(c) <= 7]
    d8 = [c for c in below if dist(c) == 8]
    assert len(closest16) == 16 and len(d8) == 9
    t0 = time.time()
    reached = 0; tot_states = 0; narm = 0
    for extra in combinations(d8, 3):
        army = closest16 + list(extra); narm += 1
        moves, n = forward_solve(army, T, toward_only=True)
        tot_states += n
        if moves is not None:
            reached += 1
            print("  !! reached with", army)
    print(f"  checked all {narm} best-19 armies with toward-only play "
          f"({tot_states} states, {time.time() - t0:.1f}s); armies that reach (0,4): {reached}")
    print("  (A 19-peg army weighs at most 1 = the target's weight, so no weight may ever be lost:")
    print("   it must be a best-19 set and every jump a toward-jump.  None works, so 19 pegs cannot do it.)")
