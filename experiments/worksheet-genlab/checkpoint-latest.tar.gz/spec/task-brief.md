<!-- Task brief, identical in every workflow; version tb-v1 -->
Make an activity packet for a one-hour math circle session for grades K–5, where the kids work with each other and with professional mathematicians guiding them. The organizer's high-level activity outline is given below.

The group: ten children (two kindergartners and a first grader / four third graders / two fourth graders and a fifth grader) and three adults (the organizer, a math PhD; a second mathematician; one parent who is not a mathematician). One adult is anchored to each of three tables: K–1, grades 2–3 (the third graders sit here), grades 4–5. Session shape: a few minutes of free handling of the materials, a short whole-group launch, table work for most of the hour, a brief share at the end. The children have done math circle before; the older ones have seen simple games and puzzles, but nothing from this theme.

Deliverables — LaTeX sources that compile with `pdflatex -interaction=nonstopmode` (TikZ is available) to US Letter PDFs, written into the working directory named at the end of this message:

- `week-k-1.tex` — student pages for the K–1 table (no independent reading required; the adult reads aloud)
- `week-grades-2-3.tex` — student pages for the grades 2–3 table
- `week-grades-4-5.tex` — student pages for the grades 4–5 table
- `week-facilitator.tex` — one facilitator guide for the three adults: materials and preparation, the whole-group launch, what each table does in what order, complete answers and arguments for every problem, hints, and what to do when a table stalls or finishes early

Call it Week 1. Compile all four files until they build without errors, and look at the rendered pages (`pdftoppm -r 60 -png file.pdf out`) to check that diagrams and spacing came out as intended. Do not leave stray files other than the four `.tex` sources and their PDFs (plus any `.tex` files you `\input`).
