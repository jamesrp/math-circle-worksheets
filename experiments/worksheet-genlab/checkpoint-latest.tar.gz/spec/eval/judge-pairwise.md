You are comparing two activity packets, A and B, made for the same one-hour elementary math-circle session. You do not know who or what produced either. Your standard is the organizer's: a parent with a math PhD who runs the circle, has piloted packets with these children, and wants the packet that needs less human editing before being handed to the tables.

Packet A is in `{{PACKET_A_DIR}}` and packet B in `{{PACKET_B_DIR}}`. Each has `week-k-1.tex`, `week-grades-2-3.tex`, `week-grades-4-5.tex`, `week-facilitator.tex`, their PDFs, and rendered pages in `render/` (`<file>-<n>.png`, one per page, plus `<file>.txt` extracted text). Look at every rendered page of both packets with your image viewer, in order, and read the sources when you need to quote or check something.

The organizer's request was:

{{TASK_BRIEF}}

The organizer's high-level outline for this session:

{{OUTLINE}}

A verified fact sheet for this theme, prepared independently and checked by computer, is at `{{FACTS_PATH}}`; read it and use it to check the mathematics of both packets. Where a packet makes a claim the sheet does not cover, recompute it yourself (a short program is fine).

What the organizer wants from a packet, in order of importance:

1. Mathematics. The problems are concrete instances of the real questions in the theme (existence, impossibility, invariants, optimality, completeness, reconfiguration, counting, dynamics), with a ladder from doing toward an argument that a mathematician at the table can push toward. Every answer and claim, on student pages and in the guide, is correct.
2. Concrete work, and enough of it. Nearly every problem has a physical or drawn action with the materials and a board, grid or blank to record in; sequences run act → record → compare → explain; a representation (table, code, coloring, map) is introduced only after the question it answers; each idea gets several purposeful, contrasting instances rather than one example and a question; each table has at least forty minutes of real work, and the last problems for the fast table are still real problems.
3. The next action is always clear. Each problem says what to build, place, move, count, draw, compare or record and where; rules are stated inside the problem text; nothing must be inferred from a title or label; text can be read aloud; no hidden tricks.
4. Level fit. K–1 needs no reading but is real mathematics, not decoration, and would keep three young children and an adult busy for the hour with big clear diagrams; 2–3 and 4–5 are demanding but reachable; explanations are asked for in forms a child can produce, never as a general rule with a variable.
5. Student pages carry nothing but the running header, the footer, `Problem N:` problems in plain direct sentences, and the diagrams and recording space children need. No page titles, teaser questions, section headings, labels ("Warm-up", "Challenge", "Go further", "Bonus", "Rules", "Fun fact", "Think about"), rule boxes, Name/Date lines, encouragement, exclamation marks, emoji, adult-facing remarks, explanations of the answer, or cute register.
6. The facilitator guide has materials with counts, a short whole-group launch built on the one concrete action everyone will use, per-table order with rough timings, complete answers and complete arguments for every problem, hints in order, what to do when a table stalls or finishes, and a short mathematical background for the mathematicians.
7. Production: compiles, diagrams legible and correctly scaled to the physical pieces where they are meant to be covered, layout clean.

Do not prefer a packet for being longer or having more pages unless the extra pages are distinct real work, and do not prefer a packet for being shorter unless the other's length is padding. Do not reward sophistication of vocabulary. The order in which you were given the packets carries no information. Judge from what a child at each table would actually do with the page.

Procedure: view every page of both packets; check the mathematics of both against the fact sheet; for each of the dimensions below decide A, B or tie, giving one or two sentences that quote or name the specific evidence from each packet; then give an overall verdict: which packet would need less editing before use, and how confident you are (0.5 = coin flip, 1.0 = certain). A tie overall is allowed only if you truly cannot separate them.

Write your comparison as JSON to `{{OUTPUT_PATH}}` with exactly this structure:

{
  "A": "{{PACKET_A_DIR}}",
  "B": "{{PACKET_B_DIR}}",
  "dimensions": {
    "D1_math_substance_and_correctness": {"winner": "A|B|tie", "reason": "..."},
    "D2_concreteness_and_order": {"winner": "A|B|tie", "reason": "..."},
    "D3_amount_and_contrast_of_work": {"winner": "A|B|tie", "reason": "..."},
    "D4_next_action_clarity": {"winner": "A|B|tie", "reason": "..."},
    "D5_level_fit": {"winner": "A|B|tie", "reason": "..."},
    "D6_page_slop_and_register": {"winner": "A|B|tie", "reason": "..."},
    "D7_facilitator_guide": {"winner": "A|B|tie", "reason": "..."},
    "D8_production": {"winner": "A|B|tie", "reason": "..."}
  },
  "math_errors_found": {"A": ["..."], "B": ["..."]},
  "overall": {"winner": "A|B|tie", "confidence": 0.5-1.0, "reason": "..."}
}

End your final message with the overall winner and confidence, nothing else.
