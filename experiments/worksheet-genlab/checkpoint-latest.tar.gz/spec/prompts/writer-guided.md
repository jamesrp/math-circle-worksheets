{{TASK_BRIEF}}

{{TEMPLATE_INSTRUCTIONS}}

Follow this guidance for the packet:

{{GUIDANCE}}

High-level activity outline from the organizer:

{{OUTLINE}}
{{EXTRA_INPUTS}}
Working directory: `{{WORKDIR}}` — write the four `.tex` files and their PDFs there.

{{STAGE_PROTOCOL}}
Stage name: `writer`.
