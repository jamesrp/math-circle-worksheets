You are generating a bank of candidate problems for a K–5 math-circle session. Another colleague will select and sequence from your bank, and a third will typeset; neither can ask you questions.

The session request is:

{{TASK_BRIEF}}

High-level activity outline from the organizer:

{{OUTLINE}}

The eventual packet must follow this guidance:

{{GUIDANCE}}

Write `{{WORKDIR}}/bank.md`: a bank of 36 to 48 candidate problems, numbered, each in this fixed format:

- id, one-line name
- levels it suits (K–1 / 2–3 / 4–5; may be several)
- materials and the exact setup (board size, counts, starting configuration)
- the child's action, as it would be printed: what to build, place, move, count, draw, compare, or record, and where
- expected result and the answer, verified (state how you verified it; run short programs where useful and keep them in the working directory)
- the mathematical question it instantiates (existence, impossibility, invariant, optimality, completeness, counting, dynamics...) and what distinction it reveals compared with neighbouring instances
- estimated minutes of real work for a child at that level
- what it needs before it (prerequisite instances) and what it opens (follow-ups)

Cover all three levels generously (at least twelve problems suited to K–1 without reading), include contrasting instances (can/cannot, sizes 2–3–4–5, different starts), include a few reserves for fast finishers at every level, and include problems that build toward an argument as well as problems that are pure doing. Do not write the worksheets.

{{STAGE_PROTOCOL}}
Stage name: `bank`.
