A colleague produced a math-circle activity packet in response to the request below. The packet is in the working directory `{{WORKDIR}}`: `week-k-1.tex`, `week-grades-2-3.tex`, `week-grades-4-5.tex`, `week-facilitator.tex`, with compiled PDFs. Render the PDFs to images (`pdftoppm -r 60 -png`) and look at every page as well as reading the sources.

The original request was:

{{TASK_BRIEF}}

High-level activity outline from the organizer:

{{OUTLINE}}

Do a review of this packet. Write your review to `{{WORKDIR}}/review.md`: what is wrong or weak, most important first, and what should change. Be specific enough that another person could make the changes without talking to you. Do not edit the packet yourself.

{{STAGE_PROTOCOL}}
Stage name: `reviewer`.
