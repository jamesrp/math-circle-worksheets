A colleague produced a math-circle activity packet in response to the request below. The packet is in the working directory `{{WORKDIR}}`: `week-k-1.tex`, `week-grades-2-3.tex`, `week-grades-4-5.tex`, `week-facilitator.tex`, with compiled PDFs. Render the PDFs to images (`pdftoppm -r 60 -png`) and look at every page as well as reading the sources.

The original request was:

{{TASK_BRIEF}}

High-level activity outline from the organizer:

{{OUTLINE}}

The packet was supposed to follow this guidance:

{{GUIDANCE}}

Review the packet against that guidance and against the following checks, in this order of importance. For every problem you find, quote or name the exact place (file, problem number, page) and say precisely what to change; do not write general advice.

1. Mathematics. Recompute every answer and claim in the facilitator guide and every "can/cannot" or "always" statement on the student pages, by hand or with a short program. List every error.
2. Enough work. For each table, estimate the minutes of real work in each problem and add them up. Say where a table would run out before forty minutes, where a problem is one example followed by a question, and where instances repeat a procedure instead of showing a contrast. Say what instances to add.
3. Concreteness and order. For each problem, name the physical or drawn action and where the child records it. Flag problems that ask for an explanation before enough cases have been done, representations introduced before the question they answer, and recording space that is missing or too small.
4. Next action. Flag every problem where a child or a parent reading aloud would not know what to do, every rule stated outside the problem text, and every hidden trick or ambiguity.
5. Level fit. Flag K–1 problems that are decoration rather than mathematics, or that assume reading; flag 2–3 and 4–5 problems that are too easy for the whole table or that ask for a general rule with a variable.
6. Page slop. List every title, teaser, heading, label, box, Name/Date line, encouragement, exclamation mark, fun fact, adult-facing remark, or explanation of the answer that appears on a student page, and every sentence written in a cute or hyped register.
7. Facilitator guide. List anything missing from: materials with counts, launch, per-table order and timing, complete solutions and arguments, hints, stall/finish plans, mathematical background.
8. Production. Flag diagrams that are wrong, illegible, mis-scaled relative to the physical pieces, or overflowing; flag layout problems.

Write `{{WORKDIR}}/review.md` as a numbered list of required changes (most important first), each with location, the issue, and the exact change to make. End with a short list of what should be kept as is. Do not edit the packet yourself.

{{STAGE_PROTOCOL}}
Stage name: `reviewer`.
