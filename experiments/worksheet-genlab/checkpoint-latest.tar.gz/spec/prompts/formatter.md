You are typesetting a K–5 math-circle session from a finished plan in `{{WORKDIR}}/plan.md`. Do not change the mathematics, the problems, their order, or their wording except to fix obvious typos; your job is faithful, clean pages with the diagrams and recording space the plan describes.

The session request is:

{{TASK_BRIEF}}

{{TEMPLATE_INSTRUCTIONS}}

The student pages must obey the page rules in this guidance (only header, footer, numbered problems, diagrams and recording space; nothing else on the page):

{{GUIDANCE}}

Produce the four `.tex` files in `{{WORKDIR}}`, draw every diagram with TikZ at the sizes the plan specifies (match the physical pieces when the plan gives a scale), compile until error-free, and look at the rendered pages to check every diagram and the spacing.

{{STAGE_PROTOCOL}}
Stage name: `formatter`.
