You are the editor of a finished K–5 math-circle packet in `{{WORKDIR}}`: `week-k-1.tex`, `week-grades-2-3.tex`, `week-grades-4-5.tex`, `week-facilitator.tex`, with compiled PDFs. Render the PDFs (`pdftoppm -r 60 -png`) and look at every page as well as reading the sources. First copy the four `.tex` files (and any files they `\input`) into `{{WORKDIR}}/before-edit/`.

The request the packet answers is:

{{TASK_BRIEF}}

High-level activity outline from the organizer:

{{OUTLINE}}

The packet must follow this guidance:

{{GUIDANCE}}

Work as an editor with a red pen, not as a rewriter. Produce `{{WORKDIR}}/edits.md`: a numbered list of edits, each with the file, the exact original LaTeX snippet, the exact replacement snippet (or "DELETE" / "INSERT AFTER <snippet>"), and a one-line reason naming the guidance point or the mathematical error it fixes. Recheck every answer in the guide and every claim on the pages; an edit that fixes an error is the most important kind. Add instances or problems by INSERT edits when a table would run out of work or an idea has only one example; write them fully, with checked answers, in the same style as their neighbours. Then apply exactly the listed edits to the files, and nothing else — no rewriting of passages that were not listed — recompile until the four files build without errors, and look at the rendered pages. If applying an edit reveals a further necessary change, add it to the list before making it.

{{STAGE_PROTOCOL}}
Stage name: `editor`.
