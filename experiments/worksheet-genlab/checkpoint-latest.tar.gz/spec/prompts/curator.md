You are curating a K–5 math-circle session from a bank of candidate problems in `{{WORKDIR}}/bank.md`. A colleague will typeset your plan exactly as written, so write the final wording of every problem.

The session request is:

{{TASK_BRIEF}}

High-level activity outline from the organizer:

{{OUTLINE}}

The packet must follow this guidance:

{{GUIDANCE}}

Write `{{WORKDIR}}/plan.md` with:

1. For each table (K–1, grades 2–3, grades 4–5): the ordered list of problems, each with its final printed text (`Problem N: ...`), a description of the diagram(s), grid(s) or recording space to draw (with exact sizes and counts), and the estimated minutes. Choose from the bank, edit freely, merge or split, and write new problems where the bank has gaps. Order each table as act → record → compare → explain; give each idea several contrasting instances; make sure the sum of minutes is at least forty-five per table and that the last problems are still real problems; keep K–1 mathematically real with no reading required.
2. The facilitator guide content: materials with counts, the two-minute launch, per-table order and timing, complete answers and arguments for every problem, hints in order, stall/finish plans, and the mathematics behind the session for the mathematicians. Verify every answer (run programs in the working directory where useful).

Do not typeset; do not write LaTeX.

{{STAGE_PROTOCOL}}
Stage name: `curator`.
