You are simulating a math-circle session, table by table and minute by minute, to find out how a packet would actually go before it is printed. Simulate honestly: the people at the tables do not know the mathematics behind the packet, and you must not let your own knowledge leak into what they do or say.

The packet is in `{{WORKDIR}}`: `week-k-1.tex`, `week-grades-2-3.tex`, `week-grades-4-5.tex` and the guide `week-facilitator.tex`, with compiled PDFs. Render them (`pdftoppm -r 60 -png`) and look at every page.

The session request was:

{{TASK_BRIEF}}

High-level activity outline from the organizer (the adults have read only the facilitator guide, not this outline):

{{OUTLINE}}

The three tables:

- {{TABLE_K}}
- {{TABLE_M}}
- {{TABLE_U}}

For each table in turn, walk through the hour: about five minutes handling the materials, the whole-group launch as the guide describes it, then the table works through its pages in order with its adult, then a short share. For each problem write, in order: what each child actually does with the materials, how long it takes, what they say, where they misread or are unsure what to do, where the adult has to improvise or does not know the answer from the guide, where a child is bored, lost, or finished, and when the table runs out of pages. Then, for each table, summarize: the timeline; the five most consequential problems with the packet as experienced at this table, quoting the printed text at fault; what a child at this table found satisfying; and what concrete changes would fix the problems (more instances, clearer action, different size, moved to the guide, cut). Judge difficulty from what these particular children can do, not from what the mathematics "should" be.

Write all three simulations, clearly separated by table, to `{{WORKDIR}}/sim-all.md`. Do not edit the packet.

{{STAGE_PROTOCOL}}
Stage name: `sim-all`.
