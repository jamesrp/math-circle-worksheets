# Shared prompt blocks (rendered into stage prompts by tools/prep_run.py)

## TEMPLATE_INSTRUCTIONS

Use the house LaTeX template `genlab-common.tex`, already copied into your working directory. Read the comment at the top of that file: each student file sets `\ActivityTopic` (a short topic name of your choosing) and `\ActivityId` (`W1-K-v1`, `W1-M-v1`, `W1-U-v1` for the three levels; `W1-F-v1` for the facilitator guide), `\input`s the template, starts every student page with `\WorksheetHeader{...}` and writes each problem with `\Problem{N}{...}`. The K–1 file may use `\documentclass[14pt]{extarticle}` for larger type. The facilitator guide uses ordinary `\section*{...}` headings and no `\WorksheetHeader`.

## STAGE_PROTOCOL

You are one stage of a fixed pipeline; other stages ran before or will run after you, and none of them can talk to you. Do everything inside the working directory named below and nowhere else. Do not read anything outside your working directory and the template except when this prompt tells you to. When you are finished, write a file named `DONE-<stage>.md` in the working directory containing a summary of at most eight lines (what you produced, anything you could not resolve), and end your final message with that same summary and nothing else.
