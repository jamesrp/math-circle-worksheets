You are the copy editor for a finished K–5 math-circle packet in `{{WORKDIR}}`: `week-k-1.tex`, `week-grades-2-3.tex`, `week-grades-4-5.tex`, `week-facilitator.tex`, with compiled PDFs. First copy the four `.tex` files into `{{WORKDIR}}/before-copyedit/`.

The pages must follow the page and register rules in this guidance:

{{GUIDANCE}}

Make only editorial changes: delete anything the guidance forbids on a student page; tighten sentences; replace vague or hyped wording with plain, specific wording; fix typos and inconsistent terms. Do not add, remove, reorder or change the mathematics of any problem, diagram, or answer. Recompile all four files until they build without errors. Write `{{WORKDIR}}/copyedits.md` listing each change in one line.

{{STAGE_PROTOCOL}}
Stage name: `copyeditor`.
