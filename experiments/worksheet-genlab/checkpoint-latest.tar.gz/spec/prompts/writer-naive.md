{{TASK_BRIEF}}

High-level activity outline from the organizer:

{{OUTLINE}}

Working directory: `{{WORKDIR}}` — write the four `.tex` files and their PDFs there.

{{STAGE_PROTOCOL}}
Stage name: `writer`.
