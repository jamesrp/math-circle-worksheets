Three colleagues independently produced a math-circle activity packet from the same request. They are in `{{WORKDIR}}/cand1/`, `{{WORKDIR}}/cand2/`, `{{WORKDIR}}/cand3/`, each with `week-k-1.tex`, `week-grades-2-3.tex`, `week-grades-4-5.tex`, `week-facilitator.tex` and compiled PDFs. Render every PDF to images (`pdftoppm -r 60 -png`) and look at every page of all three, as well as reading the sources.

The request was:

{{TASK_BRIEF}}

High-level activity outline from the organizer:

{{OUTLINE}}

The packets were supposed to follow this guidance:

{{GUIDANCE}}

Rank the three packets by how little a careful human editor would need to change before handing them to the three tables, judging in this order: mathematical correctness (recheck the answers), enough concrete work per table, clarity of the next action, level fit (K–1 real but unreadable-free), page slop, facilitator guide completeness, production quality. Write `{{WORKDIR}}/selection.md` with, for each candidate, its main strengths and its specific defects (quote them), then your ranking and the reason for the winner. Then copy the winner's four `.tex` files, any files they `\input`, and their PDFs into `{{WORKDIR}}/` (top level). Do not edit the winner.

{{STAGE_PROTOCOL}}
Stage name: `selector`.
