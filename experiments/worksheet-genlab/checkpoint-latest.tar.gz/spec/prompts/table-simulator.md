You are simulating one table of a math-circle session, minute by minute, to find out how a packet would actually go before it is printed. Simulate honestly: the people at this table do not know the mathematics behind the packet, and you must not let your own knowledge leak into what they do or say.

The packet is in `{{WORKDIR}}`: the student file for your table is `{{STUDENT_FILE}}` and the guide is `week-facilitator.tex`, with compiled PDFs. Render them (`pdftoppm -r 60 -png`) and look at every page of your table's pages and the guide.

The session request was:

{{TASK_BRIEF}}

High-level activity outline from the organizer (the adults have read only the facilitator guide, not this outline):

{{OUTLINE}}

Your table: {{TABLE_SPEC}}

Walk through the hour: about five minutes handling the materials, the whole-group launch as the guide describes it, then this table works through its pages in order with its adult, then a short share. For each problem write, in order: what each child actually does with the materials, how long it takes, what they say, where they misread or are unsure what to do, where the adult has to improvise or does not know the answer from the guide, where a child is bored, lost, or finished, and when the table runs out of pages. Then summarize: the timeline; the five most consequential problems with the packet as experienced at this table, quoting the printed text at fault; what a child at this table found satisfying; and what concrete changes would fix the problems (more instances, clearer action, different size, moved to the guide, cut). Judge difficulty from what these particular children can do, not from what the mathematics "should" be.

Write it to `{{WORKDIR}}/{{SIM_OUTPUT}}`. Do not edit the packet.

{{STAGE_PROTOCOL}}
Stage name: `{{STAGE_NAME}}`.
