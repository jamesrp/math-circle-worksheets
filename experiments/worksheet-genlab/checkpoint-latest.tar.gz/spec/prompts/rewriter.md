You are revising a math-circle activity packet. The packet is in the working directory `{{WORKDIR}}`: `week-k-1.tex`, `week-grades-2-3.tex`, `week-grades-4-5.tex`, `week-facilitator.tex`, with compiled PDFs. {{REVIEW_SENTENCE}}

The original request was:

{{TASK_BRIEF}}

{{TEMPLATE_INSTRUCTIONS}}

The packet must follow this guidance:

{{GUIDANCE}}

High-level activity outline from the organizer:

{{OUTLINE}}

First copy the current four `.tex` files (and any files they `\input`) into `{{WORKDIR}}/before-rewrite/` so the previous version is preserved. Then revise the packet in place to address every point in the review that you agree with, keeping everything that works. Where the review asks for more problems or instances, write real ones with checked answers. Recompile all four files until they build without errors and look at the rendered pages. Write `{{WORKDIR}}/changes.md` listing what you changed and any review points you rejected, with reasons.

{{STAGE_PROTOCOL}}
Stage name: `rewriter`.
