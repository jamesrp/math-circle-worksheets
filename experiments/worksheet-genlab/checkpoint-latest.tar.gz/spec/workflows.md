# Generation workflows (wf-set v1)

All roles use the same model (Fable) unless noted; temperature is the default. Every stage is a fresh agent that reads its stage prompt from the run directory; stages cannot talk to each other. The final packet of every workflow is the set `week-k-1.tex`, `week-grades-2-3.tex`, `week-grades-4-5.tex`, `week-facilitator.tex` (+ PDFs) at the top level of the run directory. Snapshots of intermediate versions are kept in `snapshots/`.

| id | name | pipeline | what it tests |
|---|---|---|---|
| W01 | naive | writer(naive) | the organizer's plain one-sentence request; no template, no guidance |
| W02 | antislop | writer(guided) | one-shot with the house template + antislop-v1 guidance |
| W03 | review-generic | writer(guided) → reviewer(generic: "do a review") → rewriter | does an unguided adversarial review help? |
| W04 | review-targeted | writer(guided) → reviewer(targeted checklist) → rewriter | does a checklist-driven review help more? |
| W05 | math-first | mathematician(dossier) → writer(guided + dossier) → reviewer(targeted) → rewriter | planning the mathematics before writing |
| W06 | problem-bank | bank(36–48 candidates) → curator(select, sequence, write final wording + solutions) → formatter(typeset only) → copyeditor(slop pass only) | separating invention, curation, typesetting and editing |
| W07 | sim-classroom | writer(guided) → [table simulators K–1, 2–3, 4–5 in parallel] → rewriter(with the three simulations) | testing the packet against simulated children/adults with specified epistemic state |
| W08 | best-of-3 | 3 × writer(guided) in parallel → selector(rank with checklist, copy winner) | selection without rewriting |
| W09 | refine-x3 | writer(guided) → [reviewer(targeted) → rewriter] × 3 | does iteration keep helping? (snapshots v1..v4 also scored) |
| W10 | edit-list | writer(guided) → editor(explicit edit list, minimal diffs) | surgical editing instead of rewriting |

Noise floor: W01 and W02 are also run with a second seed on every outline (identical prompts; sampling variance only).

## Shared base (paired design, decided at scale-out)

Stage 1 of W03, W04, W07, W09 and W10 is the identical writer(guided) prompt of W02. To make the effect of the added stages measurable without writer-sampling noise, those workflows branch from the W02 seed-1 output of the same outline (`tools/branch_from_base.sh`), and W08's cand1 is that same output (cand2, cand3 are fresh writers). Each workflow's score is therefore "W02 base + pipeline"; the difference from W02 is the pipeline's effect on that base. W05 and W06 do not share the base (their first stages differ).

## Prompt templates

`spec/prompts/*.md`, rendered with `tools/prep_run.py`. Placeholders: TASK_BRIEF (spec/task-brief.md), OUTLINE (spec/outlines/<id>.md), GUIDANCE (spec/antislop-v1.md), TEMPLATE_INSTRUCTIONS and STAGE_PROTOCOL (spec/prompts/_blocks.md), WORKDIR, and per-stage extras.

## Table specs for W07 simulators

- K–1: two kindergartners (5 years old; count to about 20 by ones, compare more/fewer, cannot read, can copy a shape, lose focus after about eight minutes on one task and need a change of activity or a new piece to hold) and a first grader (6; reads short words slowly, adds within 10 on fingers, likes to explain), with the parent who is not a mathematician (reads the pages aloud, follows the guide literally, cannot supply a missing rule or answer, will ask the organizer if stuck).
- Grades 2–3: four third graders (8–9; read fluently, add and subtract within 100, know some multiplication, can list cases with prompting, work in two pairs, argue about rules, one is fast and gets restless, one is careful and slow), with the second mathematician (knows the guide, enjoys asking "how do you know", can supply the argument if asked).
- Grades 4–5: two fourth graders and a fifth grader (9–11; fluent readers; multiplication and division; can follow a two-step rule and check each other; will try to generalize early and can be wrong; one has seen parity arguments before), with the organizer (math PhD, knows the guide and the mathematics; wants to push toward the argument without giving it away).

## Trimmed scope (approved by the organizer 2026-10-02, after two weeks of Fable budget)

- W07 sim-classroom: ONE simulator agent covers all three tables (`spec/prompts/table-simulator-all.md`, output `sim-all.md`) instead of three parallel simulators; then the rewriter. (6 runs instead of 12.)
- W08 best-of-3: cand1 = W02 s1 (shared base), cand2 = W02 s2 (the second-seed guided writer, which also serves as the noise-floor twin), cand3 = one fresh guided writer; then the selector. (6 runs instead of 12.)
- W09 refine: round 1 IS W04 (same prompts on the same base), so W09 branches from the W04 output and runs one further review→rewrite round (two rounds total); a third round only if rounds 1–2 show a trend worth confirming. (6 runs instead of 18.)
- Noise floor: W02 s2 only (the writer every pipeline branches from); the second naive seed is dropped.
- W03, W04, W10 unchanged.
- Judging (paired design): pairwise vs the shared base W02 s1 on the same outline for every other workflow (8 × 3 = 24, presentation order randomized), W02 s1 vs W02 s2 twins (3, noise floor), a top-3 round robin per outline (9); absolute judging only for W02 s1 (3) and the two leading workflows (6) in addition to the two naive packets already judged.
- Execution: pending stages run through the Workflow tool (`tools/pending.py` → stage-runner workflow), batches of ~6 agents, checkpoint after each batch.
