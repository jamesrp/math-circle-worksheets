# Research log — AI worksheet generation experiment

Chronological. Times are America/Los_Angeles. Every entry says what was done, what was observed, and any decision taken.

## 2026-09-29 — Session 1

**Setup.** Read the corpus: AGENTS.md (organizer-approved guidance), Week 1 sources and the classroom review (the v2→v3 before/after pair), Year-1 human handouts, fall plan, the pre-deslop Week 3 sources. Extracted the three MSRI books to text. Organizer's answers to the four design questions: three outlines (tilings + peg jumping + Bulgarian solitaire); full LaTeX→PDF packets (three student levels + facilitator guide); the only allowed use of existing material is calibrating the judge on the real Week 1 before/after pair (generators never see Year-2 worksheets; no Year-1 handouts as exemplars; no book quotes in prompts); organizer will blind-rank ~6 packets at the end.

**Research memos** (subagents): `research-orchestration-and-judging.md` (45 sources) and `research-math-circle-books.md`. Design consequences adopted: pairwise judging with per-dimension forced choice and evidence quotes; yes/no checklist rather than bare 1–10; verified fact sheets per theme for the judge; frozen calibration set including egregious-failure items (planted math errors, chrome, truncation); positive-framed guidance with a short explicit "do not" list; test both a generic and a checklist reviewer; test best-of-N with a checklist selector; test simulated tables with explicit epistemic state; test an edit-list editor; measure iteration (W09) up to three rounds.

**Fact sheets** (`notes/facts-*.md`): all small-case data brute-forced by code. Correction from the pegs agent: Conway's Soldiers row 5 is unreachable by any finite sequence (transfinite play does reach it), so the sheet says "no finite sequence".

**Spec frozen**: `spec/task-brief.md` (tb-v1), `spec/antislop-v1.md`, `spec/genlab-common.tex`, `spec/workflows.md` (W01–W10), `spec/prompts/*`. Every stage is a fresh agent that reads its prompt from the run directory; stages cannot talk to each other; all roles Fable.

**Calibration** (`notes/eval-calibration.md`): five blinded packets; the judge preferred the organizer's post-feedback Week 1 over the pre-feedback version, over a chrome-inflated copy, over a truncated copy and over a copy with three planted errors — 8/8 pairwise in both orders (confidence 0.90–0.97), and the absolute scores separated the defects on the intended dimensions. All planted errors were found. Judge cost ≈ 170–220k tokens per call. EVAL FROZEN.

**Vertical slice, attempt 1 (W01 naive on T, P, B).** Two findings:
1. *Harness bug.* `prep_run.py` copied the house template `genlab-common.tex` into every run directory, including W01. Both naive writers found it and used it (header/footer/`Problem N:` format appeared in the "naive" output), contaminating the baseline. Fixed: W01 gets no template file. The two contaminated runs are archived as `runs/{T,B}/W01/s1-contaminated-template/` (not scored in the experiment; kept because they are an accidental data point: "naive prompt + template merely present in the directory").
2. *Rate limit.* The P writer was cut off by the organizer's 5-hour usage limit mid-run (reset 4:10 pm). Archived as `runs/P/W01/s1-aborted-ratelimit/`. All three W01 runs restarted from scratch at 4:20 pm.

Observation from the contaminated T output (not a result): even the naive prompt produced real mathematics (mutilated boards, coloring, L-trominoes, exact-cover-verified answers) and a long facilitator guide (11 pp); lint slop 0.43 items/page.

## 2026-09-29 (evening) to 2026-10-02 — scale-out, rate limits, scope decision

**Paired design adopted at scale-out.** Stage 1 of W03/W04/W07/W09/W10 is the identical W02 writer prompt, so those workflows branch from the W02 seed-1 output per outline; W08's cand1 is the same output. Effects of added stages are therefore measured on a common base (see spec/workflows.md).

**Rate limits.** Fable has a 5-hour session limit (observed: roughly 10–12 heavy agent runs, ~3M subagent tokens per window) and a weekly limit, which the organizer reports was exhausted twice by this experiment. Four batches were cut mid-run (A, C, D and one judge), losing ~3.5M tokens of partial work in 21 agents. Complete artifacts from cut agents were accepted when verifiably complete (T/W05 dossier, B/W06 bank, B/W05 review); everything else was archived as `*-partial-ratelimit-N` and re-run from scratch; cut rewriters had their pre-rewrite sources restored from `before-rewrite/`.

**Spend to 2026-10-02:** ~75 heavy agent runs, ~15M subagent tokens (plus orchestrator context overhead). Completed: W01 and W02 on all outlines; W05 complete on B (3/4 on T, P); W06 complete on T, B (2/4 on P); 2 absolute judgments.

**Scope decision (organizer approved the recommended trim):** W07 with one simulator agent for all three tables; W08 candidates = base + W02 s2 + one fresh writer; W09 = W04 + one more round; drop W01 s2; judging switched to the paired design (every workflow vs the W02 base, twins, top-3 round robin; absolute only for base and leaders). Remaining ≈ 40 generation + ≈ 45 judging runs. Stages now run through the Workflow tool in batches of ~6 (`tools/pending.py` builds the chain list).

**Observations so far (not yet judged):**
- Lint slop items per student page: naive W01 0.24 (T), 0.53 (P), 2.17 (B); guided W02 0.48 (T), 0.15 (P), 0.04 (B); W05 writer 0.0 (T), 0.02 (P), 0.17 (B). The guided prompt alone removes nearly all visible chrome.
- Packet size balloons with planning stages: W05 writer (from a mathematician's dossier) produced 43/49/30 student pages and a 33-page guide (T/P/B) versus 27/27/24 for W02 and 21/15/18 for W01. The targeted reviewers of W05 estimated core table time at 75–107 minutes against the 40-minute budget and flagged it; the W06 curator for B also planned 61-minute K–1 cores "by design, with cuts marked".
- Naive W01 packets had real mathematics (judges found one false sentence in T's 19-page guide, none in B) but classic chrome: titles, teaser headings, Name lines, labels, answer leakage (answers to earlier questions printed in later ones), and general rules with variables demanded of 4th graders. Absolute editing_need 6 (T) and 5 (B); the organizer's own post-feedback Week 1 scores 6 on the same judge.

## 2026-10-02 (late) — batch 1 through the Workflow tool

Batch 1 (6 agents, 1.75M tokens, 89 min, no cuts): W05 rewriters T and P, W06 formatter→copyeditor P, W02 s2 writers T and B. Two process notes from the agents: (1) the W05-T rewriter found that pdflatex in the shared scratchpad had once picked up another packet's `week-k-1.tex` from a stale build directory — it isolated its build and verified the log; from now on `tools/collect.py` recompiles the comment-stripped sources inside the blind evaluation directory instead of copying PDFs, so judged PDFs always match judged sources. (2) The W06-P formatter found the earlier rate-limited partial attempt's K–1 and 2–3 files in the run directory and reused them after checking them against plan.md word by word; partial archives are now moved out of `runs/` into `archive/` so later stages cannot see them. Both are recorded as deviations, not re-run (the formatter stage is a faithful-typesetting stage and its output was verified against the plan).

## 2026-10-03 — batch 2 (W04 targeted review→rewrite on all outlines; W02 s2 P)

7 agents, 1.85M tokens, 110 min, no cuts. The targeted reviewers recomputed every claim by exhaustive search. On the tilings and Bulgarian bases they found **no mathematical errors**; on the pegs base they found **four false statements in the facilitator guide** (e.g. "every other four-piece shape stops in row 1 or lower" — a shifted L reaches row 2; "19 pegs can be worth 377" on board T — only 372), plus duplicated problems between the 2–3 and 4–5 pages and three answer-leaking sentences. All three rewriters adopted every review item (20/24/28 items), none rejected outright, each with a few noted variations. Page counts after W04 vs the W02 base: T 30 (27), P 29 (27), B 24 (24) student pages. W09 now branches from the W04 output (round 1 = W04); W08 cand2 = W02 s2.

## 2026-10-03 — batch 3 (W03 generic review→rewrite; W10 edit-list editor)

9 agents, 2.2M tokens, 99 min, no cuts. The generic reviewers ("do a review") also recomputed the mathematics (no errors found on any base except that P's "19 pegs worth 377" statement was flagged as true only on an unbounded board) but their leading findings were about length and pacing ("2–3× too long for 40 minutes") and, for pegs, "no structure for children working with each other"; the rewriters then cut each table to a core plus extras — the P rewriter labelled the extras "Extra" on the student pages (a label the guidance forbids) and added "design-for-your-neighbour" collaboration tasks. The edit-list editors (W10) made 14–22 surgical edits each, mostly in the guides, and found no mathematical errors in the T and B bases; the editor on P kept the base's page count. Lint slop items/page after W03: 0.50 (T), 0.33 (P), 0.03 (B); after W10: 0.48 (T), 0.15 (P), 0.04 (B); base W02: 0.48, 0.15, 0.04 — i.e. W10 left the visible register unchanged while W03 added labels on P.
