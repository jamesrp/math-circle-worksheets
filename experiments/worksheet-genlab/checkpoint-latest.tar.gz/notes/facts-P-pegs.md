# Verified fact sheet: peg-jumping games (theme P)

**Conventions.** Squares are (column, row). The line lies between row 0 and row 1; rows 1, 2, 3, … are above it; armies start in rows ≤ 0; target = (0, k). A jump a→c moves the peg at a two squares in a straight orthogonal line to the empty square c and removes the peg between. σ = (√5−1)/2 ≈ 0.618, σ² = 1−σ, 1+σ = 1/σ; d = Manhattan distance to the target; weight of a square = σ^d. All numbers come from the appendix code (run 2026-09-29, 1 min); "cited" = taken from sources, not checked.

## 1. Conway's Soldiers

**Rules.** Infinite square grid; finitely many pegs, all below the line; orthogonal jumps only (no diagonals), the jumped peg is removed. Goal: a peg on row k.

**Theorem (Conway 1961; Berlekamp–Conway–Guy, *Winning Ways* vol. 4 ch. 23; Honsberger, *Mathematical Gems II*, 1976; Aigner, *Math. Magazine* 70, 1997).** Rows 1–4 are reachable; no finite sequence of moves puts a peg on row 5, however many pegs are available (even the whole half-plane: a finite play touches finitely many pegs).

**Proof.** Weight each square σ^d, d = distance to the target (0,5). A jump towards the target replaces σ^{d+2} + σ^{d+1} = σ^{d+1}(σ+1) = σ^d by σ^d: no gain. A sideways jump (d+1 over d to d+1) loses σ^d; a jump away (d over d+1 to d+2) loses 2σ^{d+1}. So total weight never increases. Below the line, 2j+1 squares lie at distance 5+j, so the whole half-plane weighs Σ(2j+1)σ^{5+j} = σ^5(1+σ)/(1−σ)² = σ^5·σ^{−1}·σ^{−4} = 1, the weight of the target alone. A finite army weighs less than 1; a position containing the target weighs at least 1. (Verified: closed form = numeric sum; for target row k the half-plane weighs σ^{k−5}, 1.618 for row 4.)

**Infinite play (cited; never phrase as "row 5 is possible").** Tatham & Taylor ("Reaching row 5 in Solitaire Army", chiark.greenend.org.uk/~sgtatham/solarmy) reach row 5 with an infinite sequence of moves (at times ½, ¾, ⅞, …, each square changing state finitely often, then further moves after the limit) that consumes the entire infinite half-plane. Worksheets must say "finitely many moves".

**Diagonal jumps allowed.** With Chebyshev distance, σ^d is again non-increasing under every orthogonal or diagonal jump; the half-plane weighs (2k+1)σ^{k−2} + 4σ^{k−3}: 1.308 for row 8, 0.877 for row 9. Verified: row 9 is unreachable. Cited (Bell, Hirschberg, Guerrero-García, *INTEGERS* 7 (2007) G07; OEIS A125730): row 8 is reachable; minimum armies for rows 1–8 are 2, 3, 5, 8, 13, 23, 46, 123 (last two best known; lower bounds 45, 122).

## 2. Minimal armies, rows 1–4

Minimum pegs **2, 4, 8, 20**, verified. Lower bounds: the heaviest N-set below the line weighs σ+σ² = 1 for row 1 (N=2; N=1 gives 0.618), 1.090 for row 2 (N=4; N=3: 0.854), 1.034 for row 3 (N=8; N=7: 0.944), and exactly 1 for row 4 at N=19 (N=18: 0.979); so 1, 3, 7, 18 pegs fail. A 19-peg row-4 army must weigh exactly 1: the 16 squares within distance 7 plus 3 of the 9 at distance 8, every jump lossless, no other survivor; forward search of all 84 such sets (209,848 positions) finds none. Upper bounds: the armies below, each simulated. Exhaustive reverse search (rows 1–3; the weight slack forces plays to end with the lone target peg) lists **all** minimal armies: row 1 one; row 2 one up to reflection; row 3 three, two up to reflection. Row-4 armies were not enumerated; the one below is verified.

- Row 1 (2 pegs): (0,0), (0,−1). Move (0,−1)→(0,1).
- Row 2 (4 pegs, an L; the T (−1,0),(0,0),(1,0),(0,−1) fails): (0,0), (1,0), (2,0), (0,−1). Moves (0,−1)→(0,1); (2,0)→(0,0); (0,0)→(0,2). Target above the end of the row of three.
- Row 3 (8 pegs): (−2,0), (−1,0), (0,0), (1,0), (2,0), (0,−1), (1,−1), (2,−1). Moves (0,−1)→(0,1); (−2,0)→(0,0); (2,−1)→(2,1); (0,0)→(0,2); (1,−1)→(1,1); (2,1)→(0,1); (0,1)→(0,3). Other shape: the same five plus (0,−1), (0,−2), (0,−3): (0,−1)→(0,1); (−2,0)→(0,0); (0,0)→(0,2); (2,0)→(0,0); (0,−3)→(0,−1); (0,−1)→(0,1); (0,1)→(0,3). Both use 5 columns.
- Row 4 (20 pegs, weight exactly 1, all jumps lossless, 7 columns × 4 rows): row 0: x = −2…4; row −1: x = −2…2; row −2: x = −2…3; row −3: x = 0, 1. Moves (−1,−1)→(−1,1); (2,−1)→(2,1); (4,0)→(2,0); (−2,−1)→(−2,1); (−2,1)→(0,1); (0,0)→(0,2); (2,0)→(0,0); (1,−2)→(1,0); (3,−2)→(1,−2); (0,−1)→(0,1); (0,1)→(0,3); (0,−3)→(0,−1); (1,−3)→(1,−1); (−2,−2)→(0,−2); (1,−1)→(1,1); (2,1)→(0,1); (0,−2)→(0,0); (0,0)→(0,2); (0,2)→(0,4).

A k-peg army ending with one peg makes exactly k−1 jumps: 1, 3, 7, 19. **Narrow printed grids.** A horizontal jump needs three columns, so on 1 or 2 columns each column is a separate 1-D game and row 1 is the limit; on 3 columns the middle column is entered only vertically, so a target above it is limited to row 1, while above a side column row 3 takes 10 pegs (3×3 block in rows 0 to −2 plus one peg under its target-side corner; 9 pegs weigh at most 0.966). Row 4 is impossible on 3 or 4 columns (half-strip weight 0.854, 1); the 20-army needs 7 columns and 4 rows below the line.

## 3. One dimension and small boards

**Block of n pegs on an unbounded line** (cells 1…n): no peg ever passes cell n+1, i.e. advance 1 for every n ≥ 2 (n=1: no move); verified n ≤ 10, proved in §4. The block cannot be reduced below ⌈n/2⌉ pegs; reachable positions number 1, 3, 3, 6, 6, 10, 10, 15, 15, 21.

**1×n strip** (jumps must land on the strip). Subsets reducible to one peg, n = 1…8: 1, 2, 5, 9, 13, 22, 31, 52 of 2^n−1 (n=4: 11.., .11., 11.1, ..11, 1.11, singletons). Full strip with one hole at cell h: n=3: h=1 or 3 (finish at the hole); n=4: h=2 (finish 3) or 3 (finish 2); n=5, 7, 9, 11: never; n=6: h=2, 5 (finish 2 or 5); n=8: h=2, 4, 5, 7 (h=2 finishes at 4 or 7; h=4 at 2 or 5); n=10: h=2, 5, 6, 9; n=12: h=2, 5, 8, 11. Pattern (verified n ≤ 12): even n works iff h ≡ 2 or n+1−h ≡ 2 (mod 3); odd n ≥ 5 never; matches Beeler–Hoilman (*Discrete Math.* 311, 2011): the path P_n is solvable iff n is even or n = 3. On the unbounded line, Moore–Eppstein (2000, arXiv math/0008172) give a regular language for reducible strings; verified equal to brute force for all strings of length ≤ 12 (counts 1, 1, 0, 2, 0, 5, 0, 12, 0, 23, 0, 38; odd length ≥ 3 never).

**Rectangles, one hole.** 2×n (n ≤ 5): never. 3×3: never; centre empty has no legal move at all. 3×4: a corner hole works (finish at either corner of that short side); hole (1,2) works (finish there); middle-row holes fail. 3×5: only the hole mid-long-side (1,3). 4×4: only an edge non-corner hole, e.g. (1,2), finishing at (1,3) or (4,3). 5×5: only (1,3) and (2,3) and their images; corners, (1,2), (2,2), centre fail. **English 33-hole board** (cited: Beasley, *The Ins and Outs of Peg Solitaire*, 1985; *Winning Ways* ch. 23): centre vacant to centre peg is solvable, 18 moves minimum (Bergholt 1912; Beasley 1964). Verified: the mod-3 position class allows a lone survivor only at the centre or (±3,0), (0,±3).

## 4. Invariants children can find

1. **Counting.** Each jump removes exactly one peg: pegs + jumps is constant, the count's parity alternates, one peg left ⇔ n−1 jumps.
2. **Three colours** (1-D): colour cells A, B, C, A, B, C, …; a jump touches one cell of each colour, so all three colour-counts change parity together. A lone peg has counts 1, 0, 0, so a position with all counts even, or all odd, is never reducible to one peg (1×5, hole 3: counts 2, 2, 0). Necessary only: 3·2^{n−2} subsets pass, far more than are reducible. Labels x+y and x−y mod 3 give the 2-D version (English-board position class).
3. **Fibonacci weights** (1-D bound): weight cell j by F_j = 1, 1, 2, 3, 5, … for j ≥ 1 and by 1 for j ≤ 0. Every jump has w(from) + w(over) ≥ w(to) (rightward: F_j + F_{j+1} = F_{j+2}), so the total never rises; block 1…n weighs F_{n+2} − 1, one less than cell n+2 alone, so no peg reaches n+2. The σ^d weights of §1 are the same idea.

## 5. Common errors to watch for

1. Diagonal jumps allowed silently (then row 8 is reachable; minima 2, 3, 5, 8, 13, …).
2. Jumping over an empty square, over two pegs, onto an occupied square, or off the board.
3. Not removing the jumped peg; k pegs and more than k−1 jumps.
4. Off-by-one rows: row 1 is the first row above the line ("row 5 with 20 pegs", "row 3 with 4 pegs").
5. "Row 5 with enough / infinitely many pegs" — false for finite play; Tatham–Taylor is not classroom evidence.
6. Wrong minima (3 for row 2; 6–7 for row 3; 16–19 for row 4): 3, 7, 18 fail by weight, 19 by search.
7. The T-shaped 4-army for row 2; only the L works, target above the end of the three.
8. Armies with a peg above the line at the start.
9. Linear weights 1, 2, 3, … or "weight is conserved": a valid weighting never increases under any jump and may decrease.
10. 1-D: a longer row lets a peg get two cells past the end; a 1×5 or 1×7 strip with one hole can be finished.
11. "First jump into the centre" of a 3×3 with centre empty: no legal move exists.
12. Ignoring board edges: above the middle column of a 3-wide grid, row 2 is impossible.

**Checklist for a move sequence.** Coordinates for every square; per move a→c: a, b (midpoint), c share a row or column, |a−c| = 2; a, b occupied, c empty and on the board; delete a, b, add c; count falls by 1; starting pegs all below the line; final peg on the claimed row. `play()` below does this.

## 6. What children can realistically do (judgment, not fact)

**K–1.** Learn the jump on a 1×6 strip, count pegs after each jump (one vanishes each time), find the 2-peg row-1 jump, and the L for row 2 with hints.

**Grades 2–3.** Find the L and explain why the T fails; find an 8-army with support; play 1×6, 1×8 one-hole strips and the 3×4; discover the three-colour rule and apply it to 1×5, middle hole.

**Grades 4–5.** Rebuild the 20-army from a picture and check it; prove the 1-D bound with Fibonacci weights; follow the golden-ratio proof given σ² = 1−σ; find the 3×3 no-move fact and the 4×4 hole rule by exhaustion. Row-4 minimality and row-5 impossibility stay reported facts.

## Code (Python 3)

```python
import re, time
from itertools import combinations
from functools import lru_cache
add = lambda u, v: (u[0]+v[0], u[1]+v[1]); sub = lambda u, v: (u[0]-v[0], u[1]-v[1])
def sgn(u):                                   # sign of a+b*s, s=(sqrt5-1)/2: ((2a-b)+b*sqrt5)/2
    p, q = 2*u[0]-u[1], u[1]
    if p >= 0 and q >= 0: return int(p or q > 0)
    if p <= 0 and q <= 0: return -1
    return 1 if (p > 0) == (p*p > 5*q*q) else -1
S = [(1, 0)]
for d in range(40): S.append((S[-1][1], S[-1][0]-S[-1][1]))     # S[d] = s^d, using s^2 = 1-s
fl = lambda u: u[0]+u[1]*(5**.5-1)/2
DIRS = [(1, 0), (-1, 0), (0, 1), (0, -1)]
dist = lambda p, k: abs(p[0])+abs(k-p[1])
W = lambda st, k: sum(fl(S[dist(p, k)]) for p in st)
F = {1: 1, 2: 2, 3: 4, 4: 7, 5: 12, 6: 20, 7: 33}                # reverse moves needed to clear a peg on row r
phi = lambda st: sum(F[y] for x, y in st if y > 0)
def reverse_bfs(k, N, xr=(-99, 99)):          # armies of <=N pegs whose play ends with exactly (0,k)
    start = frozenset([(0, k)]); par = {start: None}; fr = [start]; armies = {}
    for _ in range(N-1):
        nxt = []
        for st in fr:
            for (x, y) in st:
                for dx, dy in DIRS:
                    B, C = (x+dx, y+dy), (x+2*dx, y+2*dy)
                    if B in st or C in st or not xr[0] <= C[0] <= xr[1]: continue
                    ns = (st-{(x, y)})|{B, C}
                    if ns in par or len(ns)+phi(ns) > N: continue
                    par[ns] = (st, (C, B, (x, y)))
                    if all(v <= 0 for _, v in ns):
                        mv, c = [], ns
                        while par[c]: mv.append(par[c][1]); c = par[c][0]
                        armies[ns] = mv
                    else: nxt.append(ns)
        fr = nxt
    return armies
def play(army, moves, k):                     # legality check of a forward move list
    st = set(army); assert all(y <= 0 for x, y in st)
    for f, o, t in moves:
        assert (o[0]-f[0], o[1]-f[1]) == (t[0]-o[0], t[1]-o[1]) and abs(o[0]-f[0])+abs(o[1]-f[1]) == 1
        assert f in st and o in st and t not in st; st -= {f, o}; st.add(t)
    assert (0, k) in st; return st
layer = lambda k, d: sorted({(sx*(d-k-j), -j) for j in range(d-k+1) for sx in (1, -1)})
for k in range(1, 6):                          # least N whose heaviest N-set weighs >= 1
    sq = [p for d in range(k, k+12) for p in layer(k, d)]
    for N in range(1, 30):
        w = (0, 0)
        for p in sq[:N]: w = add(w, S[dist(p, k)])
        if sgn(sub(w, (1, 0))) >= 0: print(f"row {k}: N={N} max weight {w} ({fl(w):.4f}); N-1: {W(sq[:N-1], k):.4f}"); break
    else: print(f"row {k}: no N<30 reaches 1 (whole half-plane = s^(k-5) = {fl(S[5-k]):.4f})")
sf = (5**.5-1)/2
print("row 5 half-plane weight:", round(sum((2*j+1)*sf**(5+j) for j in range(500)), 9),
      "| diagonal variant rows 8,9:", [round((2*k+1)*sf**(k-2)+4*sf**(k-3), 4) for k in (8, 9)])
for k, N in [(1, 2), (2, 4), (3, 8)]:
    a0, a1 = reverse_bfs(k, N-1), reverse_bfs(k, N)
    shapes = {min(tuple(sorted(a)), tuple(sorted((-x, y) for x, y in a))) for a in a1}
    print(f"row {k}: {len(a0)} armies with {N-1} pegs; {len(a1)} with {N} ({len(shapes)} up to reflection)")
    for a, mv in a1.items(): assert play(a, mv, k) == {(0, k)}
    for a, mv in sorted(a1.items(), key=lambda kv: sorted(kv[0])):
        print("  ", sorted(a, key=lambda p: (-p[1], p[0])), "\n   moves:", "; ".join(f"{f}>{o}>{t}" for f, o, t in mv))
k = 4; T = (0, 4); top16 = [p for d in range(4, 8) for p in layer(4, d)]; L8 = layer(4, 8)
memo = {}
def solve(st, budget):                         # forward search; budget = W(st)-1 exact; prune when < 0
    if T in st: return []
    if st in memo: return memo[st]
    res = None
    for (x, y) in st:
        for dx, dy in DIRS:
            Q, R = (x+dx, y+dy), (x+2*dx, y+2*dy)
            if Q not in st or R in st: continue
            nb = sub(budget, sub(add(S[dist((x, y), 4)], S[dist(Q, 4)]), S[dist(R, 4)]))
            if sgn(nb) < 0: continue
            r = solve((st-{(x, y), Q})|{R}, nb)
            if r is not None: res = [((x, y), Q, R)]+r; break
        if res: break
    memo[st] = res; return res
t0 = time.time(); ok = 0
for extra in combinations(L8, 3):
    st = frozenset(top16+list(extra)); assert W(st, 4) > 1-1e-9
    ok += solve(st, (0, 0)) is not None
print(f"row 4, 19 pegs: {ok} of 84 weight-1 sets solvable ({len(memo)} positions, {time.time()-t0:.0f}s)")
army20 = [(-2,0),(-1,0),(0,0),(1,0),(2,0),(3,0),(4,0),(-2,-1),(-1,-1),(0,-1),(1,-1),(2,-1),(-2,-2),(-1,-2),(0,-2),(1,-2),(2,-2),(3,-2),(0,-3),(1,-3)]
mv20 = [((-1,-1),(-1,0),(-1,1)),((2,-1),(2,0),(2,1)),((4,0),(3,0),(2,0)),((-2,-1),(-2,0),(-2,1)),((-2,1),(-1,1),(0,1)),((0,0),(0,1),(0,2)),((2,0),(1,0),(0,0)),((1,-2),(1,-1),(1,0)),((3,-2),(2,-2),(1,-2)),((0,-1),(0,0),(0,1)),((0,1),(0,2),(0,3)),((0,-3),(0,-2),(0,-1)),((1,-3),(1,-2),(1,-1)),((-2,-2),(-1,-2),(0,-2)),((1,-1),(1,0),(1,1)),((2,1),(1,1),(0,1)),((0,-2),(0,-1),(0,0)),((0,0),(0,1),(0,2)),((0,2),(0,3),(0,4))]
print("row 4, 20-peg army verified, final:", play(army20, mv20, 4), "weight", round(W(army20, 4), 6))
print("strips: row3 mid col of width 3 (<=12 pegs):", len(reverse_bfs(3, 12, (-1, 1))), "| row3 edge col of width 3:",
      [N for N in range(2, 11) if reverse_bfs(3, N, (0, 2))])
print("3-column strip, target over a side column: heaviest 9-set weighs",
      round(sum(sorted((sf**dist((x, y), 3) for x in range(3) for y in range(0, -9, -1)), reverse=True)[:9]), 4))
def jumps(m, n):                               # 1-D: cells 0..n-1 as bits
    for i in range(n):
        if m >> i & 1:
            for d in (1, -1):
                j, t = i+d, i+2*d
                if 0 <= t < n and m >> j & 1 and not m >> t & 1: yield m & ~(1 << i) & ~(1 << j) | 1 << t
def reach(start, n):
    seen, stack = {start}, [start]
    while stack:
        for nm in jumps(stack.pop(), n):
            if nm not in seen: seen.add(nm); stack.append(nm)
    return seen
for n in range(1, 11):                         # block at cells n+2..2n+1 of a line of 4n+4 cells
    R = reach(sum(1 << i for i in range(n+2, 2*n+2)), 4*n+4)
    hi = max(m.bit_length() for m in R)-1; lo = min((m & -m).bit_length() for m in R)-1
    print(f"line, block of {n}: advance {hi-(2*n+1)}, retreat {n+2-lo}, min pegs left {min(bin(m).count('1') for m in R)}, configs {len(R)}")
for n in range(2, 13):
    @lru_cache(None)
    def ends(m): return frozenset([m.bit_length()]) if m & (m-1) == 0 else frozenset().union(*(ends(x) for x in jumps(m, n)))
    full = (1 << n)-1; sol = [m for m in range(1, full+1) if ends(m)]
    cls = lambda m: len({sum(m >> i & 1 for i in range(n) if i % 3 == r) % 2 for r in range(3)})
    assert all(cls(m) > 1 for m in sol)        # mod-3 colour-parity test is necessary
    holes = {h+1: sorted(ends(full & ~(1 << h))) for h in range(n) if ends(full & ~(1 << h))}
    print(f"strip 1x{n}: {len(sol)} of {full} subsets reducible to one peg; pass mod-3 test {sum(cls(m)>1 for m in range(1,full+1))}; one hole: {holes or 'none'}"
          + (f"; all: {' '.join(''.join('1' if m>>i&1 else '.' for i in range(n)) for m in sol if m&(m-1))}" if n <= 6 else ""))
ME = re.compile(r'1|011|110|11(01)*(00|00(11)+|(11)+00|(11)*1011|1101(11)*)(10)*11|11(01)*(11)*01|10(11)*(10)*11')
bad, cnt = [], []
for m in range(1, 13):                         # strings of length m starting and ending with a peg
    strs = ['1'] if m == 1 else ['1'+format(b, f'0{m-2}b')[-(m-2):]*(m > 2)+'1' for b in range(1 << (m-2))]
    solv = [s for s in strs if any(bin(x).count('1') == 1 for x in reach(int(s[::-1], 2) << m, 3*m))]
    cnt.append(len(solv)); bad += [s for s in strs if (s in solv) != bool(ME.fullmatch(s))]
print("infinite line, solvable strings by length 1..12:", cnt, "| mismatches with Moore-Eppstein regex:", bad)
def fib(j):
    a, b = 1, 1
    for _ in range(max(j, 1)-1): a, b = b, a+b
    return a
assert all(fib(a)+fib(a+d) >= fib(a+2*d) for a in range(-9, 30) for d in (1, -1))
print("Fibonacci pagoda ok; block weights F_{n+2}-1 vs target:", [(sum(fib(j) for j in range(1, n+1)), fib(n+2)) for n in range(1, 8)])
def board(cells):
    idx = {c: i for i, c in enumerate(cells)}
    J = [(1 << i, 1 << idx[(r+dr, c+dc)], 1 << idx[(r+2*dr, c+2*dc)]) for (r, c), i in idx.items()
         for dr, dc in DIRS if (r+dr, c+dc) in idx and (r+2*dr, c+2*dc) in idx]
    @lru_cache(None)
    def ends(m):
        if m & (m-1) == 0: return frozenset([cells[m.bit_length()-1]])
        return frozenset().union(*(ends(m & ~a & ~b | t) for a, b, t in J if m & a and m & b and not m & t))
    return idx, ends
for R, C in [(2, 3), (2, 4), (2, 5), (3, 3), (3, 4), (3, 5), (4, 4), (4, 5), (5, 5)]:
    cells = [(r, c) for r in range(R) for c in range(C)]; idx, ends = board(cells); full = (1 << R*C)-1
    out = {}
    for (r, c) in cells:
        if r <= (R-1)/2 and c <= (C-1)/2 and (R != C or r <= c):
            out[(r+1, c+1)] = sorted((a+1, b+1) for a, b in ends(full & ~(1 << idx[(r, c)]))) or 'no'
    print(f"{R}x{C} one hole ->", out)
eng = [(r, c) for r in range(-3, 4) for c in range(-3, 4) if abs(r) <= 1 or abs(c) <= 1]
cl = lambda P: tuple((sum((r+c) % 3 == i for r, c in P)+sum((r+c) % 3 == i+1 for r, c in P)) % 2 for i in range(2)) + \
               tuple((sum((r-c) % 3 == i for r, c in P)+sum((r-c) % 3 == i+1 for r, c in P)) % 2 for i in range(2))
print("English board, centre vacant, finishes allowed by position class:", [p for p in eng if cl([p]) == cl([q for q in eng if q != (0, 0)])])
```
