# Verified fact sheet: Bulgarian solitaire (theme B)

All numbers come from the script at the end (its assertions pass; the same checks were also run to n ≤ 40, k ≤ 9). States are pile lists, decreasing; 1^5 means five 1-piles; T_k = k(k+1)/2.

## 1. Rules, theorem, proof idea, move bound

**Rule.** A state is a multiset of pile sizes summing to n (a partition; order irrelevant). A move takes one counter from every pile and makes one new pile of them; a 1-pile disappears (its counter is in the new pile). New pile size = number of piles before the move, 1s included. Finite and deterministic, so every start eventually enters a cycle.

**Theorem (Brandt 1982).** If n = T_k, every start reaches the staircase (k, k−1, …, 1) and stays: k piles make a new pile of k, replacing the pile that reached 0. Fixed points exist only for triangular n. Write n = T_k + r, 0 ≤ r ≤ k. The states on cycles are exactly the C(k+1, r) partitions obtained from (k, k−1, …, 1, 0) by adding 1 to r of the k+1 entries (drop a final 0). A move rotates the pattern of added 1s cyclically, so cycles ↔ binary necklaces of length k+1 with r ones; every cycle length divides k+1.

**Proof idea (sliding diagonals).** Order the piles, always putting the new pile at the far left: (a₁,…,a_m) → (m, a₁−1, …, a_m−1), zeros deleted; as multisets this is the same game. Label the counter at height h of the c-th pile by its diagonal d = c + h − 1. A surviving counter lands at (c+1−v, h−1), v = number of vanishing 1-piles to its left, so its label drops by v; the m removed bottom counters had labels 1…m, as do the new pile's counters. So Φ = sum of labels never increases, and stays equal only when every vanishing pile lies right of all survivors. Along a cycle Φ is constant, so each move slides every counter one step along its diagonal, (c,h) → (c+1,h−1), the bottom cell of diagonal d wrapping to its top (1,d): the occupancy pattern of diagonal d rotates with period d. If diagonal d had a hole while d+1 held a counter, gcd(d, d+1) = 1 gives a moment when that counter sits directly above the hole, impossible in a stack. So on a cycle diagonals 1…k are full, diagonal k+1 holds r ≤ k counters, nothing beyond: n = T_k + r, Brandt's form; for n = T_k the staircase alone.

**Moves.** For n = T_k the staircase is reached within k² − k moves (Igusa 1985; Etienne 1991), and the bound is attained. Verified: maximum exactly k² − k for k = 1…9 (0, 2, 6, 12, 20, 30, 42, 56, 72), attained for k = 2…9 by (k−1, k−1, k−2, …, 1, 1), the staircase with one counter moved from its largest pile into a new 1-pile. Slowest starts: k=2 (1,1,1); k=3 (2,2,1,1); k=4 (3,3,2,1,1), (3,2,2,2,1), (3,2,2,1,1,1); k=5: 16 starts, all with largest pile ≤ 4, e.g. (4,4,3,2,1,1), (3,3,3,2,2,2). The single pile (T_k) takes exactly T_{k−1} moves and (1^{T_k}) one more, its first move giving (T_k): (6) 3, (1^6) 4, (10) 6, (1^10) 7, (15) 10, (1^15) 11.

## 2. Small-case data, n = 1…15

cyc = cycle states; max = most moves to reach a cycle; #max = starts attaining it; GoE = states without predecessor.

```
 n  p(n)  cyc  lengths  max  #max  GoE
 1     1    1  1          0     1    0
 2     2    2  2          0     2    0
 3     3    1  1          2     1    1
 4     5    3  3          2     1    1
 5     7    3  3          3     1    2
 6    11    1  1          6     1    3
 7    15    4  4          4     1    5
 8    22    6  4,2        5     1    7
 9    30    4  4          7     1   10
10    42    1  1         12     3   14
11    56    5  5          8     3   20
12    77   10  5,5        8     2   27
13   101   10  5,5        9     1   37
14   135    5  5         14     6   49
15   176    1  1         20    16   66
```

Slowest starts: n=3 (1,1,1); 4 (1^4); 5 (1^5); 6 (2,2,1,1); 7 (1^7); 8 (1^8); 9 (3,2,2,1,1); 10 see §1; 11 (3,3,2,2,1), (3,3,2,1,1,1), (3,2,2,2,1,1); 12 (3,3,2,2,1,1), (1^12); 13 (1^13); 14 (4,3,3,2,1,1), (4,3,2,2,2,1), (4,3,2,2,1,1,1), (3,3,3,2,2,1), (3,3,3,2,1,1,1), (3,3,2,2,2,1,1); 15 see §1. Moves for (n) to reach a cycle, n = 1…15: 0, 0, 1, 1, 2, 3, 3, 4, 5, 6, 6, 7, 8, 9, 10; (1^n) one more (n ≥ 3).

**Garden of Eden.** No predecessor iff largest pile ≤ (number of piles) − 2. Predecessors = distinct pile sizes m with m ≥ piles − 1; the predecessor for m: delete one m-pile, add 1 to every other pile, add 1-piles until there are m piles. GoE(n) = p(n−3) − p(n−9) + p(n−18) − … (Hopkins–Sellers 2007; verified n ≤ 40). Lists: n=3 (1,1,1); 4 (1^4); 5 (2,1,1,1), (1^5); 6 (2,2,1,1), (2,1^4), (1^6); 10: (4,2,1^4), (4,1^6), (3,3,2,1,1), (3,3,1^4), (3,2,2,2,1), (3,2,2,1,1,1), (3,2,1^5), (3,1^7), (2^5), (2^4,1,1), (2,2,2,1^4), (2,2,1^6), (2,1^8), (1^10).

**Full transitions**, state→successor [moves to staircase].

n=3: (2,1)→(2,1) [0]; (3)→(2,1) [1]; (1,1,1)→(3) [2].

n=6: (3,2,1)→itself [0]; (4,2)→(3,2,1) [1]; (5,1)→(4,2), (3,1,1,1)→(4,2) [2]; (6)→(5,1), (2,2,2)→(3,1,1,1), (2,1^4)→(5,1) [3]; (1^6)→(6), (3,3)→(2,2,2) [4]; (4,1,1)→(3,3) [5]; (2,2,1,1)→(4,1,1) [6]. Longest: (2,2,1,1)→(4,1,1)→(3,3)→(2,2,2)→(3,1,1,1)→(4,2)→(3,2,1).

n=10, all 42: (4,3,2,1)→itself [0]; (5,3,2)→(4,3,2,1) [1]; (6,4)→(5,3,2), (6,3,1)→(5,3,2), (4,3,1,1,1)→(5,3,2) [2]; (7,2,1)→(6,3,1), (7,1,1,1)→(6,4), (5,1^5)→(6,4), (4,2,2,2)→(4,3,1,1,1), (4,2,1^4)→(6,3,1) [3]; (8,2)→(7,2,1), (3,3,3,1)→(4,2,2,2), (3,2,1^5)→(7,2,1), (2^5)→(5,1^5), (2,2,2,1^4)→(7,1,1,1) [4]; (9,1)→(8,2), (4,4,2)→(3,3,3,1), (3,1^7)→(8,2) [5]; (10)→(9,1), (5,5)→(4,4,2), (5,3,1,1)→(4,4,2), (2,1^8)→(9,1) [6]; (1^10)→(10), (6,2,2)→(5,3,1,1), (6,1^4)→(5,5), (4,2,2,1,1)→(5,3,1,1) [7]; (7,3)→(6,2,2), (3,3,2,2)→(4,2,2,1,1), (3,3,1^4)→(6,2,2), (2^4,1,1)→(6,1^4) [8]; (8,1,1)→(7,3), (4,3,3)→(3,3,2,2), (4,1^6)→(7,3) [9]; (5,4,1)→(4,3,3), (4,4,1,1)→(4,3,3), (2,2,1^6)→(8,1,1) [10]; (6,2,1,1)→(5,4,1), (5,2,2,1)→(4,4,1,1), (5,2,1,1,1)→(5,4,1) [11]; (3,3,2,1,1)→(5,2,2,1), (3,2,2,2,1)→(5,2,1,1,1), (3,2,2,1,1,1)→(6,2,1,1) [12]. Longest: (3,3,2,1,1)→(5,2,2,1)→(4,4,1,1)→(4,3,3)→(3,3,2,2)→(4,2,2,1,1)→(5,3,1,1)→(4,4,2)→(3,3,3,1)→(4,2,2,2)→(4,3,1,1,1)→(5,3,2)→(4,3,2,1); the other two slowest starts join it at (4,3,3).

n=15 longest (20): (4,4,3,2,1,1)→(6,3,3,2,1)→(5,5,2,2,1)→(5,4,4,1,1)→(5,4,3,3)→(4,4,3,2,2)→(5,3,3,2,1,1)→(6,4,2,2,1)→(5,5,3,1,1)→(5,4,4,2)→(4,4,3,3,1)→(5,3,3,2,2)→(5,4,2,2,1,1)→(6,4,3,1,1)→(5,5,3,2)→(4,4,4,2,1)→(5,3,3,3,1)→(5,4,2,2,2)→(5,4,3,1,1,1)→(6,4,3,2)→(5,4,3,2,1).

**All cycles.** n=4: (3,1)→(2,2)→(2,1,1)→(3,1); others (4)→(3,1), (1^4)→(4). n=5: (3,2)→(2,2,1)→(3,1,1)→(3,2); others (5)→(4,1)→(3,2), (2,1,1,1)→(4,1), (1^5)→(5). n=7: (4,2,1)→(3,3,1)→(3,2,2)→(3,2,1,1)→(4,2,1); (7)→(6,1)→(5,2)→(4,2,1). n=8, two cycles: (4,3,1)→(3,3,2)→(3,2,2,1)→(4,2,1,1)→(4,3,1) and (4,2,2)↔(3,3,1,1); (8)→(7,1)→(6,2)→(5,2,1)→(4,3,1); (2,2,2,2)→(4,1^4)→(5,3)→(4,2,2). n=12: (5,4,2,1)→(4,4,3,1)→(4,3,3,2)→(4,3,2,2,1)→(5,3,2,1,1)→ and (5,3,3,1)→(4,4,2,2)→(4,3,3,1,1)→(5,3,2,2)→(4,4,2,1,1)→.

## 3. Trivial cases; one cycle or several

n = 1: the only state (1) is fixed. n = 2: (2) ↔ (1,1), a 2-cycle. Number of cycles = number of binary necklaces of length k+1 with r ones (n = T_k + r); it is 1 exactly when r ∈ {0, 1, k}, i.e. n within 1 of a triangular number: n = T_k gives the fixed point, n = T_k + 1 or T_{k+1} − 1 a single cycle of length k+1. All other n (8, 12, 13, 17, …) have ≥ 2 cycles. n = 8 is the first with two cycles and a 2-cycle; for k+1 prime and n non-triangular every cycle has length k+1.

## 4. Common errors to watch for

1. Forgetting that a 1-pile vanishes and its counter joins the new pile: (3,1,1,1)→(4,2) (four piles give a pile of 4), not (2,3) or "(2,0,0,0,4)".
2. Counting rearrangements as different states: (4,1,1) = (1,4,1); 6 counters have 11 states, 10 have 42, 15 have 176.
3. Claiming every n ends at a fixed point: n = 4 loops (3,1)→(2,2)→(2,1,1)→(3,1); "ends" must mean "repeats a state".
4. Misusing k² − k: k is the staircase height (n=6: 6, n=10: 12, n=15: 20), not n² − n; it fails for non-triangular n with k = floor (n = 14 needs 14 moves > 4² − 4). Nor is n a bound (12 > 10, 20 > 15).
5. Wrong step counts: (3,3) 4, (5,5) 6, (2^5) 4, (5,5,5) 17, and the §1 values. All-ones is not slowest for n = 6, 10, 15.
6. Calling a state a Garden of Eden when it has a predecessor: (3,3) ← (4,1,1); (4,2) ← (5,1), (3,1,1,1). Test: largest pile ≥ piles − 1 ⇒ predecessor exists.
7. "Piles always decrease" / "the biggest pile always shrinks": (2,2,2)→(3,1,1,1) has 3 then 4 piles; (3,1,1,1)→(4,2) grows the biggest pile.
8. "At most one predecessor" / "starts never merge": (5,1) and (3,1,1,1) both go to (4,2); (3,2,1) ← itself and (4,2).
9. "8 counters always reach the same loop": (2,2,2,2) ends in (4,2,2)↔(3,3,1,1), (8) in the 4-cycle.
10. Calling the single pile (n) a Garden of Eden: (1^n)→(n). Conversely (1^n) is one for every n ≥ 3, as is every slowest start (its predecessor would be slower).

## 5. What children can realistically do (judgment, not fact)

**K–1.** Play with 3 and 6 counters, draw towers, notice the game "gets stuck" at the 2-1 or 3-2-1 staircase, meet 1, 3, 6, 10 as staircase numbers, count moves. "Every start we tried ended there" is observation, not proof.

**Grades 2–3.** With 6 counters: list all 11 states and draw the complete arrow map, proving the theorem for n = 6 by exhaustion; find the longest path (6 moves from (2,2,1,1)) and the three states nobody arrives at; find the loops for 4 and 5 counters; explain why the staircase is stuck; reason backwards to a predecessor.

**Grades 4–5.** A group can map all 42 states for n = 10, explain why order is irrelevant, prove the staircase is fixed for every triangular number, discover and justify the predecessor rule, conjecture 2, 6, 12, 20 = k² − k, and describe the cycles for 7 and 8 counters. The general theorem and bound stay reported facts.

## Code (Python 3, run 2026-09-29)

```python
from collections import defaultdict
from itertools import combinations
from math import comb, gcd

def parts(n, m=None):                      # partitions of n as decreasing tuples
    m = n if m is None else m
    if n == 0: yield (); return
    for p in range(min(n, m), 0, -1):
        for r in parts(n - p, p): yield (p,) + r

def move(s):                               # one Bulgarian-solitaire move
    return tuple(sorted([p - 1 for p in s if p > 1] + [len(s)], reverse=True))

def analyse(n):
    S = list(parts(n)); nxt = {s: move(s) for s in S}
    pred = defaultdict(list)
    for s in S: pred[nxt[s]].append(s)
    cyc = set()
    for s in S:                            # states on cycles
        seen, t = {s}, nxt[s]
        while t not in seen: seen.add(t); t = nxt[t]
        c = t
        while True:
            cyc.add(c); c = nxt[c]
            if c == t: break
    dist = {}
    for s in S:
        d, t = 0, s
        while t not in cyc: t = nxt[t]; d += 1
        dist[s] = d
    cycles, done = [], set()
    for s in sorted(cyc, reverse=True):
        if s in done: continue
        c, t = [s], nxt[s]; done.add(s)
        while t != s: c.append(t); done.add(t); t = nxt[t]
        cycles.append(c)
    goe = [s for s in S if not pred[s]]
    return S, nxt, pred, cyc, dist, cycles, goe

f = lambda s: "(" + ",".join(map(str, s)) + ")"
def path(s, nxt, cyc):
    out = [s]
    while out[-1] not in cyc: out.append(nxt[out[-1]])
    return " -> ".join(map(f, out))

for n in range(1, 16):
    S, nxt, pred, cyc, dist, cycles, goe = analyse(n)
    mx = max(dist.values()); slow = [s for s in S if dist[s] == mx]
    k = 0
    while (k + 1) * (k + 2) // 2 <= n: k += 1
    r = n - k * (k + 1) // 2
    # Brandt: cycle states = staircase (k,...,1,0) with +1 on r of the k+1 entries
    brandt = {tuple(sorted([x for x in [k - i + (i in c) for i in range(k + 1)] if x], reverse=True))
              for c in combinations(range(k + 1), r)}
    neck = sum(comb((k + 1) // d, r // d) * sum(1 for a in range(1, d + 1) if gcd(a, d) == 1)
               for d in range(1, k + 2) if (k + 1) % d == 0 and r % d == 0) // (k + 1)
    assert brandt == cyc and neck == len(cycles) and all((k + 1) % len(c) == 0 for c in cycles)
    assert set(goe) == {s for s in S if s[0] <= len(s) - 2}               # rank <= -2
    assert all(len(pred[s]) == len({m for m in s if m >= len(s) - 1}) for s in S)
    print(f"n={n} p={len(S)} cyc={len(cyc)} lens={[len(c) for c in cycles]} max={mx} "
          f"#max={len(slow)} GoE={len(goe)} slowest={[f(s) for s in slow]}")
    for c in cycles: print("  cycle:", " -> ".join(map(f, c)))
    if n in (3, 6, 10):
        print("  ", "; ".join(f"{f(s)}->{f(nxt[s])} [{dist[s]}]" for s in sorted(S, key=lambda s: (dist[s], s))))
        print("  GoE:", [f(s) for s in goe]); print("  longest:", path(slow[0], nxt, cyc))
    print("  from (n):", path((n,), nxt, cyc), "| (1^n):", dist[(1,) * n])
for k in range(2, 9):                      # Igusa/Etienne bound k^2-k is attained
    n = k * (k + 1) // 2; S, nxt, pred, cyc, dist, cycles, goe = analyse(n)
    sp = tuple(sorted([k - 1, k - 1] + list(range(k - 2, 0, -1)) + [1], reverse=True))
    assert max(dist.values()) == k * k - k == dist[sp] and dist[(n,)] == k * (k - 1) // 2
print("bound checks k<=8 OK")
```
