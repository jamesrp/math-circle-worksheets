# Verified fact sheet: theme T (tilings)

**Conventions.** Square cells are (row, column), 0-indexed; "colour" = parity of row + column; "balanced" = equal colour counts. Triangular-grid cells are up- or down-pointing unit triangles; blocks: green 1 cell, blue rhombus 2, red trapezoid 3, yellow hexagon 6, purple chevron = two blues. All numbers come from the appendix code (run 2026-09-29), cross-checked against MacMahon's formula and an independent naive search.

## 1. Theorems and proof ideas

**T1 Mutilated checkerboard** (Max Black, 1946). The 8×8 minus two diagonally opposite corners (62 cells) has no domino tiling: each domino covers one cell of each colour, but opposite corners share a colour, leaving 30 vs 32. Any unbalanced region fails the same way. Opposite corners of *any* n×n share a colour; adjacent corners share a colour iff n is odd; an odd×odd board has (n²+1)/2 cells of the corner colour.

**T2 Gomory's theorem** (Honsberger, *Mathematical Gems I*, 1973). Remove one cell of each colour from an m×n board (mn even, m,n ≥ 2): the rest is always tileable. Proof: thread the cells by a closed rook tour; deleting two opposite-colour cells leaves two even-length paths. Verified: for square boards up to 6×6 with ≤3 cells removed, and 8×8 with 2 removed, *balanced ⇔ tileable*, so a balanced-but-untileable example needs an irregular region (§2a).

**T3 Other colourings.** Any labelling for which every legal placement has the same sum gives a necessary condition. For straight (I) trominoes colour by (r+c) mod 3 and by (r−c) mod 3: the 8×8 minus one cell is I-tileable only for holes (2,2), (2,5), (5,2), (5,5), and those work (Golomb 1954); 4×4: hole must be a corner; 5×5: the centre.

**T4 Tilings are perfect matchings.** Cells are vertices, adjacent cells edges; the grid graph is bipartite (the two colours) and a domino tiling is a perfect matching. Hall's theorem is the exact criterion: tileable iff every set S of black cells has ≥ |S| white neighbours; colour counting is the case S = all black cells; the §2a counterexamples violate Hall with |S| = 2. So domino tileability and counting are polynomial (Kasteleyn, Temperley–Fisher 1961: 8×8 has 12,988,816 tilings; 2×n strips give Fibonacci numbers), whereas L-tromino tiling is NP-complete (Moore–Robson 2001) and tiling the plane with a finite tile set is undecidable (Berger 1966). Flips (rotating two parallel dominoes in a 2×2 block) connect all tilings of a hole-free region (Thurston 1990), not necessarily of a region with holes.

**T5 L-tromino theorem** (Golomb 1954). Every 2ⁿ×2ⁿ board minus one cell is L-tileable. Induction: cut into quadrants; one L in the centre covers one cell of each of the three quadrants without the hole; each quadrant is now a deficient 2ⁿ⁻¹ board. Piece counts (4ⁿ−1)/3 = 1, 5, 21, 85. Other sizes (Chu–Johnsonbaugh 1986; verified): n divisible by 3 is impossible by counting; 5×5 works only for the 9 holes with both coordinates even; 7×7 works for every hole; an m×n rectangle (m,n ≥ 2) is L-tileable iff 3 | mn and it is not 3×odd.

**T6 Up/down colouring.** Adjacent unit triangles point opposite ways, so every grid-aligned blue rhombus covers one up and one down cell; so does each chevron (2 blue) and yellow hexagon (3+3). A red trapezoid covers 2+1, a green 1+0. So a region with U up- and D down-cells cannot be covered by blue/purple/yellow unless U = D, and any covering needs at least |U−D| red or green pieces. The side-n triangle has n² cells, U = n(n+1)/2, D = n(n−1)/2, excess n: at most n(n−1)/2 blue rhombi fit, leaving at least n uncovered cells (verified n = 2..6). Balanced still does not imply tileable: two red trapezoids joined along their short sides (a bow tie) have 3 up + 3 down and no rhombus tiling.

**T7 Lozenge tilings of hexagons.** The hexagon with sides a,b,c,a,b,c has 2(ab+bc+ca) cells, U = D, and its rhombus tilings are exactly pictures of cube stacks (plane partitions) in an a×b×c box (David–Tomei 1989). MacMahon (1915): count = ∏_{i≤a, j≤b, k≤c} (i+j+k−1)/(i+j+k−2); (1,b,c) = C(b+c, b). A flip rotates the three rhombi filling a unit hexagon (adds or removes a cube); every stack reduces to the empty one, so the flip graph is connected. Verified counts (a,b,c ≤ 3): (1,1,1) 2; (1,1,2) 3; (1,1,3) 4; (1,2,2) 6; (1,2,3) 10; (1,3,3) 20; (2,2,2) 20; (2,2,3) 50; (2,3,3) 175; (3,3,3) 980.

## 2. Small-case data (brute force)

**(a) Dominoes.** Full boards: 2×n, n = 1..8: 1, 2, 3, 5, 8, 13, 21, 34. 3×2, 3×4, 3×6, 3×8: 3, 11, 41, 153. 4×4 36; 4×5 95; 4×6 281; 5×6 1183; 6×6 6728; 8×8 12,988,816.

| board minus k cells | balanced = tileable removals | note |
|---|---|---|
| 3×3 − 1 | 5 of 9 | corner or centre hole works; edge-middle hole leaves 5:3 |
| 4×4 − 2 | 64 of 120 | every opposite-colour pair; every same-colour pair fails |
| 5×5 − 1 | 13 of 25 | exactly the holes with r+c even |
| 6×6 − 2 | 324 of 630 | |
| 8×8 − 2 | 1024 of 2016 | e.g. two adjacent corners (31:31) tileable |
| 3×3 − 3, 5×5 − 3 | 40, 936 | all balanced removals tileable |
| even − 1 or − 3; odd − 2 | none | odd cell count |

Balanced but untileable: (i) hexomino `.X.. / XXXX / ..X.` (3:3; cells (0,1) and (1,0) both touch only (1,1)); (ii) 1×4 strip minus its two middle cells; (iii) two separate odd pieces of opposite majority colour. Domino flip graphs of 2×3, 2×4, 3×4, 4×4 (3, 5, 11, 36 tilings) are connected; some tiling has only 1 flip; maxima 2, 3, 4, 6.

**(b) Side-n triangle.**

| n | cells (n²) | up | down | max blue | min uncovered | max red | all-red tilings |
|---|---|---|---|---|---|---|---|
| 2 | 4 | 3 | 1 | 1 | 2 | 1 | 0 |
| 3 | 9 | 6 | 3 | 3 | 3 | 3 | 2 |
| 4 | 16 | 10 | 6 | 6 | 4 | 5 | 0 |
| 5 | 25 | 15 | 10 | 10 | 5 | 8 | 0 |
| 6 | 36 | 21 | 15 | 15 | 6 | – | 220 |

Fillings with green/blue/red/yellow, counted as placed pictures [piece-combinations]: yellow hexagon 40 [8], of which blue-only 2, red-only 3; side-2 triangle 7 [3]; side-3 triangle 202 [11]. Side-2 hexagon (24 cells): 20 blue tilings, 9 red, 0 by yellow hexagons. Two red trapezoids: long-to-long is the hexagon (2 blue tilings), offset a parallelogram (1), short-to-short the bow tie (0).

**(c)** See T7; brute force matched MacMahon in every case.

**(d) Flips.** (1,1,1): 2 tilings, 1 flip each. (1,1,2): 3 tilings, flip counts 1,1,2 (a path). (1,2,2), i.e. sides 1,2,2,1,2,2: 6 tilings, flip counts 1,1,2,2,3,3. (2,2,2): 20 tilings; flip counts 1 (×2: empty and full stack), 2 (×3), 3 (×6), 4 (×8), 6 (×1). (2,2,3): 50 tilings, flip counts 1–7. All connected.

**(e) Trominoes.** 4×4 minus one cell: exactly **1** L-tiling for every hole; I-trominoes: 4 tilings if the hole is a corner, else 0. 5×5 minus one cell: L-tilings 8 (corner), 16 (edge-middle), 32 (centre), 0 for the other 16 holes; I-trominoes: centre only (2). 8×8 minus a corner: 30,355 L-tilings; minus (3,3): 13,779. Rectangles: 2×3 has 2 L-tilings, 3×4 4, 2×6 4, 4×6 18, 6×6 162; 3×3, 3×5, 3×7, 3×9 impossible; 5×9, 6×7, 7×9, 9×9 possible.

## 3. Common errors to watch for

1. "Equal colour counts, so it can be tiled": false (hexomino, bow tie); colouring only proves impossibility.
2. Applying the checkerboard argument to *any* two removed squares: two opposite-colour squares (e.g. adjacent corners) always leave a tileable board.
3. Colour slips: adjacent corners of an 8×8 differ; opposite corners always agree; on a 5×5 all four corners agree.
4. Chevrons or yellow hexagons "fixing" a blue-impossible region: they are unions of blue rhombi. Only red or green pieces absorb imbalance, at least |U−D| of them.
5. Miscounting: a side-n triangle holds n² cells (not 2n, nor n(n+1)/2, the up cells only); a side-2 hexagon holds 24 cells and four yellows do not form it (the 7-yellow "flower" is not a hexagon).
6. Scale: with 1-inch edges the yellow hexagon is 2 in corner-to-corner, ≈1.73 in flat-to-flat; a printed side-n triangle needs n-inch sides; the tan (30°) rhombus and orange square are not grid pieces (tan area 0.5 in² vs green 0.433 in²).
7. Carrying the L-tromino induction to other boards: 3×3 and 6×6 minus a cell are impossible by counting; 5×5 works for 9 holes only; 7×7 works everywhere but not by the quadrant argument; the full 3×3 is not L-tileable.
8. "Find another way to tile the 4×4 with a hole": the tiling is unique for every hole.
9. Conflating straight and L trominoes: 4×4 minus a corner has 1 L-tiling and 4 I-tilings; minus any other cell, 1 and 0.
10. "8 ways to fill the yellow hexagon" holds for piece-combinations only; as pictures there are 40.
11. Counting 2×n strips as n ways: 1, 2, 3 breaks at n = 4 (5 ways); 4×4 has 36.
12. Flip overclaims: "every tiling has several flips" (the empty and full stacks of (2,2,2) have one) or "flips connect everything" for regions with holes.

## 4. Age-appropriate reach (judgment, not fact)

**K–1.** Can cover shapes with dominoes and blocks, discover by trial that side-2 and side-3 triangles refuse blue rhombi, and count cells by colouring them (1, 4, 9). "Each domino eats one white and one black" works only with a coloured board and physical pieces; expect checking of specific boards, not a general explanation.

**2–3.** Can run the checkerboard argument on a 4×4 or 6×6 with two same-colour holes and state it as an explanation, and colour up/down cells to explain why the side-3 triangle needs red or green pieces. Can find the 2 blue and 3 red fillings of the hexagon and tabulate 2×n counts to n = 5. The 4×4 L-tromino tiling by hand, yes; the induction only as "the centre trick".

**4–5.** Can give the 8×8 colouring proof, adapt it to "which two squares can be removed", discover Gomory's case experimentally, execute the 8×8 L-tromino construction and say why the quadrant trick always works, count the 20 tilings of the (2,2,2) hexagon as cube stacks, and see flips as adding or removing a cube. Hall's condition and hardness stay out of reach; balanced-but-untileable examples convince only as puzzles.

## Appendix: verification code (Python 3, about 2 s; the word count above excludes this block)

```python
#!/usr/bin/env python3
"""Brute-force checks for the tilings fact sheet."""
import sys, itertools
from fractions import Fraction
sys.setrecursionlimit(10000)

def count_covers(cells, placements, limit=None):
    """Exact covers of `cells` by `placements` (frozensets). Memoized on (first uncovered index, covered cells beyond it). limit=1 -> existence."""
    order = sorted(cells); pos = {c: i for i, c in enumerate(order)}; by_min = {}
    for p in placements:
        if p <= cells: by_min.setdefault(min(pos[c] for c in p), []).append(p)
    memo = {}
    def rec(i, filled):
        while i < len(order) and order[i] in filled: filled = filled - {order[i]}; i += 1
        if i == len(order): return 1
        key = (i, filled)
        if key in memo: return memo[key]
        tot = 0
        for p in by_min.get(i, ()):
            if not (p & filled):
                tot += rec(i + 1, filled | (p - {order[i]}))
                if limit and tot >= limit: break
        memo[key] = tot; return tot
    return rec(0, frozenset())

def grid(m, n): return {(r, c) for r in range(m) for c in range(n)}
def dominoes(cells):
    return {frozenset(p) for (r, c) in cells for p in [((r, c), (r, c + 1)), ((r, c), (r + 1, c))] if p[1] in cells}
def L_trominoes(cells):
    out = set(); anchors = {(r + dr, c + dc) for (r, c) in cells for dr in (-1, 0) for dc in (-1, 0)}
    for (r, c) in anchors:  # every 2x2 box minus one cell
        sq = [(r, c), (r, c + 1), (r + 1, c), (r + 1, c + 1)]
        for k in range(4):
            t = sq[:k] + sq[k + 1:]
            if all(x in cells for x in t): out.add(frozenset(t))
    return out
def I_trominoes(cells):
    out = set()
    for (r, c) in cells:
        for t in [((r, c), (r, c + 1), (r, c + 2)), ((r, c), (r + 1, c), (r + 2, c))]:
            if all(x in cells for x in t): out.add(frozenset(t))
    return out
def color_counts(cells):
    b = sum((r + c) % 2 == 0 for r, c in cells); return b, len(cells) - b

print("=== (A) DOMINOES ===")
for m, n in [(2,1),(2,2),(2,3),(2,4),(2,5),(2,6),(2,7),(2,8),(3,2),(3,4),(3,6),(3,8),(4,4),(4,5),(4,6),(5,6),(6,6),(8,8)]:
    print(f"  {m}x{n}: {count_covers(grid(m, n), dominoes(grid(m, n)))}")
print("n x n minus k cells: (#balanced, #tileable, balanced==tileable for all?)")
for n in range(2, 7):
    for k in (1, 2, 3):
        if n == 6 and k == 3: continue
        G = grid(n, n); nb = nt = 0; ok = True
        for rem in itertools.combinations(sorted(G), k):
            R = G - set(rem); b, w = color_counts(R)
            bal = (b == w); til = bool(count_covers(R, dominoes(R), limit=1)); nb += bal; nt += til; ok &= (bal == til)
        print(f"  {n}x{n} minus {k}: balanced={nb} tileable={nt} equivalent={ok}")
print("5x5 minus one cell, tileable (T) / not (.):")
for r in range(5):
    print("   " + "".join("T" if count_covers(grid(5,5)-{(r,c)}, dominoes(grid(5,5)-{(r,c)}), 1) else "." for c in range(5)))
for name, R in [("hexomino .X../XXXX/..X.", {(0,1),(1,0),(1,1),(1,2),(1,3),(2,2)}), ("1x4 minus middle two", {(0,0),(0,3)})]:
    print(f"  {name}: colors={color_counts(R)} tilings={count_covers(R, dominoes(R))}")
G8 = grid(8, 8)
print("Gomory: every 8x8 minus two opposite-colored cells tileable:",
      all(count_covers(G8 - set(p), dominoes(G8 - set(p)), 1) for p in itertools.combinations(sorted(G8), 2) if (sum(p[0]) + sum(p[1])) % 2 == 1))
print("8x8 minus opposite corners:", color_counts(G8-{(0,0),(7,7)}), " minus adjacent corners:", color_counts(G8-{(0,0),(0,7)}),
      "tileable:", bool(count_covers(G8-{(0,0),(0,7)}, dominoes(G8-{(0,0),(0,7)}), 1)))

def enumerate_tilings(R, P):
    out = []
    def rec(rem, cur):
        if not rem: out.append(frozenset(cur)); return
        c = min(rem)
        for p in P:
            if c in p and p <= rem: rec(rem - p, cur + [p])
    rec(frozenset(R), []); return out
def flip_graph_stats(tilings, flips):
    """flips(t) -> iterable of neighbouring tilings; returns (count, connected?, degree distribution)"""
    idx = {t: i for i, t in enumerate(tilings)}; adj = {i: {idx[t2] for t2 in flips(t)} for t, i in idx.items()}
    seen = {0}; st = [0]
    while st:
        u = st.pop()
        for v in adj[u]:
            if v not in seen: seen.add(v); st.append(v)
    degs = sorted(len(adj[i]) for i in adj)
    return len(tilings), len(seen) == len(tilings), {d: degs.count(d) for d in sorted(set(degs))}
def domino_flips(t):
    for d1, d2 in itertools.combinations(t, 2):
        sq = d1 | d2; rs = {r for r, c in sq}; cs = {c for r, c in sq}
        if len(sq) == 4 and max(rs) - min(rs) == 1 and max(cs) - min(cs) == 1:   # two parallel dominoes in a 2x2 block
            q = sorted(sq); alt = {frozenset([q[0], q[1]]), frozenset([q[2], q[3]])}
            if alt & {d1, d2}: alt = {frozenset([q[0], q[2]]), frozenset([q[1], q[3]])}
            yield (t - {d1, d2}) | alt
for m, n in [(2,3),(2,4),(3,4),(4,4)]:
    print(f"  {m}x{n} domino flip graph (tilings, connected, degree distribution):", flip_graph_stats(enumerate_tilings(grid(m,n), dominoes(grid(m,n))), domino_flips))

print("=== (E) TROMINOES ===")
for r in range(4):
    print("  4x4 minus cell row", r, "L-tilings:", [count_covers(grid(4,4)-{(r,c)}, L_trominoes(grid(4,4)-{(r,c)})) for c in range(4)],
          "I-tilings:", [count_covers(grid(4,4)-{(r,c)}, I_trominoes(grid(4,4)-{(r,c)})) for c in range(4)])
for r in range(5):
    print("  5x5 minus cell row", r, "L-tilings:", [count_covers(grid(5,5)-{(r,c)}, L_trominoes(grid(5,5)-{(r,c)})) for c in range(5)],
          "I-tilings:", [count_covers(grid(5,5)-{(r,c)}, I_trominoes(grid(5,5)-{(r,c)})) for c in range(5)])
print("  7x7 minus one cell, all L-tileable:", all(count_covers(grid(7,7)-{(r,c)}, L_trominoes(grid(7,7)-{(r,c)}), 1) for r in range(7) for c in range(7)))
print("  8x8 minus corner / minus (3,3): L-tilings =", count_covers(G8-{(0,0)}, L_trominoes(G8-{(0,0)})), count_covers(G8-{(3,3)}, L_trominoes(G8-{(3,3)})))
print("  8x8 minus one cell, I-tileable holes:", [(r,c) for r in range(8) for c in range(8) if count_covers(G8-{(r,c)}, I_trominoes(G8-{(r,c)}), 1)])
rects = [(m,n) for m in range(2,10) for n in range(m,10) if (m*n) % 3 == 0]
print("  L-tileable rectangles:", [p for p in rects if count_covers(grid(*p), L_trominoes(grid(*p)), 1)])
print("  NOT L-tileable:", [p for p in rects if not count_covers(grid(*p), L_trominoes(grid(*p)), 1)])
print("  L-tilings of 2x3, 3x4, 2x6, 4x6, 6x6:", [count_covers(grid(m,n), L_trominoes(grid(m,n))) for m,n in [(2,3),(3,4),(2,6),(4,6),(6,6)]])

print("=== (B) TRIANGULAR GRID ===")
# ('U',i,j) has vertices (i,j),(i+1,j),(i,j+1); ('D',i,j) has (i+1,j),(i,j+1),(i+1,j+1)  [lattice point (i,j) -> i*(1,0)+j*(1/2,sqrt3/2)]
def verts(t):
    o, i, j = t; return [(i,j),(i+1,j),(i,j+1)] if o == 'U' else [(i+1,j),(i,j+1),(i+1,j+1)]
def region(inside, rng): return {(o,i,j) for o in 'UD' for i in rng for j in rng if all(inside(v) for v in verts((o,i,j)))}
def triangle_region(n): return region(lambda v: v[0] >= 0 and v[1] >= 0 and v[0]+v[1] <= n, range(-1, n+1))
def hexagon_region(a, b, c):   # big triangle of side a+b+c with corners of sides a, b, c cut off
    L = a + b + c
    return region(lambda v: v[0] >= 0 and v[1] >= 0 and a <= v[0]+v[1] <= L and v[0] <= L-b and v[1] <= L-c, range(-1, L+1))
def adjacent(t1, t2): return len(set(verts(t1)) & set(verts(t2))) == 2
def updown(R): return sum(t[0] == 'U' for t in R), sum(t[0] == 'D' for t in R)
def lozenges(R):
    return {frozenset([u, d]) for u in R if u[0] == 'U' for d in [('D',u[1],u[2]),('D',u[1],u[2]-1),('D',u[1]-1,u[2])] if d in R}
def trapezoids(R):   # 3 consecutive triangles in a row = side-2 triangle minus a corner
    out = set(); anchors = {(i + di, j + dj) for (_, i, j) in R for di in (-1, 0) for dj in (-1, 0)}
    for (i, j) in anchors:
        for corners, mid in [([('U',i,j),('U',i+1,j),('U',i,j+1)], ('D',i,j)), ([('D',i+1,j),('D',i,j+1),('D',i+1,j+1)], ('U',i+1,j+1))]:
            for k in range(3):
                t = frozenset([mid] + corners[:k] + corners[k+1:])
                if t <= R: out.add(t)
    return out
def unit_hexagons(R):
    out = set()
    for (i, j) in {v for t in R for v in verts(t)}:
        h = frozenset([('U',i,j),('U',i-1,j),('U',i,j-1),('D',i-1,j-1),('D',i-1,j),('D',i,j-1)])
        if h <= R: out.add(h)
    return out
for R in [triangle_region(n) for n in range(2, 6)] + [hexagon_region(2,2,2)]:   # sanity: trapezoid generator == all 3-triangle edge paths
    assert trapezoids(R) == {frozenset(t) for t in itertools.combinations(sorted(R), 3) if sum(adjacent(a, b) for a, b in itertools.combinations(t, 2)) == 2}
def max_matching(R):
    adj = {}
    for l in lozenges(R):
        u, d = sorted(l, key=lambda t: t[0] == 'D'); adj.setdefault(u, []).append(d)
    match = {}
    def aug(u, seen):
        for d in adj.get(u, []):
            if d not in seen:
                seen.add(d)
                if d not in match or aug(match[d], seen): match[d] = u; return True
        return False
    return sum(aug(u, set()) for u in R if u[0] == 'U')
def max_pack(R, T):
    best = [0]
    def pack(rem, cnt):
        best[0] = max(best[0], cnt)
        if not rem or cnt + len(rem)//3 <= best[0]: return
        c = min(rem)
        for t in T:
            if c in t and t <= rem: pack(rem - t, cnt + 1)
        pack(rem - {c}, cnt)
    pack(frozenset(R), 0); return best[0]
for n in range(2, 7):
    R = triangle_region(n); up, dn = updown(R); mm = max_matching(R)
    print(f"  side-{n}: cells={len(R)} up={up} down={dn} maxblue={mm} mingaps={len(R)-2*mm} maxtrap={max_pack(R, trapezoids(R)) if n<=5 else '-'} trapTilings={count_covers(R, trapezoids(R)) if n%3==0 else 0}")
def pattern_block_tilings(R):
    P = {frozenset([t]) for t in R} | lozenges(R) | trapezoids(R) | unit_hexagons(R)
    sols = [tuple(sorted(len(p) for p in t)) for t in enumerate_tilings(R, P)]
    return len(sols), sorted(set(sols))
H1 = hexagon_region(1,1,1)
print("  unit hexagon with green/blue/red/yellow: placed tilings, multisets =", pattern_block_tilings(H1))
print("  side-2 triangle:", pattern_block_tilings(triangle_region(2)), " side-3 triangle:", pattern_block_tilings(triangle_region(3)))
print("  unit hexagon: blue-only", count_covers(H1, lozenges(H1)), "red-only", count_covers(H1, trapezoids(H1)))
H2 = hexagon_region(2,2,2)
print("  side-2 hexagon: cells", len(H2), "yellow-only", count_covers(H2, unit_hexagons(H2)), "red-only", count_covers(H2, trapezoids(H2)))
bowtie = {('U',1,1),('D',1,0),('D',0,1),('D',1,1),('U',2,1),('U',1,2)}; strip6 = {(o,i,0) for o in 'UD' for i in range(3)}
for name, R in [("hexagon", H1), ("parallelogram", strip6), ("bow tie", bowtie)]:
    print(f"  two trapezoids as {name}: up/down={updown(R)} blue tilings={count_covers(R, lozenges(R))} red tilings={count_covers(R, trapezoids(R))}")

print("=== (C),(D) LOZENGE TILINGS OF HEXAGONS ===")
def macmahon(a, b, c):
    p = Fraction(1)
    for i, j, k in itertools.product(range(1,a+1), range(1,b+1), range(1,c+1)): p *= Fraction(i+j+k-1, i+j+k-2)
    return int(p)
def lozenge_flips(R):
    L, H = lozenges(R), unit_hexagons(R)
    def flips(t):
        for h in H:
            inside = {l for l in t if l <= h}
            if len(inside) == 3: yield (t - inside) | {l for l in L if l <= h and l not in inside}
    return flips
for a, b, c in [(1,1,1),(1,1,2),(1,1,3),(1,2,2),(1,2,3),(1,3,3),(2,2,2),(2,2,3),(2,3,3),(3,3,3)]:
    R = hexagon_region(a, b, c)
    if a*b*c <= 12: print(f"  ({a},{b},{c}): cells={len(R)} macmahon={macmahon(a,b,c)} (tilings, connected, flip degrees)={flip_graph_stats(enumerate_tilings(R, lozenges(R)), lozenge_flips(R))}")
    else: print(f"  ({a},{b},{c}): cells={len(R)} tilings={count_covers(R, lozenges(R))} macmahon={macmahon(a,b,c)}")
```
