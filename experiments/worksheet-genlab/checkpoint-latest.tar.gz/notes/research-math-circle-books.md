# What three math-circle books say about sessions and worksheets for K–5

**Sources and citations.** *MCBB* = Givental, Nemirovskaya, Zakharevich, *Math Circle by the Bay* (2018), cited by page. *NR* = Rozhkovskaya, *Math Circles for Elementary School Students* (2014; the Kindle text has no page numbers), cited by Lesson; "ATL" = that lesson's "At the lesson" report. *Decade* = Stankova & Rike, *A Decade of the Berkeley Math Circle* (2008), cited by page; a middle/high-school book, used only for its framing of proof and session design. **[inference]** marks my own conclusions.

---

## 1. What makes a session or problem set work

**Sequencing.** MCBB names "the logical sequence of the problems" as the book's main feature (p. vii). Their arc, told to the children after the Fibonacci tilings: "We studied the simplest examples first. We figured out the pattern. We invented a systematic way of reasoning" (p. 44). They engineer an early pattern-break: for strips of length 4 "Most students immediately yelled four... this guess turned out to be wrong" (p. 42), which "justified the question: 'Will this pattern continue forever?'" (p. 42). NR opens the circle game by considering "easier cases... with two, four, or six points" (Lesson 7). Both seed topics ahead: MCBB gives "an introductory warmup problem a week or two before starting an in-depth discussion" (p. ix; warmups 6.1–6.14 are each tied to a later chapter, pp. 135–145).

**Quantity, pace, text.** MCBB sessions are "50–55 minutes long, with 25–30 students (and two instructors)" (p. viii). Neither book gives a problem count; MCBB: "we do not believe it makes sense to estimate how much time a particular topic will take" (p. x). Real throughput was low: NR finished "only one or two drawings of knots... fewer than I intended" (L1 ATL); pizza cutting stopped at four cuts because "It is a challenging task to draw neat straight lines" (L9 ATL); arithmetic tables "took a lot of time" (L8 ATL). On text: "This age group does not enjoy reading long texts" (L4 ATL); "not everyone in the class was yet a fluent reader" (L2 ATL); "I retold the problem in my own words" (L8 ATL). MCBB's two rules: statements must be "unambiguous for the children and at the same time easy to understand"; "Presenting problems as funny or even silly stories excites the kids", and "Most of our problems have names or characters" so children recall them by name (p. ix). They avoid long expressions because "many of our students do not know the order of operations and/or parentheses" (p. 131).

**Manipulatives, games, movement.** MCBB: "We always have a bag of manipulatives (little cubes, coins, sticks, etc.)" (p. ix); coins for triangular numbers, scissors and duplicate pictures for children who cannot rearrange mentally (pp. 12, 116). NR: marbles as frogs (L11), dice in a Random Maze (L4), K'nex polygons (L7), pocket mirrors and kaleidoscopes (L12), paper crafts as topology (L3, L9). Whole-body enactment recurs: seven children "played the part of the frogs" at the board (L11 ATL); board circle-drawing was so absorbing that "for some parents it was difficult to take their kids home" (L4 ATL); the race game's "overexcited players could be heard all over the department" (L15 ATL).

**Explain vs. discover.** Both run a short solo attempt then group discussion: "students spent a few minutes trying to solve the problem themselves, and after that we discussed the problem on the board" (NR L3 ATL). MCBB scripts leading questions ("What can be the first step in building the strip?", p. 43) and calls its fullest hints "the worst case scenario" (p. 43). They postpone telling: after bead-coloring they "postponed the actual discussion, giving the kids a chance to discover for themselves a systematic way" (p. 25). NR withholds Gauss's sum "to leave the participants the opportunity to find the solution on their own" (L9 ATL). Definitions come by examples: "Many notions were discussed only through examples, without strict definitions" (L3 ATL); MCBB will not say "area" until children "have some experience with it" (p. 99).

**Mixed levels and fast finishers.** NR's room spanned "five-year-old kids who worked with their parents" to children "with very solid math skills", so "for every lesson, I prepared additional problems for those participants who quickly completed the main task. As a rule, the additional problems were not discussed in class" (L3 ATL). MCBB: "We keep a stack of challenging problems for the kids who are ahead of the rest of the class"; warmups "help to cope with late arrivals" (p. ix). On age bands: the same material serves grades 1–2 and 3–4, and "the difference between the older and the younger groups is not that significant"; younger children "digest information slower, and the older students retain it better" (p. x). MCBB differentiates by numbers and prerequisites, not topic: skip 7², 8², 9² for children "not comfortable with... multiplication" (p. 2); hypotenuse 5 or 13 rather than 25 for younger ones (p. 124); a folding square with "extra slanted lines, which help the younger children" (p. 99).

**Proof for ages 5–11.** MCBB: "We prefer not to use the word 'proof' and use the word 'explanation' instead, until children prove a few facts by themselves" (p. 10); "Our students cannot formulate statements which involve unknown quantities... It is enough if they can see that 'the same argument also works for longer strips'" (p. 44); "one needs a single counterexample to show that a statement is incorrect" (p. 144). "Proof" is named only after Pythagoras: "A proof must withstand any possible attack — it should be watertight" (p. 122). They knowingly leave gaps ("We decided not to focus their attention on this gap", p. 59). NR: the goal was "not only to solve the problems, but to learn to give arguments"; "A table is more illustrative than a long explanation in words" (L3 ATL); a winning strategy stands in for a parity proof the children "were not ready for" (L7 ATL); parity gives a complete impossibility proof (M.12). *Decade* adds the "annoying little sister test" ("And why is this? And how do you know that?", p. 87), Manin's "A good proof is one that makes us wiser" (p. 88), and delays formal proof until students have met "two or three intriguing mathematical topics" (p. xiv).

---

## 2. What failed or surprised them

- **Words and culture.** Non-readers in grades 1–3 (NR L2 ATL). A yes/no tree broke on "Is this a wild hare or a pet rabbit?" and on whether bears hibernate (L10 ATL). A sweepstakes example failed because "Santa Claus never gives gifts randomly" (L13 ATL). "Area" was heard as "Bay Area" (MCBB p. 99).
- **The question was the obstacle.** Flower pots: "We spent a significant amount of time trying to understand the question" (L6 ATL). Coins read aloud: "The majority of the children immediately decided that this problem has no solution" (MCBB p. 145).
- **Hidden-trick problems fail with beginners**, who "carefully read every word... honestly climbed with the caterpillar each foot"; "I try to avoid problems 'with hidden tricks'" (L6 ATL).
- **Notation.** 5² = 10, and squares of numbers "produced even more confusion" (L3 ATL); "3-by-3-by-3" lets children compute "without understanding the geometry" (MCBB p. 18); zeroth rows confuse, so number from one (p. 76); "congruent" is unrecoverable once forgotten, hence "SAME SHAPE SAME SIZE" (p. 107). Counter-surprise: "even the first and second graders were writing such monstrous fractions as 1/256 without hesitation" (p. 106).
- **Physical logistics.** Craft sticks "too big for standard university desks" killed matchstick problems (L5 ATL); without mirrors "imagining two mirrors was already challenging" (L12 ATL); coded pictures "may go outside of the borders" unless the grid is ~20×20 and the start cell is given (L2 ATL); race lanes should be "six or seven boxes instead of ten" (L15 ATL); scoops must be drawn side-by-side or children treat CV ≠ VC (MCBB p. 28); children "draw their own grid on top of the existing one" (p. 99).
- **Pacing splits.** Table-filling made "two groups: those who had finished coloring and those who were still writing" (L8 ATL); "many students simply copied the solution from the board" (L9 ATL).
- **Data games get gamed.** Children "first colored houses and tables, and only after that they rolled a die until they got the desired color" (L13 ATL); racers switched lanes (L15 ATL). Children doubted a die is fair: "maybe 3 appears more often... since it is a number in the middle" (L13 ATL).
- **Geometry is harder than logic.** Children "skillfully resolved complicated logic situations... could get stuck with the easiest geometry questions" (L6 ATL); the angle-sum experiment moved parents, not kids: "I cannot recall any case where any of the kids were much surprised" (L6 ATL), and nobody remembered it a week later (L7 ATL). "Many children struggled with visualization of three-dimensional shapes" (MCBB p. 23).
- **Unexpectedly engaging.** Knights-and-dragon logic yielded "very clear and well-organized arguments" (L12 ATL); the marble-guessing game made "faces lit up with joy" and a child invented binary search (L10 ATL); frogs succeed because failure is impossible (L11 ATL); children kept wanting a game they knew was forced (L7 ATL); "the students love this word [isomorphic] and use it all the time" (MCBB p. 29).
- **Explaining lags solving.** "Many kids did it in their heads, but they could not explain their answer" (L3 ATL); children who found all 10 chains "were unable to explain why all the possibilities are exhausted" (MCBB p. 25).

---

## 3. How they choose topics

MCBB: "we try to choose topics with deep mathematical context, which are parts of a continuously developing stream of mathematical thought"; the goal is "a theme that will be exciting for first graders and can be taught to fourth graders, and later to middle schoolers, high schoolers, undergrads, graduate students, professors" (p. viii). Olympiad problems appear "only occasionally as warmups and challenges" (p. viii); school topics are avoided, except area formulas because children "do not understand why those formulas work" (p. 126). NR chose knots first to show mathematics "is not bounded solely by operations with numbers" and to be "equally interesting for schoolchildren with some math experience and for math beginners" (L1 ATL). *Decade*: for mixed U.S. groups "single powerful sessions... are more practical than long sequences of linked sessions" (p. 288).

Advanced ideas made concrete: knots from graphs via Adams's *Knot Book* (NR L1); tropical arithmetic renamed "sun" and "pineapple", from MSRI's tropical geometry program (L8 ATL); symmetry "as a property of invariance", tested by flipping figures onto photocopied "shadows" (L12 ATL); a uniform distribution built from a die (L13); the "bell curve" from a dice race (L15 ATL); pigeonhole and parity impossibility (M.12–13); Sierpinski via Pascal mod 2 and 3 (MCBB pp. 84–97); bijections as "isomorphic" problems (pp. 29–37); Pick's formula with "no expectations that students would solve" it (p. 129); Pythagoras via tilted squares (pp. 114–123).

---

## 4. The written handout

Neither book reproduces a worksheet, but both describe them. Problems are numbered and carry a short **name** ("Problem 2.1. Coloring Two out of Five Beads", MCBB p. 25) plus a character-driven statement of one to four sentences; NR's are story-framed (Squirrel's birthday, Mister Spy, knights and a dragon), author-illustrated, with occasional printed hints ("Hint. What do we usually write at the very end of a letter?", L2). Handouts are tools for doing rather than reading: "handouts with 12 copies of uncolored beads" (p. 25), a Mouseville map "to write down the number" of paths (p. 70), Pascal's triangle "with numbers in hexagons" for coloring (p. 85), "two copies of the picture" to cut (p. 116), templates for the coding wheel and snowflakes (NR L2, L3, L12). Recording is built in (Random Maze tallies, L4; a cuts-vs-pieces table, L9). Graph paper is default (MCBB p. 99), dropped when grid size causes anxiety (p. 116). Pictures are deliberate: included to prevent misreading (ice cream, p. 28), withheld when they give away the decomposition (pyramid, p. 23). Some problems are "read to the children, not written down" (p. 145). Encouragement is spoken culture more than print: "The best mathematicians make a lot of mistakes... What is important is that they correct them later" (p. ix). Answers sit in a separate section (NR, every lesson). NR's Part 2 has children write problems (M.4).

---

## 5. Design principles and failure modes

**Principles (restated from the books unless marked).**

1. Open with a case small enough to enumerate fully, then grow one step at a time. [MCBB pp. 41–44; NR L7]
2. Plant an "obvious" pattern that breaks by the fourth case, then ask "Will this continue forever?" [MCBB p. 42]
3. Give every problem a name and a character; that is how it will be recalled. [MCBB p. ix]
4. Keep each statement to a few sentences at weak-grade-1 reading level; assume it may be read aloud. [NR L2, L4, L8 ATL]
5. Disambiguate by picture (scoops side-by-side), not by extra words. [MCBB p. 28]
6. Withhold any picture or phrase that gives away the decomposition ("3-by-3-by-3"). [MCBB pp. 18, 23]
7. Use children's words until the concept is owned: "explanation" not "proof", "SAME SHAPE SAME SIZE", "half of 5 × 3". [MCBB pp. 10, 107, 131]
8. Specify the manipulative and the geometry of the page: grid size, start cell, what to cut, where marbles go. [NR L2, L11, L12 ATL; MCBB p. 116]
9. Include one activity where failure is impossible and one where children get up. [NR L11, L15 ATL]
10. Ask for arguments in producible forms: a table, a systematic list, a strategy, one counterexample, "the same argument again". Never a statement with unknown quantities. [NR L3; MCBB pp. 25, 44, 144]
11. Attach an extension stack for fast finishers that is not discussed in class. [NR L3 ATL; MCBB p. ix]
12. Differentiate levels by numbers and prerequisites, not topic. [MCBB pp. 2, 99, 124]
13. No hidden-trick problems and no culturally loaded facts (hares, hibernation, Santa). [NR L6, L10, L13 ATL]
14. Prefer a theme with a continuation to undergraduate mathematics; name it once the children have done it. [MCBB p. viii; NR L1, L8 ATL]
15. **[inference]** Budget by activities, not problem counts: NR's good lessons had three or four distinct acts; cap anything needing neat drawing or table-filling (four cuts, sixteen squares). [from NR L4, L8, L9 ATL]

**Failure modes for a reviewer.**

A. The question takes longer to parse than to answer. [NR L6 ATL]
B. A trick that relies on reflexes beginners lack, or on adult cultural knowledge. [NR L6, L10, L13 ATL]
C. Notation or vocabulary without a concrete anchor: powers, zeroth row, "congruent", parentheses. [NR L3; MCBB pp. 76, 107, 131]
D. A geometry or 3-D step assumed easy because it is visual. [NR L6; MCBB p. 23]
E. Copy-work masquerading as thinking: big tables, ten-box lanes, precision drawing. [NR L8, L9, L15 ATL]
F. A data game whose incentive lets children fake the data. [NR L13, L15 ATL]
G. A proof demand needing a general variable; check that a table, list, strategy, or "same argument" would satisfy it. [MCBB p. 44; NR L7]
H. **[inference]** Nothing withheld. MCBB's best moves are omissions (the pyramid picture, "3-by-3-by-3", the word "area"); a worksheet that only adds is over-explaining.
