# Evaluation calibration (run before freezing the judge)

Date: 2026-09-29. Judge model: Fable (general-purpose agent; sees rendered page PNGs + sources + the theme fact sheet). Prompts: `spec/eval/judge-absolute.md`, `spec/eval/judge-pairwise.md`. Packets were blinded (random ids, LaTeX comments stripped, version ids neutralized, same font).

## Calibration packets (theme T, tilings)

| id | packet | what it is |
|---|---|---|
| pk58 | CAL-Ap | the organizer's real Week 1 as brought to the classroom (pre-feedback: K v3 mats, M v2, U v2, guide v2), recompiled |
| pk76 | CAL-Bp | the real Week 1 after the organizer's classroom feedback (K v4, M v3, U v3, guide v3), recompiled |
| pk47 | CAL-C | CAL-Bp with v2-style chrome re-added synthetically (titles, teasers, Name/Date, rule boxes, Warm-up/Challenge/Bonus/Go further labels, fun facts, encouragement); same mathematics |
| pk95 | CAL-D | CAL-Bp with about half the concrete work removed (2 boards instead of 4, triangles 2–3 only, 2 of 6 comparison boards, K–1 problems 1–2 only, 4–5 problems 1–4 only); guide unchanged |
| pk69 | CAL-E | CAL-Bp with three planted mathematical errors (student page: "One purple covers three triangle spaces"; guide: side-n triangle "at least n−1 gaps"; guide: "shortest A–F route A–B–E–F, three flips") |

## Results

Absolute judge (`editing_need` 1–10; dimensions D1–D8 on 1–5):

| packet | editing_need | D1 math | D2 concrete | D3 amount | D4 clarity | D5 level | D6 slop | D7 guide | D8 prod | minutes K1/23/45 | checks flagged |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CAL-Ap pre-feedback | 4 | 3 | 3 | 3 | 3 | 3 | 2 | 3 | 4 | 30/39/49 | 12/16 |
| CAL-Bp post-feedback | **6** | 4 | 4 | 3 | 4 | 3 | 5 | 3 | 4 | 30/52/52 | 5/16 |
| CAL-C chrome | 4 | 3 | 3 | 3 | 3 | 3 | **1** | 3 | 3 | 26/47/59 | 13/16 |
| CAL-D truncated | 4 | 3 | 3 | **2** | 4 | 3 | 4 | **2** | 3 | 16/28/38 | 9/16 |
| CAL-E math errors | 5 | 3 | 4 | 3 | 4 | 3 | 4 | 3 | 4 | 30/42/60 | 7/16 |

Pairwise judge, both orders, all eight comparisons: the post-feedback packet (CAL-Bp) won every comparison in both presentation orders with confidence 0.90–0.97. No position flips.

All three planted errors in CAL-E were found by every judge that saw it (absolute and both pairwise orders), by recomputation from the packets' own TikZ coordinates, and the judges noted the guide contradicted itself.

## Assessment

- The judge reproduces the organizer's own classroom judgment (post-feedback > pre-feedback) and separates chrome, insufficient work, and mathematical error from the base, each on the intended dimension (D6, D3/D7, D1). Position bias was not observed at this quality gap. The absolute scale is severe (the organizer-approved packet scores 6/10) but the severity is consistent and the reasons are legitimate relative to the task brief: every judge independently flagged that K–1 is "decorative" (all fill tasks succeed; ~30 minutes of work) — which is the organizer's own complaint about K–1 packets — and that the guide's roster/materials (written for an earlier 3/3/1 group) do not match the brief's 3/4/3 group, plus leftover process notes.
- Cost: absolute judge ≈ 170–200k tokens and 11–14 minutes per packet; pairwise ≈ 165–220k tokens and 8–12 minutes per pair (judges brute-force the mathematics).
- Known limitation: same model family as the writers (self-preference cannot be excluded); no cross-family judge is available in this environment. Mitigation: the fact sheets, mandatory evidence quotes, and the human blind ranking at the end.

## Decision

Judge prompts, fact sheets, blinding procedure and lint are FROZEN as of this note. No wording changes during the experiment. If a bug is found (e.g., a judge cannot read a packet), the whole affected batch is re-run with the fixed harness and noted here.

Eval design for the main experiment (fixed now): every packet gets one absolute judgment; pairwise comparisons use a circulant partial design per outline (each packet vs. four others: offsets +1, +2 in a fixed random arm order), single presentation order assigned at random, aggregated with Bradley–Terry; twin (same-workflow, different-seed) pairs are compared to measure the noise floor.
