# Week 1 (tilings) — editor's edits

Every answer, count, tiling figure and tileability claim in the guide and on the pages was rechecked by exhaustive search (rhombus/trapezoid/chevron tilings of every lettered board, the 2-by-n and 3-by-n counts, the 4-by-4 minus two squares rule over all 120 pairs, board S, the 5-by-5 and 7-by-7 L-tromino maps, the fault-free 6-by-6, the hexagon counts 2/3/4/5/6/20, and every drawn answer figure in `week-boards.tex`). All of them are correct; no answer needed changing. The edits below fix a materials-count inconsistency, a false scale claim (two student boards were printed smaller than the paper pieces the children must lay on them), one incomplete argument, three wording errors in the guide, one act-before-explain ordering problem, and add one contrasting instance where an idea had a single example.

Originals are quoted exactly as they appear in the files.

---

## 1. `week-grades-4-5.tex` — Problem 1, record instead of explain

**Original:**
```
Then try to cover board D using exactly 3 vertical dominoes and 5 horizontal ones. If you cannot, write on the line why it is impossible.}
```
**Replacement:**
```
Then try to cover board D using exactly 3 vertical dominoes and 5 horizontal ones. Write on the lines how many vertical dominoes you ended up using on each of the four boards.}
```
**Reason:** act → record → compare → explain; the "why" here is a parity argument with no scaffolding yet, and the guide already says to spend at most a minute on D and keeps the argument for the finish-early list (edits 14, 16).

## 2. `week-grades-4-5.tex` — Problem 8 boards at the size of the paper dominoes

**Original:**
```
\begin{center}
{\setlength{\cell}{0.5in}%
\Board{V}{4}{4}{\Checker{4}{4}\LoopFour}\hspace{0.5in}\Board{W}{4}{4}{\Checker{4}{4}\LoopFour}\hspace{0.5in}\Board{X}{6}{6}{\Checker{6}{6}\Xat{1}{4}\Xat{4}{2}}}
\end{center}
```
**Replacement:**
```
\begin{center}
\Board{V}{4}{4}{\Checker{4}{4}\LoopFour}\hspace{0.5in}\Board{W}{4}{4}{\Checker{4}{4}\LoopFour}\\[8pt]
\Board{X}{6}{6}{\Checker{6}{6}\Xat{1}{4}\Xat{4}{2}}
\end{center}
```
**Reason:** the problem asks the child to lay dominoes along the loop, but V, W, X were printed at 0.5 in cells while the cut-out dominoes are 0.58 in (the guide claimed they match); V and W now share a row and X sits below at the true size.

## 3. `week-grades-4-5.tex` — Problem 9, draw the 31 dominoes

**Original:**
```
Then cover every square except the two crossed-out ones with dominoes, following your path.
```
**Replacement:**
```
Then draw dominoes along your path so that every square except the two crossed-out ones is covered.
```
**Reason:** 31 dominoes are needed and a child has 16; the guide says the 8-by-8 boards are drawn on, so the page must say so too (what to do with the materials and where to record it).

## 4. `week-grades-4-5.tex` — Problem 13 boards at the size of the paper trominoes

**Original:**
```
\Problem{13}{Each board below is 5-by-5 with one square crossed out, so 24 squares are left and 8 L-trominoes would be needed. Cover each board if you can and draw the trominoes; write \No\ under the board if you cannot. Then, on the small 5-by-5 map, write \Yes\ in every square that can be crossed out and still leave a board you can cover, and \No\ in every square that cannot.}
\Space{4pt}
\begin{center}
{\setlength{\cell}{0.5in}%
\begin{tabular}{@{}c@{\hspace{0.2in}}c@{\hspace{0.2in}}c@{}}
\Board{(a)}{5}{5}{\Xat{0}{4}} & \Board{(b)}{5}{5}{\Xat{1}{4}} & \\[3pt]
\RecBox{0.45in}{0.4in} & \RecBox{0.45in}{0.4in} & \\[8pt]
\Board{(c)}{5}{5}{\Xat{2}{2}} & \Board{(d)}{5}{5}{\Xat{1}{3}} & {\setlength{\cell}{0.3in}\Board{map}{5}{5}{}}\\[3pt]
\RecBox{0.45in}{0.4in} & \RecBox{0.45in}{0.4in} & \\
\end{tabular}}
\end{center}
```
**Replacement:**
```
\noindent\begin{minipage}[t]{5.3in}
\Problem{13}{Each board below is 5-by-5 with one square crossed out, so 24 squares are left and 8 L-trominoes would be needed. Cover each board if you can and draw the trominoes; draw a big \No\ across the board if you cannot. Then, on the small 5-by-5 map, write \Yes\ in every square that can be crossed out and still leave a board you can cover, and \No\ in every square that cannot.}
\end{minipage}\hfill
\begin{minipage}[t]{1.7in}\vspace{0pt}\centering
{\setlength{\cell}{0.3in}\Board{map}{5}{5}{}}
\end{minipage}
\Space{4pt}
\begin{center}
\begin{tabular}{@{}c@{\hspace{0.5in}}c@{}}
\Board{(a)}{5}{5}{\Xat{0}{4}} & \Board{(b)}{5}{5}{\Xat{1}{4}}\\[8pt]
\Board{(c)}{5}{5}{\Xat{2}{2}} & \Board{(d)}{5}{5}{\Xat{1}{3}}\\
\end{tabular}
\end{center}
```
**Reason:** "cover each board if you can" with 0.58 in trominoes on a 0.5 in grid cannot be done physically (eight pieces overflow the outline), which would make the child's "cannot" meaningless; boards are now at the true size, the map moves beside the text, and the × goes on the board instead of in a box.

## 5. `week-grades-2-3.tex` — Problem 4, name the two trapezoid positions

**Original:**
```
Then do the same with a red trapezoid (two directions), a green triangle (two directions) and a yellow hexagon.}
```
**Replacement:**
```
Then do the same with a red trapezoid (long side down, then long side up), a green triangle (two directions) and a yellow hexagon.}
```
**Reason:** a trapezoid has six positions on the grid, not two; the problem must say exactly what to place (plain, concrete instructions).

## 6. `week-k-1.tex` — Problem 9, add the parallelogram as a contrasting instance

**Original:**
```
\Problem{9}{Cover shape D, the hexagon, with three blue rhombi \IconBlue. Draw your three rhombi on the first small hexagon: draw a dark line along every edge where two of your rhombi meet. Now cover the hexagon in a different way and draw it on the second small hexagon. Try to find a third way and draw it on the third hexagon.}
```
**Replacement:**
```
\Problem{9}{Cover shape D, the hexagon, with three blue rhombi \IconBlue. Draw your three rhombi on the first small hexagon: draw a dark line along every edge where two of your rhombi meet. Now cover the hexagon in a different way and draw it on the second small hexagon. Try to find a third way and draw it on the third hexagon. Then cover shape A with two blue rhombi, draw it on the first small copy of A, and try to find a second way for shape A.}
```
**Reason:** "how many ways" had a single instance at K–1; the parallelogram (exactly one way) contrasts with the hexagon (two) — several contrasting instances per idea.

## 7. `week-k-1.tex` — small copies of A for Problem 9

**INSERT AFTER:**
```
\begin{tikzpicture}[tripic]\GridB\OutlineB\end{tikzpicture}\hspace{0.45in}
\begin{tikzpicture}[tripic]\GridB\OutlineB\end{tikzpicture}}
\end{center}
```
**Inserted text:**
```
\begin{center}
{\setlength{\tri}{0.62in}%
\begin{tikzpicture}[tripic]\GridA\OutlineA\end{tikzpicture}\hspace{0.45in}
\begin{tikzpicture}[tripic]\GridA\OutlineA\end{tikzpicture}}
\end{center}
```
**Reason:** recording space for edit 6 (a separate diagram for each instance).

## 8. `week-facilitator.tex` — section 2, piece counts and which boards the pieces fit

**Original:**
```
and cut along the heavy lines before the session: 36 dominoes and 24 L-trominoes, that is 12 dominoes and 8 trominoes per child in two envelopes. The cell size (0.58\,in) matches the boards on the grades 4--5 pages. The 8-by-8 boards are meant to be drawn on, not covered.
```
**Replacement:**
```
and cut along the heavy lines before the session: 50 dominoes and 30 L-trominoes, that is 16 dominoes and 10 trominoes per child in two envelopes (two dominoes spare). The cell size (0.58\,in) matches the boards of Problems 1, 2, 5, 6, 8, 9, 10, 11 and 13; the boards of Problems 7 and 12 are printed smaller and are drawn on, as are the three 8-by-8 boards, which need more pieces than one child has.
```
**Reason:** the appendix sheets hold 50 and 30 pieces, not 36 and 24; and the sentence claiming every board matched the pieces was false (Problems 7, 8, 12, 13), which edits 2 and 4 fix where pieces are laid.

## 9. `week-facilitator.tex` — K–1 Problem 5, why the trading cannot stall early

**Original:**
```
and B, C, E have 1, 1, 3 down-triangles against 2, 3, 6 up-triangles.
```
**Replacement:**
```
and B, C, E have 1, 1, 3 down-triangles against 2, 3, 6 up-triangles. (The trading cannot stop early on these shapes: on B and C the single down-triangle touches every up-triangle, and on E each down-triangle touches a corner triangle that touches nothing else, so a green down-triangle always still has a green neighbor to trade with.)
```
**Reason:** complete arguments for every answer; the count alone does not show that the trading always reaches the same end (on the hexagon it does not, as the guide itself notes).

## 10. `week-facilitator.tex` — K–1 Problem 9, answer for shape A

**Original:**
```
\textbf{Problem 9} (two ways for the hexagon). \Ans{Exactly two ways; each is the other turned by one sixth of a turn.} Why there is no third: every rhombus inside the hexagon touches the center point, so once the first rhombus is placed, the other two are forced; there are six possible rhombi and each way uses three, so there are two ways.
```
**Replacement:**
```
\textbf{Problem 9} (two ways for the hexagon, one for A). \Ans{Hexagon D: exactly two ways; each is the other turned by one sixth of a turn. Shape A: only one way.} Why there is no third for D: every rhombus inside the hexagon touches the center point, so once the first rhombus is placed, the other two are forced; there are six possible rhombi and each way uses three, so there are two ways. Why A has only one: each sharp corner of A lies in a single small triangle, and that triangle has only one neighbor inside A, so the rhombus at each end is forced, and the two forced rhombi already fill A.
```
**Reason:** complete answer for the instance added by edit 6 (checked: A has exactly one rhombus covering).

## 11. `week-facilitator.tex` — K–1 Problem 11, a complete argument that 4 pieces are impossible

**Original:**
```
A child-sized reason that 4 is hard: each of the three sharp corners of H needs its own piece with a sharp corner (a hexagon has none), and three such pieces cover at most $4+4+4=12$ of the 16 small triangles.
```
**Replacement:**
```
Why 4 is impossible, in a form a child can follow: H has 10 up-pointing and 6 down-pointing triangles, 4 more up than down. A blue, a yellow or a purple piece covers equally many of each, so it does not change the difference; a red or a green covers at most one more up than down. So at least 4 of the pieces must be red or green, and those 4 cover at most $3+3+3+3=12$ triangles; the 4 or more triangles left need at least one more piece. That makes 5 at least, and 5 is enough (picture). (With the purple chevron allowed, an exhaustive search confirms that no 4 pieces work; keep the nonstandard pieces in the tub for this problem.)
```
**Reason:** the original only shows that 3 pieces fail ("hard" is not an argument); the guide must give a complete argument, and this one uses the session's own up/down count.

## 12. `week-facilitator.tex` — grades 2–3 Problem 8, wording of the standing rhombus

**Original:**
```
a standing rhombus fits only under the 1st, 3rd or 5th triangle of the bottom row.
```
**Replacement:**
```
a standing rhombus can only stand on the 1st, 3rd or 5th triangle of the bottom row (the three that point down).
```
**Reason:** nothing is "under" the bottom row; the standing rhombus uses a down-pointing bottom-row triangle and the up-pointing one above it.

## 13. `week-facilitator.tex` — grades 2–3 Problem 10, which coloring gives no obstruction

**Original:**
```
There is no coloring obstruction for trapezoids: a red piece covers 2 and 1 or 1 and 2, so it changes the difference by 1 either way.
```
**Replacement:**
```
The up/down coloring gives no obstruction for trapezoids: a red piece covers 2 and 1 or 1 and 2, so it changes the difference by 1 either way. (Other weightings can: on W, give the middle down-triangle weight 1 and the rest 0; every trapezoid inside W contains it, so two trapezoids would need total weight 2, but W has 1.)
```
**Reason:** mathematical error: as stated the claim is false (W has a one-line weighting obstruction); only the up/down coloring is silent.

## 14. `week-facilitator.tex` — grades 4–5 Problem 1 answer, what the record shows

**Original:**
```
\Ans{Any covering of A and B (there are 36 in all). C: a covering with exactly 2 vertical dominoes exists (picture). D: exactly 3 vertical dominoes is impossible.}
```
**Replacement:**
```
\Ans{Any covering of A and B (there are 36 in all). C: a covering with exactly 2 vertical dominoes exists (picture). D: exactly 3 vertical dominoes is impossible; whatever the children end up with, every number of vertical dominoes written on their lines is even.}
```
**Reason:** matches the recording task of edit 1 and tells the adult what to look for.

## 15. `week-facilitator.tex` — grades 4–5 Problem 13 figure caption

**Original:**
```
\Fig{\Sq{\SqBoard{5}{5}\Xat{2}{4}\LTilingFiveSide}}{side-middle}\quad
```
**Replacement:**
```
\Fig{\Sq{\SqBoard{5}{5}\Xat{2}{4}\LTilingFiveSide}}{side-middle, row 1, column 3 (not (b))}\quad
```
**Reason:** the figure sits between (a) and (c) and could be read as board (b); board (b) (row 1, column 2) cannot be covered. (Revised after a first compile: a longer caption pushed the map figure onto a second row.)

## 16. `week-facilitator.tex` — grades 4–5 finish-early item (a)

**Original:**
```
(a) Problem~1 board D, the parity of vertical dominoes, if it was skipped;
```
**Replacement:**
```
(a) Problem~1 board D: ask why every number of vertical dominoes on the lines is even, then give the parity argument from Problem~1;
```
**Reason:** the "why" removed from the page by edit 1 lives here, with the recorded numbers as its starting point.

## 17. `week-grades-2-3.tex` — page 3 spacing after edit 5 (consequential)

**Original:**
```
{\renewcommand{\arraystretch}{1.55}\begin{tabular}{|c|c|c|}\hline
board & green triangles & \Yes\ or \No\\ \hline
```
**Replacement:**
```
{\renewcommand{\arraystretch}{1.45}\begin{tabular}{|c|c|c|}\hline
board & green triangles & \Yes\ or \No\\ \hline
```
**and, in Problem 4, Original:**
```
with a red trapezoid (long side down, then long side up), a green triangle (two directions) and a yellow hexagon.}
\Space{4pt}
```
**Replacement:**
```
with a red trapezoid (long side down, then long side up), a green triangle (two directions) and a yellow hexagon.}
\Space{0pt}
```
**Reason:** edit 5 lengthened Problem 4 by one line and the piece table ended 0.09 in above the footer rule; the Problem 3 table rows and the gap are trimmed to restore the clearance (found on the first recompile).
