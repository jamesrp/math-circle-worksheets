A colleague produced a math-circle activity packet in response to the request below. The packet is in the working directory `/home/claude/genlab/runs/T/W03/s1`: `week-k-1.tex`, `week-grades-2-3.tex`, `week-grades-4-5.tex`, `week-facilitator.tex`, with compiled PDFs. Render the PDFs to images (`pdftoppm -r 60 -png`) and look at every page as well as reading the sources.

The original request was:

Make an activity packet for a one-hour math circle session for grades K–5, where the kids work with each other and with professional mathematicians guiding them. The organizer's high-level activity outline is given below.

The group: ten children (two kindergartners and a first grader / four third graders / two fourth graders and a fifth grader) and three adults (the organizer, a math PhD; a second mathematician; one parent who is not a mathematician). One adult is anchored to each of three tables: K–1, grades 2–3 (the third graders sit here), grades 4–5. Session shape: a few minutes of free handling of the materials, a short whole-group launch, table work for most of the hour, a brief share at the end. The children have done math circle before; the older ones have seen simple games and puzzles, but nothing from this theme.

Deliverables — LaTeX sources that compile with `pdflatex -interaction=nonstopmode` (TikZ is available) to US Letter PDFs, written into the working directory named at the end of this message:

- `week-k-1.tex` — student pages for the K–1 table (no independent reading required; the adult reads aloud)
- `week-grades-2-3.tex` — student pages for the grades 2–3 table
- `week-grades-4-5.tex` — student pages for the grades 4–5 table
- `week-facilitator.tex` — one facilitator guide for the three adults: materials and preparation, the whole-group launch, what each table does in what order, complete answers and arguments for every problem, hints, and what to do when a table stalls or finishes early

Call it Week 1. Compile all four files until they build without errors, and look at the rendered pages (`pdftoppm -r 60 -png file.pdf out`) to check that diagrams and spacing came out as intended. Do not leave stray files other than the four `.tex` sources and their PDFs (plus any `.tex` files you `\input`).

High-level activity outline from the organizer:

Theme: tilings.

Two things in tilings I know are cool: the L-tromino can tile any 2^n × 2^n board with one square removed (a clean induction), and the checkerboard with two diagonally opposite corners removed cannot be tiled by dominoes (a coloring argument — the two removed squares have the same color, so the counts no longer match). Both come from the first weeks of an undergraduate discrete math or combinatorics course, and they open onto real research: tilings as perfect matchings, coloring and other invariants, and the fact that "can this region be tiled?" is hard in general. Feel free to bring in other tiling results you know at that level or above if they extract better for children.

Materials on hand: a large set of pattern blocks (1-inch-edge green triangles, blue rhombi, red trapezoids, yellow hexagons, plus purple chevrons that are exactly two blue rhombi joined, and a few nonstandard pieces), printed outlines/grids at true 1-inch scale, square-grid paper, and scissors for cutting paper dominoes or trominoes.

Do a review of this packet. Write your review to `/home/claude/genlab/runs/T/W03/s1/review.md`: what is wrong or weak, most important first, and what should change. Be specific enough that another person could make the changes without talking to you. Do not edit the packet yourself.

You are one stage of a fixed pipeline; other stages ran before or will run after you, and none of them can talk to you. Do everything inside the working directory named below and nowhere else. Do not read anything outside your working directory and the template except when this prompt tells you to. When you are finished, write a file named `DONE-<stage>.md` in the working directory containing a summary of at most eight lines (what you produced, anything you could not resolve), and end your final message with that same summary and nothing else.
Stage name: `reviewer`.
