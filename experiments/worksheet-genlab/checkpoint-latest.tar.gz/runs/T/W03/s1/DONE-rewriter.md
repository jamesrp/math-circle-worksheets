Revised the Week 1 tilings packet in place (previous sources preserved in before-rewrite/); all four files compile cleanly, every rendered page checked.
Addressed all ten review items: paper pieces now fit every board the children are told to cover (0.58 in, measured); each table has a default core (30/36/38 min) with extensions in a fixed order, and pages were reordered and renumbered to match.
Board D (exactly 3 vertical) removed from the warm-up; "exactly 2/4/6 vertical" is the last grades 4-5 extension, with the parity argument and hints in the guide.
Materials counts fixed (50 dominoes, 30 trominoes), launch rebuilt as A-then-C on a per-table card (Appendix C), board N moved to Appendix D, hints added for every explain-why problem.
K-1 shapes relabeled with the grades 2-3 letters; arguments corrected (five-piece bound via the up/down difference, trading-game termination, hexagon count); layout faults fixed (2-by-n strips, grid lines, run-in answers, no orphaned figures).
New claims verified by code before printing. Two small deviations from the review's extension order are explained in changes.md; no review point was rejected.
Page counts: K-1 8, grades 2-3 8, grades 4-5 14, guide 22 (18 + appendices). Nothing left unresolved.
