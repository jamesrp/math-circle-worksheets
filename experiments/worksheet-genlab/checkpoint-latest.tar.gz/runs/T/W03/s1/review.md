# Review of the Week 1 "Tilings" packet

**What I checked.** All four sources plus the shared `week-boards.tex`; every rendered page of the four PDFs (8 + 8 + 11 + 18 pages, `pdftoppm -r 60`, with higher-resolution crops where spacing looked tight); a clean recompile (no errors, no overfull boxes, no warnings beyond hyperref's `.out` notice); and the mathematics. I re-derived every answer in `week-boards.tex` by exhaustive search: rhombus-tiling counts and trapezoid-tiling counts for boards A–N and W, fewest-greens values, every domino/loop/snake/L-tromino answer figure (coverage, no overlaps, loops and snakes Hamiltonian, loop tilings actually follow the loops, the 6×5 fault-free tiling has no fault line, the 2×n lists are complete and distinct), and the printed shapes are at true 1-inch scale (shape C's base measures 2.00 in). **Every mathematical claim and answer in the packet is correct.** The problems below are about fit to the materials, the clock, and the children, plus wording and layout faults. Numbered items are in priority order; within each item, "Change" says exactly what to do.

---

## 1. The paper dominoes and trominoes do not fit several grades 4–5 boards that the children are told to *cover* (most important)

The cut-out sheets (Appendix A/B) use 0.58 in cells, and the guide, section 2, says "The cell size (0.58 in) matches the boards on the grades 4–5 pages." It matches Problems 1, 2, 3, 5, 6, 9, 10 and 11 only. These do not match:

- **Problem 8** (page 6): boards V, W, X are drawn with `\cell=0.5in`. The text says "cover all the other squares with dominoes by following the path" and "use it to cover board X". A 4×4 at 0.5 in is 2.0 in wide; four 0.58 in dominoes are 2.32 in. The pieces will not sit on the board.
- **Problem 13** (page 11): boards (a)–(d) are 5×5 at `\cell=0.5in` (2.5 in) and the text says "Cover each board if you can and draw the trominoes." Eight 0.58 in trominoes cannot be arranged on a 2.5 in board (five cells of piece-scale are 2.9 in). This is the problem where physical trial matters most, since the child is searching for which square can be removed.
- Problems 7 (T, U at 0.36 in), 9 (Y, 0.58 in but 31 dominoes) and 12 (0.3 in strips) are drawing-only and their texts say so or imply it; those are fine.

**Change.**
- `week-grades-4-5.tex`, Problem 8: set `\cell=0.58in` for V, W and X. V and W side by side (2 × 2.32 in + 0.5 in gap = 5.14 in) fit the 7.2 in text width; put X (3.48 in) on its own centered row below them. Height check: text ≈ 1.2 in, V/W row with labels ≈ 2.9 in, X row ≈ 4.1 in, four answer lines ≈ 1.0 in: about 9.2 in against a 9.75 in text height. Tight; if it overflows, cut to three answer lines.
- `week-grades-4-5.tex`, Problem 13: set `\cell=0.58in` for (a)–(d) (2.9 in each; two per row with a 0.3 in gap = 6.1 in). That no longer leaves room for the map beside (c)/(d) on one page, so either (i) split Problem 13 over two pages — (a),(b) on page 11; (c),(d) and the map on page 12 — or (ii) keep four boards on one page and put the 5×5 map (at `\cell=0.3in`) in the row of answer boxes under (c)/(d), right-aligned. Option (i) is simpler and safer.
- `week-facilitator.tex`, section 2, "Paper pieces": replace the sentence "The cell size (0.58 in) matches the boards on the grades 4–5 pages" with "After the change above, the pieces fit the boards of Problems 1, 2, 3, 5, 6, 8, 10, 11 and 13. Boards T, U and the 2-by-n strips are printed smaller and are drawn on; Y and Z are at piece scale but need 31 and 21 pieces, so they are drawn on too."
- Problem 8's and Problem 13's texts should also say what is expected: "cover with the paper dominoes, then draw them" (8) and "cover each board with the paper trominoes if you can, then draw them" (13); Problem 9's "cover every square … with dominoes" should become "draw dominoes along your path", so a child does not wait for 31 pieces.

## 2. There is far more than 42 minutes of work at every table, and the guide's default plan is already over budget

Table work is 0:08–0:50 (42 min). The guide's own "core" timings add to 38 min (K–1), 43 min (2–3) and 44 min (4–5) *before* any of the adult questions the guide asks them to pose, and several single-problem estimates are not credible: 4–5 Problem 11 (draw 21 trominoes on an 8×8 by the recursive plan) is given 5 min; Problem 8 (two loop tilings, draw your own 36-square loop, tile X, write the argument) 6 min; 2–3 Problem 1 (four boards, each covered twice) 7 min; K–1 Problem 2 (four shapes covered twice each, by two kindergartners and a first grader) 7 min. The packets have 11, 10 and 13 problems; each table will reach about half, and nothing tells the adult which half.

The guide does have the right instinct ("If time is short, do only board I … only board L"; "Problem 9 is skipped if time is short") but leaves the long plan as the default. Make the short plan the default and put the rest explicitly under "if time".

**Change** (`week-facilitator.tex`, the three "Order and rough timing" paragraphs, and section 1's table; reorder the student pages to match so each packet reads core first):

- **K–1 core (≈30 min):** 1 (4), 2 (7), 3 with shape F only (2), 5 on C and B only (4), 6 (5), 7 (4), 8 (4). Then in order: 3-E, 4, 5-E, 9, 10, 11. (Dependencies to keep: 7 compares D and F with C, so F's check from Problem 3 is needed; 4 needs the green counts for all six shapes, so it goes after 3-E.)
- **2–3 core (≈36 min):** 1 (7), 2 (6), 3 (3), 4 blue rows only (4), 5 (5), 6 board I only (4), 7 board L only (7). Then: 4's red/green/yellow rows, 6-K, 7-J, 8, 9, 10. L is the board the guide itself calls "the important board of the day"; this ordering protects it.
- **4–5 core (≈38 min):** 1 with boards A and B only (3), 2 (6), 3 (3), 4 (4), 5 boards (a)–(c) (5), 7 (4; the drawn covering of U is optional), 10 (a) and (b) (5), 11 (8). Then in order: 6, 8 (V and X), 5 (d)–(f), 9, 12, 13, 1-C/D. Rationale: the organizer's two headline results are the opposite-corner checkerboard (7) and the tromino induction (10–11); the loop argument (8–9) is a bonus and is the most expensive item. Note that 10 must stay before 11 (11's plan uses "the plan of Problem 10" for each quarter). If the organizer would rather keep the loop in the core, drop 10–11 to the extension instead — but one of the two has to go.
- Rewrite section 1's timing line as "Table work, 42 minutes: each table has a 30–38 minute core and extensions in a fixed order (sections 4–6)", and in each table section add one sentence: "Stop the core at 0:47 regardless, so the share has its shape ready."
- When pages are reordered, renumber problems and fix the cross-references ("board G (page 2)", "board I (page 5)", the share, section 8's "Problem 8/11/12/13" mentions).

## 3. Grades 4–5 Problem 1 D (exactly 3 vertical dominoes) is a hard parity proof planted in the warm-up

The "why it is impossible" argument (vertical dominoes come in even numbers row-pair by row-pair) is among the hardest pieces of reasoning on the 4–5 pages, and it appears on page 1 with answer lines, before the checkerboard idea exists. The guide says "Do not spend more than a minute on D at the start" — which is a sign it should not be there. Children who take the page seriously will stall at minute 2.

**Change.** In `week-grades-4-5.tex`, Problem 1: keep A, B and C ("exactly 2 vertical"); delete D and the two answer lines. In the guide, keep the D argument under "If the table finishes early (a)" (it is already listed there) and add the board as a sentence: "draw a 4×4 on grid paper". If D is kept anyway, give it hints: (1) "In the top row, the horizontal dominoes cover how many squares, odd or even?" (2) "So how many vertical dominoes poke down from the top row?" (3) "Do the same for each row."

## 4. Materials and preparation: four contradictions to fix

- `week-facilitator.tex` section 2 says "36 dominoes and 24 L-trominoes, that is 12 dominoes and 8 trominoes per child", but Appendix A yields **50** dominoes and Appendix B **30** trominoes (both headings say so). Change section 2 to "50 dominoes and 30 L-trominoes: 16 dominoes and 10 trominoes per child, in two envelopes" (Problem 13 needs 8 trominoes per board, Problem 5 needs 7 dominoes, so 10 and 16 are comfortable).
- Section 1 (0:00–0:05) says "Pattern blocks are out on all three tables"; section 2 says "Grades 4–5 table: two blue rhombi only, for the launch." Decide: give the 4–5 table a small tub for the free-handling minutes and the launch and collect it at 0:08, and say so in both places.
- Section 3 says the K–1 launch shape is "shape C on their page"; on the K–1 pages C is on page 2 (page 1 is the hexagon). Either say "page 2" or, better, print Appendix C's launch card once per table (three copies) and have all three tables launch on the card — this also fixes item 5.
- "Three copies of this guide" will print the cut-out sheets three times. Say "three copies of pages 1–15; one copy of Appendix A and B; three copies of Appendix C".

## 5. The launch spends shape C, then both younger tables are told to try C again "for a full two minutes"

In the launch everyone tries C with two blue rhombi for thirty seconds and fails. K–1 Problem 2 and 2–3 Problem 1 then ask for C again, and the K–1 guide says "Let them try C for a full two minutes and try it yourself, visibly; the X should be earned." The children have just earned it in public; a second two-minute attempt is dead time, and the "guess before you try" framing of later problems is weakened because C's answer is already known.

**Change** (pick one):
- Keep the launch on C, print the launch card for every table (item 4), and in the guide replace "Let them try C for a full two minutes" with "They tried C in the launch; thirty seconds more is enough. Ask how sure they are, then move on." Add the same sentence to the 2–3 section after "Do not explain the X's."
- Or restructure the launch as a 30-second success first (shape A with two blues: "this is what covering exactly means"), then C for thirty seconds, then the question. The pages then treat C as a 20-second confirmation, not a two-minute search, and the first genuinely new impossibility a child meets is one they predict themselves (K–1 G, 2–3 F).

## 6. Hints are missing for exactly the problems where children get stuck: the "explain why" ones

The request asked for hints. The guide gives ordered hints for 2–3 Problems 7–8 and 4–5 Problems 6, 8, 11, 12, 13 only. The problems that ask for a written argument have none, and these are where a table stalls.

**Change.** Add a `\Hint{…}` block after each of these answers in `week-facilitator.tex`:
- 2–3 Problem 5 (why F cannot be covered): (1) "Say out loud what one blue covers on the colored grid." (2) "Four blues would cover how many colored and how many white?" (3) "How many colored and white does F have? Now put the two sentences together."
- 2–3 Problem 9 (why not fewer greens on G): (1) "Each blue needs one white. How many whites does G have?" (2) "After three blues, what is left over?" (3) "Can a blue ever cover two colored triangles?"
- 2–3 Problem 10 (what is true about the numbers): (1) "How many small triangles is one red piece?" (2) "Say the numbers of the boards you covered. Count by threes."
- 4–5 Problem 4: (1) "What color is the crossed-out square in (b)?" (2) "How many dark and how many light are left?" (3) "One domino takes one of each, so four dominoes take how many of each?"
- 4–5 Problem 7: (1) "Color the four corners. What color are the two crossed-out ones on T?" (2) "How many dark and light remain?" (3) "What does each domino take?"
- 4–5 Problem 9 (both squares dark): (1) "Walk the loop from one cross to the other. What color is the first square? The last?" (2) "So is the piece even or odd?"
- 4–5 Problem 10 (c)–(d): (1) "There are only three kinds of square: corner, edge, inside. Try one of each." (2) "Split the board into four 2-by-2 blocks and put one tromino in the middle."
- K–1 is adult-led and the scripted questions do the job; one line for Problem 8 would help: "Count the colored and the white. Can every blue get one of each?"

## 7. Student-page wording that will misfire

- `week-grades-2-3.tex`, Problem 4: "a red trapezoid (two directions)". A trapezoid has six orientations on the triangle grid; what the problem means is two *kinds* of answer (long side down: 2 colored + 1 white; long side up: 1 + 2). Change to "a red trapezoid (first with its long side at the bottom, then with its long side at the top)" and label the table rows "long side down / long side up". "Green triangle (two directions)" and "blue rhombus … three directions" are right.
- `week-grades-2-3.tex`, Problem 8: "Find every different way" — say what different means, or a child who sees the two hexagon coverings as "the same one turned" will write 1: add "Two ways count as different if some rhombus is in a different place, even if one is the other turned around."
- `week-grades-2-3.tex`, Problem 4 then Problem 6: the side-4 triangle is colored on page 3 (unnamed, "the grid below") and then again on page 5 as "board I" (color it, count, predict). Name it in Problem 4 ("Board I is the big triangle below…") and in Problem 6 say "use the board I you colored on page 3" or drop the second copy; that also saves most of a page.
- `week-k-1.tex`, Problem 4: "Write the green number of each shape" — say "the number of green triangles you wrote for each shape in Problems 2 and 3".
- `week-k-1.tex`, Problems 9 and 10: say where the full-size shape is ("shape D on page 2"; E is reprinted on page 8, fine).
- `week-grades-4-5.tex`, Problem 8 and 13: see item 1 for "cover" vs "draw".

## 8. Layout faults seen on the rendered pages

- `week-grades-4-5.tex`, Problem 12 (page 10): the 2-by-4 and 2-by-5 groups run into each other. The 2-by-4 label sits beside the *second* row of 2-by-4 strips and the 2-by-5 label beside the *third* row of 2-by-5 strips, with the same row spacing inside and between groups, and 4-cell and 5-cell strips look alike at 0.3 in. Add `\vspace{10pt}` between size groups and anchor each label to the top row of its group (use `m{}` → `p{}`/`[t]` alignment for the label column, or put each size in its own small `tabular`).
- `week-grades-4-5.tex`, page 3: the "Problem 4" heading sits almost on the 3×3 board of Problem 3 (the `m{}` cell has no bottom padding). Add `\Space{12pt}` before Problem 4; there is half a page free.
- `week-k-1.tex`: the little-triangle grid lines (`black!55`, 0.45 pt) print as faint gray hairlines. These are the lines kindergartners color inside; set the K–1 `gridline` style to `black!80, line width=.7pt`.
- `week-facilitator.tex`, Problem 8/9 answer figures (V, W, X, Y): checkerboard shading + gray domino fills + the gray loop + crosses at 0.25 in cells is a gray mush; the loop is hard to follow. Drop `\Checker` from those four figures (the dominoes already show the matching) or raise `\cell` to 0.35 in for them.
- `week-facilitator.tex`, Problem 11: the Z figure is orphaned at the top of page 12 with its answer text on page 11. Put the figure before the "Answer." paragraph or add `\needspace{3in}` (package `needspace`) before the answer.
- Guide typography: "Problem 1 (hexagon: green, blue, red)." then "Answer." on a new paragraph because `\Ans` starts with `\par`. Make `\Ans` run in (`\newcommand{\Ans}[1]{ \textbf{Answer.} #1}`) so the heading and the answer share a paragraph; this saves about half a page and reads better.

## 9. Gaps in the arguments the guide gives

- K–1 Problem 11 says 4 pieces is impossible "by exhaustive search" and offers a corner argument that only shows 4 is "hard". There is a two-line proof that fits the theme and should replace both: H has 10 up and 6 down triangles, difference 4; a green or a red piece changes the difference by at most 1, and a blue, yellow or purple piece by 0; so at least 4 pieces are green or red, those cover at most 12 of the 16 triangles, so a fifth piece is needed. Five is achieved by the picture.
- K–1 Problem 5: the guide explains why the leftover count is *at least* 1, 2, 3 (each trade uses a down-triangle) but not why the game cannot end early with a down-triangle untraded; add: "on B, C and E every down-triangle touches more up-triangles inside the shape than there are other down-triangles (B: 2 against 0; C: 3 against 0; E: 3 against 2), so a down-triangle can never find all its green neighbors already traded away; on the hexagon each triangle touches only two others, which is why the game can get stuck there."
- K–1 Problem 9: "there are six possible rhombi and each way uses three, so there are two ways" reads as numerology; say "placing one rhombus forces the other two, so each of the six positions belongs to exactly one covering, and six positions in groups of three make two coverings."
- Guide section 4, Problem 11: say whether purple chevrons count as "any pieces" (they are on the K–1 table) — they do, and the argument above covers them.

## 10. Lower priority

- K–1 and 2–3 use different letters for the same shapes (K–1 B = 2–3 D, K–1 D = 2–3 B, K–1 E = 2–3 G, K–1 F = 2–3 E, K–1 G = 2–3 F, K–1 H = 2–3 I). Only A and C coincide, and C is what the share relies on. Either relabel the K–1 shapes with the 2–3 letters (on K–1 page 2 swap the hexagon and trapezoid rows so they read A, B, C, D; page 3 becomes G and E; Problem 8's shape becomes F; Problem 11's becomes I; update every mention in the text and in guide section 4) or add a one-line cross-reference table to guide section 4.
- The closing line of the share ("two tables found shapes where the colors match and it still can't be done") depends on 2–3 reaching L and 4–5 reaching S. With the lean cores in item 2, S is an extension; either keep S in the 4–5 core (it is 3 minutes) or soften the line to "one table…".
- The 4–5 "at a glance" line "its page 1 with the 4-by-4 boards" for free handling is good; say the same for the other tables (K–1 page 1 hexagon, 2–3 page 1) so the parent knows what "free handling" can lead into.
- `week-boards.tex` defines a few unused macros (`\DomFiveExample`, `\LTilingEightFirst`, `\RedTilingD`, `\MinGreenF`); harmless, delete or leave.

---

## What is right and should not be touched

- All counts, tilings and impossibility claims (checked by search; letters as in `week-boards.tex` and the 2–3 pages): rhombus coverings A 1, B 2, C 0, D 0, E 1, F 0, G 0, H 3, I 0, J 6, K 0, L 0, M 4, N 20, W 1; trapezoid coverings B 3, D 1, G 2, K 1 and none for A, C, E, F, H, I, J, W; fewest greens C 2, F 2, G 3, I 4, K 2; 4×4 minus two squares (a) ✗ (b) ✓ (c) ✓ (d) ✗ (e) ✓ (f) ✗; 3×3 minus a square: corners and center ✓; 5×5 L-tromino map = the nine odd-odd squares; 2×n = 1, 2, 3, 5, 8, 13; 4×4 domino tilings 36; fault-free 6×6 impossible, 6×5 example valid; Z's crossed square (row 3, column 6) is in the top-right quarter and the first tromino covers the three central squares of the other three quarters, as the plan says.
- The printed outlines are at true 1-inch scale; the hourglass L and board S are well chosen; the act–record–compare–explain order; the share plan; section 8 for the mathematicians (references and numbers are accurate).
- Compilation is clean and the directory contains only the required files.
