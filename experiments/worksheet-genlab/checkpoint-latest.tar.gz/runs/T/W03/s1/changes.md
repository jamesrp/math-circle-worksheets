# Changes made by the rewriter (Week 1, Tilings)

The previous version is preserved in `before-rewrite/`. All four files recompile with no errors, no overfull boxes and no warnings; every rendered page was inspected (`pdftoppm`). Page counts: K-1 8 pages, grades 2-3 8 pages, grades 4-5 14 pages (was 11), guide 22 pages (18 of guide plus 4 appendix pages; was 18).

New mathematical claims added in this pass were checked by code before printing (`verify.py` in the scratchpad, not left in the working directory): the 36 domino tilings of the 4-by-4 have 0, 2, 4, 6 or 8 vertical dominoes (never odd); the three "exactly 2/4/6 vertical" answer tilings are valid; the side-4 triangle needs 5 pieces even with purple chevrons allowed; the trading game on C, D, G always ends with 2, 1, 3 greens, while on the hexagon B it can end with 0 or 2 and on E with 0, 2 or 4; the colored/white counts of every piece in every orientation.

## Review item 1 (pieces do not fit the boards) -- done
- Grades 4-5 loop boards V, W, X and the 5-by-5 boards are now drawn at `\cell` = 0.58 in (measured on the PDF: 2.33 in, 3.50 in, 2.91 in). V and W side by side, X on its own row; the 5-by-5 problem is split into Problem 14 ((a), (b)) and Problem 15 ((c), (d) and the map) rather than one problem continued over two pages, so every page starts with a complete problem statement.
- Texts now say cover-with-paper-pieces-then-draw where the pieces fit, and "draw dominoes along your path" for Y.
- Guide section 2 lists exactly which boards the pieces fit and which are drawn on.

## Review item 2 (too much work; short plan as default) -- done, with two small deviations
- Each table section now opens with a core that fits (K-1 30 min, grades 2-3 36 min, grades 4-5 38 min), then "Extensions, in order" with timings, and "Stop the core at 0:47 regardless." Section 1 says the same.
- Student pages were reordered and renumbered so each packet reads core first. All cross-references ("board G (page 2)", "the table in Problem 4", the share, section 8) were updated and checked.
- K-1: core = hexagon; A-D; E; trading on C and D; coloring G; color-and-count C, B, E; F predict-and-try. Extensions: G (blue check, green count, trading), pairs, hexagon two ways, G with reds / fewest greens, I fewest pieces. Deviation: the review's "3-E" and "5-E" are merged into one problem (Problem 8: cover G with blue, count greens, then trade), since they are the same shape; the pairs problem comes after it as required.
- Grades 2-3: core = A-D; E-H; table; color board I + blue rhombus in three directions; color-and-count C, E, F with the F explanation; board I predict/check; board L. Extensions: the other pieces on board I; K and J; counting ways; fewest greens; red trapezoids.
- Grades 4-5: core = A, B; 3-by-3 minus one; checkerboard; explain; 4-by-4 minus two (a)-(c); T and U; 4-by-4 L-trominoes; Z. Extensions: S; (d)-(f); loop V, W, X; Y; 2-by-n; 5-by-5 (a), (b); 5-by-5 (c), (d) and map; exactly 2/4/6 vertical. Deviation: (d)-(f) is placed before the loop (the review had the loop first) because S and (d)-(f) share a page and the sequence "S breaks the equal-counts rule; (d)-(f) show it holding again on the 4-by-4; the loop explains why it always holds there" reads better. The guide notes W can be skipped if short.

## Review item 3 (board D, exactly 3 vertical) -- done
- Board D is deleted from Problem 1. Problem 1 now asks for A and B in two different ways and for the number of vertical dominoes in each (a recording step; the counts are always even). "Exactly 2 vertical" is kept as the last extension, Problem 16, together with new boards for exactly 4 and exactly 6 vertical dominoes (answers drawn in the guide; a new `\DomFourFourVert` macro). The "exactly 3?" question is asked orally from the guide, with the parity argument and the review's three hints.

## Review item 4 (materials contradictions) -- done
- 50 dominoes and 30 trominoes, 16 and 10 per child in two envelopes.
- The grades 4-5 table gets a small tub of blocks for free handling and the launch, collected at 0:08 (said in sections 1 and 2).
- The launch uses a card at every table (Appendix C, three copies); board N moved to its own Appendix D (one copy). Printing instructions use `\pageref` for the guide's last page (pages 1-18), one copy each of Appendix A and B.

## Review item 5 (launch spends shape C) -- done (second option, plus the first option's sentence)
- The launch now covers shape A with two blues first (a thirty-second success: "that is what covering exactly means"), then C with the same two blues, then the question. Appendix C carries both shapes. The K-1 and grades 2-3 sections say A and C are thirty-second confirmations, ask how sure they are, and move on.

## Review item 6 (hints) -- done
- `\Hint` blocks added for grades 2-3 Problems 5, 11, 12 (old 5, 9, 10); grades 4-5 Problems 4, 6, 7 (c)-(d), 12 (old 4, 7, 9, 10 (c)-(d)); a two-line hint for K-1 Problem 7 (old 8); and hints for the "exactly 3" question.

## Review item 7 (wording) -- done
- Trapezoid rows are "long side down / long side up" with the matching sentence; "Find every different way" now defines different; board I is named in Problem 4 and reused (not reprinted) in Problems 6, 8 and 11; the K-1 pairs problem says which numbers to copy ("Problems 2, 3 and 8"); the hexagon problem says "on page 2"; cover-vs-draw per item 1.

## Review item 8 (layout) -- done
- 2-by-n strips: each size in its own top-aligned row with 10 pt between groups; labels sit on the first row of their group.
- `\Space{12pt}` before Problem 4 on the grades 4-5 checkerboard page.
- K-1 grid lines `black!80, .7pt`.
- Loop answer figures V, W, X drawn without the checkerboard shading at `\cell` = 0.3 in; Y at 0.26 in.
- `needspace` is used before every answer paragraph that carries a figure (26 guards), so no figure is separated from its text; this costs some white space at a few page bottoms.
- `\Ans` runs in with the heading.

## Review item 9 (gaps in arguments) -- done
- K-1 shape I: the difference argument (10 up minus 6 down = 4; green or red changes the difference by exactly 1, blue/yellow/purple by 0; so at least four green/red pieces, covering at most 12 of 16, so a fifth piece is needed) replaces "exhaustive search" and the corner argument; chevrons are said to count.
- Trading game: added why no down-triangle can be stranded on C, D, G (each down-triangle touches more up-triangles than there are other down-triangles) and why the hexagon and E can get stuck.
- Hexagon two ways: reworded as "placing one rhombus forces the other two, so each of the six positions belongs to exactly one covering."

## Review item 10 (lower priority) -- done
- K-1 shapes relabeled with the grades 2-3 letters (A parallelogram, B hexagon, C triangle, D trapezoid, E 2-by-2 parallelogram, F trapezoid base 3, G side-3 triangle, I side-4 triangle; no H on the K-1 pages, which the guide notes).
- Share closing line softened to the grades 2-3 table, with "two tables" if grades 4-5 reached S.
- Section 1 says what free handling leads into for every table.
- The four unused macros were deleted from `week-boards.tex`.

## Review points rejected
None rejected outright. The two deviations from the review's exact extension order (merging the K-1 shape-E parts into one problem; placing 4-by-4 (d)-(f) before the loop) are explained above; the review's own dependency constraints are respected in both.
