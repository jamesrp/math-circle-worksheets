#!/usr/bin/env python3
"""
verify.py -- exhaustive checks for the Week 1 (tilings) dossier.

Everything the dossier states as a number or a yes/no is computed here.
Run:  python3 verify.py > verify-output.txt

Part A: square-grid tilings (dominoes, L-trominoes, straight trominoes,
        straight tetrominoes) on boards with and without holes.
Part B: pattern-block tilings on the triangular grid (green triangle,
        blue rhombus, red trapezoid, yellow hexagon, purple chevron).
Part C: polyiamond counts, minimum "jammed" domino placements.
"""
import sys
import itertools
from functools import lru_cache
from collections import Counter

sys.setrecursionlimit(10000)


# ----------------------------------------------------------------------
# Generic bitmask tiler.  A region is a set of hashable cells; pieces are
# given as a list of orientations, each orientation a tuple of cells with
# a distinguished "anchor" = the first cell in scan order.  We always
# cover the lowest uncovered cell (in scan order) with the anchor cell of
# some orientation.  Scan order must be translation invariant.
# ----------------------------------------------------------------------
class Tiler:
    def __init__(self, cells, orientations, translate, key):
        """cells: iterable of cells; orientations: list of lists of cells
        (already normalised so that the anchor is the min in scan order);
        translate(cell, anchor, target) -> cell shifted so anchor maps to target;
        key: scan-order key function."""
        self.cells = sorted(cells, key=key)
        self.index = {c: i for i, c in enumerate(self.cells)}
        self.n = len(self.cells)
        self.full = (1 << self.n) - 1
        self.key = key
        self.translate = translate
        # For each cell index, the list of (piecemask, piece_id) placements anchored there.
        self.place = [[] for _ in range(self.n)]
        for pid, ors in enumerate(orientations):
            for o in ors:
                anchor = o[0]
                for i, c in enumerate(self.cells):
                    # the anchor must land exactly on the target cell (on the
                    # triangular grid an up-anchor cannot sit on a down cell)
                    if translate(anchor, anchor, c) != c:
                        continue
                    m = 0
                    ok = True
                    for oc in o:
                        t = translate(oc, anchor, c)
                        j = self.index.get(t)
                        if j is None:
                            ok = False
                            break
                        m |= 1 << j
                    if ok:
                        self.place[i].append((m, pid))

    def count(self):
        place = self.place

        @lru_cache(maxsize=None)
        def go(m):
            if m == 0:
                return 1
            low = (m & -m).bit_length() - 1
            tot = 0
            for pm, pid in place[low]:
                if m & pm == pm:
                    tot += go(m ^ pm)
            return tot

        r = go(self.full)
        go.cache_clear()
        return r

    def exists(self):
        place = self.place

        @lru_cache(maxsize=None)
        def go(m):
            if m == 0:
                return True
            low = (m & -m).bit_length() - 1
            for pm, pid in place[low]:
                if m & pm == pm and go(m ^ pm):
                    return True
            return False

        r = go(self.full)
        go.cache_clear()
        return r

    def count_by_multiset(self):
        """Counter: tuple(sorted piece ids used) -> number of tilings."""
        place = self.place

        @lru_cache(maxsize=None)
        def go(m):
            if m == 0:
                return Counter({(): 1})
            low = (m & -m).bit_length() - 1
            tot = Counter()
            for pm, pid in place[low]:
                if m & pm == pm:
                    for ms, cnt in go(m ^ pm).items():
                        tot[tuple(sorted(ms + (pid,)))] += cnt
            return tot

        r = go(self.full)
        go.cache_clear()
        return r

    def tilings(self):
        """Generate every tiling as a list of (piecemask, pid)."""
        place = self.place

        def go(m, acc):
            if m == 0:
                yield list(acc)
                return
            low = (m & -m).bit_length() - 1
            for pm, pid in place[low]:
                if m & pm == pm:
                    acc.append((pm, pid))
                    yield from go(m ^ pm, acc)
                    acc.pop()

        yield from go(self.full, [])

    def one_tiling(self):
        for t in self.tilings():
            return t
        return None


# ----------------------------------------------------------------------
# Part A: square grid
# ----------------------------------------------------------------------
def sq_key(c):
    return c


def sq_translate(cell, anchor, target):
    return (cell[0] - anchor[0] + target[0], cell[1] - anchor[1] + target[1])


def sq_orientations(shape):
    """All rotations/reflections of a polyomino (set of (r,c)), normalised so
    the anchor (min cell in scan order) is first."""
    res = set()
    pts = list(shape)
    for flip in (False, True):
        for rot in range(4):
            q = []
            for (r, c) in pts:
                if flip:
                    r, c = r, -c
                for _ in range(rot):
                    r, c = c, -r
                q.append((r, c))
            mn = min(q)
            q = tuple(sorted((r - mn[0], c - mn[1]) for r, c in q))
            res.add(q)
    return [list(o) for o in sorted(res)]


DOMINO = sq_orientations({(0, 0), (0, 1)})
LTROM = sq_orientations({(0, 0), (0, 1), (1, 0)})
ITROM = sq_orientations({(0, 0), (0, 1), (0, 2)})
ITET = sq_orientations({(0, 0), (0, 1), (0, 2), (0, 3)})
LTET = sq_orientations({(0, 0), (1, 0), (2, 0), (2, 1)})
TTET = sq_orientations({(0, 0), (0, 1), (0, 2), (1, 1)})
SQ2 = sq_orientations({(0, 0), (0, 1), (1, 0), (1, 1)})


def board(h, w, holes=()):
    return {(r, c) for r in range(h) for c in range(w)} - set(holes)


def sq_tiler(h, w, pieces, holes=()):
    return Tiler(board(h, w, holes), pieces, sq_translate, sq_key)


def color(r, c):
    return "D" if (r + c) % 2 == 0 else "L"   # D = dark (corner colour), L = light


def grid_string(h, w, f):
    return "\n".join("  " + " ".join(f(r, c) for c in range(w)) for r in range(h))


def hr(title):
    print()
    print("=" * 72)
    print(title)
    print("=" * 72)


hr("A1. Number of domino tilings of full rectangles (fixed tilings)")
print("2 x n :", [sq_tiler(2, n, [DOMINO]).count() for n in range(1, 11)], "(n = 1..10)")
print("3 x n :", [(n, sq_tiler(3, n, [DOMINO]).count()) for n in range(1, 9)])
print("4 x n :", [(n, sq_tiler(4, n, [DOMINO]).count()) for n in range(1, 8)])
for (h, w) in [(5, 6), (6, 6), (6, 8), (8, 8)]:
    print(f"{h} x {w} :", sq_tiler(h, w, [DOMINO]).count())

hr("A2. 3x3 board minus one square, dominoes: tileable? (count of tilings)")
c33 = {}
for r in range(3):
    for cc in range(3):
        c33[(r, cc)] = sq_tiler(3, 3, [DOMINO], holes=[(r, cc)]).count()
print(grid_string(3, 3, lambda r, c: f"{c33[(r,c)]:2d}"))
print("  (entry = number of domino tilings when that square is the hole; 0 = impossible)")
print("  colouring: dark squares (corner colour) =",
      sum(1 for r in range(3) for c in range(3) if color(r, c) == "D"),
      ", light =", sum(1 for r in range(3) for c in range(3) if color(r, c) == "L"))
print(grid_string(3, 3, color))

hr("A3. 5x5 and 7x7 minus one square, dominoes: count of tilings per hole")
for n in (5, 7):
    cnt = {}
    for r in range(n):
        for cc in range(n):
            cnt[(r, cc)] = sq_tiler(n, n, [DOMINO], holes=[(r, cc)]).count()
    print(f"{n}x{n}:")
    print(grid_string(n, n, lambda r, c: f"{cnt[(r,c)]:4d}"))
    dark_ok = all(cnt[(r, c)] > 0 for r in range(n) for c in range(n) if color(r, c) == "D")
    light_no = all(cnt[(r, c)] == 0 for r in range(n) for c in range(n) if color(r, c) == "L")
    print(f"  every dark hole tileable: {dark_ok}; every light hole impossible: {light_no}")

hr("A4. Even boards minus TWO squares, dominoes (Gomory): all pairs")
for n in (4, 6):
    cells = [(r, c) for r in range(n) for c in range(n)]
    same_ok = diff_ok = same_no = diff_no = 0
    for a, b in itertools.combinations(cells, 2):
        ex = sq_tiler(n, n, [DOMINO], holes=[a, b]).exists()
        if color(*a) == color(*b):
            if ex:
                same_ok += 1
            else:
                same_no += 1
        else:
            if ex:
                diff_ok += 1
            else:
                diff_no += 1
    print(f"{n}x{n}: pairs of SAME colour: {same_no} impossible, {same_ok} tileable;"
          f" pairs of DIFFERENT colour: {diff_ok} tileable, {diff_no} impossible")
# 8x8: opposite corners, adjacent corners, and a random sample of pairs
import random
random.seed(1)
cells8 = [(r, c) for r in range(8) for c in range(8)]
print("8x8 opposite corners (0,0),(7,7):", sq_tiler(8, 8, [DOMINO], holes=[(0, 0), (7, 7)]).exists())
print("8x8 corners on one side (0,0),(0,7):", sq_tiler(8, 8, [DOMINO], holes=[(0, 0), (0, 7)]).exists())
ok = True
for _ in range(60):
    a, b = random.sample(cells8, 2)
    ex = sq_tiler(8, 8, [DOMINO], holes=[a, b]).exists()
    if ex != (color(*a) != color(*b)):
        ok = False
        print("  MISMATCH", a, b, ex)
print("8x8, 60 random pairs: tileable iff different colours ->", ok)

hr("A5. Counts for the 4x4 two-hole instances used on the student pages")
pairs = {
    "A opposite corners (0,0),(3,3)": [(0, 0), (3, 3)],
    "B corners on one side (0,0),(0,3)": [(0, 0), (0, 3)],
    "C corner + its neighbour (0,0),(0,1)": [(0, 0), (0, 1)],
    "D two dark middle squares (1,1),(2,2)": [(1, 1), (2, 2)],
    "E middle pair (1,1),(1,2)": [(1, 1), (1, 2)],
    "F corner + far edge square (0,0),(3,1)": [(0, 0), (3, 1)],
    "G (0,1),(2,3) both light": [(0, 1), (2, 3)],
    "H (0,0),(2,3) dark+light far apart": [(0, 0), (2, 3)],
}
for name, hs in pairs.items():
    t = sq_tiler(4, 4, [DOMINO], holes=hs)
    print(f"  {name}: colours {color(*hs[0])},{color(*hs[1])}: tilings = {t.count()}")

hr("A6. L-tromino: n x n minus one square, which holes work (count of tilings)")
for n in (2, 3, 4, 5, 6, 7):
    if (n * n - 1) % 3 != 0:
        print(f"{n}x{n} minus one: {n*n-1} squares, not a multiple of 3 -> impossible for every hole")
        continue
    cnt = {}
    for r in range(n):
        for cc in range(n):
            t = sq_tiler(n, n, [LTROM], holes=[(r, cc)])
            cnt[(r, cc)] = t.count() if n <= 5 else (1 if t.exists() else 0)
    print(f"{n}x{n} minus one square ({(n*n-1)//3} pieces):"
          + ("  [entries are counts]" if n <= 5 else "  [1 = tileable, 0 = not]"))
    print(grid_string(n, n, lambda r, c: f"{cnt[(r,c)]:5d}"))
# 8x8: existence for every hole (by symmetry only 10 classes, but check all 64)
allok = True
for r in range(8):
    for cc in range(8):
        if not sq_tiler(8, 8, [LTROM], holes=[(r, cc)]).exists():
            allok = False
            print("  8x8 hole", (r, cc), "NOT tileable ??")
print("8x8 minus one square, L-trominoes (21 pieces): every hole tileable ->", allok)

hr("A7. L-tromino tilings of full rectangles")
for (h, w) in [(2, 3), (3, 3), (3, 4), (3, 5), (3, 6), (4, 6), (5, 6), (6, 6), (3, 7), (6, 9)]:
    t = sq_tiler(h, w, [LTROM])
    if h * w <= 36:
        print(f"  {h}x{w}: {t.count()} tilings")
    else:
        print(f"  {h}x{w}: tileable = {t.exists()}")
print("  9x9 tileable =", sq_tiler(9, 9, [LTROM]).exists())

hr("A8. Straight tromino (1x3): n x n minus one square, which holes work")
for n in (4, 5, 7, 8):
    cnt = {}
    for r in range(n):
        for cc in range(n):
            t = sq_tiler(n, n, [ITROM], holes=[(r, cc)])
            cnt[(r, cc)] = t.count() if n <= 5 else (1 if t.exists() else 0)
    print(f"{n}x{n} minus one square:" + ("  [counts]" if n <= 5 else "  [1 = tileable]"))
    print(grid_string(n, n, lambda r, c: f"{cnt[(r,c)]:4d}"))
print("3x3 full board, straight trominoes:", sq_tiler(3, 3, [ITROM]).count(), "tilings")
print("3x3 full board, L-trominoes:", sq_tiler(3, 3, [LTROM]).count(), "tilings")
print("diagonal 3-colouring counts (i+j mod 3) on 4x4:",
      Counter((r + c) % 3 for r in range(4) for c in range(4)))
print("diagonal 3-colouring counts (i+j mod 3) on 5x5:",
      Counter((r + c) % 3 for r in range(5) for c in range(5)))
print("diagonal 3-colouring counts (i+j mod 3) on 8x8:",
      Counter((r + c) % 3 for r in range(8) for c in range(8)))

hr("A9. Tetromino facts used as reserves")
print("6x6 by straight tetrominoes (1x4):", sq_tiler(6, 6, [ITET]).exists(),
      "; 4-colouring (i+j mod 4) counts:", Counter((r + c) % 4 for r in range(6) for c in range(6)))
print("6x6 by L-tetrominoes:", sq_tiler(6, 6, [LTET]).exists())
print("4x4 by T-tetrominoes:", sq_tiler(4, 4, [TTET]).count(), "tilings")
print("6x6 by T-tetrominoes:", sq_tiler(6, 6, [TTET]).exists())
print("4x8 by T-tetrominoes:", sq_tiler(4, 8, [TTET]).exists())
print("4x4 by 2x2 squares:", sq_tiler(4, 4, [SQ2]).count(), "tiling(s)")

hr("A10. Minimum 'jammed' domino placements (fewest dominoes so that no more fit)")


def min_jam(h, w):
    cells = [(r, c) for r in range(h) for c in range(w)]
    edges = []
    for (r, c) in cells:
        if c + 1 < w:
            edges.append(((r, c), (r, c + 1)))
        if r + 1 < h:
            edges.append(((r, c), (r + 1, c)))
    for k in range(1, len(cells) // 2 + 1):
        for combo in itertools.combinations(edges, k):
            used = set()
            ok = True
            for e in combo:
                if e[0] in used or e[1] in used:
                    ok = False
                    break
                used.add(e[0])
                used.add(e[1])
            if not ok:
                continue
            # maximal?  every edge must touch a used cell
            if all(e[0] in used or e[1] in used for e in edges):
                return k, combo
    return None


for (h, w) in [(2, 2), (2, 3), (2, 4), (2, 5), (2, 6), (3, 3), (3, 4), (4, 4)]:
    k, combo = min_jam(h, w)
    print(f"  {h}x{w}: fewest dominoes to jam = {k}; example: {list(combo)}")

# ----------------------------------------------------------------------
# Part B: triangular grid / pattern blocks
# Vertices (a,b) stand for a*e1 + b*e2 with e1=(1,0), e2=(1/2, sqrt3/2).
# Up triangle U(a,b): vertices (a,b),(a+1,b),(a,b+1).
# Down triangle D(a,b): vertices (a+1,b),(a,b+1),(a+1,b+1).
# A cell is (a, b, t) with t = 0 (up) or 1 (down).
# ----------------------------------------------------------------------
def verts(cell):
    a, b, t = cell
    if t == 0:
        return [(a, b), (a + 1, b), (a, b + 1)]
    return [(a + 1, b), (a, b + 1), (a + 1, b + 1)]


def cell_from_verts(vs):
    amin = min(v[0] for v in vs)
    bmin = min(v[1] for v in vs)
    return (amin, bmin, 0) if (amin, bmin) in vs else (amin, bmin, 1)


def rot60(v):
    a, b = v
    return (-b, a + b)


def swap(v):
    return (v[1], v[0])


def symmetries():
    """The 12 linear symmetries of the triangular lattice as functions on vertices."""
    funcs = []
    for flip in (False, True):
        for k in range(6):
            def f(v, k=k, flip=flip):
                if flip:
                    v = swap(v)
                for _ in range(k):
                    v = rot60(v)
                return v
            funcs.append(f)
    return funcs


SYMS = symmetries()


def tri_key(cell):
    a, b, t = cell
    return (b, a, t)


def tri_translate(cell, anchor, target):
    return (cell[0] - anchor[0] + target[0], cell[1] - anchor[1] + target[1], cell[2])


def tri_orientations(shape):
    res = set()
    for f in SYMS:
        img = [cell_from_verts([f(v) for v in verts(c)]) for c in shape]
        mn = min(img, key=tri_key)
        img = tuple(sorted(((a - mn[0], b - mn[1], t) for a, b, t in img), key=tri_key))
        res.add(img)
    return [list(o) for o in sorted(res)]


def around(v):
    """The six triangles around vertex v, in cyclic order."""
    a, b = v
    return [(a, b, 0), (a - 1, b, 1), (a - 1, b, 0), (a - 1, b - 1, 1), (a, b - 1, 0), (a, b - 1, 1)]


GREEN = [(0, 0, 0)]
BLUE = [(0, 0, 0), (0, 0, 1)]
RED = [(0, 0, 0), (0, 0, 1), (1, 0, 0)]
YELLOW = around((1, 1))
PURPLE = around((1, 1))[2:]          # four consecutive triangles around a vertex = chevron
STRIP = [(0, 0, 0), (0, 0, 1), (1, 0, 0), (1, 0, 1)]  # parallelogram of 4 = two rhombi in a row

# sanity: orientations
for name, sh in [("green", GREEN), ("blue", BLUE), ("red", RED), ("yellow", YELLOW), ("purple", PURPLE)]:
    pass
PIECES = {"G": GREEN, "B": BLUE, "R": RED, "Y": YELLOW, "P": PURPLE}
ORIENT = {k: tri_orientations(v) for k, v in PIECES.items()}


def hexagon(n):
    cells = set()
    for a in range(-n - 1, n + 2):
        for b in range(-n - 1, n + 2):
            for t in (0, 1):
                c = (a, b, t)
                if all(max(abs(x), abs(y), abs(x + y)) <= n for x, y in verts(c)):
                    cells.add(c)
    return cells


def triangle(n):
    cells = set()
    for a in range(n):
        for b in range(n - a):
            cells.add((a, b, 0))
            if a + b <= n - 2:
                cells.add((a, b, 1))
    return cells


def parallelogram(m, n):
    return {(a, b, t) for a in range(m) for b in range(n) for t in (0, 1)}


def updown(cells):
    return (sum(1 for c in cells if c[2] == 0), sum(1 for c in cells if c[2] == 1))


def tri_tiler(cells, kinds):
    return Tiler(cells, [ORIENT[k] for k in kinds], tri_translate, tri_key), kinds


def multiset_report(cells, kinds, label):
    t, kinds = tri_tiler(cells, kinds)
    res = t.count_by_multiset()
    total = sum(res.values())
    print(f"{label}: {len(cells)} triangles, up/down = {updown(cells)}, pieces {''.join(kinds)}:"
          f" {total} tilings, {len(res)} different sets of pieces")
    for ms, cnt in sorted(res.items(), key=lambda kv: (len(kv[0]), kv[0])):
        print("   ", "".join(kinds[i] for i in ms).ljust(26), f"{cnt} tiling(s)")
    return res


hr("B1. Piece sizes (in green triangles) and sanity checks")
for k, v in PIECES.items():
    print(f"  {k}: {len(v)} triangles, {len(ORIENT[k])} distinct orientations")
print("  hexagon side 1:", len(hexagon(1)), "triangles; side 2:", len(hexagon(2)), "; side 3:", len(hexagon(3)))
print("  triangle side n, (up, down):", [(n, updown(triangle(n))) for n in range(1, 7)])
print("  hexagon side n, (up, down):", [(n, updown(hexagon(n))) for n in range(1, 4)])

hr("B2. The yellow-hexagon outline (6 triangles): every way to fill it")
multiset_report(hexagon(1), ["G", "B", "R", "Y"], "hexagon, standard pieces")
multiset_report(hexagon(1), ["G", "B", "R", "Y", "P"], "hexagon, with purple chevron")
multiset_report(hexagon(1), ["B"], "hexagon, blues only")
multiset_report(hexagon(1), ["R"], "hexagon, reds only")

hr("B3. Hexagon with one triangle bitten off (5 triangles)")
bite = set(hexagon(1))
bite.discard(around((0, 0))[0])
multiset_report(bite, ["G", "B", "R", "Y", "P"], "hexagon minus one triangle")

hr("B4. Triangles of side 2, 3, 4 (and 5, 6) with pattern blocks")
multiset_report(triangle(2), ["G", "B", "R", "Y", "P"], "triangle side 2")
multiset_report(triangle(3), ["G", "B", "R", "Y", "P"], "triangle side 3")
res4 = multiset_report(triangle(4), ["B", "R", "Y", "P"], "triangle side 4 (no greens)")
t4, _ = tri_tiler(triangle(4), ["B"])
print("  triangle side 4, blues only:", t4.count(), "tilings (up/down =", updown(triangle(4)), ")")
t4, _ = tri_tiler(triangle(4), ["R"])
print("  triangle side 4, reds only:", t4.count(), "tilings (16 is not a multiple of 3)")
t4, _ = tri_tiler(triangle(4), ["G", "B", "R", "Y", "P"])
print("  triangle side 4, all pieces:", t4.count(), "tilings in total")
for n in (5, 6):
    tb, _ = tri_tiler(triangle(n), ["B"])
    tr, _ = tri_tiler(triangle(n), ["R"])
    print(f"  triangle side {n}: blues only -> {tb.exists()}; reds only -> {tr.exists()}"
          f" (up/down = {updown(triangle(n))}, {n*n} triangles)")
t6, _ = tri_tiler(triangle(6), ["R"])
print("  triangle side 6, reds only: number of tilings =", t6.count())

hr("B5. Strip (two rhombi in a row) and chevron: tilings by rhombi")
for name, sh in [("strip 1x2", STRIP), ("chevron", PURPLE)]:
    t, _ = tri_tiler(set(sh), ["B"])
    print(f"  {name}: {t.count()} tiling(s) by blue rhombi; up/down = {updown(sh)}")

hr("B6. The side-2 hexagon (24 triangles)")
H2 = hexagon(2)
tB, _ = tri_tiler(H2, ["B"])
print("  blues only:", tB.count(), "tilings")


def rhombus_direction(pm_cells):
    """Direction of the shared (short-diagonal) edge of a placed rhombus."""
    (u, d) = (pm_cells[0], pm_cells[1]) if pm_cells[0][2] == 0 else (pm_cells[1], pm_cells[0])
    a, b, _ = u
    if d == (a, b, 1):
        return "120deg"
    if d == (a - 1, b, 1):
        return "60deg"
    if d == (a, b - 1, 1):
        return "0deg (standing rhombus)"
    raise ValueError


dir_counts = Counter()
for til in tB.tilings():
    cnt = Counter()
    for pm, pid in til:
        cells = [tB.cells[i] for i in range(tB.n) if pm >> i & 1]
        cnt[rhombus_direction(cells)] += 1
    dir_counts[tuple(sorted(cnt.items()))] += 1
print("  orientation counts per tiling (direction of short diagonal):")
for k, v in dir_counts.items():
    print("   ", k, "occurs in", v, "tilings")
for kinds in (["R"], ["Y"], ["Y", "B"], ["Y", "R"], ["B", "R"], ["Y", "G"]):
    t, _ = tri_tiler(H2, kinds)
    n = t.count()
    print(f"  pieces {''.join(kinds)} only: {n} tilings")
res = tri_tiler(H2, ["Y", "B"])[0].count_by_multiset()
print("  Y+B multisets:", {("Y" * sum(1 for i in ms if i == 0) + "B" * sum(1 for i in ms if i == 1)): c for ms, c in res.items()})
res = tri_tiler(H2, ["Y", "G"])[0].count_by_multiset()
print("  Y+G multisets:", {("Y" * sum(1 for i in ms if i == 0) + "G" * sum(1 for i in ms if i == 1)): c for ms, c in res.items()})
res = tri_tiler(H2, ["Y", "R"])[0].count_by_multiset()
print("  Y+R multisets:", {("Y" * sum(1 for i in ms if i == 0) + "R" * sum(1 for i in ms if i == 1)): c for ms, c in res.items()})
print("  side-1 hexagon by rhombi:", tri_tiler(hexagon(1), ["B"])[0].count(),
      "; side-3 hexagon by rhombi:", tri_tiler(hexagon(3), ["B"])[0].count(), "(MacMahon: 2, 20, 980)")

hr("B7. Flip distance in the side-2 hexagon: plane partitions in a 2x2x2 box")
# plane partitions with 2 rows, 2 columns, entries <= 2
pps = [p for p in itertools.product(range(3), repeat=4)
       if p[0] >= p[1] and p[0] >= p[2] and p[1] >= p[3] and p[2] >= p[3]]
print("  number of plane partitions in a 2x2x2 box:", len(pps),
      "; max number of cubes:", max(sum(p) for p in pps), "(= flips from empty box to full box)")

# ----------------------------------------------------------------------
# Part C: polyiamonds (free) of size 1..6
# ----------------------------------------------------------------------
hr("C1. Number of different shapes made of n green triangles (free polyiamonds)")


def neighbours(cell):
    a, b, t = cell
    if t == 0:
        return [(a, b, 1), (a - 1, b, 1), (a, b - 1, 1)]
    return [(a, b, 0), (a + 1, b, 0), (a, b + 1, 0)]


def canon(shape):
    best = None
    for f in SYMS:
        img = [cell_from_verts([f(v) for v in verts(c)]) for c in shape]
        mn = min(img, key=tri_key)
        img = tuple(sorted(((a - mn[0], b - mn[1], t) for a, b, t in img), key=tri_key))
        if best is None or img < best:
            best = img
    return best


shapes = {canon([(0, 0, 0)])}
counts = [1]
for n in range(2, 7):
    new = set()
    for s in shapes:
        for c in s:
            for nb in neighbours(c):
                if nb not in s:
                    new.add(canon(list(s) + [nb]))
    shapes = new
    counts.append(len(shapes))
print("  n = 1..6:", counts, "(expected 1, 1, 1, 3, 4, 12)")

# ----------------------------------------------------------------------
# Part D: explicit pictures the guide can reproduce
# ----------------------------------------------------------------------
LETTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"


def show_sq_tiling(t, tiling, h, w, holes=()):
    lab = {}
    for k, (pm, pid) in enumerate(tiling):
        for i in range(t.n):
            if pm >> i & 1:
                lab[t.cells[i]] = LETTERS[k % len(LETTERS)]
    for c in holes:
        lab[c] = "#"
    return "\n".join("  " + " ".join(lab.get((r, c), ".") for c in range(w)) for r in range(h))


hr("D1. All domino tilings of 2x4 (5), 2x5 (8) and 3x4 (11)")
for (h, w) in [(2, 4), (2, 5), (3, 4)]:
    t = sq_tiler(h, w, [DOMINO])
    tl = list(t.tilings())
    print(f"{h}x{w}: {len(tl)} tilings")
    for k, til in enumerate(tl):
        print(f" #{k+1}")
        print(show_sq_tiling(t, til, h, w))

hr("D2. L-tromino tilings: 2x3 (both), 3x4 (all four), 4x4 minus corner (unique), 4x4 minus (1,1) (unique)")
for (h, w, holes) in [(2, 3, []), (3, 4, []), (4, 4, [(0, 0)]), (4, 4, [(1, 1)]), (4, 4, [(0, 1)])]:
    t = sq_tiler(h, w, [LTROM], holes=holes)
    tl = list(t.tilings())
    print(f"{h}x{w} minus {holes}: {len(tl)} tiling(s)")
    for til in tl:
        print(show_sq_tiling(t, til, h, w, holes))
        print()

hr("D3. One L-tromino tiling of 5x5 minus a corner, minus (0,2), minus the centre; 7x7 minus (0,1)")
for holes in [[(0, 0)], [(0, 2)], [(2, 2)]]:
    t = sq_tiler(5, 5, [LTROM], holes=holes)
    print("5x5 minus", holes)
    print(show_sq_tiling(t, t.one_tiling(), 5, 5, holes))
t = sq_tiler(7, 7, [LTROM], holes=[(0, 1)])
print("7x7 minus (0,1)  (a hole that is NOT on the 5x5-style dot lattice; still tileable)")
print(show_sq_tiling(t, t.one_tiling(), 7, 7, [(0, 1)]))

hr("D4. Straight-tromino tilings: 5x5 minus centre (both), 4x4 minus corner (all four)")
t = sq_tiler(5, 5, [ITROM], holes=[(2, 2)])
for til in t.tilings():
    print(show_sq_tiling(t, til, 5, 5, [(2, 2)]))
    print()
t = sq_tiler(4, 4, [ITROM], holes=[(0, 0)])
for til in t.tilings():
    print(show_sq_tiling(t, til, 4, 4, [(0, 0)]))
    print()

hr("D5. The recursive (Golomb) L-tromino tiling of 8x8 minus a corner, built exactly as the induction says")


def golomb(n, hole, r0=0, c0=0, out=None, counter=[0]):
    """Tile the 2^n x 2^n board with top-left (r0,c0), hole given in absolute
    coordinates, by the induction: one L at the centre, then recurse."""
    if out is None:
        out = {}
    size = 2 ** n
    if size == 2:
        counter[0] += 1
        for r in range(r0, r0 + 2):
            for c in range(c0, c0 + 2):
                if (r, c) != hole:
                    out[(r, c)] = counter[0]
        return out
    half = size // 2
    hr_, hc = hole
    quads = [(r0, c0), (r0, c0 + half), (r0 + half, c0), (r0 + half, c0 + half)]
    centre = [(r0 + half - 1, c0 + half - 1), (r0 + half - 1, c0 + half),
              (r0 + half, c0 + half - 1), (r0 + half, c0 + half)]
    counter[0] += 1
    k = counter[0]
    subholes = []
    for (qr, qc), cc in zip(quads, centre):
        if qr <= hr_ < qr + half and qc <= hc < qc + half:
            subholes.append(hole)
        else:
            out[cc] = k
            subholes.append(cc)
    for (qr, qc), sh in zip(quads, subholes):
        golomb(n - 1, sh, qr, qc, out, counter)
    return out


out = golomb(3, (0, 0), counter=[0])
print("8x8 minus (0,0): piece numbers (21 pieces; piece 1 is the centre L placed first)")
print("\n".join("  " + " ".join(f"{out.get((r,c),0):2d}" if (r, c) != (0, 0) else " #" for c in range(8)) for r in range(8)))
assert len(set(out.values())) == 21 and len(out) == 63
out = golomb(2, (2, 1), counter=[0])
print("4x4 minus (2,1) by the same recipe:")
print("\n".join("  " + " ".join(f"{out.get((r,c),0):2d}" if (r, c) != (2, 1) else " #" for c in range(4)) for r in range(4)))

hr("D6. Gomory loops (closed paths through every square) for 4x4 and 6x6, and a snake path for 5x5")


def loop(n):
    path = [(0, c) for c in range(n)]
    for r in range(1, n):
        cols = range(n - 1, 0, -1) if r % 2 == 1 else range(1, n)
        path += [(r, c) for c in cols]
    path += [(r, 0) for r in range(n - 1, 0, -1)]
    return path


for n in (4, 6):
    p = loop(n)
    assert len(p) == n * n and len(set(p)) == n * n
    assert all(abs(a[0] - b[0]) + abs(a[1] - b[1]) == 1 for a, b in zip(p, p[1:] + p[:1]))
    order = {c: i + 1 for i, c in enumerate(p)}
    print(f"{n}x{n} loop, squares numbered in loop order (square {n*n} is next to square 1):")
    print("\n".join("  " + " ".join(f"{order[(r,c)]:2d}" for c in range(n)) for r in range(n)))
    # verify the argument: removing two squares of different colour leaves two even arcs
    ok = True
    for a, b in itertools.combinations(p, 2):
        ia, ib = order[a], order[b]
        arc1 = ib - ia - 1
        arc2 = n * n - 2 - arc1
        if color(*a) != color(*b):
            ok &= (arc1 % 2 == 0 and arc2 % 2 == 0)
    print(f"  different-colour holes always cut the loop into two even arcs: {ok}")
snake = []
for r in range(5):
    cols = range(5) if r % 2 == 0 else range(4, -1, -1)
    snake += [(r, c) for c in cols]
order = {c: i + 1 for i, c in enumerate(snake)}
print("5x5 snake path, squares numbered in path order:")
print("\n".join("  " + " ".join(f"{order[(r,c)]:2d}" for c in range(5)) for r in range(5)))
print("  dark squares (corner colour) sit at odd positions:",
      all((order[c] % 2 == 1) == (color(*c) == "D") for c in snake))

hr("D7. L-tromino 'dot' argument: 2x2 windows and (odd,odd) cells on 5x5")
dots = {(r, c) for r in range(5) for c in range(5) if r % 2 == 0 and c % 2 == 0}
print("  dots (1-indexed odd,odd) as 0-indexed even,even:", sorted(dots), "->", len(dots), "dots")
ok = all(len(dots & {(r, c), (r, c + 1), (r + 1, c), (r + 1, c + 1)}) == 1 for r in range(4) for c in range(4))
print("  every 2x2 window contains exactly one dot:", ok)
d3 = sorted({(r, c) for r in range(3) for c in range(3) if r % 2 == 0 and c % 2 == 0})
print("  3x3 board: dots =", d3, f"-> {len(d3)} dots (the four corners), 3 pieces -> impossible")
ok3 = all(len(set(d3) & {(r, c), (r, c + 1), (r + 1, c), (r + 1, c + 1)}) == 1 for r in range(2) for c in range(2))
print("  every 2x2 window of the 3x3 contains exactly one corner:", ok3)

hr("D8. Flip graphs: dominoes on 2x4, 2x5, 3x4, 4x4; rhombi on the side-2 hexagon")


def flip_graph(t, block_size):
    """Vertices: tilings as frozensets of piece masks.  Edge: the two tilings
    differ in exactly the pieces inside one 'block' (a 2x2 square for dominoes,
    a unit hexagon for rhombi), i.e. symmetric difference = 2 pieces (dominoes)
    or 6 pieces (3 rhombi out, 3 in) covering the same cells."""
    tl = [frozenset(pm for pm, pid in til) for til in t.tilings()]
    adj = {i: set() for i in range(len(tl))}
    for i in range(len(tl)):
        for j in range(i + 1, len(tl)):
            diff = tl[i] ^ tl[j]
            if len(diff) == 2 * block_size:
                # pieces removed cover the same cells as pieces added, and they
                # form one block: total cells = 2*block_size (dominoes) or
                # 6 (rhombi)
                out = [pm for pm in tl[i] if pm not in tl[j]]
                inn = [pm for pm in tl[j] if pm not in tl[i]]
                cells_out = 0
                for pm in out:
                    cells_out |= pm
                cells_in = 0
                for pm in inn:
                    cells_in |= pm
                if cells_out == cells_in and len(out) == block_size:
                    adj[i].add(j)
                    adj[j].add(i)
    return tl, adj


def bfs_all(adj, n):
    dist_all = {}
    for s in range(n):
        dist = {s: 0}
        frontier = [s]
        while frontier:
            nxt = []
            for u in frontier:
                for v in adj[u]:
                    if v not in dist:
                        dist[v] = dist[u] + 1
                        nxt.append(v)
            frontier = nxt
        dist_all[s] = dist
    return dist_all


for (h, w) in [(2, 4), (2, 5), (3, 4), (4, 4)]:
    t = sq_tiler(h, w, [DOMINO])
    tl, adj = flip_graph(t, 2)
    d = bfs_all(adj, len(tl))
    connected = all(len(d[s]) == len(tl) for s in d)
    diam = max(max(d[s].values()) for s in d)
    print(f"  {h}x{w} dominoes: {len(tl)} tilings, flip graph connected: {connected}, diameter {diam}")

tB, _ = tri_tiler(H2, ["B"])
tl, adj = flip_graph(tB, 3)
d = bfs_all(adj, len(tl))
connected = all(len(d[s]) == len(tl) for s in d)
diam = max(max(d[s].values()) for s in d)
ecc = sorted(max(d[s].values()) for s in d)
print(f"  side-2 hexagon rhombi: {len(tl)} tilings, spin graph connected: {connected}, diameter {diam}"
      f" (exactly {sum(1 for e in ecc if e == diam)} tilings are at distance {diam} from another: the empty and the full box)")

print()
print("done.")
