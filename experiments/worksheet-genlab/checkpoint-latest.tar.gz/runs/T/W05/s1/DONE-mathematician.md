dossier.md complete (6 sections, verified data) when the agent was cut by the Fable rate limit before writing its DONE marker; accepted by the orchestrator
