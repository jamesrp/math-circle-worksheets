# Week 1 — Tilings. Mathematician's dossier

Every number and every yes/no below was computed by `verify.py` in this directory (it runs in under a second); its output is `verify-output.txt`, and bracketed labels [A1]–[D8] point to sections of that output. Conventions:

- Squares are (row, column) counted **from 1**, top-left first. (`verify-output.txt` counts from 0.)
- "Dark" is the checkerboard colour of the corner square (1,1). A domino always covers one dark and one light square.
- A hole is a blacked-out or cut-out square (or triangle); no piece may cover it.
- Tilings are counted as **fixed** tilings: two fillings of the same printed board are different if some piece is in a different place, so a mirror image counts separately. Every count here (1, 2, 3, 5, 8; 11; 20; …) uses this convention and the student pages must say so.
- Pattern blocks live on the triangular grid; each piece is a union of unit (green) triangles: blue rhombus 2, red trapezoid 3, purple chevron 4 (the V-shaped piece: two rhombi meeting at 120°, i.e. a hexagon minus one rhombus), yellow hexagon 6. Printed hexagons have a **flat top and bottom**. A unit triangle "points up" (flat side down) or "points down".

---

## 1. The real questions

**Q1. Existence.** Can this region be tiled by these pieces? Domino tilings are the perfect matchings of the region's grid graph, so existence is decidable in polynomial time, and for simply connected regions Thurston's height function decides it in linear time. For most other tile sets the question is NP-complete (L-trominoes: Moore–Robson 2001; bars: Beauquier–Nivat–Rémila–Robson 1995); for tiling the whole plane with Wang tiles it is undecidable (Berger 1966). Elementary form: an outline, a pile of pieces, "no gaps, no overlaps, nothing sticking out, never on the black square — can you?" A tiling found is a proof of *yes*; a failure proves nothing, which is why Q2 exists.

**Q2. Impossibility by an invariant.** Weight the cells so that every placed piece consumes a fixed amount; if the region's total is wrong, no tiling exists. The organiser's example (8×8 minus opposite corners: 32 squares of one colour, 30 of the other) is the checkerboard weight. This week the same idea appears in four costumes:
- checkerboard (dominoes): dark − light must be 0;
- up/down triangles (blue rhombi): each rhombus covers one up- and one down-pointing triangle. A triangle of side n has n more up-triangles than down-triangles, so **no triangle outline can be filled with rhombi**, even one of even area (side 4: 16 triangles, 10 up, 6 down);
- dots (L-trominoes): mark the squares in an odd row *and* an odd column. Every 2×2 window contains exactly one dot, and every L lies inside a 2×2 window, so an L covers **at most one dot**. A 5×5 has 9 dots and a deficient 5×5 uses 8 pieces, so the hole must be a dot. On the 3×3 the dots are the four corners and there are three pieces;
- three diagonal colours (straight trominoes): colour (r+c) mod 3; a 1×3 bar covers one of each; with the other diagonal (r−c) mod 3 as well, the hole of a deficient 4×4 must be a corner and of a deficient 5×5 the centre (Golomb's 8×8: four squares).
Research form: invariants that are not colourings (Conway–Lagarias boundary words, Thurston height functions, Pak's ribbon-tile invariants). For the children the one sentence is: "count two kinds of cells; every piece eats a fixed amount of each."

**Q3. Completeness.** When is the invariant also sufficient? Gomory: remove one dark and one light square from an even board and a domino tiling always exists — a closed loop through all squares is cut by the holes into two even paths; tile along the paths. Odd boards minus one square: tileable iff the hole is dark (snake path). Deficient 2ⁿ×2ⁿ boards with L-trominoes: always (Golomb 1954, induction). Deficient 5×5: iff the hole is a dot; 7×7 and 8×8: every hole (Chu–Johnsonbaugh 1986). Straight trominoes: 4×4 corners only, 5×5 centre only, 8×8 exactly (3,3),(3,6),(6,3),(6,6). All verified exhaustively [A2–A8].

**Q4. Counting.** 2×n by dominoes: 1, 2, 3, 5, 8, 13 — Fibonacci, by looking at the left end. Kasteleyn and Temperley–Fisher count any rectangle (8×8: 12,988,816); MacMahon counts lozenge tilings of hexagons (side 2: 20 = plane partitions in a 2×2×2 box); Aztec diamonds have 2^{n(n+1)/2}; random tilings have limit shapes. Elementary form: list them all, organised so the list is visibly complete.

**Q5. Reconfiguration.** Any two domino (or lozenge) tilings of a simply connected region are joined by local flips (two parallel dominoes in a 2×2 rotate; three rhombi in a unit hexagon spin), and the height function measures the distance. Elementary form: the two fillings of the yellow hexagon by three blues differ by one spin; the 20 fillings of the side-2 hexagon are stacks of 0–8 cubes in a corner, a spin adds or removes a cube, empty-to-full is exactly 8 spins [B7].

**Q6. Optimality (jamming).** Fewest dominoes so that no further domino fits — a minimum maximal matching, NP-hard in general (Yannakakis–Gavril 1980). 3×3: 3; 4×4: 6; 2×n: 2, 2, 3, 4, 4 for n = 2…6 [A10].

**Q7. Listing the shapes.** Shapes made of n unit triangles: 1, 1, 1, 3, 4, 12 for n = 1…6 [C1]. "Make every shape from four greens; there are three" is a completeness argument K–1 can give.

---

## 2. Instances

Board; what the child does; what they find; the answer; why it is there. **Core** instances form the sequence; **reserve** ones are for a fast table or a stall. Times are working-time estimates; piece counts are in §5.

### 2.1 K–1 (pattern blocks; the adult reads and scribes)

Outlines are printed at true 1-inch scale. Recording: the child colours a printed copy of the outline subdivided into unit triangles, one colour per piece; the adult writes counts.

**K1 (core, 5 min). Trading.** Outlines of single pieces. Cover a blue with greens (2), a red (3), a purple with greens (4) or blues (2), a yellow with greens (6), blues (3), reds (2). *Why:* sizes as numbers; every later count is "how many greens".

**K2 (core, 8 min). The yellow-hexagon outline, one colour at a time.** Greens only: 6, one way. Blues only: 3 blues, **exactly two ways** — the second is the first turned by 60°; side by side they look like a cube seen from two directions. Reds only: 2 reds, **three ways** (one per long diagonal). *Why:* existence and counting on a region small enough to exhaust; the two blue fillings are the first spin (Q5).

**K3 (core, 10 min). The yellow-hexagon outline, any pieces.** How many *different sets of pieces* fill it? **8** without the chevron: Y; RR; RBG; RGGG; BBB; BBGG; BGGGG; GGGGGG. With the chevron **10** (add PB, PGG) [B2]. Record on a sheet of twelve small subdivided hexagons. *Why:* completeness, with a case argument on the biggest piece (§4).

**K4 (core, 6 min). Side-2 triangle (4 triangles).** Greens: 4. Blues only: **impossible** although 4 is even. Red + green: 3 ways [B4]. *Why:* first impossibility; up/down (3 up, 1 down) is the K–1 checkerboard.

**K5 (core, 8 min). Side-3 triangle (9 triangles).** Greens: 9. Blues only: impossible (9 is odd; also 6 up, 3 down). Reds only: **yes, 3 reds in a pinwheel**, exactly 2 ways (pinwheel and its mirror) [B4]. Yellow in the middle + 3 greens at the corners: 1 way. *Why:* parity as an argument; a "no" for one piece next to a "yes" for another; the pinwheel is a real find.

**K6 (core, 8 min). Side-4 triangle (16 triangles).** Blues only: **impossible although 16 is even** (10 up, 6 down: at most 6 blues, 4 up-triangles always left). Reds only: impossible (16 is not a multiple of 3). Fill it **using no green**: only 4 reds + 1 purple (6 tilings) or 4 reds + 2 blues (39 tilings) [B4]; with greens there are 38,337 fillings, so "fill it somehow" is easy and "no greens" is the puzzle. *Why:* the invariant beats parity; a necessity argument (at least 4 reds, §4).

**K7 (reserve, 10 min). Side-2 hexagon (24 triangles).** Blues only: 12 blues, many ways (20 in all). Sort the blues in the child's filling by how they lie — *standing* (no flat edge), *leaning left*, *leaning right*: **always 4, 4, 4** [B6]. Reds only: 8 reds, possible (9 ways). Yellows only: impossible — at most 3 fit; 3 yellows + 3 blues, or 3 yellows + 6 greens, each works in 2 ways. *Why:* an invariant that is not a cell count; a share item.

**K8 (reserve, 8 min). Paper dominoes on 1-inch grids.** 2×3: 3 ways. 3×3: impossible (9 squares, 4 dominoes cover 8). 3×3 with one square cut out: corner yes, middle-of-a-side no, centre yes [A2]. *Why:* the same two-kinds-of-cells idea in the square world, for the share.

**K9 (reserve, 6 min). All shapes from four greens** (edge to edge): exactly **3** — big triangle, straight strip (two blues in a row), chevron [C1]. From two greens: 1 (the blue); from three: 1 (the red). *Why:* listing all cases and knowing you are done.

**K10 (reserve, 5 min). Hexagon with one triangle bitten off (5 triangles).** Blues only: no (odd). Reds only: no. Six sets work: PG, RB, RGG, BBG, BGGG, GGGGG [B3].

### 2.2 Grades 2–3 (paper dominoes and L-trominoes on 1-inch grids)

**M1 (core, 10 min). Counting domino tilings of 2×n.** Boards 2×1 … 2×5, each printed ten times for recording. **1, 2, 3, 5, 8** [A1, D1]; reserve 2×6 = 13. Finding: each is the sum of the previous two. Argument: the left end is one standing domino (rest: 2×(n−1)) or two lying dominoes (rest: 2×(n−2)), nothing else. *Why:* counting with a complete-list argument; the recursion is the theorem.

**M2 (core, 8 min). 3×3.** Full: impossible (odd). One square cut out, nine boards: **the 4 corners and the centre work; the 4 middle-of-side squares do not** [A2]. Finding: the good holes form the checkerboard pattern. Argument: 5 dark, 4 light; a domino takes one of each; a middle-of-side hole is light. *Why:* first impossibility that is not parity (8 squares, 4 dominoes, still no).

**M3 (core, 10 min). 4×4 with two holes.** Printed boards: A (1,1)&(4,4) no; B (1,1)&(1,4) yes (12 tilings); C (1,1)&(1,2) yes (18); D (2,2)&(3,3) no; E (2,2)&(2,3) yes (6); F (1,1)&(4,2) no; G (1,2)&(3,4) no; H (1,1)&(3,4) yes (6) [A5]; then two holes of the child's choice. Finding: yes exactly when the holes have different colours. *No* by colouring; *yes, always* by the loop [D6]. *Why:* a complete answer — necessary and sufficient, all 120 pairs verified [A4].

**M4 (core, 6 min). L-trominoes on 2×3 and 3×3.** 2×3: yes, exactly 2 ways [D2]. 3×3: **impossible although 9 = 3+3+3**; an L never touches two corners, 4 corners, 3 pieces. *Why:* a divisibility test passes and the tiling still fails.

**M5 (core, 10 min). 4×4 with one hole, L-trominoes (5 pieces).** Holes (1,1), (1,2), (2,2), then any hole. **Every hole works, and for each hole the tiling is unique** [A6, D2]. Argument: one L in the middle touching the three quarters without the hole; each quarter is a 2×2 minus one square, which is one L. *Why:* a construction independent of the hole — the base of the older table's induction.

**M6 (reserve, 8 min). 5×5 with one hole, dominoes (12 pieces).** (1,1) yes, (1,2) no, (1,3) yes, (2,2) yes, (2,3) no, (3,3) yes: **dark holes work, light never** [A3]. (1,3) kills the guess "corners and centre only". Sufficiency: the snake path [D6]. *Why:* the same reason on a bigger board.

**M7 (reserve, 10 min). 5×5 with one hole, L-trominoes (8 pieces).** Hole types: (1,1) yes (8 tilings), (1,2) no, (1,3) yes (16), (2,2) no, (2,3) no, (3,3) yes (32) [A6]; the 9 good holes are the dots. *Why:* a which-holes question with a new pattern; argument in §4.

**M8 (reserve, 10 min). 3×4 with dominoes.** **11** ways [D1], organised by the domino on the top-left square (lying: 7; standing: 4). *Why:* a count that needs an organising principle.

**M9 (reserve, 5 min). Jamming.** Fewest dominoes so that no more fit: 2×3 → 2, 3×3 → 3, 4×4 → 6 [A10]. *Why:* optimality; "no more fit" is concrete to check.

### 2.3 Grades 4–5 (paper pieces; scale in §5)

**U1 (core, 8 min). Two holes, dominoes.** Boards A, B, D, H from M3 (two no, two yes); then 6×6 minus opposite corners (17 dominoes: three minutes of trying, then the argument); then 8×8 in words. Also: every dark-light pair on 6×6 works (324 pairs), no same-colour pair does (306) [A4]; loop pictures for 4×4 and 6×6 [D6].

**U2 (core, 12 min). L-tromino ladder: 2×2, 4×4, 8×8 minus one square.** 2×2 minus one = one L. 4×4 minus one: any hole, 5 pieces, unique tiling. 8×8 minus one: 21 pieces by the recipe — one L in the middle touching the three quarters without the hole; each quarter is a 4×4 with one hole; do the 4×4 recipe in each [D5]. Then 16×16? 32×32? *Why:* the induction, performed physically.

**U3 (core, 10 min). Which holes? 3×3, 5×5, 7×7 with L-trominoes.** 3×3 impossible (corners). 5×5 minus one: the six hole types of M7 — **works iff the hole is in an odd row and an odd column**. 7×7 minus one (16 pieces): **every hole works** [A6; D3 shows (1,2)]. *Why:* a genuine weight argument, and 7×7 shows the pattern does not simply continue.

**U4 (core or reserve, 10 min). Straight trominoes (1×3).** 3×3: yes, 2 ways. 4×4 minus one: **only the 4 corners** (4 tilings each). 5×5 minus one: **only the centre** (2 tilings, the pinwheel) [A8, D4]. Argument: two diagonal 3-colourings (§4). *Why:* same-size piece as the L, opposite answers; a second colouring.

**U5 (reserve, 10 min). Counting.** 2×n Fibonacci with the left-end argument; 3×4 = 11; the big table (4×4 = 36, 6×6 = 6,728, 8×8 = 12,988,816) [A1].

**U6 (reserve, 10 min). Side-2 hexagon with 12 blue rhombi.** Three different fillings; count standing / leaning-left / leaning-right: **always 4, 4, 4** (true of all 20) [B6]. Argument: chains (§4). Then: each filling is a picture of cubes in a 2×2×2 corner; a spin of three rhombi adds or removes a cube; empty-to-full is exactly 8 spins; 20 fillings [B7]. *Why:* an invariant that is not a cell count; reconfiguration.

**U7 (reserve, 8 min). Jamming.** 3×3 → 3, 4×4 → 6 (examples in T9) [A10]. "4 is impossible on 4×4" has a clean argument: 4 dominoes leave 8 uncovered squares, no two adjacent, so each row holds exactly 2 of them, in columns {1,3}, {1,4} or {2,4}; {1,4} clashes vertically with every pattern, so consecutive rows alternate {1,3} and {2,4} — a whole colour class. The 8 covered squares are then the other colour class, in which no two squares are adjacent, so no domino can lie there. "5 is impossible" rests on the exhaustive check.

**U8 (reserve, 8 min). 6×6 with straight tetrominoes (1×4).** Impossible although 36 = 9×4: colours (r+c) mod 4 occur 9, 10, 9, 8 times; a bar covers one of each [A9]. 6×6 with L-tetrominoes: impossible — colour the columns alternately; each L covers 3 of one colour and 1 of the other, so 9 pieces cover an odd number of dark squares, but there are 18 [A9]. *Why:* two more colourings for a table that has digested U3–U4.

**U9 (reserve, 6 min). Flips.** On a 3×4 domino tiling find a 2×2 with two parallel dominoes and rotate it; any tiling reaches any other (all 11 are connected; the farthest pair is 6 flips apart) [D8]. *Why:* Q5.

---

## 3. Verified data

From `verify-output.txt`; rows/columns 1-indexed.

**T1. Domino tilings of full rectangles [A1].**

| 2×n, n = 1…10 | 1, 2, 3, 5, 8, 13, 21, 34, 55, 89 |
|---|---|
| 3×n, n = 2, 4, 6, 8 | 3, 11, 41, 153 (odd n: 0) |
| 4×n, n = 1…7 | 1, 5, 11, 36, 95, 281, 781 |
| 5×6, 6×6, 6×8, 8×8 | 1,183; 6,728; 167,089; 12,988,816 |

**T2. 3×3 minus one square, dominoes: tilings by hole [A2]** (dark = corners and centre).
```
4 0 4
0 2 0
4 0 4
```
**T3. 5×5 minus one square, dominoes [A3]:** every dark hole works, every light hole fails.
```
192   0 192   0 192
  0 112   0 112   0
192   0 196   0 192
  0 112   0 112   0
192   0 192   0 192
```
7×7: same pattern (25 dark holes work, 24 light fail; counts 60,032–103,984).

**T4. Two holes, dominoes [A4, A5].** 4×4, all 120 pairs: 64 different-colour pairs all tileable, 56 same-colour pairs none. 6×6: 324 all tileable, 306 none. 8×8: opposite corners no, (1,1)&(1,8) yes, 60 random pairs follow the colour rule. Printed pairs: B 12, C 18, E 6, H 6 tilings; A, D, F, G none.

**T5. L-trominoes, n×n minus one square [A6].**

| n | squares | pieces | holes that work | tilings per hole |
|---|---|---|---|---|
| 2 | 3 | 1 | all 4 | 1 |
| 3 | 8 | — | none (not a multiple of 3) | 0 |
| 4 | 15 | 5 | all 16 | exactly 1 each |
| 5 | 24 | 8 | the 9 dots: rows 1,3,5 × columns 1,3,5 | corner 8, side-middle 16, centre 32; others 0 |
| 6 | 35 | — | none | 0 |
| 7 | 48 | 16 | all 49 | existence checked |
| 8 | 63 | 21 | all 64 | existence checked |

Full rectangles [A7]: 2×3 → 2; 3×3, 3×5, 3×7 → 0; 3×4 → 4; 3×6 → 8; 4×6 → 18; 5×6 → 72; 6×6 → 162; 6×9, 9×9 tileable.

**T6. Straight trominoes, n×n minus one square [A8].** 4×4: only the 4 corners (4 tilings each). 5×5: only the centre (2 tilings). 7×7: only the 9 squares with row and column in {1,4,7}. 8×8: only (3,3), (3,6), (6,3), (6,6). Full 3×3: 2 tilings. Diagonal colour counts (r+c mod 3): 4×4 → 6,5,5; 5×5 → 8,9,8; 8×8 → 21,22,21.

**T7. Explicit tilings to draw** (letters = pieces, # = hole) [D1–D5]. The unique L-tiling of 4×4 minus (1,1), and minus (2,2):
```
# a b b      a a b b
a a c b      a # c b
d c c e      d c c e
d d e e      d d e e
```
5×5 minus corner / minus (1,3) / minus centre, one L-tiling each:
```
# a a b b    a a # b b    a a b b c
c a d d b    a c c b d    a d b c c
c c d e e    e e c d d    d d # e e
f f g e h    e f g g h    f f g e h
f g g h h    f f g h h    f g g h h
```
5×5 minus centre, straight trominoes (the other tiling is its mirror):
```
a a a b c
d d d b c
e f # b c
e f g g g
e f h h h
```
8×8 minus (1,1) by the induction (piece 1 is the centre L; numbering then follows the recursion quarter by quarter — top-left 2–6, top-right 7–11, bottom-left 12–16, bottom-right 17–21 — so 2, 7, 12, 17 are the quarters' centre L's):
```
 #  3  4  4  8  8  9  9
 3  3  2  4  8  7  7  9
 5  2  2  6 10 10  7 11
 5  5  6  6  1 10 11 11
13 13 14  1  1 18 19 19
13 12 14 14 18 18 17 19
15 12 12 16 20 17 17 21
15 15 16 16 20 20 21 21
```
The 5 tilings of 2×4, 8 of 2×5 and 11 of 3×4 are drawn in [D1]; both L-tilings of 2×3 and all four of 3×4 in [D2].

**T8. Loops and snake [D6].** Squares numbered along a closed loop (the last is next to square 1); for every pair of different-colour holes both arcs are even (checked for all pairs on 4×4 and 6×6):
```
 1  2  3  4        1  2  3  4  5  6
16  7  6  5       36 11 10  9  8  7
15  8  9 10       35 12 13 14 15 16
14 13 12 11       34 21 20 19 18 17
                  33 22 23 24 25 26
                  32 31 30 29 28 27
```
5×5 snake (rows alternate direction, 1…25): dark squares are exactly the odd positions, so removing a dark square leaves two even runs.

**T9. Jamming [A10].** 2×2: 2; 2×3: 2; 2×4: 3; 2×5: 4; 2×6: 4; 3×3: 3; 3×4: 4; 4×4: 6. Example 3×3: (1,1)–(1,2), (2,2)–(2,3), (3,1)–(3,2). Example 4×4: (1,1)–(1,2), (1,3)–(1,4), (2,1)–(3,1), (2,2)–(2,3), (3,3)–(3,4), (4,2)–(4,3).

**T10. Pattern blocks [B1–B7, C1].**
- Up/down: a triangle of side n has n(n+1)/2 up and n(n−1)/2 down: (1,0), (3,1), (6,3), (10,6), (15,10), (21,15) for n = 1…6. Hexagon of side n: 3n² each.
- Yellow-hexagon outline: 40 fillings, **8 sets**: Y 1, RR 3, RBG 12, RGGG 6, BBB 2, BBGG 9, BGGGG 6, GGGGGG 1. With the chevron: 52 fillings, 10 sets (PB 6, PGG 6).
- Hexagon minus one triangle (2 up, 3 down): 15 fillings, 6 sets: PG 2, RB 2, RGG 3, BBG 3, BGGG 4, GGGGG 1.
- Side-2 triangle: 7 fillings, 3 sets: RG 3, BGG 3, GGGG 1; blues only 0.
- Side-3 triangle: 226 fillings, 14 sets; RRR 2; YGGG 1; blues only 0.
- Side-4 triangle: blues only 0; reds only 0; no greens: RRRRP 6, BBRRRR 39, nothing else; all pieces 38,337. Side 5: neither blues nor reds alone. Side 6: reds only 220 fillings; blues 0.
- Side-2 hexagon: blues only **20**, each with 4 standing, 4 leaning-left, 4 leaning-right. Reds only 9. Yellows only 0. YYY+BBB 2; YY+6B 15; Y+9B 32; YYY+6G 2; Y+6R 3; blues and reds together 7,320. Hexagons of side 1, 2, 3 by blues: 2, 20, 980 (MacMahon).
- Strip and chevron: 1 rhombus tiling each. Plane partitions in a 2×2×2 box: 20; maximum 8 cubes.
- Shapes from n greens: 1, 1, 1, 3, 4, 12 for n = 1…6.

**T11. Flip graphs [D8].** Domino tilings joined by 2×2 flips: 2×4 (5 tilings) connected, diameter 3; 2×5 (8) connected, diameter 4; 3×4 (11) connected, diameter 6; 4×4 (36) connected, diameter 10. Rhombus tilings of the side-2 hexagon joined by spins of three rhombi around a point: all 20 connected, diameter 8, and exactly two tilings (the empty box and the full box) are 8 apart.

---

## 4. Arguments children can give

Forms: (i) show the tiling (yes); (ii) a list of all cases organised so it is visibly complete; (iii) a colouring or marking on the picture plus a count; (iv) a counterexample to a guessed rule; (v) the same reason again on a bigger one. Never let "we tried and couldn't" stand as the reason for a *no*.

### K–1
- **Parity (K5).** "Each blue is two greens. Fill it with greens and pair them up. Is one left alone? Nine greens — one left over. So blues can't." Child's line: "Nine is one too many for pairs."
- **Up and down (K4, K6).** "Some little triangles point up like mountains, some point down. Colour the mountains green and the others orange. Put a blue anywhere: what is under it? One mountain, one orange. Always? So every blue eats one of each. Mountains: 3. Orange: 1. After one blue, two mountains are left and a blue can't sit on two mountains." Side 4: "10 mountains, 6 orange; after 6 blues, 4 mountains are left over."
- **Biggest piece (K3).** "What's the biggest piece in your filling? Yellow — one way. A red — the other half is a red, or a blue and a green, or three greens: three ways. A blue but no red — the rest is two blues, or a blue and two greens, or four greens: three ways. Only greens — one way. 1 + 3 + 3 + 1 = 8." (Purple: "a blue, or two greens — two more.")
- **At least four reds (K6).** "Which piece makes more mountains than orange? Only the red (2 and 1). We need 4 extra mountains, so at least 4 reds — 12 triangles; 4 are left: a purple or two blues."
- **Four greens (K9).** "Three greens make only one shape, the red. Add a fourth green to a red: five edges. Under the long side, either end — the chevron. On the short top — the big triangle. On a slanted side — the strip. Three shapes."

### Grades 2–3
- **The left end (M1).** "Look at the left end of the 2×5. A standing domino, or two lying ones on top of each other — could a lying domino be there alone? No, the square under it would be a hole. Standing: a 2×4 is left, 5 ways. Two lying: a 2×3 is left, 3 ways. 5 + 3 = 8, and nothing is counted twice because the left end tells you which kind you have."
- **Checkerboard (M2).** "Colour the board like a checkerboard. Put a domino anywhere: one dark, one light. Always? So 4 dominoes need 4 dark and 4 light. Count: 5 dark, 3 light. What goes wrong?" Child's line: "Dominoes take one of each, and there are more dark than light."
- **The loop (M3).** "Here is a path through every square that comes back to its start. Cross out the two holes: the loop is cut into two roads. Count the squares on each road — even and even? Walk each road two squares at a time and lay a domino on each pair." Then: "Along the loop the colours alternate; the holes are different colours, so on both sides between them there is an even number of squares."
- **Corners (M4).** "Put an L on a corner of the 3×3 in every way it can sit. Does it ever touch two corners? So each L takes at most one corner. Four corners, three L's: one corner is always left out."
- **The centre trick (M5).** "Fold the board into four 2×2 quarters. Which quarter has the hole? Put one L in the very middle touching the other three quarters, one square each. Now every quarter is a 2×2 with one square gone — one L each. You never needed to know where the hole was."
- **Same reason again (M6).** "On 5×5: 13 dark, 12 light. Which colour must the hole be? So (1,3) is fine and (1,2) is not, though both are on the edge."

### Grades 4–5
- **Induction (U2).** "Would the centre trick work on 8×8? Four 4×4 quarters, one L in the middle, and each quarter is a 4×4 with one hole — which always works. On 16×16? The same sentence with 8×8 quarters." Child's line: "It works for 8 because it works for 4, and for 16 because it works for 8."
- **Dots (U3).** "Mark every square in an odd row and an odd column: 9 marks. Slide a 2×2 window anywhere: how many marks inside? Always one — of two neighbouring rows one is odd, same for columns. Every L fits in some 2×2 window, so an L covers at most one mark. Eight L's, at most 8 marks; if the hole is not a mark, 9 marks need covering." 3×3: "the marks are the corners; three L's."
- **Three colours (U4).** "Colour the diagonals 1, 2, 3, 1, 2, 3 … starting at a corner. A straight tromino, either way, covers one of each. On 4×4: 6 ones, 5 twos, 5 threes. Five pieces cover 5 of each, so the hole is a 1. Colour the diagonals the other way, starting at another corner: the hole is a 1 there too. Which squares are 1 both times? The four corners." 5×5: "8, 9, 8 — the hole must be a 2 both times: only the centre."
- **Chains (U6).** "Hexagon flat side down. A standing rhombus has no flat edge; a leaning one has a flat bottom and a flat top, one row apart. Start on one of the 2 unit edges along the bottom: the piece on it must be leaning. Its flat top is a new floor; the piece on that is leaning too. After 4 rows you reach the top. So each bottom edge starts a chain of 4 leaning rhombi; chains can't share a piece (a piece has one flat bottom), and every leaning rhombus is in a chain (follow its floor down). 2 × 4 = 8 leaning, 12 − 8 = 4 standing. Turn the picture a third of a turn and the same sentence counts the others."
- **Cubes (U6).** "Shade the standing rhombi as tops of cubes and the others as the two visible sides: every filling is a pile of cubes in a 2×2×2 corner. Count the cubes. A spin of three rhombi around a point adds or removes one cube; empty to full is exactly 8 spins."

---

## 5. Pitfalls

**Rules.**
- Pieces lie on the grid lines and cover whole squares: no diagonal placements, nothing over the edge, nothing on the hole. Say "no gaps, no overlaps, nothing sticking out, never on the black square" at the launch and print it in the first problem of every page.
- The L may be turned **and** flipped (4 positions); the straight tromino has 2. Children who use one orientation conclude "impossible".
- A 2×2 minus one square is filled by **one** L; some children object that one piece is not a tiling. Say "we use one piece".
- Counting problems must define "different": "two fillings are different if some piece is in a different place on the paper." A turned or mirrored filling counts separately; that is what 1, 2, 3, 5, 8, 11, 20 and "two ways with three blues" count. If a child says "that's the same one, just turned", the answer is: on this fixed outline it is a different filling.
- "Sets of pieces" (K3) is a different count from "fillings": 8 sets, 40 fillings. Keep K–1 on sets.
- Pattern blocks must meet corner to corner; a trapezoid slid half a unit leaves a sliver no piece can fill, visible as a piece poking out of the outline.

**Ambiguities and common errors.**
- Parity is not the only obstruction: 3×3 minus a side-middle square (8 squares), 4×4 minus opposite corners (14) and the side-4 triangle (16) are even and impossible. Sequence them *after* the parity cases so the surprise lands.
- From 3×3 children guess "corner holes work"; on 5×5 give (1,3) (works) and (1,2) (fails).
- The dot pattern (odd row and odd column, 9 squares) is **not** the checkerboard (13 dark squares); a child who has just learned the checkerboard will reuse it. Hand out the dotted 5×5 only after the empirical step.
- A failed attempt is not a proof; the guide must carry the argument for every "no" (the 3×3 with L's is the one children most often "almost" do).
- For straight trominoes both diagonal colourings are needed; one only shows the hole is among 6 squares on the 4×4.
- The 7×7 result (every hole works) contradicts the natural conjecture from 5×5; state it from T5, do not ask the table to verify it.
- Have the yes-tilings of M3/U1 at hand (T4 counts, T8 loop); improvising 4×4 minus (1,1)&(3,4) takes an adult a minute.

**Physical and logistical.**
- Scale: the template's text width is 7.2 in. Boards up to 7×7 fit at 1-inch squares; an **8×8 at 1 inch does not fit** on Letter. Print the 8×8 (U2) at 0.8-inch squares (6.4 in) with its 21 L's cut from a 0.8-inch grid; pieces must come from the same grid as the board they are used on. Simplest: grades 2–3 everything at 1 inch, grades 4–5 everything at 0.8 inch.
- Pattern-block outlines must print at actual size (printer dialogs default to "fit to page"). Side-2 hexagon: 4.0 in corner to corner, 3.46 in flat to flat. Side-4 triangle: 4 in wide, 3.46 in tall. Twelve subdivided unit hexagons (2.0 × 1.73 in) fit in a 3×4 array.
- Pre-cut pieces (cutting 21 L's takes a child ten minutes; spares can be cut in the free-handling minutes). Grades 2–3: 14 dominoes, 10 L's. Grades 4–5 (0.8 in): 20 dominoes, 24 L's, 10 straight trominoes; for U8, 9 straight and 9 L-tetrominoes. K–1 blocks: at least 24 greens, 12 blues, 8 reds, 3 yellows, 2 purples; U6 needs 12 blues.
- Holes: print solid black; for K–1 cut them out. Children cover an X.
- Recording: drawing 8 L's on a 5×5 takes a third grader 3–4 minutes. Print several copies of each board; children outline pieces in bold or colour each piece; yes/no results go in a printed grid of small boards to tick.
- Two copies of each square board: blank for the discovery step, light-grey checkerboard (or dots, or diagonal numbers) for the argument step. Hand-colouring a 5×5 checkerboard takes two minutes and goes wrong.
- "Standing / leaning left / leaning right" only makes sense with the hexagon flat side down; print the words on the page.
- The chevron counts assume the V-shaped four-triangle piece (hexagon minus a rhombus). If the set's chevron is another shape, drop P; nothing else depends on it.
- The 8×8 with 21 pieces takes ten minutes even with the recipe; put it in the last quarter of the hour or do it as a group at the share.

---

## 6. Where it leads (for the two mathematicians)

- **Matchings and height functions.** A domino tiling is a perfect matching of the region's grid graph; the colouring argument is the easy half of Hall's condition, and Hall's theorem is the complete criterion. Thurston, "Conway's tiling groups" (Amer. Math. Monthly 97, 1990): height functions, linear-time decision for simply connected regions, flip-connectivity for dominoes and lozenges. Gomory's loop argument is in Honsberger, *Mathematical Gems I* (1973). Surveys: Pak, "Tile invariants: new horizons" (Theoret. Comput. Sci. 303, 2003); Ardila–Stanley, "Tilings" (Math. Intelligencer 32, 2010).
- **Invariants beyond colourings.** Conway–Lagarias, "Tiling with polyominoes and combinatorial group theory" (J. Combin. Theory A 53, 1990): the triangular array T_N of hexagonal cells is tileable by tribones iff N ≡ 0, 2, 9, 11 (mod 12), by a boundary-word invariant no colouring gives. Pak, "Ribbon tile invariants" (Trans. AMS 352, 2000).
- **Hardness.** NP-complete for L-trominoes (Moore–Robson, Discrete Comput. Geom. 26, 2001) and bars (Beauquier–Nivat–Rémila–Robson, Comput. Geom. 5, 1995); undecidable for Wang tiles on the plane (Berger 1966), whence aperiodic tilings and the 2023 aperiodic monotile of Smith–Myers–Kaplan–Goodman-Strauss.
- **Deficient boards.** Golomb, "Checker boards and polyominoes" (Amer. Math. Monthly 61, 1954): the 2ⁿ×2ⁿ induction and the straight-tromino four squares. Chu–Johnsonbaugh, "Tiling deficient boards with trominoes" (Math. Mag. 59, 1986): every deficient n×n with 3 ∤ n is L-tileable except n = 5, where exactly the (odd, odd) holes work; their rectangle theorem: m×n (m, n ≥ 2) is L-tileable iff 3 | mn and it is not 3×odd. Ash–Golomb, "Tiling deficient rectangles with trominoes" (Math. Mag. 77, 2004). Walkup (Amer. Math. Monthly 72, 1965): T-tetrominoes tile m×n iff 4 | m and 4 | n — so 4×4 yes and 6×6 no, with no simple colouring proof.
- **Counting.** Kasteleyn; Temperley–Fisher (1961): the m×n rectangle has ∏_{j≤m}∏_{k≤n} (4cos²(πj/(m+1)) + 4cos²(πk/(n+1)))^{1/4} domino tilings; the 3×n numbers 3, 11, 41, 153 satisfy a_n = 4a_{n−2} − a_{n−4} (transfer matrix). MacMahon's box formula ∏(i+j+k−1)/(i+j+k−2) gives 2, 20, 980 lozenge tilings of hexagons of side 1, 2, 3; the tilings are plane partitions and the flip graph is a distributive lattice. Elkies–Kuperberg–Larsen–Propp (1992) for the Aztec diamond; Jockusch–Propp–Shor for the arctic circle; Cohn–Kenyon–Propp (2001) for limit shapes; Kenyon's dimer lecture notes.
- **Jamming.** Minimum maximal matching (edge domination) is NP-hard even for planar bipartite graphs of maximum degree 3 (Yannakakis–Gavril, SIAM J. Appl. Math. 38, 1980); the grid values in T9 are computed, not from a formula.
- **Polyiamonds.** 1, 1, 1, 3, 4, 12, 24, 66, … (OEIS A000577), no closed form; Golomb, *Polyominoes* (1994). The up/down argument is the lozenge case of the height function.
