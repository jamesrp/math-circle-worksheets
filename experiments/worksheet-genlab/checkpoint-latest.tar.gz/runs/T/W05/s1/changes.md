# Changes made by the rewriter stage (Week 1 tilings packet)

The writer's version is preserved byte-for-byte in `before-rewrite/` (checked with `diff`). All four files recompile
with `pdflatex -interaction=nonstopmode` without errors; every page of all four PDFs was rendered and inspected
(K-1: 10 pages, 19 problems; grades 2-3: 15 pages, 26 problems; grades 4-5: 21 pages, 30 problems; guide: 33 pages).
The few new numbers added to the guide were recomputed by program before printing (fewest jamming dominoes on 2 by n
for n = 2..10 is 2, 2, 3, 4, 4, 5, 6, 6, 7 = ceiling of 2n/3; the 8 by 8 diagonal numberings have 21, 22, 21 squares
with the top-left square a 1 in the first and a 2 in the second, and (3,3), (3,6), (6,3), (6,6) are the squares that
are 2 in both; the two 2 by 3 jams placed side by side jam the 2 by 6 with 4 dominoes; the side-3 triangle has exactly
one interior corner point, so a yellow fits in one place only).

## Review items addressed (numbering as in review.md)

1. 4-5 Problem 22 now asks only why 4 dominoes cannot jam the 4 by 4 (uncovered squares no two side by side, where must
   they be, can a domino lie on the covered squares), with labels "with 4 dominoes:" and "covered squares:"; it also
   names the boards to build on (Problems 17 and 18). Guide: note that 5 is a computer fact with no short reason.
2. Guide Section 4 and K-1 Problem 5 now lead with 10 sets (52 fillings), 8 without the chevron.
3. Timing rewritten. K-1: core about 55 minutes, Problem 5 flagged as the long one with the "after six sets" rule.
   Grades 2-3: core = 1-4, 5-6, 7-9, 10 with boards A-D, 12 (about 45 min); reserve in the review's order; Problems 11
   and 13-18 marked "(reserve)", Problem 10 marked "A-D core, E-H reserve". Grades 4-5: core = 1, 2, 3, 4, 6, 7 (P and
   Q), 8, 11, 12 (about 40 min); reserve 13-14, 5, 9-10 and 15, 16, 17-21, 22-30; headings marked accordingly. The
   intro and Section 1 say the core is about the first 40 minutes and most tables will not reach the reserve; the
   stall/finish paragraphs and Section 9 use the new orders.
4. "If you cannot after three different starts, write N" added to 2-3 Problems 8, 19, 21 and 4-5 Problems 13, 18, 19.
5. Every board a piece is placed on is now at piece scale: 4-5 Problem 3 redrawn with four 0.8-inch checkerboards (two
   per row, labels and blanks under each) and Problem 4 moved to its own page; Problem 15 dot board at 0.8 inch;
   Problem 20's two numberings at 0.8 inch side by side with the blanks below, Problem 19 on its own page; Problem 29
   split into Problem 29 (straight tetromino numbering) and Problem 30 (shaded columns, L-tetrominoes), each with a
   0.8-inch 6 by 6 board on its own page; 2-3 Problem 22's dot board at 1 inch.
6. 4-5 Problem 19 rewritten as a full instruction and given its own 0.8-inch 5 by 5 board on the page (rather than
   sending the child back to Problem 13's board); Problem 22 names its boards; Problem 24 has a 0.8-inch 3 by 4 board
   beside its twelve small boards. 2-3 Problem 25 names the boards of Problems 14, 15, 17 and runs 2 by 3, 3 by 3,
   4 by 4; Problem 26 names the boards of Problems 3 and 4, gets a 1-inch 2 by 6 board, and includes the 2 by 2.
7. 2-3 Problem 26 ends with "put your best 2 by 3 and your best 2 by 6 side by side; what do you notice; predict
   2 by 9" with blanks for both. Guide: the "what to notice" paragraph (2 by 6 = 2 by 3 twice, 2 by 9 needs 6, values
   5, 6, 6, 7 for 2 by 7..10) and the ceiling-of-2n/3 remark in Section 10, stated as verified to n = 10 only.
8. K-1 Problem 2 says "the hexagon (the shape of a yellow piece)" and "the chevron (the shape of a purple piece)";
   Problem 12 says "the big triangle of Problem 11", "the first small triangle", "the second small triangle".
9. 2-3 Problem 23 and 4-5 Problem 14 ask the two questions in the text ("Eight L's cover at most how many dots? How
   many dots are on the board?").
10. 4-5 Problems 20 and 21 ask "How many 1s, how many 2s and how many 3s do five (eight) trominoes cover? So which
    number must the black square carry?" with "five/eight trominoes cover: 1s _ 2s _ 3s _" blanks for each numbering.
11. Cube reading fixed on 4-5 Problem 27 (shaded rhombi all at the bottom = empty box, all at the top = full box; the
    guide's note now says the page fixes the reading and that it matches the pictures); L-tetromino described as
    "three squares in a row and one more square beside an end square, making an L"; standing/lying defined at first
    use (2-3 Problem 6; 4-5 Problem 20 for trominoes, 23 for dominoes, 29 for tetrominoes); Problem 5 says "Do this
    three times; the second time choose two squares far apart"; Problem 26 prints four small hexagons (0.8 scale) and
    asks for four ways; 4-5 boards renamed A, B, C, D in Problems 1 and 3 and in the guide (which now says they are
    the 2-3 packet's A, B, D, H, and shows the tilings of B and D only; the 2-3 tilings are already in Section 6).
12. "Now the famous board" replaced by "Now the 8 by 8 board with two opposite corners removed". K-1 Problem 10 is now
    the "where can one yellow go, can two fit, how many greens" problem with a YES/NO and a count box (guide answer
    extended). 4-5 Problem 6 reduced to one 2 by 2 board with the black paper square moved through the four places
    (see the rejected-items note below for why it keeps its number).
13. 2-3 Problem 10 uses "after two different starts"; the guide says under 2-3 Problem 17 and 4-5 Problem 7 that each
    board has exactly one tiling, so trial is slow and the middle-L hint comes after three minutes.
14. Guide: launch materials list the 2 by 3 board; 1-inch cut sheet count is 6 (two for the K-1 table, three black
    squares); sheet (c) is "needed for Problem 28, print if in reach" (also on the sheet's caption); arguments for
    K-1 Problem 15 (3 ways) and 2-3 Problem 14 (2 ways) added; K-1 Problem 14 hints (red along an edge and go round;
    leave the middle empty) added; the 8 by 8 straight-tromino note states the numbering convention; "(row, column)
    from the top-left corner" stated at 2-3 Problem 19 and 4-5 Problem 13; both loop pictures say "this is the same
    loop as on the student page".
15. K-1 "shapes from 4/5 greens" boxes widened; K-1 Problem 8 box spacing; 2-3 Problem 9 blanks on their own lines;
    4-5 Problem 27 and 30 blanks laid out one per line; the dashed fragment in the guide's 4-5 Problem 7 picture R
    removed; the K-1 Problem 14 packing picture captioned "three yellows, six triangles left". The page-18 gap no
    longer exists after repagination; the last text page of the guide (Section 10) was tightened by three lines so
    that it does not spill one paragraph onto a page of its own.
16. K-1 Problem 1 outlines have no interior lines; "(a road may have no squares at all)" added to 2-3 Problems 13 and 20
    and 4-5 Problem 5; 2-3 Problem 7 says "the 3 by 3 board of Problem 8".

Other small changes while there: the nested blank columns next to large boards in the 4-5 packet (Problems 14, 15,
24) are bottom-aligned so they no longer hang below the board; the twenty cube pictures in the guide are drawn at
0.85 scale; the guide's intro gives the new 4-5 page and problem counts.

## Review points rejected or changed, with reasons

- Item 12 (fold 4-5 Problem 6 into Problem 7 "in your head"): kept as Problem 6 but cut to one 2 by 2 board with the
  black paper square moved through its four places (a one-minute physical check). Reasons: the student pages are for
  doing, and a claim to verify in the head is not an action; and keeping the number avoids renumbering Problems 7-30
  on the pages and in the guide's many cross-references (the review's own new timing line for this table uses the
  existing numbers).
- Item 5 (Problem 29 "becomes two pages"): done as a split into Problems 29 and 30 rather than one problem over two
  pages, so that every page starts with a problem statement; the guide's answer is split the same way.
- Item 6 (Problem 19 "use the 5 by 5 board from Problem 13"): the problem has its own 0.8-inch board on its page
  instead, which is what the rest of the packet does.
- Item 15 ("\clearpage before Problem 5" in the guide): not applied; after the other changes the page break falls
  elsewhere and no page has a blank lower third.
