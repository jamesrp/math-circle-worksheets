Round 1 of W09 is W04 (identical prompts on the same base); this stage's output is W04's rewriter-r1 output, branched from runs/T/W04/s1.
