#!/usr/bin/env python3
"""Independent re-check of every number and example tiling quoted in plan.md (Week 1, tilings).

Written from scratch (not importing the bank's scripts) so that it is a second opinion.
Square boards: cell (r, c) = row r from the top, column c from the left, both from 1.
Dark cells: r + c even (so (1,1) is dark).  Pieces: domino, L-tromino, straight tromino.
Triangular lattice: unit triangles (x, y, o) with o = 0 up, o = 1 down, lattice basis
e1 = (1, 0), e2 = (1/2, sqrt3/2).  Pieces: G (1), B (2), R (3), Y (6).
Run:  python3 verify_plan.py > verify_plan_output.txt
"""
import sys
from functools import lru_cache
from itertools import combinations, product
from collections import Counter
sys.setrecursionlimit(20000)

# ======================================================================
# Square boards
# ======================================================================
DOMINO = [(0, 0), (0, 1)]
L_TROM = [(0, 0), (1, 0), (1, 1)]
I_TROM = [(0, 0), (0, 1), (0, 2)]

def norm(cells):
    mr = min(r for r, c in cells); mc = min(c for r, c in cells)
    return tuple(sorted((r - mr, c - mc) for r, c in cells))

def orients(shape):
    out = set(); cur = list(shape)
    for _ in range(4):
        cur = [(c, -r) for r, c in cur]          # rotate 90 degrees
        out.add(norm(cur)); out.add(norm([(r, -c) for r, c in cur]))  # and its mirror
    return sorted(out)

def board(rows, cols, holes=()):
    return frozenset((r, c) for r in range(1, rows + 1) for c in range(1, cols + 1)) - frozenset(holes)

def placements(unc, cell, ors):
    """all placements of some orientation covering `cell` inside `unc`"""
    res = []
    for o in ors:
        for (ar, ac) in o:
            p = frozenset((r - ar + cell[0], c - ac + cell[1]) for r, c in o)
            if p <= unc: res.append(p)
    return res

def count(bd, shapes, cap=None):
    ors = []
    for s in shapes: ors += orients(s)
    ors = sorted(set(ors))
    @lru_cache(maxsize=None)
    def go(unc):
        if not unc: return 1
        cell = min(unc); tot = 0
        for p in placements(unc, cell, ors):
            tot += go(unc - p)
            if cap and tot >= cap: return tot
        return tot
    return go(bd)

def one(bd, shapes, exact=None, avoid=None):
    """one tiling as a list of placements; `exact` = dict shape-index -> required count"""
    ors = []
    for i, s in enumerate(shapes):
        for o in orients(s): ors.append((o, i))
    def go(unc, chosen, used):
        if not unc:
            if exact and any(used[i] != n for i, n in exact.items()): return None
            if avoid and frozenset(p for p, _ in chosen) == avoid: return None
            return list(chosen)
        cell = min(unc)
        for o, i in ors:
            if exact and used[i] >= exact.get(i, 10**9): continue
            for (ar, ac) in o:
                p = frozenset((r - ar + cell[0], c - ac + cell[1]) for r, c in o)
                if p <= unc:
                    chosen.append((p, i)); used[i] += 1
                    res = go(unc - p, chosen, used)
                    if res: return res
                    chosen.pop(); used[i] -= 1
        return None
    return go(bd, [], Counter())

def all_tilings(bd, shapes):
    ors = []
    for s in shapes: ors += orients(s)
    ors = sorted(set(ors)); out = []
    def go(unc, chosen):
        if not unc: out.append(frozenset(chosen)); return
        cell = min(unc)
        for p in placements(unc, cell, ors):
            chosen.append(p); go(unc - p, chosen); chosen.pop()
    go(bd, []); return out

def grid(rows, cols, bd, tiling, marks=None):
    """letters = pieces, . = crossed out, X = extra mark"""
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    pieces = [p if isinstance(p, frozenset) else p[0] for p in tiling]
    lab = {}
    for i, p in enumerate(sorted(sorted(p) for p in pieces)):
        for cell in p: lab[cell] = letters[i]
    lines = []
    for r in range(1, rows + 1):
        lines.append("".join(lab.get((r, c), "." if (r, c) not in bd else "?") for c in range(1, cols + 1)))
    return "\n".join(lines)

def show(title, rows, cols, bd, shapes, exact=None):
    t = one(bd, shapes, exact)
    print(f"# {title}")
    if t is None: print("  (no tiling)")
    else: print(grid(rows, cols, bd, [(p, i) for p, i in t]))
    print()
    return t

def dark(cell): return (cell[0] + cell[1]) % 2 == 0
def colours(bd):
    d = sum(1 for x in bd if dark(x)); return d, len(bd) - d

def sec(t): print("\n=== " + t + " ===")

# ---------- dominoes: full boards (K-1 P6, 2-3 P1) ----------
sec("Domino tilings of full boards")
for r, c in [(2, 2), (2, 3), (2, 4), (2, 5), (2, 6), (3, 3), (3, 4), (3, 5), (4, 4), (4, 5), (5, 5)]:
    n = count(board(r, c), [DOMINO])
    print(f"{r}x{c}: {r*c} squares, {n} domino tilings")

# maximal placements on 3x3: how many squares can stay uncovered when no domino fits any more?
def maximal_uncovered(r, c):
    cells = board(r, c); ors = orients(DOMINO)
    res = set()
    def go(unc, placed):
        anyp = False
        for cell in sorted(unc):
            for p in placements(unc, cell, ors):
                anyp = True
                if min(p) == cell: go(unc - p, placed + 1)
        if not anyp: res.add(len(unc))
    go(cells, 0); return sorted(res)
print("3x3: possible numbers of uncovered squares when no more domino fits:", maximal_uncovered(3, 3))

# ---------- 3x3 minus one (K-1 P7, 2-3 P2/P3) ----------
sec("3x3 minus one square, dominoes")
for r in range(1, 4):
    print("  ".join(f"({r},{c}):{count(board(3,3,[(r,c)]),[DOMINO])}" for c in range(1, 4)))
for hole in [(1, 1), (1, 2), (2, 2)]:
    bd = board(3, 3, [hole]); print(f"hole {hole}: dark/light left = {colours(bd)}")
show("3x3 minus corner (1,1), dominoes", 3, 3, board(3, 3, [(1, 1)]), [DOMINO])
show("3x3 minus centre (2,2), dominoes", 3, 3, board(3, 3, [(2, 2)]), [DOMINO])
print("all 4 covers with corner (1,1) out:")
for t in all_tilings(board(3, 3, [(1, 1)]), [DOMINO]): print(grid(3, 3, board(3, 3, [(1, 1)]), list(t))); print()
print("all 2 covers with the centre out:")
for t in all_tilings(board(3, 3, [(2, 2)]), [DOMINO]): print(grid(3, 3, board(3, 3, [(2, 2)]), list(t))); print()

# ---------- 4x4 minus two squares (K-1 P9, 2-3 P4, 4-5 P1 E/F) ----------
sec("4x4 minus two squares, dominoes")
for name, holes in [("opposite corners (1,1),(4,4)", [(1, 1), (4, 4)]),
                    ("top corners (1,1),(1,4)", [(1, 1), (1, 4)]),
                    ("corner and neighbour (1,1),(1,2)", [(1, 1), (1, 2)])]:
    bd = board(4, 4, holes)
    print(f"{name}: {count(bd, [DOMINO])} tilings; dark/light left {colours(bd)}")
show("4x4 minus top corners, dominoes", 4, 4, board(4, 4, [(1, 1), (1, 4)]), [DOMINO])
show("4x4 minus (1,1),(1,2), dominoes", 4, 4, board(4, 4, [(1, 1), (1, 2)]), [DOMINO])
cells = sorted(board(4, 4)); ok = bad = 0; same_ok = 0
for a, b in combinations(cells, 2):
    n = count(board(4, 4, [a, b]), [DOMINO], cap=1)
    if dark(a) != dark(b):
        ok += (n > 0); bad += (n == 0)
    else:
        same_ok += (n > 0)
print(f"4x4: different-colour pairs tileable {ok}, not {bad}; same-colour pairs tileable {same_ok}")

# ---------- 5x5 minus one (2-3 P5) ----------
sec("5x5 minus one square, dominoes: count per hole")
for r in range(1, 6):
    print("  ".join(f"{count(board(5,5,[(r,c)]),[DOMINO]):4d}" for c in range(1, 6)))
show("5x5 minus corner (1,1), dominoes", 5, 5, board(5, 5, [(1, 1)]), [DOMINO])
show("5x5 minus centre (3,3), dominoes", 5, 5, board(5, 5, [(3, 3)]), [DOMINO])
show("5x5 minus (2,2), dominoes", 5, 5, board(5, 5, [(2, 2)]), [DOMINO])
show("5x5 minus (1,3), dominoes", 5, 5, board(5, 5, [(1, 3)]), [DOMINO])

# ---------- corner pairs on 2x5, 3x4, 4x4, 4x5 (4-5 P1, P3) ----------
sec("Two corners crossed out (grades 4-5, Problems 1 and 3)")
cases = [("A 2x5 opposite (1,1),(2,5)", 2, 5, [(1, 1), (2, 5)]),
         ("B 2x5 top corners (1,1),(1,5)", 2, 5, [(1, 1), (1, 5)]),
         ("C 3x4 opposite (1,1),(3,4)", 3, 4, [(1, 1), (3, 4)]),
         ("D 3x4 left corners (1,1),(3,1)", 3, 4, [(1, 1), (3, 1)]),
         ("E 4x4 opposite (1,1),(4,4)", 4, 4, [(1, 1), (4, 4)]),
         ("F 4x4 top corners (1,1),(1,4)", 4, 4, [(1, 1), (1, 4)]),
         ("G 4x5 opposite (1,1),(4,5)", 4, 5, [(1, 1), (4, 5)]),
         ("H 4x5 top corners (1,1),(1,5)", 4, 5, [(1, 1), (1, 5)]),
         ("I 4x5 left corners (1,1),(4,1)", 4, 5, [(1, 1), (4, 1)])]
for name, r, c, holes in cases:
    bd = board(r, c, holes)
    print(f"{name}: dark/light {colours(bd)}; tilings {count(bd, [DOMINO])}")
for name, r, c, holes in cases:
    bd = board(r, c, holes)
    if count(bd, [DOMINO], cap=1): show(name, r, c, bd, [DOMINO])
print("all 5 covers of C (3x4 minus opposite corners):")
for t in all_tilings(board(3, 4, [(1, 1), (3, 4)]), [DOMINO]): print(grid(3, 4, board(3, 4, [(1, 1), (3, 4)]), list(t))); print()

# trapped squares on B and D: forced dominoes
def forced_chain(bd):
    """repeatedly place dominoes forced by a cell with exactly one free neighbour"""
    unc = set(bd); placed = []
    changed = True
    while changed:
        changed = False
        for cell in sorted(unc):
            nb = [n for n in [(cell[0]+1, cell[1]), (cell[0]-1, cell[1]), (cell[0], cell[1]+1), (cell[0], cell[1]-1)] if n in unc]
            if len(nb) == 0: return placed, cell
            if len(nb) == 1:
                placed.append((cell, nb[0])); unc -= {cell, nb[0]}; changed = True; break
    return placed, None
for name, r, c, holes in cases[1:2] + cases[3:4]:
    p, trapped = forced_chain(board(r, c, holes))
    print(f"{name}: forced dominoes {p}; trapped square {trapped}")

# ---------- 6x6, 8x8 minus opposite corners (4-5 P4) ----------
sec("6x6 and 8x8 minus opposite corners, dominoes")
for n in (6, 8):
    bd = board(n, n, [(1, 1), (n, n)])
    print(f"{n}x{n} minus (1,1),({n},{n}): dark/light {colours(bd)}; tilings {count(bd, [DOMINO])}")
print(f"6x6 minus top corners (1,1),(1,6): tilings {count(board(6,6,[(1,1),(1,6)]), [DOMINO])}")
print(f"6x6 full: {count(board(6,6), [DOMINO])} tilings; 8x8 full: {count(board(8,8), [DOMINO])} tilings")

# ---------- L-trominoes (2-3 P6-P8, 4-5 P5-P9) ----------
sec("L-trominoes")
print(f"2x3: {count(board(2,3), [L_TROM])} tilings; 3x3: {count(board(3,3), [L_TROM])} tilings")
print("both 2x3 covers:")
for t in all_tilings(board(2, 3), [L_TROM]): print(grid(2, 3, board(2, 3), list(t))); print()
print("2x2 blocks of the 3x3 each contain exactly one corner:",
      all(sum(1 for cell in [(r, c), (r+1, c), (r, c+1), (r+1, c+1)] if cell in {(1,1),(1,3),(3,1),(3,3)}) == 1
          for r in (1, 2) for c in (1, 2)))
print("4x4 minus one square: L-tilings per hole")
for r in range(1, 5):
    print("  ".join(f"{count(board(4,4,[(r,c)]),[L_TROM])}" for c in range(1, 5)))
for hole in [(1, 1), (1, 2), (2, 3), (3, 3)]:
    show(f"4x4 minus {hole}, L-trominoes (unique)", 4, 4, board(4, 4, [hole]), [L_TROM])
print("5x5 minus one square: L-tilings per hole")
for r in range(1, 6):
    print("  ".join(f"{count(board(5,5,[(r,c)]),[L_TROM]):3d}" for c in range(1, 6)))
for hole in [(3, 3), (1, 1), (1, 3), (5, 5)]:
    show(f"5x5 minus {hole}, L-trominoes", 5, 5, board(5, 5, [hole]), [L_TROM])
dots = {(r, c) for r in (1, 3, 5) for c in (1, 3, 5)}
print("every L placement on 5x5 covers at most one dotted square:",
      all(len(p & dots) <= 1 for o in orients(L_TROM) for r in range(1, 6) for c in range(1, 6)
          for p in [frozenset((r + a, c + b) for a, b in o)] if p <= board(5, 5)))
print("max L-trominoes that fit: ", end="")
def max_fit(r, c, shape):
    bd = board(r, c); ors = orients(shape); best = 0
    cells = sorted(bd)
    def go(unc, k, start):
        nonlocal best
        best = max(best, k)
        if k + len(unc) // len(shape) <= best: return
        for idx in range(start, len(cells)):
            cell = cells[idx]
            if cell not in unc: continue
            for p in placements(unc, cell, ors):
                if min(p) == cell: go(unc - p, k + 1, idx + 1)
    go(bd, 0, 0); return best
print(", ".join(f"{r}x{c}: {max_fit(r, c, L_TROM)}" for r, c in [(3, 3), (2, 4), (3, 4), (4, 4), (5, 5)]))

# centre trick / recursive construction
def deficient(n, hole, r0=1, c0=1):
    """L-tiling of the n x n board with rows r0.., cols c0.. minus `hole`, by the centre trick"""
    if n == 2:
        return [frozenset((r, c) for r in (r0, r0 + 1) for c in (c0, c0 + 1)) - {hole}]
    h = n // 2
    quads = [(r0, c0), (r0, c0 + h), (r0 + h, c0), (r0 + h, c0 + h)]
    centre = {(r0 + h - 1, c0 + h - 1), (r0 + h - 1, c0 + h), (r0 + h, c0 + h - 1), (r0 + h, c0 + h)}
    tiles = []; first = set()
    for (qr, qc) in quads:
        inq = qr <= hole[0] < qr + h and qc <= hole[1] < qc + h
        cc = [x for x in centre if qr <= x[0] < qr + h and qc <= x[1] < qc + h][0]
        if inq: sub = hole
        else: sub = cc; first.add(cc)
        tiles += deficient(h, sub, qr, qc)
    tiles.append(frozenset(first))
    return tiles
def check_tiling(bd, tiles, shape):
    ors = set(orients(shape))
    return (all(norm(t) in ors for t in tiles) and sum(len(t) for t in tiles) == len(bd)
            and frozenset().union(*tiles) == bd and sum(len(t) for t in tiles) == len(set().union(*tiles)))
print("centre trick on 4x4, all 16 holes: valid tiling and equal to the unique one:",
      all(check_tiling(board(4, 4, [h]), deficient(4, h), L_TROM)
          and set(deficient(4, h)) == set(all_tilings(board(4, 4, [h]), [L_TROM])[0]) for h in board(4, 4)))
print("centre trick on 8x8, all 64 holes: valid tiling with 21 pieces:",
      all(check_tiling(board(8, 8, [h]), deficient(8, h), L_TROM) and len(deficient(8, h)) == 21 for h in board(8, 8)))
print("# 8x8 minus (1,1) by the centre trick")
print(grid(8, 8, board(8, 8, [(1, 1)]), deficient(8, (1, 1)))); print()
print("# 8x8 minus (4,5) by the centre trick")
print(grid(8, 8, board(8, 8, [(4, 5)]), deficient(8, (4, 5)))); print()
print("7x7 minus one: every hole L-tileable?", all(count(board(7, 7, [h]), [L_TROM], cap=1) for h in board(7, 7)))
def count_maxorder(bd, shapes):
    ors = sorted(set(o for s in shapes for o in orients(s)))
    @lru_cache(maxsize=None)
    def go(unc):
        if not unc: return 1
        return sum(go(unc - p) for p in placements(unc, max(unc), ors))
    return go(bd)
print("8x8 minus corner (1,1): number of L-tilings:", count(board(8, 8, [(1, 1)]), [L_TROM]),
      "(re-counted with the opposite cell order:", count_maxorder(board(8, 8, [(1, 1)]), [L_TROM]), ")")

# ---------- straight trominoes (4-5 reserve) ----------
sec("Straight trominoes with one hole (reserve)")
print("4x4 minus one: tilings per hole")
for r in range(1, 5): print("  ".join(f"{count(board(4,4,[(r,c)]),[I_TROM])}" for c in range(1, 5)))
print("5x5 minus one: tilings per hole")
for r in range(1, 6): print("  ".join(f"{count(board(5,5,[(r,c)]),[I_TROM])}" for c in range(1, 6)))
for n in (4, 5):
    print(f"{n}x{n} colour counts (r+c) mod 3:", [sum(1 for r in range(1, n+1) for c in range(1, n+1) if (r + c) % 3 == k) for k in range(3)],
          " (r-c) mod 3:", [sum(1 for r in range(1, n+1) for c in range(1, n+1) if (r - c) % 3 == k) for k in range(3)])
show("4x4 minus (1,1), straight trominoes", 4, 4, board(4, 4, [(1, 1)]), [I_TROM])
show("5x5 minus centre, straight trominoes", 5, 5, board(5, 5, [(3, 3)]), [I_TROM])
print(f"3x3 straight: {count(board(3,3), [I_TROM])} tilings")

# ---------- Gomory loop (4-5 reserve) ----------
sec("Gomory loop on 4x4 (reserve)")
loop = [(1,1),(2,1),(3,1),(4,1),(4,2),(3,2),(2,2),(2,3),(3,3),(4,3),(4,4),(3,4),(2,4),(1,4),(1,3),(1,2)]
adj = lambda a, b: abs(a[0]-b[0]) + abs(a[1]-b[1]) == 1
print("comb loop visits all 16 cells once and closes up:", len(set(loop)) == 16 and all(adj(loop[i], loop[(i+1) % 16]) for i in range(16)))
print("loop:", loop)
ok = all(count(board(4, 4, [a, b]), [DOMINO], cap=1) for a, b in combinations(sorted(board(4, 4)), 2) if dark(a) != dark(b))
print("every dark+light pair on 4x4 is tileable:", ok)

# ---------- 2xn counts (2-3 reserve) ----------
sec("Domino tilings of 2xn (reserve)")
print([count(board(2, n), [DOMINO]) for n in range(1, 8)])

# ---------- blocking (reserve) ----------
sec("Fewest dominoes that block the board (reserve)")
def min_block(r, c):
    bd = board(r, c); ors = orients(DOMINO); best = [10**9, None]
    cells = sorted(bd)
    def go(unc, placed, start):
        if len(placed) >= best[0]: return
        anyp = False
        for cell in cells:
            if cell in unc and placements(unc, cell, ors): anyp = True; break
        if not anyp:
            best[0] = len(placed); best[1] = list(placed); return
        for idx in range(start, len(cells)):
            cell = cells[idx]
            if cell not in unc: continue
            for p in placements(unc, cell, ors):
                if min(p) == cell:
                    placed.append(p); go(unc - p, placed, idx); placed.pop()
    go(bd, [], 0); return best
for r, c in [(2, 3), (2, 4), (3, 3), (3, 4)]:
    n, pl = min_block(r, c)
    print(f"{r}x{c}: {n} dominoes, e.g."); print(grid(r, c, board(r, c), pl).replace("?", ".")); print()

# ---------- Cram (reserve) ----------
sec("Cram: players alternately place a domino; no move = lose (reserve)")
def cram(r, c):
    bd = board(r, c); ors = orients(DOMINO)
    @lru_cache(maxsize=None)
    def win(unc):
        for cell in sorted(unc):
            for p in placements(unc, cell, ors):
                if min(p) == cell and not win(unc - p): return True
        return False
    return win(bd)
for r, c in [(2, 3), (3, 3), (2, 4), (3, 4), (4, 4)]:
    print(f"{r}x{c}: first player wins? {cram(r, c)}")

def cram_moves(r, c):
    bd = board(r, c); ors = orients(DOMINO)
    @lru_cache(maxsize=None)
    def win(unc):
        return any(not win(unc - p) for cell in sorted(unc) for p in placements(unc, cell, ors) if min(p) == cell)
    moves = sorted({p for cell in bd for p in placements(bd, cell, ors)}, key=lambda p: sorted(p))
    return bd, win, moves
def rot180(p, r, c): return frozenset((r + 1 - a, c + 1 - b) for a, b in p)
for r, c in [(2, 4), (4, 4)]:
    bd, win, moves = cram_moves(r, c)
    ok = all(not (rot180(p, r, c) & p) and not win(bd - p - rot180(p, r, c)) for p in moves)
    print(f"{r}x{c}: half-turn copying is a winning reply to every first move: {ok}")
bd, win, moves = cram_moves(3, 4)
centre = frozenset({(2, 2), (2, 3)})
print("3x4: first move on the two central squares (2,2)-(2,3) wins:", not win(bd - centre),
      "; then half-turn copying wins:", all(not (rot180(p, 3, 4) & p) and not win(bd - centre - p - rot180(p, 3, 4))
                                            for p in moves if not (p & centre)))
print("3x4: all winning first moves:", [sorted(p) for p in moves if not win(bd - p)])
bd, win, moves = cram_moves(2, 3)
print("2x3: winning first moves:", [sorted(p) for p in moves if not win(bd - p)])
bd, win, moves = cram_moves(3, 3)
for first in [frozenset({(1, 1), (1, 2)}), frozenset({(1, 2), (2, 2)}), frozenset({(1, 1), (2, 1)}), frozenset({(2, 2), (2, 3)})]:
    replies = [sorted(p) for p in moves if not (p & first) and not win(bd - first - p)]
    print(f"3x3: after first move {sorted(first)}, winning replies: {replies}")

# ======================================================================
# Triangular lattice (pattern blocks)
# ======================================================================
sec("PATTERN BLOCKS")
def tverts(t):
    x, y, o = t
    return frozenset({(x, y), (x + 1, y), (x, y + 1)}) if o == 0 else frozenset({(x + 1, y), (x, y + 1), (x + 1, y + 1)})
def tri_of(vs):
    xs = [p[0] for p in vs]; ys = [p[1] for p in vs]
    x, y = min(xs), min(ys)
    if {(x, y), (x + 1, y), (x, y + 1)} == set(vs): return (x, y, 0)
    X, Y = max(xs), max(ys)
    if {(X, Y - 1), (X - 1, Y), (X, Y)} == set(vs): return (X - 1, Y - 1, 1)
    raise ValueError(vs)
def rot(p): return (-p[1], p[0] + p[1])
def ref(p): return (p[0] + p[1], -p[1])
def tf(shape, k, m):
    out = set()
    for t in shape:
        vs = list(tverts(t))
        if m: vs = [ref(p) for p in vs]
        for _ in range(k): vs = [rot(p) for p in vs]
        out.add(tri_of(vs))
    return frozenset(out)
def ttrans(shape, dx, dy): return frozenset((x + dx, y + dy, o) for x, y, o in shape)
def tnorm(shape):
    m = min(shape); return ttrans(shape, -m[0], -m[1])
def torients(shape):
    return sorted({tnorm(tf(shape, k, m)) for k in range(6) for m in (0, 1)})
RING = [(0, 0, 0), (-1, 0, 1), (-1, 0, 0), (-1, -1, 1), (0, -1, 0), (0, -1, 1)]
for i in range(6): assert len(tverts(RING[i]) & tverts(RING[(i + 1) % 6])) == 2
PG, PB, PR, PY = [frozenset(RING[:k]) for k in (1, 2, 3, 6)]
PNAME = {PG: 'G', PB: 'B', PR: 'R', PY: 'Y'}
def hexnorm(p): return max(abs(p[0]), abs(p[1]), abs(p[0] + p[1]))
def alltris(lo=-7, hi=7):
    for x in range(lo, hi):
        for y in range(lo, hi):
            yield (x, y, 0); yield (x, y, 1)
def region(pred): return frozenset(t for t in alltris() if all(pred(p) for p in tverts(t)))
HEX1 = region(lambda p: hexnorm(p) <= 1)
HEX2 = region(lambda p: hexnorm(p) <= 2)
TRI2 = region(lambda p: p[0] >= 0 and p[1] >= 0 and p[0] + p[1] <= 2)
TRI3 = region(lambda p: p[0] >= 0 and p[1] >= 0 and p[0] + p[1] <= 3)
up3 = region(lambda p: p[0] >= -1 and p[1] >= -1 and p[0] + p[1] <= 1)
STAR = up3 | frozenset(tri_of([(-x, -y) for x, y in tverts(t)]) for t in up3)
TWIN = HEX1 | ttrans(HEX1, 1, 1)
def updown(reg): return sum(1 for t in reg if t[2] == 0), sum(1 for t in reg if t[2] == 1)
for nm, reg in [("hexagon", HEX1), ("triangle side 2", TRI2), ("triangle side 3", TRI3), ("star", STAR), ("twin hexagons", TWIN), ("hexagon side 2", HEX2)]:
    print(f"{nm}: {len(reg)} units, up/down (white/grey) = {updown(reg)}")
print("adjacent unit triangles always point opposite ways:",
      all(a[2] != b[2] for a in HEX2 for b in HEX2 if a != b and len(tverts(a) & tverts(b)) == 2))

def tplacements(unc, t, ors):
    res = []
    for o in ors:
        for (ax, ay, ao) in o:
            if ao != t[2]: continue
            p = ttrans(o, t[0] - ax, t[1] - ay)
            if p <= unc: res.append(p)
    return res
def tcount(reg, pieces):
    ors = sorted({o for s in pieces for o in torients(s)})
    @lru_cache(maxsize=None)
    def go(unc):
        if not unc: return 1
        t = min(unc); return sum(go(unc - p) for p in tplacements(unc, t, ors))
    return go(reg)
def tall(reg, pieces):
    ors = [(o, PNAME[s]) for s in pieces for o in torients(s)]
    out = set()
    def go(unc, chosen):
        if not unc: out.add(frozenset(chosen)); return
        t = min(unc)
        for o, nm in ors:
            for (ax, ay, ao) in o:
                if ao != t[2]: continue
                p = ttrans(o, t[0] - ax, t[1] - ay)
                if p <= unc: chosen.append((p, nm)); go(unc - p, chosen); chosen.pop()
    go(reg, []); return out
def bymultiset(tilings):
    return Counter("".join(sorted(nm for _, nm in tl)) for tl in tilings)

sec("Hexagon (K-1 P1, P2)")
print("green only:", tcount(HEX1, [PG]), " blue only:", tcount(HEX1, [PB]), " red only:", tcount(HEX1, [PR]))
T = tall(HEX1, [PG, PB, PR])
ms = bymultiset(T)
print("all covers by G,B,R by piece set:", dict(ms), " total", len(T))
bycount = Counter()
for k, n in ms.items(): bycount[len(k)] += n
print("covers by number of pieces:", dict(sorted(bycount.items())))
print("piece sets with 5 pieces:", [k for k in ms if len(k) == 5], "; with 4:", [k for k in ms if len(k) == 4], "; with 3:", [k for k in ms if len(k) == 3])

sec("Triangle side 2 (K-1 P3)")
print("green only:", tcount(TRI2, [PG]), " blue only:", tcount(TRI2, [PB]))
print("one red + greens:", bymultiset(tall(TRI2, [PG, PR]))["GR"])
downs2 = [t for t in TRI2 if t[2] == 1]
print("down (grey) triangles in T2:", downs2, "-> every blue placement covers it:",
      all(any(t in p for t in downs2) for o in torients(PB) for t0 in TRI2 for p in tplacements(TRI2, t0, [o])))

sec("Triangle side 3 (K-1 P4)")
print("green only:", tcount(TRI3, [PG]), " red only:", tcount(TRI3, [PR]), " blue only:", tcount(TRI3, [PB]))
print("covers with a yellow, by piece set:", dict(bymultiset({tl for tl in tall(TRI3, [PG, PB, PR, PY]) if any(nm == 'Y' for _, nm in tl)})))
print("blues + exactly one green:", bymultiset(tall(TRI3, [PG, PB])).get("BBBBG", 0))
print("interior lattice points of T3 (possible yellow centres):",
      [(x, y) for x in range(0, 4) for y in range(0, 4) if x > 0 and y > 0 and x + y < 3])
reds = tall(TRI3, [PR]); print("the two red covers (as triangle lists):")
for tl in reds: print("   ", [sorted(p) for p, _ in tl])

sec("Star (K-1 P5)")
print("blue only:", tcount(STAR, [PB]), " red only:", tcount(STAR, [PR]), " green only:", tcount(STAR, [PG]))
points = [t for t in STAR if sum(1 for u in STAR if u != t and len(tverts(t) & tverts(u)) == 2) == 1]
print("star points (units with only one neighbour):", len(points))

sec("Twin hexagons and big hexagon (K-1 reserve)")
print("twin: yellow only", tcount(TWIN, [PY]), " red only", tcount(TWIN, [PR]), " blue only", tcount(TWIN, [PB]), " green only", tcount(TWIN, [PG]))
print("big hexagon: blue only", tcount(HEX2, [PB]), " red only", tcount(HEX2, [PR]), " yellow only", tcount(HEX2, [PY]))
yr = [tl for tl in tall(HEX2, [PR, PY]) if sum(1 for _, nm in tl if nm == 'Y') == 1]
print("big hexagon: one yellow + reds:", len(yr), "covers; yellow centred at origin in all:",
      all(any(nm == 'Y' and p == HEX1 for p, nm in tl) for tl in yr))

print("\nDONE verify_plan.py")
