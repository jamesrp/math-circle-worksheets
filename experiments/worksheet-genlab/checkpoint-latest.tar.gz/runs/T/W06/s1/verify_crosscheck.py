#!/usr/bin/env python3
"""Independent bitmask cross-check of a few strong claims in bank.md."""
def count(n, holes, shapes):
    full = (1 << (n * n)) - 1
    for h in holes: full &= ~(1 << h)
    # all placements as bitmasks
    pl = []
    for s in shapes:
        for r in range(n):
            for c in range(n):
                m = 0; ok = True
                for dr, dc in s:
                    rr, cc = r + dr, c + dc
                    if not (0 <= rr < n and 0 <= cc < n): ok = False; break
                    m |= 1 << (rr * n + cc)
                if ok: pl.append(m)
    pl = list(set(pl))
    by_low = {}
    for m in pl:
        low = (m & -m).bit_length() - 1
        by_low.setdefault(low, []).append(m)
    memo = {}
    def go(rem):
        if rem == 0: return 1
        if rem in memo: return memo[rem]
        low = (rem & -rem).bit_length() - 1
        t = 0
        for m in by_low.get(low, []):
            if m & rem == m: t += go(rem & ~m)
        memo[rem] = t; return t
    return go(full)

L = []
base = [(0,0),(1,0),(0,1)]
import itertools
def rots(s):
    out = set()
    cur = list(s)
    for _ in range(4):
        cur = [(c, -r) for r, c in cur]
        mr = min(r for r, c in cur); mc = min(c for r, c in cur)
        out.add(tuple(sorted((r - mr, c - mc) for r, c in cur)))
        mir = [(-r, c) for r, c in cur]
        mr = min(r for r, c in mir); mc = min(c for r, c in mir)
        out.add(tuple(sorted((r - mr, c - mc) for r, c in mir)))
    return [list(o) for o in out]
Ls = rots(base)
print("L orientations:", len(Ls))
print("4x4 minus each cell, L-tromino tilings:")
for r in range(4):
    print(" ", [count(4, [r * 4 + c], Ls) for c in range(4)])
print("5x5 minus each cell, L-tromino tilings:")
for r in range(5):
    print(" ", [count(5, [r * 5 + c], Ls) for c in range(5)])
print("3x3 by L-trominoes:", count(3, [], Ls))
D = rots([(0,0),(0,1)])
print("domino: 3x3 minus each cell:")
for r in range(3):
    print(" ", [count(3, [r * 3 + c], D) for c in range(3)])
print("domino 4x4 minus opposite corners:", count(4, [0, 15], D), " minus adjacent corners:", count(4, [0, 3], D), " full 4x4:", count(4, [], D))
print("domino 2x4 (as 4x4 rows 0-1 only):", count(4, list(range(8, 16)), D))
I = rots([(0,0),(0,1),(0,2)])
print("straight: 4x4 minus each cell:")
for r in range(4):
    print(" ", [count(4, [r * 4 + c], I) for c in range(4)])
