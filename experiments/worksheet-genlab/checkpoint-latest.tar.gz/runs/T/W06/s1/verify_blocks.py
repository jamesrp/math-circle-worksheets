#!/usr/bin/env python3
"""Verification for the pattern-block problems in bank.md (Week 1, tilings).

Unit triangles of the triangular lattice are (x, y, o): lattice points use the
basis e1 = (1, 0), e2 = (1/2, sqrt3/2).  Up-triangle U(x,y) has vertices
(x,y),(x+1,y),(x,y+1); down-triangle D(x,y) has vertices (x+1,y),(x,y+1),(x+1,y+1).
Pattern blocks:  G green triangle (1 unit), B blue rhombus (2), R red trapezoid (3),
Y yellow hexagon (6), C purple chevron (4 = two blue rhombi joined into a V:
four consecutive unit triangles around one lattice point).
Run:  python3 verify_blocks.py
"""
import sys
from functools import lru_cache
from itertools import combinations
from collections import Counter, deque
sys.setrecursionlimit(10000)

def U(x, y): return (x, y, 0)
def D(x, y): return (x, y, 1)

def verts(t):
    x, y, o = t
    return frozenset({(x, y), (x + 1, y), (x, y + 1)}) if o == 0 else frozenset({(x + 1, y), (x, y + 1), (x + 1, y + 1)})

def tri_from_verts(vs):
    mx = min(x for x, y in vs); my = min(y for x, y in vs)
    if {(mx, my), (mx + 1, my), (mx, my + 1)} == set(vs): return (mx, my, 0)
    Mx = max(x for x, y in vs); My = max(y for x, y in vs)
    x, y = Mx - 1, My - 1
    if {(x + 1, y), (x, y + 1), (x + 1, y + 1)} == set(vs): return (x, y, 1)
    return None

def rot60(p): x, y = p; return (-y, x + y)
def refl(p): x, y = p; return (x + y, -y)

def transform(shape, k, mirror):
    out = []
    for t in shape:
        vs = list(verts(t))
        if mirror: vs = [refl(p) for p in vs]
        for _ in range(k): vs = [rot60(p) for p in vs]
        nt = tri_from_verts(vs)
        assert nt is not None
        out.append(nt)
    return frozenset(out)

def translate(shape, dx, dy):
    return frozenset((x + dx, y + dy, o) for x, y, o in shape)

def normalize(shape):
    m = min(shape)
    return translate(shape, -m[0], -m[1])

def orientations(shape):
    out = set()
    for mirror in (False, True):
        for k in range(6):
            out.add(normalize(transform(shape, k, mirror)))
    return sorted(out)

# six unit triangles around the origin, in cyclic order
RING = [U(0, 0), D(-1, 0), U(-1, 0), D(-1, -1), U(0, -1), D(0, -1)]
G = frozenset(RING[:1]); B = frozenset(RING[:2]); R = frozenset(RING[:3]); C = frozenset(RING[:4]); Y = frozenset(RING)
NAME = {G: 'G', B: 'B', R: 'R', C: 'C', Y: 'Y'}
SIZE = {G: 1, B: 2, R: 3, C: 4, Y: 6}

# sanity: the ring really is a cycle of edge-adjacent triangles
for i in range(6):
    assert len(verts(RING[i]) & verts(RING[(i + 1) % 6])) == 2

# ---------- regions ----------
def hexnorm(p): x, y = p; return max(abs(x), abs(y), abs(x + y))

def all_tris(lo=-6, hi=6):
    for x in range(lo, hi):
        for y in range(lo, hi):
            yield (x, y, 0); yield (x, y, 1)

def hexagon(n):
    return frozenset(t for t in all_tris() if all(hexnorm(p) <= n for p in verts(t)))

def triangle(n):
    return frozenset(t for t in all_tris() if all(x >= 0 and y >= 0 and x + y <= n for x, y in verts(t)))

def big_rhombus(n):  # side-n rhombus with a 60-degree angle
    return frozenset(t for t in all_tris() if all(0 <= x <= n and 0 <= y <= n for x, y in verts(t)))

def big_trapezoid():  # long side 4, short side 2, height 2 rows
    return frozenset(t for t in all_tris() if all(x >= 0 and 0 <= y <= 2 and x + y <= 4 for x, y in verts(t)))

def star():
    up = frozenset(t for t in all_tris() if all(x >= -1 and y >= -1 and x + y <= 1 for x, y in verts(t)))
    down = frozenset(tri_from_verts([(-x, -y) for x, y in verts(t)]) for t in up)
    return up | down

def double_hex():
    return hexagon(1) | translate(hexagon(1), 1, 1)

def triple_hex_row():
    return hexagon(1) | translate(hexagon(1), 1, 1) | translate(hexagon(1), -1, -1)

def ups(region): return sum(1 for t in region if t[2] == 0)
def downs(region): return sum(1 for t in region if t[2] == 1)

REGIONS = {
    'hexagon (side 1)': hexagon(1),
    'triangle side 2': triangle(2),
    'triangle side 3': triangle(3),
    'triangle side 4': triangle(4),
    'rhombus side 2': big_rhombus(2),
    'trapezoid 4-2': big_trapezoid(),
    'star (hexagram)': star(),
    'double hexagon': double_hex(),
    'three hexagons in a row': triple_hex_row(),
    'hexagon side 2': hexagon(2),
}

# ---------- exact cover ----------
def placements_covering(region, t, orients):
    res = set()
    for o in orients:
        for (ax, ay, ao) in o:
            if ao != t[2]: continue
            p = translate(o, t[0] - ax, t[1] - ay)
            if p <= region: res.add(p)
    return res

def count_tilings(region, pieces, cap=None):
    orients = []
    for s in pieces: orients += orientations(s)
    orients = list(set(orients))
    @lru_cache(maxsize=None)
    def go(unc):
        if not unc: return 1
        t = min(unc); total = 0
        for p in placements_covering(unc, t, orients):
            total += go(unc - p)
            if cap is not None and total >= cap: return total
        return total
    return go(frozenset(region))

def all_tilings(region, pieces):
    """every tiling as a frozenset of (placement, piece-name)"""
    orients = []
    for s in pieces:
        for o in orientations(s): orients.append((o, NAME[s]))
    out = []
    def go(unc, chosen):
        if not unc: out.append(frozenset(chosen)); return
        t = min(unc)
        for o, nm in orients:
            for (ax, ay, ao) in o:
                if ao != t[2]: continue
                p = translate(o, t[0] - ax, t[1] - ay)
                if p <= unc:
                    chosen.append((p, nm)); go(unc - p, chosen); chosen.pop()
    go(frozenset(region), [])
    return list(set(out))

def symmetries(region):
    """lattice symmetries (linear part k, mirror, translation) mapping region onto itself"""
    syms = []
    m0 = min(region)
    for mirror in (False, True):
        for k in range(6):
            img = transform(region, k, mirror)
            m1 = min(img)
            if m1[2] != m0[2]: continue
            dx, dy = m0[0] - m1[0], m0[1] - m1[1]
            if translate(img, dx, dy) == region:
                syms.append((k, mirror, dx, dy))
    return syms

def orbits(tilings, region, use_mirror):
    syms = [s for s in symmetries(region) if use_mirror or not s[1]]
    canon = set()
    for tl in tilings:
        forms = []
        for k, mirror, dx, dy in syms:
            forms.append(tuple(sorted((tuple(sorted(translate(transform(p, k, mirror), dx, dy))), nm) for p, nm in tl)))
        canon.add(min(forms))
    return len(canon)

def multiset(tl):
    return "".join(sorted(nm for _, nm in tl))

def report_region(name, region, pieces_sets):
    print(f"\n--- {name}: {len(region)} unit triangles ({ups(region)} up, {downs(region)} down); "
          f"rotations {len([s for s in symmetries(region) if not s[1]])}, with mirrors {len(symmetries(region))}")
    for label, pieces in pieces_sets:
        n = count_tilings(region, pieces)
        print(f"  {label}: {n} tilings (positions distinct)")

def section(t): print("\n=== " + t + " ===")

section("Unit-triangle counts of every printed outline")
for name, reg in REGIONS.items():
    print(f"{name}: {len(reg)} units, {ups(reg)} up / {downs(reg)} down")

section("Hexagon (side 1): all covers by pattern blocks")
H = hexagon(1)
T = all_tilings(H, [G, B, R])
print("total covers with G,B,R (positions distinct, hexagon itself excluded):", len(T))
print("  up to rotation:", orbits(T, H, False), " up to rotation+mirror:", orbits(T, H, True))
by = Counter(multiset(t) for t in T)
for ms in sorted(by, key=lambda s: (len(s), s)):
    sub = [t for t in T if multiset(t) == ms]
    print(f"  pieces {ms} ({len(ms)} pieces): {by[ms]} covers; up to rotation {orbits(sub, H, False)}; up to rotation+mirror {orbits(sub, H, True)}")
print("covers using exactly k pieces:", {k: sum(v for ms, v in by.items() if len(ms) == k) for k in range(1, 7)})
print("with chevron C allowed too:", count_tilings(H, [G, B, R, C]), "covers; C+B:", count_tilings(H, [C, B]), " C+G:", count_tilings(H, [C, G]))

section("Triangle side 2 (4 units)")
Tr2 = triangle(2)
report_region("triangle side 2", Tr2, [("G only", [G]), ("B only", [B]), ("R only", [R]), ("R+G", [R, G]), ("B+G", [B, G]), ("any of G,B,R", [G, B, R])])
T = all_tilings(Tr2, [R, G]); print("  R+G covers:", len(T), "; up to rotation:", orbits(T, Tr2, False))

section("Triangle side 3 (9 units)")
Tr3 = triangle(3)
report_region("triangle side 3", Tr3, [("G only", [G]), ("B only", [B]), ("R only", [R]), ("B+G", [B, G]), ("R+B", [R, B]), ("R+G", [R, G]), ("any of G,B,R", [G, B, R]), ("with Y too", [G, B, R, Y])])
T = all_tilings(Tr3, [R]); print("  R-only covers:", len(T), "; up to rotation:", orbits(T, Tr3, False), "; up to rotation+mirror:", orbits(T, Tr3, True))
T = all_tilings(Tr3, [G, B, R])
by = Counter(multiset(t) for t in T)
print("  piece multisets that work (count of covers):")
for ms in sorted(by, key=lambda s: (len(s), s)):
    print(f"    {ms} ({len(ms)} pieces): {by[ms]}")
print("  number of pieces achievable:", sorted({len(ms) for ms in by}))
print("  B+G with exactly one G:", sum(v for ms, v in by.items() if ms.count('G') == 1 and set(ms) <= {'B', 'G'}))

section("Triangle side 4 (16 units)")
Tr4 = triangle(4)
report_region("triangle side 4", Tr4, [("B only", [B]), ("R only", [R]), ("R+G", [R, G]), ("B+G", [B, G]), ("Y+R", [Y, R]), ("Y+R+B", [Y, R, B]), ("Y+B+G", [Y, B, G])])
T = all_tilings(Tr4, [G, B, R, Y])
by = Counter(multiset(t) for t in T)
print("  fewest pieces:", min(len(ms) for ms in by), "e.g.", [ms for ms in by if len(ms) == min(len(m) for m in by)])
print("  number of pieces achievable:", sorted({len(ms) for ms in by}))

section("Rhombus side 2 (8 units)")
Rh = big_rhombus(2)
report_region("rhombus side 2", Rh, [("B only", [B]), ("R only", [R]), ("R+B", [R, B]), ("R+G", [R, G]), ("C only", [C]), ("C+B", [C, B])])
T = all_tilings(Rh, [B]); print("  B-only covers:", len(T), "; up to rotation:", orbits(T, Rh, False), "; up to rotation+mirror:", orbits(T, Rh, True))

section("Big trapezoid, long side 4, short side 2 (12 units)")
Tz = big_trapezoid()
report_region("trapezoid 4-2", Tz, [("B only", [B]), ("R only", [R]), ("Y+R", [Y, R]), ("Y+B", [Y, B]), ("R+B", [R, B]), ("R+B+G", [R, B, G]), ("C only", [C])])
T = all_tilings(Tz, [R]); print("  R-only covers:", len(T), "; up to mirror:", orbits(T, Tz, True))

section("Star / hexagram (12 units)")
S = star()
report_region("star", S, [("G only", [G]), ("B only", [B]), ("R only", [R]), ("Y+G", [Y, G]), ("R+G", [R, G]), ("R+B", [R, B]), ("R+B+G", [R, B, G]), ("C only", [C]), ("C+B", [C, B]), ("C+G", [C, G])])
T = all_tilings(S, [G, B, R, Y, C])
by = Counter(multiset(t) for t in T)
print("  fewest pieces (any blocks incl. chevron):", min(len(ms) for ms in by), [ms for ms in by if len(ms) == min(len(m) for m in by)])
T2 = all_tilings(S, [G, B, R, Y])
by2 = Counter(multiset(t) for t in T2)
print("  fewest pieces (G,B,R,Y only):", min(len(ms) for ms in by2), [ms for ms in by2 if len(ms) == min(len(m) for m in by2)])
print("  number of pieces achievable (G,B,R,Y):", sorted({len(ms) for ms in by2}))
print("  most red trapezoids in a cover:", max(ms.count('R') for ms in by2), "e.g.", [ms for ms in by2 if ms.count('R') == max(m.count('R') for m in by2)])

section("Double hexagon (12 units)")
DH = double_hex()
report_region("double hexagon", DH, [("Y only", [Y]), ("R only", [R]), ("B only", [B]), ("G only", [G]), ("C only", [C]), ("C+B", [C, B]), ("R+B", [R, B])])
T = all_tilings(DH, [B]); print("  B-only covers:", len(T), "; up to rotation:", orbits(T, DH, False), "; up to rotation+mirror:", orbits(T, DH, True))
T = all_tilings(DH, [R]); print("  R-only covers:", len(T), "; up to rotation:", orbits(T, DH, False))

section("Three hexagons in a row (18 units)")
TH = triple_hex_row()
report_region("three hexagons in a row", TH, [("Y only", [Y]), ("R only", [R]), ("B only", [B]), ("C only", [C])])

section("Hexagon side 2 (24 units)")
H2 = hexagon(2)
report_region("hexagon side 2", H2, [("Y only", [Y]), ("R only", [R]), ("B only", [B]), ("Y+R", [Y, R]), ("Y+B", [Y, B]), ("C only", [C]), ("C+B", [C, B])])
T = all_tilings(H2, [B]); print("  B-only covers:", len(T), "; up to rotation:", orbits(T, H2, False), "; up to rotation+mirror:", orbits(T, H2, True))
T = all_tilings(H2, [R]); print("  R-only covers:", len(T), "; up to rotation:", orbits(T, H2, False), "; up to rotation+mirror:", orbits(T, H2, True))
T = all_tilings(H2, [Y, R]); print("  Y+R covers:", len(T), [multiset(t) for t in T])
# fewest pieces overall, achievable piece counts, max yellows: memoised DP over uncovered sets
def dp_counts(region, pieces):
    """returns (min pieces, set of achievable piece counts, max number of yellow hexagons)"""
    orients = []
    for s in pieces:
        for o in orientations(s): orients.append((o, NAME[s]))
    orients = list(set(orients))
    @lru_cache(maxsize=None)
    def go(unc):
        if not unc: return (0, frozenset({0}), 0)
        t = min(unc); best = None; ach = set(); maxy = None
        for o, nm in orients:
            for (ax, ay, ao) in o:
                if ao != t[2]: continue
                p = translate(o, t[0] - ax, t[1] - ay)
                if p <= unc:
                    m, a, y = go(unc - p)
                    best = m + 1 if best is None else min(best, m + 1)
                    ach |= {k + 1 for k in a}
                    yy = y + (1 if nm == 'Y' else 0)
                    maxy = yy if maxy is None else max(maxy, yy)
        return (best, frozenset(ach), maxy)
    return go(frozenset(region))
mn, ach, maxy = dp_counts(H2, [G, B, R, Y])
print("  fewest pieces (G,B,R,Y):", mn, "; achievable numbers of pieces:", sorted(ach), "; max yellows:", maxy)
# which multisets give 6 pieces? enumerate covers with Y,B,R only (no G): manageable
T = all_tilings(H2, [Y, B, R])
by = Counter(multiset(t) for t in T)
print("  covers by Y,B,R (no green), by multiset:", sorted(by.items(), key=lambda kv: (len(kv[0]), kv[0])))
print("  cross-check DP on star:", dp_counts(S, [G, B, R, Y])[0], sorted(dp_counts(S, [G, B, R, Y])[1]))
print("  cross-check DP on triangle side 3:", dp_counts(Tr3, [G, B, R, Y])[0], sorted(dp_counts(Tr3, [G, B, R, Y])[1]))
print("  cross-check DP on hexagon side 1:", dp_counts(H, [G, B, R])[0], sorted(dp_counts(H, [G, B, R])[1]))

section("Hexagon side 2: rhombus tilings as cube stacks, flips")
T = all_tilings(H2, [B])
# a flip: three rhombi forming a unit hexagon around a lattice point -> re-tile that hexagon the other way
def unit_hexes(region):
    pts = set()
    for t in region:
        pts |= verts(t)
    hexes = []
    for p in pts:
        h = translate(Y, p[0], p[1])
        if h <= region: hexes.append(h)
    return hexes
HEXES = unit_hexes(H2)
print("  unit-hexagon positions inside the side-2 hexagon:", len(HEXES))
def flips(tl):
    out = []
    pl = [p for p, _ in tl]
    for h in HEXES:
        inside = [p for p in pl if p <= h]
        if len(inside) == 3:
            rest = [(p, 'B') for p in pl if not p <= h]
            for alt in all_tilings(h, [B]):
                if frozenset(p for p, _ in alt) != frozenset(inside):
                    out.append(frozenset(rest) | alt)
    return out
Tset = set(T)
dist = {}
# the "0 cubes" tiling: the one whose flips all increase; find via BFS eccentricities instead:
adj = {t: [u for u in flips(t) if u in Tset] for t in T}
print("  every rhombus tiling has at least one flip:", all(adj[t] for t in T))
# BFS from an arbitrary tiling
start = T[0]; dist = {start: 0}; dq = deque([start])
while dq:
    t = dq.popleft()
    for u in adj[t]:
        if u not in dist: dist[u] = dist[t] + 1; dq.append(u)
print("  flip graph connected:", len(dist) == len(T), "; diameter-ish (ecc of start):", max(dist.values()))
# the two extreme tilings (0 and 8 cubes) are the unique ones at distance 8 from each other
ecc = {}
for s in T:
    d = {s: 0}; dq = deque([s])
    while dq:
        t = dq.popleft()
        for u in adj[t]:
            if u not in d: d[u] = d[t] + 1; dq.append(u)
    ecc[s] = max(d.values())
print("  eccentricities:", Counter(ecc.values()))
ext = [s for s in T if ecc[s] == 8]
if len(ext) == 2:
    a, b = ext
    d = {a: 0}; dq = deque([a])
    while dq:
        t = dq.popleft()
        for u in adj[t]:
            if u not in d: d[u] = d[t] + 1; dq.append(u)
    print("  tilings by number of cubes (distance from the empty-box tiling):", sorted(Counter(d.values()).items()))
    print("  rhombus orientation counts in every tiling are the same:", len({tuple(sorted(Counter(normalize(p) for p, _ in t).values())) for t in T}) == 1)

section("Hexagon (side 1) rhombus flips")
T = all_tilings(H, [B]); print("  rhombus tilings of the unit hexagon:", len(T), " (they differ by one flip)")

print("\nDONE verify_blocks.py")

# ---------- appended checks quoted in bank.md ----------
section("Appended: symmetry classes and special covers")
T = [t for t in all_tilings(H2, [Y, R]) if 'Y' in multiset(t)]
print("H2: Y+6R covers:", len(T), "; up to rotation:", orbits(T, H2, False), "; up to rotation+mirror:", orbits(T, H2, True))
T = [t for t in all_tilings(H2, [Y, B]) if multiset(t) == 'BBBYYY']
print("H2: 3Y+3B covers:", len(T), "; up to rotation:", orbits(T, H2, False))
T = [t for t in all_tilings(Tr3, [Y, G, B, R]) if 'Y' in multiset(t)]
print("T3: covers using a yellow:", [multiset(t) for t in T])
T = [t for t in all_tilings(Tz, [Y, G, B, R]) if 'Y' in multiset(t)]
print("Z: covers using a yellow, by multiset:", dict(Counter(multiset(t) for t in T)))
T = [t for t in all_tilings(Tr4, [Y, R, G]) if multiset(t) == 'GRRRY']
print("T4: 5-piece covers Y+3R+G:", len(T))
for name, reg in [("H2", H2), ("star", S), ("W", DH), ("H3", TH), ("T3", Tr3), ("T4", Tr4), ("Z", Tz), ("R2", Rh)]:
    a = dp_counts(reg, [G, B, R, Y]); b = dp_counts(reg, [G, B, R, Y, C])
    print(f"{name}: fewest pieces {a[0]} (achievable {sorted(a[1])}); with chevrons allowed {b[0]}")
print("H2 by Y and C only:", dict(Counter(multiset(t) for t in all_tilings(H2, [Y, C]))))
print("\nDONE appended checks")
