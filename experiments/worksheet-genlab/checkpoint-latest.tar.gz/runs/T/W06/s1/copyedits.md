# Copyedits, Week 1 Tilings packet (stage 4, copyeditor)

Originals are in `before-copyedit/`. One line per change; no problem, diagram content or answer was added, removed, reordered or mathematically changed.

## week-k-1.tex
- Problem 7: "Cover the other eight squares with four dominoes" -> "Try to cover ..." (the next sentences are "If you can ... If you cannot ..."; matches grades 2-3 Problem 2).
- Problem 9: "Cover the other 14 squares with 7 dominoes" -> "Try to cover the other 14 squares with seven dominoes" (same reason; small numbers in words as elsewhere on the pages).

## week-grades-2-3.tex
- Problem 1: "Then cover the 3-by-3 board and the 3-by-4 board" -> "Then try to cover ..." (the 3-by-3 cannot be covered, and the table asks for squares left over).
- Problem 1: "write in the table how many squares it has, yes or no, and ..." -> "... how many squares it has, whether you covered it (yes or no), and ..." (says what the yes/no is for, as the table column does).
- Problem 4: "7 dominoes" -> "seven dominoes" (number style consistent with "four dominoes", "five L-pieces", "eight L-pieces").
- Problem 8: the labelled result grid moved from the left to the right end of the row of three small 5-by-5 boards, so that "first small board" and "second small board" in the text are the two blank ones; nothing else on the page changed.

## week-grades-4-5.tex
- Problem 1: "Cover the other squares with dominoes: ..." -> "Try to cover the other squares with dominoes: ..." (the next sentences are "When you succeed ... When you decide that it cannot be done ...").
- Problem 2: "Write the numbers in the table, and in the last column write yes or no from Problem 1." -> "Write the numbers in the table. In the last column, write yes or no: was that board covered in Problem 1?" (plainer; same wording as grades 2-3 Problem 3).
- Problem 7: "Draw the result on the first small board, drawing the middle L-piece darker." -> "... on the first small board and shade the middle L-piece." (tighter; "shaded" is the guide's term).
- Problem 9: the labelled result grid moved from the left to the right end of the row of three small 5-by-5 boards, so that "the first small board" is a blank one; nothing else on the page changed.

## week-facilitator.tex
- Section 2, pattern blocks: "(they only need them again for reserves)" -> "(they are not needed again)" (no reserve at the 2-3 or 4-5 table uses pattern blocks).
- Section 2, paper pieces: "Dominoes (1$\times$2)" -> "Dominoes (1-by-2)" and "Straight pieces (1$\times$3, ...)" -> "Straight pieces (1-by-3, ...)" (the packet writes sizes as n-by-m everywhere else).
- Section 4, Problem 2: "Answers." -> "Answers:" (every other problem uses the colon).
- Section 4, Problem 4, blues only: "so one triangle is always left over (a child will get 4 blues and one leftover triangle; ...)" -> "so at least one triangle is always left over (a child will get 3 blues and three leftover triangles; ...)". Factual correction carried over from plan.md: the side-3 triangle has only 3 down-pointing units and each rhombus covers one, so at most 3 blues fit (checked by exhaustive search); the guide's own Problem 5 answer already says "after 3 blues ... 3 whites are left". The answer (impossible) and the parity argument are unchanged.
- Section 4, "If the table stalls": "red with 1 green on the side-2 triangle" -> "one red and one green on the side-2 triangle" (consistent naming of that cover).
- Section 6, Problem 1: "Answers." -> "Answers:" (as above).
- Section 6, Problem 1, hint (3): "For E, give three honest minutes, then the compare conversation." -> "For E, let them try for three minutes, then hold the compare conversation." (plain wording).

## Checked and left as is
- Student pages: no titles, teaser questions, section labels, Name/Date lines, praise, exclamation marks, adult-directed instructions or explanations were present; every page carries only the header, footer, numbered problems, diagrams and recording space.
- Spelling is consistently British (colour, centre, grey); board sizes are "n-by-m" throughout; K-1 Problem 2 keeps the digits "3, 4, 5 pieces" because they match the numerals printed under the small hexagons.
- All other counts and answers in the guide agree with `verify_plan_output.txt` (domino and L-piece tiling counts, colour counts, forced chains, game strategies, pattern-block covers).
- Recompiled all four files with pdflatex: no errors, no overfull or underfull boxes; page counts unchanged (10, 8, 12, 15). `render/` was regenerated from the final PDFs (80 dpi PNGs and layout text); build byproducts (.aux/.log/.out) removed.
