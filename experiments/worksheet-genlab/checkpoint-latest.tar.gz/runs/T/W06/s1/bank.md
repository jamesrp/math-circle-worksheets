# Week 1 — Tilings: bank of candidate problems

Bank for a one-hour K–5 math-circle session on tilings (three tables: K–1, grades 2–3, grades 4–5). 47 candidate problems, B01–B47. Not a worksheet: the curator selects and sequences, the formatter typesets.

Every number below was checked by the programs kept in this directory:
`verify_square.py` (square boards; output in `verify_square_output.txt`), `verify_blocks.py` (pattern blocks on the triangular lattice; `verify_blocks_output.txt`), `verify_crosscheck.py` (independent bitmask re-count of the strongest claims), `verify_cram.py` (the domino-placing game), `verify_solutions.py` (explicit example tilings as letter grids; `verify_solutions_output.txt`). Where a fact is a hand argument, the argument is written out.

## Conventions used throughout

**Square boards.** Cells are 1 inch. Cell (r, c) means row r counted from the top, column c counted from the left, both starting at 1. Checkerboard shading: cell (1,1) is dark, so dark cells are those with r + c even. "Crossed out" cells are printed with an X and may not be covered. Paper pieces are cut from the 1-inch grid paper: a **domino** is 1×2 inches, an **L-tromino** is three 1-inch squares in an L, a **straight tromino** is 1×3 inches. A tiling ("cover") means every non-crossed cell is covered, no overlaps, nothing sticking out.

**Pattern-block outlines**, all printed at true 1-inch edge length. Units = green triangles. "Up/down" counts refer to the outline printed with a horizontal bottom edge; the down-pointing unit triangles are the ones shaded grey in the "shaded" versions.

| Outline | Shape | Units | up / down |
|---|---|---|---|
| H | yellow hexagon, side 1 | 6 | 3 / 3 |
| T2 | equilateral triangle, side 2 in | 4 | 3 / 1 |
| T3 | equilateral triangle, side 3 in | 9 | 6 / 3 |
| T4 | equilateral triangle, side 4 in | 16 | 10 / 6 |
| R2 | 60° rhombus, side 2 in | 8 | 4 / 4 |
| Z | trapezoid, long side 4 in, short side 2 in, two rows | 12 | 7 / 5 |
| S | six-pointed star (hexagram), edge 1 in: hexagon H plus one triangle on each edge | 12 | 6 / 6 |
| W | twin hexagons: two H sharing one full edge | 12 | 6 / 6 |
| H3 | three hexagons H in a row, each sharing an edge with the next | 18 | 9 / 9 |
| H2 | hexagon, side 2 in | 24 | 12 / 12 |

Pieces: G green triangle (1 unit), B blue rhombus (2), R red trapezoid (3), Y yellow hexagon (6), C purple chevron (4 units; it is two blue rhombi joined into a V, i.e. four consecutive units around one point — two-thirds of a hexagon; this is the only "chevron" two rhombi can make, the other join being a straight bar). On a shaded outline: G covers 1 triangle; B always covers 1 white + 1 grey; R covers 2 + 1 or 1 + 2; Y covers 3 + 3; C covers 2 + 2.

**Counting covers.** Printed outlines and boards for counting problems carry a small dot on the top edge; two covers count as different when they look different with the dot at the top ("positions distinct"). Each answer also gives the count "up to turning" (rotations identified) and "up to turning and flipping" for the facilitator.

**Recording.** Every problem names its recording space: small dissected copies of the outline to colour, mini-boards to draw dominoes on, a counting box, or a table. For K–1 the adult reads the problem aloud, the child builds and colours, the adult writes numbers.

## Index

| id | name | levels | min |
|---|---|---|---|
| B01 | Hexagon in one colour | K–1, 2–3 | 4 |
| B02 | Hexagon with exactly 2, 3, 4, 5, 6 pieces | K–1, 2–3 | 8 |
| B03 | The two blue covers and the three red covers | K–1, 2–3 | 5 |
| B04 | One red, one blue, one green: all placements | 2–3 | 6 |
| B05 | Every cover of the hexagon | 2–3, 4–5 | 12 |
| B06 | The side-2 triangle: green yes, red-and-green yes, blue no | K–1, 2–3 | 6 |
| B07 | The side-3 triangle: reds only, yellow in the middle, blues never | K–1, 2–3, 4–5 | 8 |
| B08 | Shaded outlines: what a blue always covers | K–1, 2–3, 4–5 | 8 |
| B09 | Which outlines can blue alone cover? | 2–3, 4–5 | 10 |
| B10 | Which outlines can red alone cover? | 2–3, 4–5 | 10 |
| B11 | The star's points | K–1 (blue part), 2–3, 4–5 | 8 |
| B12 | Twin hexagons: trades and exact piece counts | K–1, 2–3 | 7 |
| B13 | The big hexagon: flower, reds, blues, greens | K–1, 2–3 | 10 |
| B14 | Fewest pieces on the big hexagon | 4–5 (2–3 partial) | 8 |
| B15 | Cube pictures: twelve blues as stacks of cubes | 4–5 | 12 |
| B16 | The little-hexagon flip | K–1 (first part), 2–3, 4–5 | 5 |
| B17 | The side-3 triangle: how many pieces can you use? | 2–3, 4–5 | 10 |
| B18 | The big trapezoid Z | 4–5 (reserve) | 8 |
| B19 | First dominoes: 2×2, 2×3, 2×4, 3×4 | K–1 | 4 |
| B20 | Which boards can dominoes cover? | K–1, 2–3 | 6 |
| B21 | 3×3 with one square crossed out: which nine? | K–1 (adult scribes), 2–3 | 10 |
| B22 | Checkerboard: a domino covers one dark and one light | K–1, 2–3, 4–5 | 5 |
| B23 | 4×4 minus two corners: opposite, adjacent, neighbours | K–1, 2–3, 4–5 | 8 |
| B24 | 5×5 with one square crossed out: predict, then test | 2–3, 4–5 | 10 |
| B25 | 6×6 and 8×8 minus opposite corners | 4–5 | 8 |
| B26 | One dark and one light anywhere: always — the loop | 4–5 | 12 |
| B27 | All domino covers of 2×2, 2×3, 2×4, 2×5 | 2–3, 4–5 | 12 |
| B28 | All domino covers of 3×3-minus-centre, 3×3-minus-corner, 3×4 | 2–3, 4–5 (reserve) | 10 |
| B29 | Flips: from all-vertical to all-horizontal | 2–3, 4–5 | 8 |
| B30 | Fewest dominoes that block the board | K–1 (game), 2–3, 4–5 | 10 |
| B31 | The domino-placing game (Cram) | K–1, 2–3, 4–5 (reserve) | 10 |
| B32 | First L-trominoes: 2×2 minus one, 2×3, 3×3 | K–1, 2–3 | 8 |
| B33 | Straight trominoes on small boards | K–1, 2–3 | 6 |
| B34 | Filling 3×3 with mixed pieces | 2–3, 4–5 | 8 |
| B35 | 4×4 minus one square with five L's | K–1 (adult), 2–3, 4–5 | 10 |
| B36 | The centre trick (quarters) | 2–3, 4–5 | 6 |
| B37 | 5×5 minus one square with eight L's: which holes? | 4–5 (2–3 partial) | 15 |
| B38 | 8×8 minus one square, drawn with the centre trick | 4–5 | 12 |
| B39 | Straight trominoes with a hole: only the corners; only the centre | 4–5 | 12 |
| B40 | Most L's that fit | K–1, 2–3 | 6 |
| B41 | All L-covers of 2×6 and 3×6 | 2–3, 4–5 (reserve) | 8 |
| B42 | 4×4 with L's and dominoes together | 2–3, 4–5 | 8 |
| B43 | Three hexagons in a row | K–1, 2–3 | 6 |
| B44 | Chevron problems | 2–3, 4–5 (reserve) | 8 |
| B45 | The side-4 triangle | 4–5 (reserve) | 8 |
| B46 | Straight trominoes on 3×n: counting and the rule | 4–5 (reserve) | 10 |
| B47 | Opposite corners on different boards | K–1 (2×5), 2–3, 4–5 | 10 |

---

## Pattern blocks: the hexagon (B01–B05)

### B01 — Hexagon in one colour
- **Levels:** K–1, 2–3 (opener at both).
- **Materials / setup:** Outline H printed large (one blank copy for building); at least 6 G, 3 B, 2 R, 1 Y per child. Recording: three boxes labelled with a green triangle, a blue rhombus, a red trapezoid, plus three small dissected copies of H to colour.
- **Child's action (as printed):** Cover the hexagon shape completely with green triangles only. No gaps, no overlaps, nothing sticking out. Count the triangles. Write the number in the green box. Colour the small hexagon to show where each piece went. Do the same with blue rhombi only, then with red trapezoids only.
- **Expected result / answer (verified):** 6 green, 3 blue, 2 red (one yellow). Each count is forced by area: 6 units, pieces of 1, 2, 3 units. Verified by `verify_blocks.py` (G only 1 cover; B only 2 covers; R only 3 covers, positions distinct).
- **Mathematical question / distinction:** Pure doing; introduces the equal-area "trades" 1 Y = 2 R = 3 B = 6 G that every later pattern-block problem uses. Compared with B02 it fixes one colour; B02 mixes.
- **Minutes:** 4.
- **Needs / opens:** Needs nothing. Opens B02, B03, B06, B12.

### B02 — Hexagon with exactly 2, 3, 4, 5, 6 pieces
- **Levels:** K–1, 2–3.
- **Materials / setup:** Outline H (blank, for building); a strip of five small dissected copies of H, labelled 2, 3, 4, 5, 6.
- **Child's action (as printed):** Cover the hexagon using exactly 2 pieces. Colour the small hexagon marked 2 to show the pieces you used. Now cover it using exactly 3 pieces, then exactly 4, exactly 5, exactly 6. Colour one small hexagon for each. You may use any colours.
- **Expected result / answer (verified):** All five are possible. Piece sets that work: 2 pieces: R R (only). 3 pieces: B B B, or R B G. 4 pieces: B B G G, or R G G G. 5 pieces: B G G G G (only). 6 pieces: G G G G G G (only). (1 piece: the yellow itself.) Counts of covers, positions distinct: 2 pieces 3; 3 pieces 14 (BBB 2, RBG 12); 4 pieces 15 (BBGG 9, RGGG 6); 5 pieces 6; 6 pieces 1. Verified by `verify_blocks.py` ("covers using exactly k pieces").
- **Mathematical question / distinction:** Existence for every piece count 1–6 (a completeness question: "every number of pieces from 1 to 6 works"). The area bookkeeping (6 = 3+3 = 2+2+2 = 3+2+1 = ...) is the first invariant; the child discovers the 5-piece cover is forced to be one blue and four greens.
- **Minutes:** 8.
- **Needs / opens:** Needs B01. Opens B03, B05, B12, B17.

### B03 — The two blue covers and the three red covers
- **Levels:** K–1, 2–3.
- **Materials / setup:** Outline H with the top-edge dot; a strip of four small dissected copies of H (for blue) and another strip of four (for red).
- **Child's action (as printed):** Keep the dot at the top. Cover the hexagon with 3 blue rhombi. Colour the first small hexagon to show it. Now find a different way with 3 blues and colour the second small hexagon. Keep going until you cannot find a new one. Then do the same with 2 red trapezoids.
- **Expected result / answer (verified):** Exactly 2 blue covers (the rhombi meet at the centre in one of two "pinwheel" senses; each looks like a drawing of a cube seen from above or below). Exactly 3 red covers (the cut line between the two trapezoids can be any of the three long diagonals of the hexagon). Verified by `verify_blocks.py` (BBB 2, RR 3, positions distinct; each is 1 up to turning).
- **Mathematical question / distinction:** Counting with a complete list; the first "how many, and how do you know there are no more?". The blue pair are related by the flip of B16. Compared with B02, here the piece set is fixed and the child varies placement.
- **Minutes:** 5.
- **Needs / opens:** Needs B01. Opens B04, B05, B15, B16.

### B04 — One red, one blue, one green: all placements
- **Levels:** 2–3.
- **Materials / setup:** Outline H with the top dot; a sheet of 12 small dissected copies of H.
- **Child's action (as printed):** Cover the hexagon with one red, one blue and one green. Colour a small hexagon to show it. Find another cover with the same three pieces that looks different with the dot at the top, and colour the next small hexagon. Keep going. Write how many you found in the box.
- **Expected result / answer (verified):** 12 covers, positions distinct (the red can sit in any of 6 positions; the blue is then on its clockwise or counter-clockwise side). Up to turning: 2 (mirror images of each other); up to turning and flipping: 1. Verified by `verify_blocks.py` (BGR 12; orbits 2 and 1).
- **Mathematical question / distinction:** Counting by a systematic scheme (fix the red first, then two choices). Reveals what "different" means: the 12 collapse to 2 under turning, and to 1 if the board may be flipped over. Contrast with B03, where turning collapses the 2 blue covers to 1 and the 3 red covers to 1.
- **Minutes:** 6.
- **Needs / opens:** Needs B03. Opens B05.

### B05 — Every cover of the hexagon
- **Levels:** 2–3 (with the adult keeping the tally), 4–5 (as a fast-finisher reserve).
- **Materials / setup:** Outline H with the top dot; two sheets of small dissected copies of H (20 per sheet); a table with rows "pieces used" and "how many covers".
- **Child's action (as printed):** Using green, blue and red pieces, cover the hexagon in as many different ways as you can (dot at the top). Colour one small hexagon for each. Sort your covers by the pieces they use and fill the table: which piece sets appear, and how many covers each set gives.
- **Expected result / answer (verified):** 39 covers with positions distinct (excluding the single yellow): RR 3, BBB 2, RBG 12, BBGG 9, RGGG 6, BGGGG 6, GGGGGG 1. Up to turning: 9 (RBG splits into two mirror images; BBGG splits into "greens together" and "greens apart"). Up to turning and flipping: 8, the classic classroom answer. Check: 3+2+12+9+6+6+1 = 39, and independently 39 = 1·f(5) + 2·f(4) + 3·f(3) with f = number of ways to tile a path of length n by pieces of length 1, 2, 3 (f(3)=4, f(4)=7, f(5)=13). Verified by `verify_blocks.py`.
- **Mathematical question / distinction:** Counting a whole set by classifying (partition of 6 into parts 1, 2, 3 arranged around a cycle). Completeness: "why no more?" is answered by listing piece sets first (B02) and then placements per set (B03, B04). This is the largest count at the 2–3 level and the first place a table is needed.
- **Minutes:** 12.
- **Needs / opens:** Needs B02, B03, B04. Opens B17 (the same question on T3).

## Pattern blocks: bigger outlines, can / cannot (B06–B18)

### B06 — The side-2 triangle: green yes, red-and-green yes, blue no
- **Levels:** K–1, 2–3.
- **Materials / setup:** Outline T2 (blank); at least 4 G, 2 B, 1 R per child. Recording: three small dissected copies of T2 labelled "green", "red and green", "blue", and a box "blue: yes / no" to tick.
- **Child's action (as printed):** Cover the big triangle with green triangles only. Count them and colour the first small triangle. Cover it with one red and some green; colour the second. Now try to cover it with blue rhombi only. If you can, colour the third small triangle. If you cannot, cross it out and show the adult what always goes wrong.
- **Expected result / answer (verified):** Green: 4. Red + green: possible, 3 ways (the red lies along any one of the three sides; the green fills the opposite corner); the red covers the single middle down-triangle every time. Blue only: impossible. Reason at K–1 level: the triangle has three corner triangles pointing up and one middle triangle pointing down; a blue rhombus always covers one up-triangle and one down-triangle (B08), so two blues would need two down-triangles. Verified by `verify_blocks.py` (T2: G 1, B 0, R+G 3 covers containing a red, up/down 3/1).
- **Mathematical question / distinction:** Impossibility with even area (4 units, 2 blues would fit by area) — the first instance where counting area is not enough. Contrast with H (6 units, 3 blues work) and, later, Z in B09.
- **Minutes:** 6.
- **Needs / opens:** Needs B01. Opens B07, B08, B09.

### B07 — The side-3 triangle: reds only, yellow in the middle, blues never
- **Levels:** K–1 (parts 1–3), 2–3, 4–5 (the "why").
- **Materials / setup:** Outline T3 (blank); 9 G, 4 B, 3 R, 1 Y per child. Recording: four small dissected copies of T3 labelled "green", "red", "yellow + green", "blue", plus a yes/no box for blue.
- **Child's action (as printed):** Cover the big triangle with greens only; count and colour the first small triangle. Cover it with reds only; colour the second. Put the yellow hexagon inside the big triangle and finish the cover with greens; colour the third. Try to cover the triangle with blues only. If you cannot, cross out the fourth small triangle. Then try blues plus exactly one green.
- **Expected result / answer (verified):** Greens: 9. Reds only: possible with 3 reds, in exactly 2 ways (mirror images of each other; not related by turning). Yellow + 3 greens: exactly 1 way (the hexagon fills the middle; the three corners are single greens). Blues only: impossible (9 is odd; also 6 up-triangles versus 3 down). Blues plus one green: impossible (8 units left but 5 up / 3 down or 6 up / 2 down, never equal). Red and blue only: only the all-red cover works (1 red + 3 blues fails: at most 2 + 3 = 5 up-triangles covered, but there are 6). Verified by `verify_blocks.py` (T3: G 1, R 2, Y-covers exactly 'YGGG' 1, B 0, "B+G with exactly one G" 0, R+B 2 = the two RRR covers). An explicit red cover: the first red lies flat along the base, covering the left three of the five bottom-row units; the second red is the slanted piece made of the two remaining bottom-row units on the right together with the right-hand unit of the middle row; the third red is the rest — the left two units of the middle row and the top unit — a slanted piece along the left side. The mirror image is the other cover.
- **Mathematical question / distinction:** Existence (reds, yellow) and impossibility by two different obstructions: parity of area (blues only) and the up/down count (blues + one green, which has even area). Compared with T2 (B06) the phenomenon persists at the next size; compared with H, where blues work, the up/down count is what changed.
- **Minutes:** 8.
- **Needs / opens:** Needs B06. Opens B08, B10, B17.

### B08 — Shaded outlines: what a blue always covers
- **Levels:** K–1 (act and say), 2–3, 4–5 (use it as the argument).
- **Materials / setup:** Shaded versions of H, T2, T3, R2, Z, S, W (down-pointing unit triangles grey). One blue, one red, one green per child. Recording: a table with a row per outline and columns "white", "grey", and a strip of six small dissected copies of T2 to colour where the blue lay.
- **Child's action (as printed):** Put one blue rhombus anywhere on the shaded triangle. How many grey and how many white triangles does it cover? Move it to a new place and look again. Do this in six places and colour each on the small triangles. Now count the white and grey triangles in each shaded outline and fill the table.
- **Expected result / answer (verified):** A blue always covers exactly 1 white and 1 grey (two edge-adjacent unit triangles always point opposite ways). A red covers 2 + 1 or 1 + 2; a green 1 of either. Counts (white up / grey down): H 3/3, T2 3/1, T3 6/3, R2 4/4, Z 7/5, S 6/6, W 6/6, H2 12/12. Verified by `verify_blocks.py` ("Unit-triangle counts of every printed outline"); the 1+1 property is the lattice fact that adjacent unit triangles have opposite orientation.
- **Mathematical question / distinction:** Invariant / representation. This is the colouring argument of the session in its pattern-block form; it is introduced only after B06–B07 have posed the question it answers. Prediction: blue-only is impossible whenever white ≠ grey (T2, T3, Z).
- **Minutes:** 8.
- **Needs / opens:** Needs B06 or B07. Opens B09, B10, B18, B45; parallels B22 (checkerboard).

### B09 — Which outlines can blue alone cover?
- **Levels:** 2–3, 4–5.
- **Materials / setup:** Outlines H, T2, T3, R2, Z, S, W printed blank on one sheet (labelled A–G in that order), 12 B per child. Recording: a yes/no column beside each outline, and a box "how many blues".
- **Child's action (as printed):** Using blue rhombi only, try to cover each outline A to G. Write yes and the number of blues you used, or write no. Compare your yes/no column with the white/grey table.
- **Expected result / answer (verified):** A=H yes (3 blues; 2 covers). B=T2 no. C=T3 no. D=R2 yes (4 blues; exactly 1 cover). E=Z no (12 units, even, but 7 white / 5 grey). F=S yes (6 blues; exactly 1 cover, forced — see B11). G=W yes (6 blues; 4 covers = 2 × 2, one choice per hexagon; a blue cannot straddle the shared edge because that leaves two 5-unit pieces). Rule that fits all seven: possible exactly when white = grey. Verified by `verify_blocks.py` (B-only counts 2, 0, 0, 1, 0, 1, 4).
- **Mathematical question / distinction:** Classification by an invariant; the trapezoid Z is the instance that breaks "even area is enough". Equal white/grey is necessary; for these seven outlines it is also sufficient (checked), and the facilitator guide should say sufficiency is not automatic in general (see B10 for the red analogue, where the star breaks it).
- **Minutes:** 10.
- **Needs / opens:** Needs B08. Opens B10, B11.

### B10 — Which outlines can red alone cover?
- **Levels:** 2–3, 4–5.
- **Materials / setup:** Same sheet of outlines A–G as B09; 8 R per child. Recording: a yes/no column and "how many reds" box; for E and F a second try line.
- **Child's action (as printed):** Using red trapezoids only, try to cover each outline A to G. Write yes and the number of reds, or no. Circle the outlines with 12 triangles. Which of them can be covered by 4 reds?
- **Expected result / answer (verified):** A=H yes (2 reds; 3 covers). B=T2 no (4 units). C=T3 yes (3 reds; 2 covers). D=R2 no (8 units). E=Z yes (4 reds; exactly 1 cover). F=S **no** (12 units, 6 white / 6 grey, yet impossible). G=W yes (4 reds; 9 covers). Verified by `verify_blocks.py` (R-only counts 3, 0, 2, 0, 1, 0, 9). Why the star fails: each of the six points of the star is a unit triangle touching only one other triangle (its neighbour in the central hexagon), so a red covering a point must also contain that neighbour and one more central triangle; hence every red contains at most one point, four reds cover at most four points, and six points need six reds — but the star has room for only four. (Also verified: the most reds any cover of S uses is 3.)
- **Mathematical question / distinction:** "Area divisible by 3" and "white = grey" both pass, and the star still fails: a new obstruction (the trapped points) is needed. Three outlines of 12 units (Z, S, W) give three different behaviours: unique cover, impossible, many covers.
- **Minutes:** 10.
- **Needs / opens:** Needs B09. Opens B11 (the argument), B37 (the same "each piece covers at most one dot" argument on the square grid).

### B11 — The star's points
- **Levels:** K–1 (blue part, with the adult), 2–3, 4–5 (the counting argument).
- **Materials / setup:** Outline S blank and a dissected copy; 6 B, 4 R, 6 G per child. Recording: two small dissected stars to colour, a yes/no box for reds, and a box "how many reds can you fit at most".
- **Child's action (as printed):** Cover the star with blue rhombi. Colour the small star to show your cover. Try to find a second blue cover that looks different. Now try to cover the star with red trapezoids only. If you cannot, fit as many reds as you can, fill the rest with greens, and write how many reds you used.
- **Expected result / answer (verified):** Blue: exactly one cover — each point must pair with its only neighbour, and that uses up all six central triangles. Red only: impossible (argument in B10). Most reds in any cover: 3 (with 3 greens, e.g. reds on alternate points). Fewest pieces with G, B, R, Y: 6 (all blue; or BBGGRR, GGGRRR, BBBBGR). Verified by `verify_blocks.py` (S: B 1, R 0, most reds 3, fewest pieces 6).
- **Mathematical question / distinction:** Uniqueness (a forced tiling) and impossibility by a "one dot per piece" count. Compared with H, where the 3 blues can go two ways, the points of the star remove all freedom.
- **Minutes:** 8.
- **Needs / opens:** Needs B09 or B01. Opens B37 (same argument with L-trominoes), B44 (three chevrons cover the star).

### B12 — Twin hexagons: trades and exact piece counts
- **Levels:** K–1, 2–3.
- **Materials / setup:** Outline W blank; 2 Y, 4 R, 6 B, 12 G per child. Recording: a table with rows "yellow / red / blue / green" and a column "how many pieces"; small dissected copies of W labelled 3 and 5.
- **Child's action (as printed):** Cover the twin hexagons with yellows only, then reds only, then blues only, then greens only. Each time write how many pieces you used. Now cover them using exactly 3 pieces, and colour the small copy marked 3. Then exactly 5 pieces, and colour the copy marked 5.
- **Expected result / answer (verified):** 2 yellows (1 way), 4 reds (9 ways), 6 blues (4 ways), 12 greens (1 way). Exactly 3 pieces: Y + R + R (one hexagon yellow, the other two reds). Exactly 5 pieces: e.g. Y + B + B + G + G, or Y + R + G + G + G, or R + R + R + B + G. Every number of pieces from 2 to 12 is achievable (DP check in `verify_blocks.py`, "W fewest pieces 2, achievable 2–12").
- **Mathematical question / distinction:** Trades on a bigger region (2 : 4 : 6 : 12 doubles the 1 : 2 : 3 : 6 of B01) and existence for every piece count. Compared with H2 (B13–B14) the twin hexagons still split into two independent hexagons; H2 does not.
- **Minutes:** 7.
- **Needs / opens:** Needs B01. Opens B13, B43.

### B13 — The big hexagon: flower, reds, blues, greens
- **Levels:** K–1 (build and count, adult writes), 2–3.
- **Materials / setup:** Outline H2 blank (4 in across corners); 1 Y, 8 R, 12 B, 24 G per child (the table can share). Recording: four small dissected copies of H2 labelled "yellow + red", "red", "blue", "green", each with a count box.
- **Child's action (as printed):** Put the yellow hexagon in the middle of the big hexagon and finish the cover with red trapezoids. Colour the first small copy and write how many reds. Now cover the big hexagon with reds only; colour and count. Then blues only; colour and count. Then greens only; count.
- **Expected result / answer (verified):** Yellow + 6 reds: possible in 3 ways, all with the yellow in the centre — the symmetric "flower" (each red's short side against a hexagon edge) and two pinwheels (mirror images). Reds only: 8 reds, 9 covers (3 patterns up to turning, 2 up to turning and flipping). Blues only: 12 blues, 20 covers (6 up to turning; the "cube stack" pictures of B15). Greens: 24. Yellows only: impossible (at most 3 yellows fit, and then the leftover is three separate rhombus-shaped gaps). Verified by `verify_blocks.py` (H2: Y 0, R 9, B 20, Y+6R 3, max yellows 3).
- **Mathematical question / distinction:** Existence and counting on the first region that does not decompose; the yellow's position is forced (only the centre works for a yellow-plus-reds cover). The flower is the concrete anchor for the whole-group launch if the curator wants a pattern-block launch.
- **Minutes:** 10.
- **Needs / opens:** Needs B01. Opens B14, B15, B16.

### B14 — Fewest pieces on the big hexagon
- **Levels:** 4–5 (2–3 as a reserve: beat 7).
- **Materials / setup:** Outline H2; 3 Y, 8 R, 12 B, some G per child. Recording: three small dissected copies of H2 with count boxes; a line "smallest number found".
- **Child's action (as printed):** Cover the big hexagon with as few pieces as you can. Colour the small copy and write the number of pieces. Try to beat it. Then try to cover it with 3 yellows. Show where the yellows go and what is left.
- **Expected result / answer (verified):** Fewest is 6: three yellows plus three blues (2 covers, 1 up to turning; the three yellows sit around the centre point at 120° to each other, and the three gaps are rhombus-shaped). Why 5 is impossible: at most 3 yellows fit (any two yellows whose centres are adjacent lattice points overlap; the centre position blocks all six others; so at most 3 of the 6 off-centre positions, pairwise non-adjacent). With 3 yellows the 6 leftover units are three separate 2-unit gaps needing 3 more pieces; with 2 yellows 12 units remain, needing at least 4 pieces (largest non-yellow piece 3 units; the chevron, 4 units, does not help — checked); with 1 yellow, at least 6 more; with none, at least 8. Every number of pieces from 6 to 24 is achievable. Verified by `verify_blocks.py` (fewest 6, max yellows 3, achievable 6–24; also fewest with chevrons still 6).
- **Mathematical question / distinction:** Optimality with a proof of the lower bound in child form ("how many yellows can fit at most, and what is left"). Contrast with W (B12), where 2 pieces suffice because the region is two hexagons.
- **Minutes:** 8.
- **Needs / opens:** Needs B13. Opens B45 (fewest on T4).

### B15 — Cube pictures: twelve blues as stacks of cubes
- **Levels:** 4–5.
- **Materials / setup:** Outline H2; 12 B per child. Recording: a row of nine small dissected copies of H2 labelled 0 to 8 cubes; a facilitator drawing of the "empty box" tiling (three groups of four parallel rhombi, one group in each of the three orientations, meeting at the centre; it reads as the inside corner of a box) and the "full box" tiling (the same picture rotated by 60°, which reads as the outside corner of a 2×2×2 stack).
- **Child's action (as printed):** Cover the big hexagon with 12 blue rhombi. Look at it: it is a picture of cubes stacked in the corner of a box. Colour the copy that matches the number of cubes you see. Now change your cover so that the picture shows exactly 1 cube, then 2 cubes, and so on up to 8. Colour a copy for each number you manage.
- **Expected result / answer (verified):** Every number of cubes 0 to 8 occurs. The 20 covers split by cube count as 1, 1, 3, 3, 4, 3, 3, 1, 1. Each cover uses 4 rhombi of each of the three orientations (always). Two covers differ by one cube exactly when they differ by the flip of B16. Verified by `verify_blocks.py` ("tilings by number of cubes": distances from the empty-box tiling in the flip graph give exactly 1,1,3,3,4,3,3,1,1; orientation counts equal in every tiling). This is MacMahon's count of plane partitions in a 2×2×2 box.
- **Mathematical question / distinction:** A representation (stacks of cubes) that turns tilings into a familiar object, then counting through it. Compared with B13 ("find a blue cover") this asks for specific covers and reveals that the 20 are organised by a number.
- **Minutes:** 12.
- **Needs / opens:** Needs B13, B16 helps. Opens the mathematician's note on lozenge tilings, plane partitions and the flip graph.

### B16 — The little-hexagon flip
- **Levels:** K–1 (first part), 2–3, 4–5.
- **Materials / setup:** Outline H and outline H2; 3 B (K–1) or 12 B (older). Recording: two small dissected H's; for H2, two small dissected copies labelled "before" and "after".
- **Child's action (as printed):** Cover the hexagon with 3 blues. Lift the three pieces and put them back the other way, so that the picture changes. Colour both pictures. On the big hexagon covered with 12 blues, find three rhombi that together make a small hexagon. Turn just those three the other way. Colour the cover before and after.
- **Expected result / answer (verified):** The 2 blue covers of H are exchanged by this one move (a flip). In every 12-blue cover of H2 there is at least one flippable little hexagon (checked for all 20 covers), and repeated flips reach every one of the 20 covers from any other (flip graph connected; eccentricities 4–8). Verified by `verify_blocks.py`.
- **Mathematical question / distinction:** Reconfiguration (dynamics): a local move that connects all tilings. Same idea as the domino flip in B29; here it is visible as adding or removing one cube (B15).
- **Minutes:** 5.
- **Needs / opens:** Needs B03 or B13. Opens B15, B29.

### B17 — The side-3 triangle: how many pieces can you use?
- **Levels:** 2–3, 4–5.
- **Materials / setup:** Outline T3; 9 G, 4 B, 3 R, 1 Y per child. Recording: a table with rows 1 to 9 ("number of pieces") and columns "possible?" and "pieces used", plus small dissected T3 copies to colour.
- **Child's action (as printed):** Cover the big triangle using exactly 3 pieces; write which pieces in the row for 3 and colour a small copy. Do the same for exactly 4, 5, 6, 7, 8 and 9 pieces. Which rows are impossible? Say why to the adult.
- **Expected result / answer (verified):** 3 to 9 all possible; 1 and 2 impossible. Piece sets that work: 3: RRR. 4: RRBG, or YGGG. 5: RBBGG, or RRGGG. 6: BBBGGG, or RBGGGG. 7: BBGGGGG, or RGGGGGG. 8: BGGGGGGG. 9: all green. Impossible: 1 (no single piece has 9 units); 2 (would need Y + R, but once the yellow is placed the three corners are separate single triangles). Also impossible: BBBB + G (B07). Verified by `verify_blocks.py` (piece multisets with counts; "number of pieces achievable" 3–9; Y-covers only YGGG).
- **Mathematical question / distinction:** Completeness over a parameter (piece count) with two impossible values explained by two different reasons (area; geometry of the yellow). Compared with H (B02), where the piece counts 1–6 all work, here the small counts fail.
- **Minutes:** 10.
- **Needs / opens:** Needs B07. Opens B45.

### B18 — The big trapezoid Z
- **Levels:** 4–5 reserve.
- **Materials / setup:** Outline Z (4-inch long side), shaded and blank; 4 R, 6 B, 1 Y, some G. Recording: small dissected copies labelled "red", "yellow + red", "yellow + others", "fewest".
- **Child's action (as printed):** Cover the trapezoid with reds only. Is there a second way that looks different? Now put the yellow inside the trapezoid and try to finish with reds only. Then finish with any pieces. Finally cover the trapezoid with as few pieces as you can and write the number.
- **Expected result / answer (verified):** Reds only: exactly 1 cover (mirror-symmetric). Yellow + reds: impossible (the yellow fits in two positions, but the leftover cannot be done in reds). Yellow + other pieces: possible, e.g. Y + R + B + G (2 covers). Blues only: impossible (7 white / 5 grey). Fewest pieces: 4 (RRRR, or YRBG). Verified by `verify_blocks.py` (Z: R 1, Y+R 1 = the all-red cover only, B 0, covers with Y by multiset, fewest 4).
- **Mathematical question / distinction:** Uniqueness without an obvious forcing (unlike the star, no unit is trapped, yet only one red cover exists); a yellow that fits but poisons the rest. Contrast with W (many red covers) and S (no red cover).
- **Minutes:** 8.
- **Needs / opens:** Needs B09, B10. Opens nothing; reserve.

## Dominoes (B19–B31)

### B19 — First dominoes: 2×2, 2×3, 2×4, 3×4
- **Levels:** K–1.
- **Materials / setup:** Boards 2×2, 2×3, 2×4, 3×4 printed at 1 inch; 8 paper dominoes per child. Recording: a count box beside each board.
- **Child's action (as printed):** Cover the 2-by-2 board with dominoes so that every square is covered and nothing sticks out. Tell the adult how many dominoes; the adult writes it in the box. Do the same for the 2-by-3, the 2-by-4 and the 3-by-4 boards.
- **Expected result / answer (verified):** 2, 3, 4, 6 dominoes (area halves). All four boards are tileable (`verify_square.py`: 2, 3, 5, 11 tilings respectively).
- **Mathematical question / distinction:** Pure doing; establishes the covering rules and "count of pieces = half the squares".
- **Minutes:** 4.
- **Needs / opens:** Nothing. Opens B20, B21, B27.

### B20 — Which boards can dominoes cover?
- **Levels:** K–1, 2–3.
- **Materials / setup:** Boards 3×3, 3×5, 5×5 added to those of B19; 13 dominoes per child. Recording: a table of boards with columns "squares", "covered? yes/no", "squares left over".
- **Child's action (as printed):** Try to cover each board with dominoes. For each board write the number of squares, yes or no, and how many squares were left over when you could not. Look down the table: which numbers of squares give no?
- **Expected result / answer (verified):** 2×2 yes (4), 2×3 yes (6), 3×3 no (9, one left over, wherever you start), 3×4 yes (12), 4×4 yes (16), 3×5 no (15), 5×5 no (25). A domino covers 2 squares, so an odd number of squares always leaves exactly one over. Verified by `verify_square.py` (3×3, 5×5: 0 tilings; the parity argument is elementary).
- **Mathematical question / distinction:** Impossibility by the simplest invariant (parity of area). The next problems show that even area is not enough (B21, B23).
- **Minutes:** 6.
- **Needs / opens:** Needs B19. Opens B21.

### B21 — 3×3 with one square crossed out: which nine?
- **Levels:** K–1 (child chooses the crossed square with a counter; adult scribes on the result grid), 2–3.
- **Materials / setup:** Board 3×3 at 1 inch with a removable counter to mark the crossed-out square (or nine printed 3×3 boards each with a different X); 4 dominoes per child. Recording: a 3×3 "result grid" of small squares, one for each possible crossed-out position, to mark tick or cross.
- **Child's action (as printed):** Cross out one square of the 3-by-3 board and try to cover the other eight with four dominoes. In the result grid, put a tick on the square you crossed out if you succeeded and a cross if you could not. Do this for all nine squares. Look at the pattern of ticks.
- **Expected result / answer (verified):** Ticks at the four corners and the centre (5 positions); crosses at the four edge-middles (4 positions). Number of covers: corner crossed out 4, centre crossed out 2. The ticks form the dark squares of a checkerboard. Verified by `verify_square.py` and independently by `verify_crosscheck.py` (grid `Y.Y/.Y./Y.Y`). Example covers: centre out — `ABB / A.C / DDC`; corner out — `.AB / CAB / CDD` (letters = dominoes, rows top to bottom).
- **Mathematical question / distinction:** Classification of all cases (completeness: all nine tried) with a pattern that asks for a reason. Reveals that even area is not the whole story; the answer to "why" is B22.
- **Minutes:** 10.
- **Needs / opens:** Needs B20. Opens B22, B24.

### B22 — Checkerboard: a domino covers one dark and one light
- **Levels:** K–1, 2–3, 4–5.
- **Materials / setup:** Checkerboard-shaded 3×3 and 4×4 boards; 3 dominoes. Recording: a table "board / dark squares / light squares / can it be covered?" with rows: 3×3; 3×3 minus a corner; 3×3 minus the middle of an edge; 3×3 minus the centre; 4×4; 4×4 minus two opposite corners.
- **Child's action (as printed):** Put one domino anywhere on the checkerboard. How many dark and how many light squares does it cover? Move it to five other places and look each time. Now count the dark and light squares of each board in the table and write the numbers. Fill the last column from what you found in the earlier problems.
- **Expected result / answer (verified):** A domino always covers 1 dark + 1 light (neighbouring squares have opposite colours). Counts: 3×3 5 dark / 4 light; minus a corner 4/4 (yes); minus an edge-middle 5/3 (no); minus the centre 4/4 (yes); 4×4 8/8 (yes); 4×4 minus opposite corners 6/8 (no). A cover by dominoes needs dark = light. Verified by `verify_square.py` (counts of tilings 4, 0, 2, 36, 0) and by the colour argument.
- **Mathematical question / distinction:** The invariant that explains B21 and B23, introduced after the question exists. Same logic as B08 in the pattern-block world (the guide should say so).
- **Minutes:** 5.
- **Needs / opens:** Needs B21 (or B23 for K–1). Opens B23, B24, B25, B47.

### B23 — 4×4 minus two corners: opposite, adjacent, neighbours
- **Levels:** K–1 (large board, adult help), 2–3, 4–5.
- **Materials / setup:** Three 4×4 boards at 1 inch: (a) corners (1,1) and (4,4) crossed out; (b) corners (1,1) and (1,4) crossed out; (c) (1,1) and its neighbour (1,2) crossed out. 7 dominoes per child. Recording: a mini-board under each to draw the cover or a cross; dark/light count boxes.
- **Child's action (as printed):** Board (a) has two opposite corners crossed out. Cover the other 14 squares with 7 dominoes. If you cannot, cross out the mini-board. Do the same for board (b), which has two corners on the same side crossed out, and board (c), which has a corner and its neighbour crossed out. Count the dark and light squares left on each board.
- **Expected result / answer (verified):** (a) impossible (6 dark, 8 light). (b) possible, 12 covers, e.g. `.AB. / CABD / CEED / FFGG`. (c) possible, 18 covers. Verified by `verify_square.py` and `verify_crosscheck.py`. For 4–5: every choice of one dark and one light square gives a tileable board (all 64 pairs), and every same-colour pair does not (all 56 pairs) — exhaustive check; the "always" half is proved in B26.
- **Mathematical question / distinction:** The mutilated-checkerboard impossibility at the smallest size that shows it (a 2×2 minus opposite corners is too trivial: two isolated squares). Contrast (a) against (b) and (c): removing two squares is fine, removing two of the same colour is not.
- **Minutes:** 8.
- **Needs / opens:** Needs B20 (K–1) or B22. Opens B25, B26, B47.

### B24 — 5×5 with one square crossed out: predict, then test
- **Levels:** 2–3 (test several), 4–5 (predict all 25 from B21, test four).
- **Materials / setup:** Board 5×5 at 1 inch with a movable counter; 12 dominoes per child. Recording: a 5×5 "prediction grid" and a 5×5 "result grid" of small squares.
- **Child's action (as printed):** Before you try anything, mark on the prediction grid the squares you think can be crossed out so that 12 dominoes cover the rest. Then test at least four of your guesses on the big board and mark the result grid. Compare the two grids.
- **Expected result / answer (verified):** Exactly the 13 squares with r + c even (the checkerboard's dark squares: corners, centre, and the rest of that colour) work; the 12 others do not. Numbers of covers: corners 192; (1,3)-type edge cells 192; (2,2)-type cells 112; centre 196. Verified by `verify_square.py` ("5x5 minus one cell" map and counts). Example cover with the corner (1,1) crossed out: `.ABCD / EABCD / EFGHI / JFGHI / JKKLL`; with the centre crossed out: `ABCDE / ABCDE / FG.HI / FGJHI / KKJLL`.
- **Mathematical question / distinction:** The same reason works again on a bigger case (13 dark vs 12 light, so the crossed square must be dark); the new content is that "dark" is sufficient here too, which the child can only check by construction. Contrast with 3×3 (B21): pattern extends.
- **Minutes:** 10.
- **Needs / opens:** Needs B21, B22. Opens B26.

### B25 — 6×6 and 8×8 minus opposite corners
- **Levels:** 4–5.
- **Materials / setup:** Board 6×6 at 1 inch with (1,1) and (6,6) crossed out; 17 dominoes per child. Board 8×8 at 0.75 inch, checkerboard-shaded, corners (1,1) and (8,8) crossed out, for pencil drawing only (an 8-inch board at 1 inch fits Letter only with 0.25-inch margins; the formatter may choose either). Recording: dark/light count boxes.
- **Child's action (as printed):** Cover the 6-by-6 board with the two crossed corners using 17 dominoes. If you get stuck, count the dark and light squares that are left and write the numbers. Then on the 8-by-8 board, draw dominoes in pencil to cover it. Count dark and light squares.
- **Expected result / answer (verified):** Both impossible: 6×6 leaves 16 dark / 18 light; 8×8 leaves 30 dark / 32 light; each domino covers one of each. Verified by `verify_square.py` (0 tilings for both; the full 8×8 has 12,988,816 tilings, for the guide's note).
- **Mathematical question / distinction:** The classic; the child produces the explanation form "the same reason works on the bigger board". Sits after B23 so the argument is already owned.
- **Minutes:** 8.
- **Needs / opens:** Needs B23. Opens B26, B47.

### B26 — One dark and one light anywhere: always — the loop
- **Levels:** 4–5.
- **Materials / setup:** Two 4×4 checkerboards at 1 inch, one blank for drawing a loop, one with two crossed squares chosen by the child (one dark, one light); 7 dominoes. A 6×6 version for fast finishers. Recording: the loop drawn on the board; a mini-board for the cover.
- **Child's action (as printed):** Draw one closed loop that passes through every square of the 4-by-4 board exactly once, moving only to a neighbouring square, and returns to its start. Now cross out any one dark square and any one light square. Cover the remaining 14 squares with dominoes laid along your loop. Do it again with a different pair.
- **Expected result / answer (verified):** A loop exists: down column 1, up column 2 to row 2, down column 3, up column 4 to row 1, then left along row 1 back to (1,1) (the same "comb" works on 6×6). Removing one dark and one light square cuts the loop into two paths, each with an even number of squares (colours alternate along the loop, and the two removed squares have different colours), and a path with an even number of squares is covered by dominoes laid end to end along it. So every dark-light pair works: confirmed exhaustively for all 64 pairs on 4×4 and all 324 on 6×6 (`verify_square.py`, "gomory_check"). Same-colour pairs never work (56 and 306 pairs, all impossible).
- **Mathematical question / distinction:** An "always" statement proved by a construction (Gomory's argument) rather than an invariant; the first time the children see that the colour count is not only necessary but sufficient for this family. Contrast with B23(a): the same board, the only difference is colours.
- **Minutes:** 12.
- **Needs / opens:** Needs B23. Opens the mathematician's note (Hamiltonian cycles, perfect matchings).

### B27 — All domino covers of 2×2, 2×3, 2×4, 2×5
- **Levels:** 2–3 (to 2×4), 4–5 (to 2×5, predict 2×6).
- **Materials / setup:** Boards 2×2, 2×3, 2×4, 2×5 at 1 inch with the top dot; 5 dominoes. Recording: rows of mini-boards: 3 for 2×2, 4 for 2×3, 6 for 2×4, 9 for 2×5; a count box per row; a prediction box for 2×6.
- **Child's action (as printed):** Cover the 2-by-2 board with dominoes. Draw the cover on a mini-board. Find every different cover and draw each one. Write how many. Do the same for 2-by-3, 2-by-4 and 2-by-5. Look at your four numbers. Predict the number for 2-by-6 and write it in the box.
- **Expected result / answer (verified):** 2, 3, 5, 8; then 13 for 2×6 (and 21 for 2×7). Rule: the left column is either one upright domino (leaving a board one column shorter) or two flat dominoes on top of each other (leaving a board two columns shorter), so each number is the sum of the two before it. All five covers of 2×4: `ABBC/ADDC`, `ABCD/ABCD`, `ABCC/ABDD`, `AABC/DDBC`, `AABB/CCDD`. Verified by `verify_square.py` (counts 1, 2, 3, 5, 8, 13, 21 for widths 1–7).
- **Mathematical question / distinction:** Counting with a recursion the child can state in words ("the left end is upright or a flat pair"). Compared with B05 (a fixed region, many piece types) the region grows and one piece type is used; the pattern is the point.
- **Minutes:** 12.
- **Needs / opens:** Needs B19. Opens B28, B29, B41, B46.

### B28 — All domino covers of 3×3-minus-centre, 3×3-minus-corner, 3×4
- **Levels:** 2–3 (first two), 4–5 (3×4 as a reserve).
- **Materials / setup:** Board 3×3 with the centre crossed out, board 3×3 with corner (1,1) crossed out, board 3×4; 6 dominoes. Recording: 3 mini-boards, 5 mini-boards, 12 mini-boards, each row with a count box.
- **Child's action (as printed):** Find every different cover of the 3-by-3 board with the centre crossed out and draw each on a mini-board. Then every cover with the corner crossed out. Then every cover of the 3-by-4 board. Write the three counts.
- **Expected result / answer (verified):** 2 (the ring of eight squares is covered "clockwise" or "anticlockwise"), 4, 11. The 11 covers of 3×4 split by number of flat dominoes: 4 covers with 2 flat, 6 with 4 flat, 1 with 6 flat. Verified by `verify_square.py` and `verify_crosscheck.py`.
- **Mathematical question / distinction:** Counting on regions with holes (a ring gives exactly 2: a cycle has two perfect matchings); 11 is the first count where a child needs a system (e.g. sort by what covers the top-left square). Reserve value: it is honest work with a checkable answer.
- **Minutes:** 10.
- **Needs / opens:** Needs B21, B27. Opens B29.

### B29 — Flips: from all-vertical to all-horizontal
- **Levels:** 2–3 (2×4), 4–5 (4×4; the lower bound).
- **Materials / setup:** Boards 2×4 and 4×4 at 1 inch; 8 dominoes. Recording: a row of mini-boards to draw the cover after each flip; a count box "flips used".
- **Child's action (as printed):** Cover the 2-by-4 board with four upright dominoes. A flip means: find two dominoes lying side by side that make a 2-by-2 square, lift them, and put them back turned the other way. Using only flips, reach the cover with all dominoes flat. Draw the cover after each flip and count the flips. Then do the same on the 4-by-4 board with eight upright dominoes, using as few flips as you can. Can you find a cover of the 4-by-4 board that has no flippable square at all?
- **Expected result / answer (verified):** 2×4: 2 flips (each 2×2 block once). 4×4: 4 flips is the minimum, because every flip changes exactly 2 dominoes and all 8 must change; flipping the four 2×2 blocks does it. (6×6: 9 flips by the same count.) No cover of a rectangle is flip-free: every cover of 2×n, 3×4, 4×4, 4×6, 6×6 has at least one flippable square, and flips connect all covers (checked for all covers of those boards; on 4×4 every cover is within 7 flips of the all-vertical one). Verified by `verify_square.py` ("Domino flips").
- **Mathematical question / distinction:** Reconfiguration and a lower-bound argument (counting what each move changes). Same move as B16 in the pattern-block world. The "no flip-free cover" fact is a theorem for simply connected regions (Thurston), to be mentioned in the mathematician's note.
- **Minutes:** 8.
- **Needs / opens:** Needs B27. Opens B30.

### B30 — Fewest dominoes that block the board
- **Levels:** K–1 (2×3 and 3×3, as a two-player "block the board" game with the adult), 2–3 (2×3, 2×4, 3×3, 3×4), 4–5 (4×4, 5×5).
- **Materials / setup:** Boards 2×3, 2×4, 3×3, 3×4, 4×4, 5×5; 12 dominoes. Recording: a mini-board beside each board to draw the blocking position, a count box "dominoes used", and a line "smallest found".
- **Child's action (as printed):** Place dominoes on the 2-by-3 board, without overlapping, until no more domino can fit anywhere. Use as few dominoes as you can. Draw the position and write the number. Try to beat your number. Do the same on each board.
- **Expected result / answer (verified):** Minimum blocking numbers: 2×3: 2; 2×4: 3; 3×3: 3; 3×4: 4; 4×4: 6; 5×5: 9. Positions (rows top to bottom, letters = dominoes, dots = empty squares): 2×3 `AA. / .BB`; 2×4 `AABB / .CC.`; 3×3 `AA. / .BB / CC.`; 3×4 `ABB. / A.CC / .DD.`; 4×4 `AABB / CDD. / C.EE / .FF.`; 5×5 `ABBCC / A.DD. / .EE.F / GG.HF / .IIH.`. Why 2 cannot block 3×3: two dominoes leave 5 squares, none touching; the only 5 pairwise non-touching squares of a 3×3 are the corners plus the centre, and then the covered squares would be the four edge-middles, which no domino can pair. Verified by `verify_square.py` (exhaustive over all non-touching leftover sets; "Fewest dominoes that block the board").
- **Mathematical question / distinction:** Optimality in the opposite direction from tiling (minimum maximal placement); the 3×3 lower bound reuses the checkerboard picture in a new role. Feeds the game B31.
- **Minutes:** 10.
- **Needs / opens:** Needs B19. Opens B31.

### B31 — The domino-placing game (Cram)
- **Levels:** K–1 (play on 2×3 and 3×3 with the adult), 2–3 (2×4, 3×4), 4–5 (4×4; find the strategy).
- **Materials / setup:** Boards 2×3, 3×3, 2×4, 3×4, 4×4; 8 dominoes, two players. Recording: a tally "who won" per board; for 4×4 a line "the second player's rule".
- **Child's action (as printed):** Two players take turns placing one domino on the board, flat or upright, anywhere it fits. A player who cannot place a domino loses. Play the 2-by-3 board three times, changing who starts. Then the 3-by-3, the 2-by-4, the 3-by-4 and the 4-by-4. On which boards would you rather go first? Find a rule that wins.
- **Expected result / answer (verified):** 2×3: first player wins by placing an upright domino (any column; the middle column leaves two separate columns, and then the first player copies the opponent). 2×4 and 4×4: second player wins by half-turn copying — after each move, place the same domino rotated by a half turn about the board's centre (no domino is its own half-turn image on these boards). 3×4: first player wins by covering the two central squares (2,2)–(2,3) and then half-turn copying. 3×3: second player wins, but no copying rule works (the centre square breaks it); winning replies, rows from the top, columns from the left: after a first move on the top row covering (1,1)–(1,2), reply (2,2)–(3,2) (the domino from the centre straight down); after a first move covering (1,2)–(2,2) (top-middle to centre), reply (1,1)–(2,1) beside it, or (3,1)–(3,2) along the bottom; other first moves are rotations or reflections of these. Verified by `verify_cram.py` (full game-tree search; lists of all winning first moves / replies).
- **Mathematical question / distinction:** A combinatorial game on the same boards, with the symmetry strategy as the argument. Reserve at every level; ties to B30 (the game ends in a blocking position).
- **Minutes:** 10.
- **Needs / opens:** Needs B30 or B19. Opens nothing (reserve).

## Trominoes (B32–B42)

### B32 — First L-trominoes: 2×2 minus one, 2×3, 3×3
- **Levels:** K–1, 2–3.
- **Materials / setup:** Four 2×2 boards each with a different square crossed out; boards 2×3 and 3×3; 4 paper L-trominoes. Recording: mini-boards under each; a yes/no box for 3×3.
- **Child's action (as printed):** An L-piece covers three squares. Cover each 2-by-2 board with the crossed square left empty; draw the L. Cover the 2-by-3 board with two L-pieces; draw it; then find the other way and draw that too. Try to cover the 3-by-3 board with three L-pieces. Write yes or no. If no, point to the squares that cause the trouble.
- **Expected result / answer (verified):** 2×2 minus any square: exactly one L, four positions. 2×3: 2 covers (`ABB/AAB` and its mirror). 3×3: impossible. Reason: an L fits inside a 2-by-2 block, and every 2-by-2 block of the 3-by-3 board contains exactly one corner of the board; so each L covers at most one corner, three L's cover at most three of the four corners. Verified by `verify_square.py` and `verify_crosscheck.py` (0 tilings).
- **Mathematical question / distinction:** Existence at the smallest size and an impossibility with a "one corner per piece" count — the same shape of argument as the star (B11) and 5×5 (B37). Contrast with straight trominoes (B33), which do cover the 3×3.
- **Minutes:** 8.
- **Needs / opens:** Needs nothing (B19 helps). Opens B33, B35, B40.

### B33 — Straight trominoes on small boards
- **Levels:** K–1, 2–3.
- **Materials / setup:** Boards 2×3, 2×4, 3×3, 3×4, 4×4, 3×5; 5 paper straight trominoes. Recording: a table "board / squares / covered? / how many ways".
- **Child's action (as printed):** A straight piece covers three squares in a line. Try to cover each board with straight pieces only. Write yes or no. For the boards that work, find all the different covers and write how many.
- **Expected result / answer (verified):** 2×3 yes (1 cover), 2×4 no, 3×3 yes (2: three rows or three columns), 3×4 yes (3), 4×4 no (16 squares), 3×5 yes (4), 3×6 yes (6), 6×6 yes (64). Verified by `verify_square.py` ("Straight trominoes").
- **Mathematical question / distinction:** Divisibility by 3 as an invariant (2×4, 4×4 fail by area), and the contrast "3×3: straight yes, L no" (B32) — same board, same area, different piece. The counts 1, 2, 3, 4, 6 on 3×n feed B46.
- **Minutes:** 6.
- **Needs / opens:** Needs B32. Opens B34, B39, B46.

### B34 — Filling 3×3 with mixed pieces
- **Levels:** 2–3, 4–5.
- **Materials / setup:** Board 3×3; 3 L's, 3 straights, 4 dominoes. Recording: a table with rows "1 L + 3 dominoes", "1 straight + 3 dominoes", "2 L + 1 straight", "1 L + 2 straights", "3 L", "3 straights" and columns "possible?" and a mini-board.
- **Child's action (as printed):** Fill the 3-by-3 board using exactly the pieces named in each row of the table. Draw each cover you find. Write no in the rows you believe are impossible and say why to the adult.
- **Expected result / answer (verified):** 1 L + 3 dominoes: yes (8 covers, e.g. `AAB/CCB/CDD`). 1 straight + 3 dominoes: yes (12, e.g. `ABC/ABC/DDD`). 2 L + 1 straight: yes (8, e.g. `AAB/ACB/CCB`). 1 L + 2 straights: no (two straights in a 3×3 must be two parallel full rows or columns; the remaining line of three cannot be an L). 3 L: no (B32). 3 straights: yes (2). Verified by `verify_square.py` ("Mixed pieces", exact multisets).
- **Mathematical question / distinction:** Existence with prescribed piece multisets; two impossibilities with different reasons (corners; forced rows). Extends B32–B33 by mixing.
- **Minutes:** 8.
- **Needs / opens:** Needs B32, B33. Opens B42.

### B35 — 4×4 minus one square with five L's
- **Levels:** K–1 (corner hole, with the adult), 2–3, 4–5.
- **Materials / setup:** Three 4×4 boards at 1 inch: hole at the corner (1,1); hole at the edge (1,2); hole inside at (2,3). 5 L's per child. Recording: a mini-board under each; a box "did you find a second way?".
- **Child's action (as printed):** Cover the 4-by-4 board with the crossed-out corner using five L-pieces. Draw your cover. Then try to find a second cover of the same board that looks different. Do the same for the board with the hole on the edge and the board with the hole inside.
- **Expected result / answer (verified):** All three are possible, and each has exactly one cover (true for all 16 hole positions). Covers (rows top to bottom): hole (1,1): `.ABB / AACB / DCCE / DDEE`; hole (1,2): `A.BB / AACB / DCCE / DDEE`; hole (2,3): `AABB / AC.B / DCCE / DDEE`. In every one, one L sits at the centre covering one square of each of the three quarters that do not contain the hole. Verified by `verify_square.py` (count 1 for each of the 16 holes) and independently by `verify_crosscheck.py`.
- **Mathematical question / distinction:** Existence for every hole, and uniqueness — the "find a second way" fails, which is the surprise; the shared centre L is the seed of the induction (B36). Contrast with 5×5 (B37), where some holes fail and others have many covers.
- **Minutes:** 10.
- **Needs / opens:** Needs B32. Opens B36, B37, B38.

### B36 — The centre trick (quarters)
- **Levels:** 2–3, 4–5.
- **Materials / setup:** A 4×4 board with a movable counter for the hole and thick lines dividing it into four 2×2 quarters; 5 L's. Recording: three mini-boards for three holes of the child's choice, with the first L to be drawn in a darker pencil.
- **Child's action (as printed):** Put the counter on any square. The board is cut into four 2-by-2 quarters; the counter is in one of them. Place one L-piece in the middle of the board so that it covers one square of each of the other three quarters. Now every quarter is a 2-by-2 with one square missing. Finish the cover. Do this for three different counter positions, drawing the first L darker each time.
- **Expected result / answer (verified):** Always works; after the centre L each quarter is exactly the B32 situation. Since the 4×4-minus-one cover is unique (B35), this construction is the only cover. Verified by `verify_solutions.py` (the recursive construction reproduces the unique tilings; `deficient()`).
- **Mathematical question / distinction:** The inductive step made concrete: reduce a size-4 problem to four size-2 problems. Introduced after B35 so the child has already met the centre L without a name.
- **Minutes:** 6.
- **Needs / opens:** Needs B35. Opens B38.

### B37 — 5×5 minus one square with eight L's: which holes?
- **Levels:** 4–5 (2–3: try the centre, a corner, (1,3) and (1,2) only).
- **Materials / setup:** Board 5×5 at 1 inch with a movable counter; 8 L's per child. Page two: the same board with a dot printed in each of the nine squares whose row and column numbers are both odd — (1,1), (1,3), (1,5), (3,1), (3,3), (3,5), (5,1), (5,3), (5,5). Recording: a 5×5 result grid of small squares (tick/cross), mini-boards for successful covers, a box "dots covered by one L".
- **Child's action (as printed):** Put the counter on the centre square and cover the rest with eight L-pieces. Draw it. Now put the counter on a corner; then on the middle of the top edge; then on the square next to the corner along the top edge. Each time, tick or cross that square in the result grid. Try more squares until you can see which ones work. Then, on the dotted board: put one L anywhere. How many dots does it cover? Try six places. What is the most dots eight L's could cover?
- **Expected result / answer (verified):** Exactly the nine dotted squares work (both numbers odd): centre 32 covers, edge-middles such as (1,3) 16 covers, corners 8 covers; every other square (16 of them) is impossible. Argument: every L lies inside some 2-by-2 block, and a 2-by-2 block contains exactly one dotted square, so an L covers at most one dot; eight L's cover at most eight dots; there are nine dots, so the uncovered square must be a dot. Example covers (rows top to bottom): hole (1,1): `.AABB / CADDB / CCDEE / FGGEH / FFGHH`; hole (1,3): `AA.BB / ACCBD / EECDD / EFGHH / FFGGH`; hole (3,3): `ABBCC / AABCD / EE.DD / EFGHH / FFGGH`. Verified by `verify_square.py` and `verify_crosscheck.py` (counts 8/16/32 at dotted squares, 0 elsewhere).
- **Mathematical question / distinction:** Complete classification with a necessary condition (dot count) and constructions for the three symmetry types of good holes. The "any hole works" pattern of 2×2 and 4×4 (and 8×8, B38) breaks here; the dot argument is the same shape as B11 and B32 but the dots are new (not a colouring of all squares). For the mathematician: 7×7 minus any square is tileable (checked), so 5×5 is the odd one out.
- **Minutes:** 15.
- **Needs / opens:** Needs B35. Opens B38, B39, B40.

### B38 — 8×8 minus one square, drawn with the centre trick
- **Levels:** 4–5.
- **Materials / setup:** Board 8×8 at 0.75 inch (6 in square) printed twice, thick lines marking the four 4×4 quarters and thinner lines marking the 2×2 sub-quarters; the child draws L's in pencil (21 of them), with the hole chosen by the child (or fixed at (4,5) on the second copy). Recording: the boards themselves and a count box "L-pieces drawn".
- **Child's action (as printed):** Cross out any one square. Draw one L in the centre of the board covering one square of each of the three quarters that do not contain your crossed square. Now each quarter is a 4-by-4 board with one square missing: do the centre trick inside each quarter, then inside each 2-by-2. Count your L's. Do it again on the second board with the marked hole.
- **Expected result / answer (verified):** Always works, 21 L's. Example with hole (1,1) (rows top to bottom): `.CDDHHII / CCBDHGGI / EBBFJJGK / EEFFAJKK / MMNAARSS / MLNNRRQS / OLLPTQQU / OOPPTTUU`. Every one of the 64 holes is tileable (checked by search) and the construction itself is verified for several holes (`verify_solutions.py`, `deficient()`; `verify_square.py`, "8x8 minus one cell: all 64 positions L-tileable? True").
- **Mathematical question / distinction:** The induction run twice; the explanation form "the same reason works again on the bigger board". Compared with B37, no obstruction: 16 dots for 21 pieces.
- **Minutes:** 12.
- **Needs / opens:** Needs B36. Opens the mathematician's note (2^n × 2^n boards; which other boards work).

### B39 — Straight trominoes with a hole: only the corners; only the centre
- **Levels:** 4–5.
- **Materials / setup:** Board 4×4 with a movable counter; board 5×5 with a movable counter; 8 straight trominoes. Page two: the 4×4 board coloured in three colours along diagonals (cell (r, c) gets colour (r + c) mod 3) and the same board coloured along the other diagonals ((r − c) mod 3). Recording: 4×4 and 5×5 result grids (tick/cross); a table "colour / how many squares".
- **Child's action (as printed):** On the 4-by-4 board put the counter on a square and try to cover the other 15 with five straight pieces. Tick or cross the square in the result grid. Test all 16 squares. Do the same on the 5-by-5 board with eight straight pieces, testing the centre, a corner, an edge-middle and one more square of your choice. Then, on the striped board, lay one straight piece anywhere: which colours does it cover? Count the squares of each colour.
- **Expected result / answer (verified):** 4×4: only the four corners work (4 covers each, e.g. hole (1,1): `.ABC / DABC / DABC / DEEE`); all other 12 holes impossible. 5×5: only the centre works (2 covers, pinwheels: `ABCCC / ABDDD / AB.EF / GGGEF / HHHEF`); all 24 other holes impossible. Argument: a straight tromino always covers one square of each of the three diagonal colours; on the 4×4 the colours have 6, 5, 5 squares, so the hole must be in the 6-colour; using both diagonal directions, the hole must be in the 6-colour of each, and only the four corners are in both. On the 5×5 the counts are 8, 9, 8 for one direction and 9, 8, 8 for the other, and only the centre is in both 9-colours. (8×8: only (3,3), (3,6), (6,3), (6,6) — checked; for the guide.) Verified by `verify_square.py` ("Straight trominoes", hole maps and colour counts).
- **Mathematical question / distinction:** A three-colouring invariant, contrasting with the two-colouring of dominoes and the dot count of L's: same 4×4 board, L's work for all 16 holes (B35), straight pieces for only 4. Here the invariant is also sufficient (constructions exist for every allowed hole).
- **Minutes:** 12.
- **Needs / opens:** Needs B33, B35. Opens the note on colouring arguments (Golomb).

### B40 — Most L's that fit
- **Levels:** K–1 (3×3, 2×4), 2–3 (3×4, 4×4, 5×5).
- **Materials / setup:** Boards 3×3, 2×4, 3×4, 4×4, 5×5; 8 L's. Recording: a table "board / most L's / squares left empty", mini-boards.
- **Child's action (as printed):** Put as many L-pieces as you can on the 3-by-3 board without overlapping. Write the number and how many squares stay empty. Draw the position. Do the same on each board. Try to beat each number.
- **Expected result / answer (verified):** 3×3: 2 (3 empty); 2×4: 2 (2 empty); 3×4: 4 (0 empty: 3×4 is tileable); 4×4: 5 (1 empty); 5×5: 8 (1 empty). Verified by `verify_square.py` ("Maximum number of L-trominoes that fit"). On 5×5 the single empty square is necessarily a dotted square of B37.
- **Mathematical question / distinction:** Optimality (packing) as the flip side of tiling: for 3×3 the answer is below the area bound 3 (B32), for 4×4 and 5×5 it meets it. Simple, concrete, and every case has a different flavour.
- **Minutes:** 6.
- **Needs / opens:** Needs B32. Opens B37 (why the leftover square must be a dot).

### B41 — All L-covers of 2×6 and 3×6
- **Levels:** 2–3 (2×6), 4–5 (3×6, and 2×9 as a prediction).
- **Materials / setup:** Boards 2×6 and 3×6 at 1 inch with the top dot; 6 L's. Recording: 5 mini-boards for 2×6, 9 for 3×6, count boxes, a prediction box for 2×9.
- **Child's action (as printed):** Find every different cover of the 2-by-6 board by L-pieces and draw each. Write how many. Then the 3-by-6 board. Predict the number for 2-by-9.
- **Expected result / answer (verified):** 2×6: 4; 3×6: 8; 2×9: 8 (and 2×3: 2, 3×4: 4, 3×8: 16). Reason for 2×3n: the top-left square's L must lie in the first two columns; if it covers both squares of column 1 the leftover square of column 2 forces an L that completes a 2×3 block; the only other option (top-left, top of column 2, bottom of column 2) leaves the bottom-left square isolated. So the board splits into 2×3 blocks, 2 ways each: 2^n. Verified by `verify_square.py` (counts 2, 4, 8 and 2, 4, 8, 16).
- **Mathematical question / distinction:** Counting with a forcing argument (the board decomposes). Contrast with domino counting (B27), where blocks do not decompose and the numbers are Fibonacci.
- **Minutes:** 8.
- **Needs / opens:** Needs B32. Reserve; opens B46.

### B42 — 4×4 with L's and dominoes together
- **Levels:** 2–3, 4–5.
- **Materials / setup:** Board 4×4; 5 L's, 8 dominoes. Recording: a table "L-pieces / dominoes / possible?" with rows "4 L + 2 dominoes", "2 L + 5 dominoes", "8 dominoes", "L-pieces only", and mini-boards.
- **Child's action (as printed):** Cover the 4-by-4 board with exactly 4 L-pieces and 2 dominoes; draw it. Then with exactly 2 L-pieces and 5 dominoes. Then with 8 dominoes. Then try with L-pieces only. Fill the table. Which numbers of L-pieces are possible?
- **Expected result / answer (verified):** (4 L, 2 D): yes, 96 covers, e.g. `AABB / CCDD / CEDF / EEFF`. (2 L, 5 D): yes, 248 covers, e.g. `AABB / CCDD / EEFF / EGGF`. (0, 8): yes, 36 covers. L-pieces only: no (16 is not a multiple of 3). Possible numbers of L's: 0, 2, 4 (3a + 2b = 16 forces a even). Verified by `verify_square.py` ("Mixed pieces").
- **Mathematical question / distinction:** Existence under an arithmetic constraint (3a + 2b = 16) — the invariant is the equation, and every solution of the equation is realised. Extends B34 to a bigger board.
- **Minutes:** 8.
- **Needs / opens:** Needs B34. Reserve.

## Reserves and extras (B43–B47)

### B43 — Three hexagons in a row
- **Levels:** K–1, 2–3.
- **Materials / setup:** Outline H3 (three hexagons sharing edges, about 5.2 in wide); 3 Y, 6 R, 9 B, 18 G. Recording: a table "yellow / red / blue / green → how many pieces"; small copies labelled 4 and 5.
- **Child's action (as printed):** Cover the three hexagons with yellows only, then reds only, then blues only, then greens only; write the number of pieces each time. Now cover them with exactly 4 pieces, and then with exactly 5 pieces; colour the small copies.
- **Expected result / answer (verified):** 3, 6, 9, 18. Exactly 4 pieces: Y Y R R (yellows on the two ends, two reds in the middle). Exactly 5: Y Y B B B, or Y R R R R. Red-only covers: 27; blue-only: 8; every number of pieces from 3 to 18 is achievable. Verified by `verify_blocks.py` (H3 counts; DP achievable 3–18).
- **Mathematical question / distinction:** Trades tripled (3 : 6 : 9 : 18); a K–1 "how many pieces" region larger than W. Note for B44: chevrons alone cannot cover H3, although they cover W.
- **Minutes:** 6.
- **Needs / opens:** Needs B12. Opens B44.

### B44 — Chevron problems
- **Levels:** 2–3, 4–5 (reserve). **Check the physical piece first**: everything below assumes the chevron is the V made of two rhombi sharing an edge (four consecutive units around one point). If the set's "chevron" is a different shape, drop this problem.
- **Materials / setup:** Outlines H, W, H3, S, H2, R2; 6 chevrons, some B and G. Recording: a table "outline / chevrons only? / how many ways", mini-copies.
- **Child's action (as printed):** Cover the hexagon with one chevron and other pieces; how many different ways with the dot at the top? Cover the twin hexagons with chevrons only. Cover the three-hexagon row with chevrons only. Cover the star with chevrons only. Cover the big hexagon with chevrons only. Cover the side-2 rhombus with chevrons only. Fill the table.
- **Expected result / answer (verified under the shape assumption):** H: a chevron plus a blue, 6 ways; a chevron plus two greens, 6 ways. W: chevrons only, yes, 2 ways (3 chevrons). H3: chevrons only, impossible (18 units, 9/9, but no cover). S: yes, 2 ways (3 chevrons) — so with chevrons the star's fewest-pieces number drops from 6 to 3. H2: yes, 2 ways (6 chevrons; pinwheels). R2: impossible (a chevron's inner corner must sit at a point with four units around it inside the outline; R2 has only its centre point, and two chevrons cannot share it). Verified by `verify_blocks.py` (C-only counts 2, 0, 2, 2, 0 on W, H3, S, H2, R2; C+B and C+G on H).
- **Mathematical question / distinction:** A new piece with a new kind of constraint (its inner corner needs a point with room around it) and a surprising failure (H3 versus W, found by search; no short argument is offered). Reserve for tables that finish the blue/red classification.
- **Minutes:** 8.
- **Needs / opens:** Needs B09, B10. Opens nothing.

### B45 — The side-4 triangle
- **Levels:** 4–5 (reserve).
- **Materials / setup:** Outline T4 (4-inch sides), shaded copy too; 1 Y, 4 R, 8 B, 16 G. Recording: three small dissected copies labelled "blue", "red", "fewest", count boxes.
- **Child's action (as printed):** Try to cover the big triangle with blues only; then with reds only. Write yes or no for each and the white/grey counts. Then cover it with as few pieces as you can and write the number.
- **Expected result / answer (verified):** Blues only: no (10 white / 6 grey). Reds only: no (16 units). Fewest pieces: 5, namely Y + R + R + R + G (3 covers, one per corner): the yellow sits just inside one corner with the green filling that corner's tip, and the three reds fill the strip along the opposite side — one flat in the middle of that side and one slanted piece in each of the two remaining corners. Every number of pieces from 5 to 16 is achievable. Yellow + reds only: impossible. Verified by `verify_blocks.py` (T4: B 0, R 0, Y+R 0, fewest 5 'GRRRY', achievable 5–16).
- **Mathematical question / distinction:** Two impossibilities by two invariants on one region (up/down count; divisibility by 3) and an optimality with a small answer. Compared with T3 (B07, B17): reds work on T3 and fail on T4.
- **Minutes:** 8.
- **Needs / opens:** Needs B08, B17. Reserve.

### B46 — Straight trominoes on 3×n: counting and the rule
- **Levels:** 4–5 (reserve).
- **Materials / setup:** Boards 3×3, 3×4, 3×5, 3×6 at 1 inch with the top dot; 6 straight trominoes. Recording: rows of mini-boards (3, 4, 5, 7) with count boxes; prediction boxes for 3×7 and 3×8.
- **Child's action (as printed):** Find every different cover of the 3-by-3 board by straight pieces and draw each. Then the 3-by-4, the 3-by-5, the 3-by-6. Write the four counts. Predict the counts for 3-by-7 and 3-by-8 and explain your rule to the adult.
- **Expected result / answer (verified):** 2, 3, 4, 6; then 9 and 13 (widths 1–8: 1, 1, 2, 3, 4, 6, 9, 13). Rule: the left column is either one upright piece (board one column shorter) or three flat pieces stacked (board three columns shorter), so each count is the count one step back plus the count three steps back. Verified by `verify_square.py` (appended section "3xn straight trominoes": 1, 1, 2, 3, 4, 6, 9, 13 for widths 1–8).
- **Mathematical question / distinction:** The Fibonacci argument of B27 with a different step (n − 1 and n − 3); the child sees that the same reasoning gives a different rule.
- **Minutes:** 10.
- **Needs / opens:** Needs B27, B33. Reserve.

### B47 — Opposite corners on different boards
- **Levels:** K–1 (the 2×5 board), 2–3 (2×5, 3×4, 4×4), 4–5 (all, with the colour rule).
- **Materials / setup:** Checkerboard-shaded boards 2×5, 3×4, 4×4, 4×5, 6×6, each printed twice: once with the two opposite corners (top-left and bottom-right) crossed out, once with the two corners of one side crossed out (2×5: both top corners; 3×4: both left corners; 4×4: both top corners; 4×5: both top corners; 6×6: both top corners). 17 dominoes. Recording: a table "board / opposite corners: yes-no / same-side corners: yes-no / dark left / light left".
- **Child's action (as printed):** On each board with two crossed corners, cover the rest with dominoes or decide that it cannot be done. Count the dark and light squares that are not crossed out and write them in the table. Find the rule that predicts every yes and no.
- **Expected result / answer (verified):** Opposite corners: 2×5 yes (exactly 1 cover, a forced staircase), 3×4 yes (5 covers), 4×4 no, 4×5 yes (23 covers), 6×6 no. Same-side corners: 2×5 top corners no; 3×4 left corners no (but its two top corners: yes, 6 covers); 4×4 top corners yes (12); 4×5 top corners no (but two corners of a short side: yes, 42); 6×6 top corners yes. Rule: possible exactly when the two crossed squares have different colours (then dark = light remain); "opposite" or "same side" is irrelevant. Verified by `verify_square.py` (appended section "Two corners crossed out": all six corner pairs of 2×5, 3×4, 4×4, 4×5; 6×6 by the exhaustive pair check: every different-colour pair works, every same-colour pair fails).
- **Mathematical question / distinction:** The pattern "opposite corners fail" breaks on the third board, and the colouring, not the geometry, explains all ten cases. A fast route to the invariant for a table that already did B23.
- **Minutes:** 10.
- **Needs / opens:** Needs B22, B23. Opens B26.

---

## Coverage notes for the curator

- **K–1 without reading (adult reads aloud, child builds/colours, adult scribes):** B01, B02, B03, B06, B07, B08, B11 (blue part), B12, B13, B16 (first part), B19, B20, B21, B22, B23, B30 (as a game), B31, B32, B33, B35 (corner hole), B40, B43, B47 (2×5). That is 23 problems; a forty-minute K–1 sequence is e.g. B01 → B02 → B06 → B08 (act only) → B07 → B19 → B20 → B21 → B23 → B32 → B35, with B12, B13, B40, B31 in reserve.
- **Contrasting instances:** can/cannot pairs (B06 red vs blue; B09/B10 across seven outlines; B21 nine holes; B23 three corner pairs; B32/B33 L vs straight on 3×3; B35/B37/B38 sizes 4, 5, 8; B47 five boards). Sizes 2–3–4–5: B27 (2×2…2×5), B46 (3×3…3×6), B35/B37/B38, B06/B07/B45 (triangles 2, 3, 4). Different starts: B29 (flips from all-vertical), B15/B16 (cube counts), B36 (three holes).
- **Toward an argument:** parity (B20), checkerboard (B22 → B23 → B24 → B25 → B47), Gomory loop (B26), up/down (B08 → B09), trapped points (B10 → B11), corner/dot counts (B32 → B37), three-colouring (B39), recursion (B27, B41, B46), lower bounds (B14, B29, B30), symmetry strategy (B31), induction (B36 → B38).
- **Pure doing / recording:** B01, B12, B13, B19, B33, B40, B43.
- **Reserves for fast finishers:** K–1: B12, B13, B40, B31, B43. 2–3: B05, B28, B41, B42, B44. 4–5: B15, B18, B28 (3×4), B31 (4×4 strategy), B44, B45, B46.
- **Materials totals if everything were printed (per child, upper bounds):** 24 G, 12 B, 8 R, 3 Y, 6 C pattern blocks; paper pieces 18 dominoes, 8 L-trominoes, 8 straight trominoes (21 L's drawn in pencil for B38, not cut). All boards fit US Letter at 1 inch except 8×8 (see B25/B38).
