#!/usr/bin/env python3
"""Verification for the square-grid problems in bank.md (Week 1, tilings).

Exact-cover search over polyomino placements on small boards.
Run:  python3 verify_square.py   (prints every fact quoted in bank.md)
"""
import sys
from functools import lru_cache
from collections import deque

sys.setrecursionlimit(10000)

# ---------- shapes ----------
def normalize(cells):
    mx = min(x for x, y in cells); my = min(y for x, y in cells)
    return frozenset((x - mx, y - my) for x, y in cells)

def orientations(shape):
    out = set()
    cells = list(shape)
    for _ in range(4):
        cells = [(y, -x) for x, y in cells]          # rotate 90 degrees
        out.add(normalize(cells))
        out.add(normalize([(-x, y) for x, y in cells]))  # mirror
    return sorted(out, key=sorted)

DOMINO = frozenset({(0, 0), (0, 1)})
L3 = frozenset({(0, 0), (1, 0), (0, 1)})       # L-tromino
I3 = frozenset({(0, 0), (0, 1), (0, 2)})       # straight tromino

def rect(r, c):
    return frozenset((i, j) for i in range(r) for j in range(c))

def minus(board, *cells):
    b = set(board)
    for c in cells:
        b.remove(c)
    return frozenset(b)

# ---------- exact cover ----------
def placements_covering(board, cell, orients):
    """All placements (frozensets of cells inside board) that cover `cell`."""
    res = set()
    for o in orients:
        for (ax, ay) in o:
            dx, dy = cell[0] - ax, cell[1] - ay
            p = frozenset((x + dx, y + dy) for x, y in o)
            if p <= board:
                res.add(p)
    return res

def count_tilings(board, shapes, cap=None):
    """Number of tilings of `board` by copies of the given shapes (all
    rotations/reflections allowed). Memoised on the uncovered set.
    If cap is given, stop counting beyond cap (existence tests)."""
    orients = []
    for s in shapes:
        orients += orientations(s)
    orients = list(set(orients))
    board = frozenset(board)

    @lru_cache(maxsize=None)
    def go(uncovered):
        if not uncovered:
            return 1
        cell = min(uncovered)
        total = 0
        for p in placements_covering(uncovered, cell, orients):
            total += go(uncovered - p)
            if cap is not None and total >= cap:
                return total
        return total
    return go(board)

def all_tilings(board, shapes):
    """List every tiling as a frozenset of placements (small boards only)."""
    orients = []
    for s in shapes:
        orients += orientations(s)
    orients = list(set(orients))
    out = []
    def go(uncovered, chosen):
        if not uncovered:
            out.append(frozenset(chosen)); return
        cell = min(uncovered)
        for p in placements_covering(uncovered, cell, orients):
            chosen.append(p); go(uncovered - p, chosen); chosen.pop()
    go(frozenset(board), [])
    return out

def tileable(board, shapes):
    return count_tilings(board, shapes, cap=1) > 0

def show_map(r, c, f):
    return "\n".join("".join(f(i, j) for j in range(c)) for i in range(r))

# ---------- report ----------
def section(t):
    print("\n=== " + t + " ===")

section("Domino tilings of rectangles (existence / counts)")
for r, c in [(2, 1), (2, 2), (2, 3), (2, 4), (2, 5), (2, 6), (2, 7), (3, 3), (3, 4), (4, 4), (5, 5), (4, 6), (6, 6)]:
    print(f"{r}x{c}: {count_tilings(rect(r, c), [DOMINO])} domino tilings")

section("3x3 minus one cell, dominoes: which cell can be removed?")
b = rect(3, 3)
print(show_map(3, 3, lambda i, j: "Y" if tileable(minus(b, (i, j)), [DOMINO]) else "."))
for cell in [(0, 0), (1, 1), (0, 1)]:
    print(f"  remove {cell}: {count_tilings(minus(b, cell), [DOMINO])} tilings")

section("5x5 minus one cell, dominoes: which cell can be removed? (count of tilings)")
b = rect(5, 5)
print(show_map(5, 5, lambda i, j: "Y" if tileable(minus(b, (i, j)), [DOMINO]) else "."))
print("counts per removed cell:")
for i in range(5):
    print("  " + " ".join(f"{count_tilings(minus(b, (i, j)), [DOMINO]):4d}" for j in range(5)))

section("4x4 minus two cells, dominoes")
b = rect(4, 4)
print("opposite corners (0,0),(3,3):", count_tilings(minus(b, (0, 0), (3, 3)), [DOMINO]))
print("adjacent corners (0,0),(0,3):", count_tilings(minus(b, (0, 0), (0, 3)), [DOMINO]))
print("corner + neighbour (0,0),(0,1):", count_tilings(minus(b, (0, 0), (0, 1)), [DOMINO]))
print("corner (0,0) + centre-ish (1,2):", count_tilings(minus(b, (0, 0), (1, 2)), [DOMINO]))
print("two centre cells same colour (1,1),(2,2):", count_tilings(minus(b, (1, 1), (2, 2)), [DOMINO]))
# Gomory-type check: every (dark, light) pair removal is tileable; every same-colour pair is not
def gomory_check(n):
    b = rect(n, n)
    cells = sorted(b)
    ok_diff = bad_diff = ok_same = bad_same = 0
    for a in cells:
        for c in cells:
            if a >= c: continue
            t = tileable(minus(b, a, c), [DOMINO])
            same = (a[0] + a[1]) % 2 == (c[0] + c[1]) % 2
            if same:
                if t: ok_same += 1
                else: bad_same += 1
            else:
                if t: ok_diff += 1
                else: bad_diff += 1
    print(f"{n}x{n}: different-colour pairs tileable {ok_diff}, not tileable {bad_diff}; "
          f"same-colour pairs tileable {ok_same}, not tileable {bad_same}")
gomory_check(4)
gomory_check(6)

section("6x6 and 8x8 minus opposite corners, dominoes")
print("6x6 minus (0,0),(5,5):", count_tilings(minus(rect(6, 6), (0, 0), (5, 5)), [DOMINO], cap=1))
print("8x8 minus (0,0),(7,7):", count_tilings(minus(rect(8, 8), (0, 0), (7, 7)), [DOMINO], cap=1))
print("8x8 full board domino tilings:", count_tilings(rect(8, 8), [DOMINO]))

section("L-trominoes")
print("2x3:", count_tilings(rect(2, 3), [L3]), "tilings")
print("3x3:", count_tilings(rect(3, 3), [L3]), "tilings")
print("2x6:", count_tilings(rect(2, 6), [L3]), "tilings")
print("3x6:", count_tilings(rect(3, 6), [L3]), "tilings")
print("4x6:", count_tilings(rect(4, 6), [L3]), "tilings (exists)")
b = rect(2, 2)
print("2x2 minus each cell:", [count_tilings(minus(b, c), [L3]) for c in sorted(b)])
b = rect(4, 4)
print("4x4 minus one cell: number of L-tilings by removed cell")
for i in range(4):
    print("  " + " ".join(f"{count_tilings(minus(b, (i, j)), [L3]):3d}" for j in range(4)))
b = rect(5, 5)
print("5x5 minus one cell: number of L-tilings by removed cell (0 = impossible)")
for i in range(5):
    print("  " + " ".join(f"{count_tilings(minus(b, (i, j)), [L3]):5d}" for j in range(5)))
b = rect(8, 8)
res = [[tileable(minus(b, (i, j)), [L3]) for j in range(8)] for i in range(8)]
print("8x8 minus one cell: all 64 positions L-tileable?", all(all(r) for r in res))
b = rect(7, 7)
print("7x7 minus one cell: which positions L-tileable?")
print(show_map(7, 7, lambda i, j: "Y" if tileable(minus(b, (i, j)), [L3]) else "."))

section("Maximum number of L-trominoes that fit (non-overlapping)")
def max_pieces(board, shape):
    orients = orientations(shape)
    board = frozenset(board)
    best = 0
    @lru_cache(maxsize=None)
    def go(uncovered):
        # max pieces placeable in `uncovered`; either leave min cell empty or cover it
        if not uncovered: return 0
        cell = min(uncovered)
        best = go(uncovered - {cell})
        for p in placements_covering(uncovered, cell, orients):
            best = max(best, 1 + go(uncovered - p))
        return best
    return go(board)
for r, c in [(2, 2), (2, 3), (2, 4), (3, 3), (3, 4), (4, 4), (5, 5)]:
    print(f"{r}x{c}: max L-trominoes = {max_pieces(rect(r, c), L3)}, max dominoes = {max_pieces(rect(r, c), DOMINO)}")

section("Straight trominoes")
for r, c in [(2, 3), (2, 4), (2, 6), (3, 3), (3, 4), (3, 5), (3, 6), (4, 4), (4, 6), (5, 5), (6, 6)]:
    print(f"{r}x{c}: {count_tilings(rect(r, c), [I3])} straight-tromino tilings")
b = rect(4, 4)
print("4x4 minus one cell: straight-tromino tilings by removed cell")
for i in range(4):
    print("  " + " ".join(f"{count_tilings(minus(b, (i, j)), [I3]):3d}" for j in range(4)))
b = rect(5, 5)
print("5x5 minus one cell: straight-tromino tilings by removed cell")
for i in range(5):
    print("  " + " ".join(f"{count_tilings(minus(b, (i, j)), [I3]):4d}" for j in range(5)))
b = rect(8, 8)
print("8x8 minus one cell: which positions straight-tromino tileable?")
print(show_map(8, 8, lambda i, j: "Y" if tileable(minus(b, (i, j)), [I3]) else "."))
print("3-colouring counts (i+j) mod 3 on 5x5:", [sum(1 for i in range(5) for j in range(5) if (i + j) % 3 == k) for k in range(3)])
print("3-colouring counts (i-j) mod 3 on 5x5:", [sum(1 for i in range(5) for j in range(5) if (i - j) % 3 == k) for k in range(3)])
print("3-colouring counts (i+j) mod 3 on 4x4:", [sum(1 for i in range(4) for j in range(4) if (i + j) % 3 == k) for k in range(3)])
print("3-colouring counts (i+j) mod 3 on 8x8:", [sum(1 for i in range(8) for j in range(8) if (i + j) % 3 == k) for k in range(3)])

section("Mixed pieces")
print("4x4 with 4 L-trominoes + 2 dominoes (any mix counted):", count_tilings(rect(4, 4), [L3, DOMINO]), "tilings by L's and dominoes together")
def count_with_exact(board, shapes_counts):
    """tilings using exactly the given multiset of shapes: shapes_counts = [(shape, k), ...]"""
    orients_by = [(list(set(orientations(s))), k) for s, k in shapes_counts]
    board = frozenset(board)
    @lru_cache(maxsize=None)
    def go(uncovered, counts):
        if not uncovered: return 1 if all(c == 0 for c in counts) else 0
        cell = min(uncovered); total = 0
        for idx, (orients, _) in enumerate(orients_by):
            if counts[idx] == 0: continue
            nc = list(counts); nc[idx] -= 1; nc = tuple(nc)
            for p in placements_covering(uncovered, cell, orients):
                total += go(uncovered - p, nc)
        return total
    return go(board, tuple(k for _, k in shapes_counts))
print("4x4 with exactly 4 L + 2 dominoes:", count_with_exact(rect(4, 4), [(L3, 4), (DOMINO, 2)]))
print("3x3 with exactly 2 L + 1 straight:", count_with_exact(rect(3, 3), [(L3, 2), (I3, 1)]))
print("3x3 with exactly 1 L + 2 straight:", count_with_exact(rect(3, 3), [(L3, 1), (I3, 2)]))
print("3x3 with 1 L + 3 dominoes:", count_with_exact(rect(3, 3), [(L3, 1), (DOMINO, 3)]))
print("3x3 with 1 straight + 3 dominoes:", count_with_exact(rect(3, 3), [(I3, 1), (DOMINO, 3)]))
print("3x3 with 3 L + 0:", count_with_exact(rect(3, 3), [(L3, 3)]))
print("4x4 with 2 L + 5 dominoes:", count_with_exact(rect(4, 4), [(L3, 2), (DOMINO, 5)]))

section("Fewest dominoes that block the board (minimum maximal matching)")
def min_blocking(r, c):
    board = sorted(rect(r, c))
    n = len(board)
    idx = {cell: k for k, cell in enumerate(board)}
    adj = {cell: [nb for nb in [(cell[0] + 1, cell[1]), (cell[0] - 1, cell[1]), (cell[0], cell[1] + 1), (cell[0], cell[1] - 1)] if nb in idx] for cell in board}
    best = [None, None]
    # enumerate independent sets S (uncovered cells) of even complement, check complement tileable
    def rec(k, chosen, blocked):
        if k == n:
            comp = frozenset(set(board) - set(chosen))
            if len(comp) % 2 == 0 and tileable(comp, [DOMINO]):
                m = len(comp) // 2
                if best[0] is None or m < best[0]:
                    best[0] = m; best[1] = list(chosen)
            return
        cell = board[k]
        rec(k + 1, chosen, blocked)
        if cell not in blocked:
            nb = set(blocked); nb.update(adj[cell]); nb.add(cell)
            chosen.append(cell); rec(k + 1, chosen, nb); chosen.pop()
    rec(0, [], set())
    return best
for r, c in [(2, 2), (2, 3), (2, 4), (3, 3), (3, 4), (4, 4), (5, 5)]:
    m, free = min_blocking(r, c)
    print(f"{r}x{c}: fewest blocking dominoes = {m}; uncovered cells e.g. {free}")

section("Domino flips (rotate two parallel dominoes forming a 2x2 square)")
def flips_of(tiling):
    """tilings reachable by one flip"""
    out = []
    pl = list(tiling)
    for a in pl:
        for b in pl:
            if a >= b: continue
            cells = a | b
            xs = {x for x, y in cells}; ys = {y for x, y in cells}
            if len(xs) == 2 and len(ys) == 2 and len(cells) == 4 \
                    and max(xs) == min(xs) + 1 and max(ys) == min(ys) + 1:
                # a,b parallel and form a 2x2 square: flip
                (x0, x1), (y0, y1) = sorted(xs), sorted(ys)
                if a == frozenset({(x0, y0), (x0, y1)}) or a == frozenset({(x1, y0), (x1, y1)}):
                    na, nb = frozenset({(x0, y0), (x1, y0)}), frozenset({(x0, y1), (x1, y1)})
                else:
                    na, nb = frozenset({(x0, y0), (x0, y1)}), frozenset({(x1, y0), (x1, y1)})
                out.append((tiling - {a, b}) | {na, nb})
    return out
def flip_report(r, c):
    T = all_tilings(rect(r, c), [DOMINO])
    Tset = set(T)
    no_flip = [t for t in T if not flips_of(t)]
    vert = frozenset(frozenset({(i, j), (i + 1, j)}) for i in range(0, r, 2) for j in range(c)) if r % 2 == 0 else None
    horiz = frozenset(frozenset({(i, j), (i, j + 1)}) for i in range(r) for j in range(0, c, 2)) if c % 2 == 0 else None
    # BFS from all-vertical
    start = vert if vert is not None else horiz
    dist = {start: 0}; dq = deque([start])
    while dq:
        t = dq.popleft()
        for u in flips_of(t):
            if u not in dist:
                dist[u] = dist[t] + 1; dq.append(u)
    msg = f"{r}x{c}: {len(T)} tilings; tilings with no flip: {len(no_flip)}; flip graph connected: {len(dist) == len(T)}; max flip distance from start: {max(dist.values())}"
    if vert is not None and horiz is not None:
        msg += f"; all-vertical -> all-horizontal in {dist[horiz]} flips"
    print(msg)
for r, c in [(2, 2), (2, 3), (2, 4), (2, 5), (3, 4), (4, 4), (4, 6), (6, 6)]:
    flip_report(r, c)

section("Hamiltonian cycle (a loop through all cells) on 4x4 and 6x6 boards")
def ham_cycle(n):
    cells = sorted(rect(n, n))
    start = (0, 0)
    path = [start]; seen = {start}
    def nb(c):
        return [d for d in [(c[0] + 1, c[1]), (c[0] - 1, c[1]), (c[0], c[1] + 1), (c[0], c[1] - 1)] if d in cells]
    def rec():
        if len(path) == n * n:
            return start in nb(path[-1])
        for d in nb(path[-1]):
            if d not in seen:
                seen.add(d); path.append(d)
                if rec(): return True
                path.pop(); seen.remove(d)
        return False
    return path if rec() else None
for n in [4, 6]:
    p = ham_cycle(n)
    print(f"{n}x{n}: loop exists: {p is not None}; e.g. {p}")

section("Cram: two players alternately place a domino (either direction); a player who cannot move loses")
def cram_first_player_wins(r, c):
    board = frozenset(rect(r, c))
    orients = orientations(DOMINO)
    @lru_cache(maxsize=None)
    def win(uncovered):
        for cell in uncovered:
            for p in placements_covering(uncovered, cell, orients):
                if not win(uncovered - p):
                    return True
        return False
    return win(board)
for r, c in [(2, 2), (2, 3), (3, 3), (2, 4), (3, 4), (4, 4), (3, 5)]:
    print(f"{r}x{c}: first player wins? {cram_first_player_wins(r, c)}")

print("\nDONE verify_square.py")

# ---------- appended checks quoted in bank.md (B41, B46, B47) ----------
section("3xn straight trominoes and 2x3n / 3x2n L-trominoes (B46, B41)")
print("3xn straight-tromino tilings, n=1..8:", [count_tilings(rect(3, n), [I3]) for n in range(1, 9)])
print("2x3n L-tromino tilings, n=1,2,3:", [count_tilings(rect(2, n), [L3]) for n in (3, 6, 9)])
print("3x2n L-tromino tilings, n=1..4:", [count_tilings(rect(3, n), [L3]) for n in (2, 4, 6, 8)])

section("Two corners crossed out on rectangular boards (B47)")
from itertools import combinations
for r, c in [(2, 5), (3, 4), (4, 4), (4, 5)]:
    corners = [(0, 0), (0, c - 1), (r - 1, 0), (r - 1, c - 1)]
    for a, b2 in combinations(corners, 2):
        same = (sum(a) + sum(b2)) % 2 == 0
        print(f"{r}x{c} minus {a},{b2}: same colour={same}; domino tilings={count_tilings(minus(rect(r, c), a, b2), [DOMINO])}")
print("6x6 minus top corners (0,0),(0,5):", count_tilings(minus(rect(6, 6), (0, 0), (0, 5)), [DOMINO], cap=1), "(exists)")
print("\nDONE appended checks")
