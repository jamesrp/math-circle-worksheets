#!/usr/bin/env python3
"""Explicit example tilings (letter grids) for the answers quoted in bank.md.
Each grid: rows top to bottom; '.' = removed cell; same letter = same piece."""
src = open('verify_square.py').read().split('# ---------- report ----------')[0]
ns = {}; exec(src, ns)
rect, minus, orientations, placements_covering = ns['rect'], ns['minus'], ns['orientations'], ns['placements_covering']
DOMINO, L3, I3 = ns['DOMINO'], ns['L3'], ns['I3']

def one_tiling(board, shapes, exact=None):
    """first tiling found; exact = dict shape->count to enforce a multiset"""
    orients = []
    for s in shapes:
        for o in orientations(s): orients.append((o, s))
    orients = list(set(orients))
    sol = []
    counts = dict(exact) if exact else None
    def go(unc):
        if not unc: return True
        cell = min(unc)
        for o, s in orients:
            if counts is not None and counts[s] == 0: continue
            for p in placements_covering(unc, cell, [o]):
                sol.append(p)
                if counts is not None: counts[s] -= 1
                if go(unc - p): return True
                sol.pop()
                if counts is not None: counts[s] += 1
        return False
    return sol if go(frozenset(board)) else None

def grid(r, c, board, sol, letters="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"):
    lab = {}
    for k, p in enumerate(sol):
        for cell in p: lab[cell] = letters[k % len(letters)]
    return "\n".join("".join(lab.get((i, j), '.' if (i, j) not in board else '?') for j in range(c)) for i in range(r))

def show(title, r, c, board, shapes, exact=None):
    sol = one_tiling(board, shapes, exact)
    print(f"\n# {title}")
    print(grid(r, c, board, sol) if sol else "  (no tiling)")

show("3x3 minus centre, dominoes (one of 2)", 3, 3, minus(rect(3, 3), (1, 1)), [DOMINO])
show("3x3 minus corner, dominoes (one of 4)", 3, 3, minus(rect(3, 3), (0, 0)), [DOMINO])
show("4x4 minus adjacent corners (0,0),(0,3), dominoes (one of 12)", 4, 4, minus(rect(4, 4), (0, 0), (0, 3)), [DOMINO])
show("4x4 minus (0,0) and (1,2) (one dark, one light), dominoes", 4, 4, minus(rect(4, 4), (0, 0), (1, 2)), [DOMINO])
show("5x5 minus corner, dominoes", 5, 5, minus(rect(5, 5), (0, 0)), [DOMINO])
show("5x5 minus centre, dominoes", 5, 5, minus(rect(5, 5), (2, 2)), [DOMINO])
show("5x5 minus (1,1), dominoes", 5, 5, minus(rect(5, 5), (1, 1)), [DOMINO])
show("2x3, L-trominoes (tiling 1)", 2, 3, rect(2, 3), [L3])
show("4x4 minus corner (0,0), L-trominoes (unique)", 4, 4, minus(rect(4, 4), (0, 0)), [L3])
show("4x4 minus edge cell (0,1), L-trominoes (unique)", 4, 4, minus(rect(4, 4), (0, 1)), [L3])
show("4x4 minus inner cell (1,1), L-trominoes (unique)", 4, 4, minus(rect(4, 4), (1, 1)), [L3])
show("4x4 minus (1,2), L-trominoes (unique)", 4, 4, minus(rect(4, 4), (1, 2)), [L3])
show("5x5 minus corner (0,0), L-trominoes (one of 8)", 5, 5, minus(rect(5, 5), (0, 0)), [L3])
show("5x5 minus edge-middle (0,2), L-trominoes (one of 16)", 5, 5, minus(rect(5, 5), (0, 2)), [L3])
show("5x5 minus centre (2,2), L-trominoes (one of 32)", 5, 5, minus(rect(5, 5), (2, 2)), [L3])
show("5x5 minus (0,4)... corner (4,4) L-trominoes (one of 8)", 5, 5, minus(rect(5, 5), (4, 4)), [L3])
show("2x6, L-trominoes (one of 4)", 2, 6, rect(2, 6), [L3])
show("3x6, L-trominoes (one of 8)", 3, 6, rect(3, 6), [L3])
show("3x3, straight trominoes (one of 2)", 3, 3, rect(3, 3), [I3])
show("3x4, straight trominoes (one of 3)", 3, 4, rect(3, 4), [I3])
show("3x5, straight trominoes (one of 4)", 3, 5, rect(3, 5), [I3])
show("4x4 minus corner, straight trominoes (one of 4)", 4, 4, minus(rect(4, 4), (0, 0)), [I3])
show("5x5 minus centre, straight trominoes (one of 2)", 5, 5, minus(rect(5, 5), (2, 2)), [I3])
show("6x6, straight trominoes (one of 64)", 6, 6, rect(6, 6), [I3])
show("3x3 with 2 L + 1 straight (one of 8)", 3, 3, rect(3, 3), [L3, I3], {L3: 2, I3: 1})
show("3x3 with 1 L + 3 dominoes (one of 8)", 3, 3, rect(3, 3), [L3, DOMINO], {L3: 1, DOMINO: 3})
show("3x3 with 1 straight + 3 dominoes (one of 12)", 3, 3, rect(3, 3), [I3, DOMINO], {I3: 1, DOMINO: 3})
show("4x4 with 4 L + 2 dominoes (one of 96)", 4, 4, rect(4, 4), [L3, DOMINO], {L3: 4, DOMINO: 2})
show("4x4 with 2 L + 5 dominoes (one of 248)", 4, 4, rect(4, 4), [L3, DOMINO], {L3: 2, DOMINO: 5})

# 8x8 minus a corner by the quadrant construction (recursive), then verify it is a tiling
def deficient(n, hole, offset=(0, 0)):
    """L-tromino tiling of the n x n board (n power of 2) minus `hole`, by the induction."""
    ox, oy = offset
    if n == 2:
        return [frozenset((ox + i, oy + j) for i in range(2) for j in range(2) if (ox + i, oy + j) != hole)]
    h = n // 2
    quads = [(ox, oy), (ox, oy + h), (ox + h, oy), (ox + h, oy + h)]
    # which quadrant holds the hole
    qi = [k for k, (qx, qy) in enumerate(quads) if qx <= hole[0] < qx + h and qy <= hole[1] < qy + h][0]
    # central cells: the cell of each quadrant nearest the centre
    centre_cells = [(ox + h - 1, oy + h - 1), (ox + h - 1, oy + h), (ox + h, oy + h - 1), (ox + h, oy + h)]
    central_L = frozenset(c for k, c in enumerate(centre_cells) if k != qi)
    pieces = [central_L]
    for k, (qx, qy) in enumerate(quads):
        sub_hole = hole if k == qi else centre_cells[k]
        pieces += deficient(h, sub_hole, (qx, qy))
    return pieces
for hole in [(0, 0), (3, 4), (5, 1)]:
    sol = deficient(8, hole)
    b = minus(rect(8, 8), hole)
    assert set().union(*sol) == set(b) and sum(len(p) for p in sol) == 63 and len(sol) == 21
    print(f"\n# 8x8 minus {hole}, L-trominoes by the quadrant construction (21 pieces)")
    print(grid(8, 8, b, sol))
sol = deficient(4, (1, 2))
print("\n# 4x4 minus (1,2) by the quadrant construction (must equal the unique tiling above)")
print(grid(4, 4, minus(rect(4, 4), (1, 2)), sol))

# fewest blocking dominoes: show configurations
def show_block(r, c, free):
    b = frozenset(set(rect(r, c)) - set(free))
    sol = one_tiling(b, [DOMINO])
    print(f"\n# {r}x{c} blocked by {len(sol)} dominoes (uncovered cells marked .)")
    print(grid(r, c, b, sol))
show_block(2, 3, [(0, 2), (1, 0)])
show_block(2, 4, [(1, 0), (1, 3)])
show_block(3, 3, [(0, 2), (1, 0), (2, 2)])
show_block(3, 4, [(0, 3), (1, 1), (2, 0), (2, 3)])
show_block(4, 4, [(1, 3), (2, 1), (3, 0), (3, 3)])
show_block(5, 5, [(1, 1), (1, 4), (2, 0), (2, 3), (3, 2), (4, 0), (4, 4)])

# 4x4 all-vertical to all-horizontal in 4 flips: explicit sequence (flip each 2x2 block)
print("\n# 4x4: flip the four 2x2 blocks one at a time: 4 flips (minimum, since each flip changes 2 of the 8 dominoes)")
# all 36 tilings of 4x4 listed compactly? just count by number of horizontal dominoes
T = ns['all_tilings'](rect(4, 4), [DOMINO])
from collections import Counter
print("4x4 domino tilings by number of horizontal dominoes:", sorted(Counter(sum(1 for p in t if len({x for x, y in p}) == 1) for t in T).items()))
T = ns['all_tilings'](rect(3, 4), [DOMINO])
print("3x4 domino tilings by number of horizontal dominoes:", sorted(Counter(sum(1 for p in t if len({x for x, y in p}) == 1) for t in T).items()))
T = ns['all_tilings'](rect(2, 4), [DOMINO])
print("2x4 domino tilings, all 5:")
for t in T: print(grid(2, 4, rect(2, 4), sorted(t, key=min)), "\n")
print("DONE verify_solutions.py")
