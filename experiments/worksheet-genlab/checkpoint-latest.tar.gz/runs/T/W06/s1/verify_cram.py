#!/usr/bin/env python3
"""Cram (take turns placing a domino; no move = you lose) on small boards: winning moves and replies."""
from functools import lru_cache
def placements(r, c):
    out = []
    for i in range(r):
        for j in range(c):
            if j + 1 < c: out.append(frozenset({(i, j), (i, j + 1)}))
            if i + 1 < r: out.append(frozenset({(i, j), (i + 1, j)}))
    return out
def analyse(r, c):
    P = placements(r, c)
    @lru_cache(maxsize=None)
    def win(unc):
        return any(not win(unc - p) for p in P if p <= unc)
    board = frozenset((i, j) for i in range(r) for j in range(c))
    print(f"\n{r}x{c}: first player wins? {win(board)}")
    if win(board):
        print("  winning first moves:", [sorted(p) for p in P if not win(board - p)])
    else:
        for p in P:
            rest = board - p
            replies = [sorted(q) for q in P if q <= rest and not win(rest - q)]
            print(f"  after first move {sorted(p)}: winning replies {replies}")
for r, c in [(2, 3), (3, 3), (2, 4), (3, 4), (4, 4)]:
    analyse(r, c)
