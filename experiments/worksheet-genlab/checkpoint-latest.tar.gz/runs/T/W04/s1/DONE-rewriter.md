Revised the Week 1 tilings packet in place; previous sources preserved in before-rewrite/. All four .tex files compile cleanly (K-1 9 pp, grades 2-3 8 pp, grades 4-5 13 pp, facilitator 18 pp); every page rendered and checked.
Addressed all 20 review points, none rejected: tromino/domino boards at the 0.58-in piece scale, map as its own problem with two blank test boards, piece counts fixed, K-1 P11 restricted to the five standard shapes, board D asks only for a check or X, checks recorded as well as X's, comb-loop and hexagon arguments corrected.
Added real instances with verified answers: K-1 shape J (5 up/5 down, three coverings) as the check case of predict-then-try; grades 4-5 board R (3/3, exactly one covering) beside S.
Grades 4-5 renumbered in page order (1-8, trominoes 9-10, 2-by-n 11, 5-by-5 boards 12, map 13, Y 14) with every guide reference updated; ordered hints added to five guide problems; timing and skip notes added.
Wording fixes (trapezoid orientations, trace-and-lift, result columns), larger K-1 hexagons, better recording spaces, Z figure and section 8 layout fixed.
Facts verified by exhaustive search before printing (R, S, J, 4-by-4 vertical-domino parity, side-4 triangle minimum of 5 pieces with or without chevrons).
Small departures noted in changes.md: a box instead of a rule for board D, three lines under Problem 8, letter J rather than I, two blank boards on the map page.
Nothing left unresolved.
