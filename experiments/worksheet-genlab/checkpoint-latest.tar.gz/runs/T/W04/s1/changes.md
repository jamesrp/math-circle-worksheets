# Changes to the Week 1 (Tilings) packet — rewriter stage

The previous version is preserved in `before-rewrite/` (the four `.tex` sources plus `week-boards.tex` and `genlab-common.tex`, which they `\input`). All four files recompile with `pdflatex -interaction=nonstopmode` without errors or overfull boxes; every page was rendered and checked. Page counts: K–1 9 (was 8), grades 2–3 8, grades 4–5 13 (was 11), facilitator 18 (was 19 with the half-empty pages).

Every new fact was checked by exhaustive search before printing: board R has 3 dark and 3 light squares and exactly one domino covering, board S has 3 and 3 and none; shape J (two rows of five) has 5 up and 5 down triangles and 3 rhombus coverings; a 4-by-4 board has domino tilings with 0, 2, 4, 6 or 8 vertical dominoes only (1, 9, 16, 9, 1 of them); the side-4 triangle needs 5 pattern-block pieces, with or without chevrons; the hexagon has 2 coverings.

## Review items addressed (all 20)

1. **Scale of the tromino/domino boards (grades 4–5).** The 5-by-5 boards now print at 0.58 in (two per row, two rows) as Problem 12; the ✓/× map is a separate Problem 13 at 0.4-in cells, on its own page, with two blank 5-by-5 boards (e), (f) at 0.58 in so the child can test squares beyond (a)–(d). Problem 8's boards V, W (side by side) and X (centered on its own line) print at 0.58 in. The guide notes which boards can be covered with the envelope pieces and which are drawn.
2. **Paper-piece counts.** §2 now says 50 dominoes and 30 L-trominoes (16 and 10 per child, extras with the adult), that X needs 17 dominoes and Z 21 trominoes, and that T, U, Y, Z are drawn on.
3. **K–1 Problem 11.** Student text: "Cover it with green, blue, red, yellow and purple pieces, any mix you like." §2 says to keep the nonstandard pieces in the tub; the "child-sized reason" now ends with the hexagon-or-chevron case and says the proof is the search.
4. **Grades 4–5 Problem 1 board D.** Now "Write ✓ in the box marked D if you did it and × if you could not", with a small labelled box instead of two ruled lines (a box reads better for a single mark than a full-width rule; cf. item 14). The parity argument stays in the guide, flagged "for the adult" and pointed to from the early-finish list.
5. **✓ as well as ×.** Problem 2 and Problem 12 (old 13) now ask for ✓ or × under every board.
6. **Comb loop.** Described as back and forth along the rows using every column but the first, then up the first column; even number of rows.
7. **Hexagon two-ways argument.** Replaced by the six-spokes / no-two-neighbouring-spokes argument.
8. **K–1 Problem 8.** Shape J (two rows of five, `\GridH\OutlineH`) added with its own colored/white boxes and J guess / J try boxes; the box labels carry the letter and the text names them. Guide: J 5/5, guess ✓, confirmed ✓, with a shaded figure and one covering. Problems 9–11 moved to pages 8–9 (P9 and P10 together, P11 alone with the big triangle).
9. **Grades 4–5 Problem 6.** Board R added (macros `\BoardR`, `\BoardRshade`, `\DomTilingR` in `week-boards.tex`), printed left of S with a two-row table (dark, light, ✓ or ×) and the explanation lines. Guide gives R's counts, its unique covering (figure) and why the end squares force it; hint (3) asks why S fails where R does not. Problem 7 moved to its own page to make room.
10. **Grades 2–3 Problem 4.** Trapezoid "long side at the bottom / at the top", green "pointing up / pointing down", hexagon; "so that it covers whole small triangles exactly" added; table rows renamed. Guide answer rows match.
11. **"Write what happened."** Now "write ✓ or × in the result column" in grades 2–3 Problems 6 and 7 and grades 4–5 Problem 5.
12. **Problem 8 layout.** V and W in one `tabular`, X centered below it.
13. **K–1 Problem 6.** "Trace around the rhombus with your pencil, lift it, and count ..."; guide line about tracing and lifting added.
14. **Grades 2–3 Problem 3.** The full-width rule is replaced by "boards □ and □"; the boxes sit beside the table (the page overflowed with them underneath), and the table's row height was reduced a little.
15. **Recording space.** Problem 7 has "T □" with two lines and "U □" with two lines; Problem 11 (old 12) has four lines.
16. **Numbering = page order (grades 4–5).** New order 1–8, 9 (4-by-4 trominoes), 10 (Z), 11 (2-by-n), 12 (5-by-5 boards), 13 (map), 14 (Y). Every reference in the guide updated (§2, §6 order line and headings, the plan-of-Problem cross-references, stall and early-finish lists, §8).
17. **Ordered hints** added to §5 Problem 5, §5 Problem 9, §6 Problem 4, §6 Problem 7, §6 Problem 9 (old 10); also a hint list for the new map problem.
18. **K–1 Problem 9** hexagons at `\tri=0.8in`.
19. **Guide layout.** The Z figure is set at 0.22 in and placed before its Answer paragraph; the Gomory paragraph was folded into the "Tilings are perfect matchings" paragraph and §8 tightened by a few words so it ends on page 15 and the appendix follows directly.
20. **Timing.** §6 states the realistic 50-minute total, that U's covering drawing may be skipped, and that Problem 10 reached with under 7 minutes left ends after the first tromino and one quarter; Problem 6 gets 4 minutes, Problem 8 gets 8. K–1 Problem 8 is now 6 minutes (two shapes).

## Small departures from the review's wording

- Item 1: the map page also carries two blank 5-by-5 boards (e), (f), because the four boards of Problem 12 settle only four of the six kinds of square and the child needs somewhere to test the others; the guide says which two to test and how to fill the rest by symmetry.
- Item 1/12: the explanation under Problem 8 has three ruled lines rather than four; with V, W and X at 0.58 in a fourth line does not fit the page.
- Item 4: a labelled box rather than a single ruled line, for the reason above.
- Item 8: the new K–1 shape is called J (not I) so that it is not confused with the numeral 1; the guide says so.

## Review points rejected

None.
