Wrote review.md: 20 numbered required changes (location, issue, exact change) plus a keep-as-is list; the packet itself was not edited.
Recomputed every answer, count and drawn figure by exhaustive search and recompiled all four sources: no mathematical errors found; all tilings, counts and can/cannot claims are correct.
Top changes: grades 4-5 boards for Problems 8 and 13 are printed at 0.5 in cells while the paper dominoes/trominoes are cut at 0.58 in, so "cover" is impossible as printed; facilitator materials say 36 dominoes/24 trominoes but the sheets yield 50/30.
Other changes: K-1 Problem 11 "any pieces you like" must exclude the nonstandard pieces (answer 5 verified for the five standard shapes); 4-5 Problem 1 D asks for a hard parity proof after one try; two single-instance problems (K-1 P8, 4-5 P6) need a contrasting second shape; several "write what happened" / "write x only" instructions, one wrong loop description and one non-argument in the guide, missing ordered hints, numbering vs order on the 4-5 pages, and minor layout/recording-space fixes.
Working time per table estimated and summed: no table runs out before forty minutes.
Temporary render/verification files were removed; nothing else in the directory was changed.
Unresolved: none.
