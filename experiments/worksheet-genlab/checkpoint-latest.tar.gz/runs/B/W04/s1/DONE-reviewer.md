Wrote review.md: 24 numbered required changes (most important first, each with file, problem, page/line and the exact edit) plus a keep-as-is list.
Read all four sources, rendered and inspected every PDF page (7 + 8 + 9 + 12), recompiled all four files cleanly; temporary renders removed, packet left untouched.
Recomputed by program every run, answer, appendix row (120), cycle structure (3–17 counters), basin size, Garden-of-Eden count and transient maximum: no mathematical error in the guide or tables.
Top findings: grades 4–5 Problem 12 asks to "find" a predecessor of 2 2 2 2, which has none; the 22-arrangement census (2–3 Pr 14, 4–5 Pr 6) has no recording space or stopping rule; 2–3 Pr 9 asks for a run with no table; 4–5 Pr 15 prints the explanation on the student page.
Other items: missing recording circles/blanks (K–1 Pr 6, 14; 4–5 Pr 13, 14, 16), undefined "round and round" at K–1, self-loop instruction and cell spacing in the 2–3 map, stacked stairs pictures in K–1 Pr 4, counter counts, table lengths that reveal answers, timing realism and a loose step in the fixed-point argument.
Work estimates: K–1 about 48 min, grades 2–3 about 61 min, grades 4–5 about 84 min of real work; no table runs out before forty minutes.
Unresolved: the attribution "this route is close to Akin and Davis, 1985" could not be checked against the paper (flagged, not marked wrong).
