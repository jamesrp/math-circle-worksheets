Revised all four Week 1 sources in place (previous version saved in before-rewrite/); all compile cleanly with no overfull boxes, and every rendered page was inspected.
Addressed all 24 review items: the impossible "find one" task, census stopping rules, missing recording spaces and blanks, the explanation printed on the 4-5 page, the second 7-counter start, the re-laid map of 6 counters, the K-1 stairs overlap, "round and round" and "stopped" defined on the K-1 page, counter budgets, table slack (8 rows), result statements turned into references to the child's records, the fixed-point step (a), timings with cut orders, and the softened attribution.
K-1 pictures re-set at a 2 cm pitch (counters up to 2 cm fit one per circle) with a measure-first note in Materials; a full 1-inch pitch would not fit the two-problems-per-page layout, so that part of item 22 was taken only halfway.
Items 7, 8, 9, 14 and 16 were carried out in a different form than suggested (reasons in changes.md); no review point was rejected outright.
All new facts (2 2 2 1 run, 5-move bound for the 8-counter census, no predecessor of 2 2 2 2, stairs-plus-one placements, 12-counter basins) were verified by program.
Page counts: K-1 7, grades 2-3 8, grades 4-5 9, facilitator 13 (appendix tables spill to a 13th page). changes.md lists every change.
Nothing left unresolved.
