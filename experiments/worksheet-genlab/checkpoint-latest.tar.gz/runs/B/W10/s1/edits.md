# Week 1 (Bulgarian solitaire) — editor's list of edits

Every run, loop, transient length, Garden-of-Eden list and count, the 10-counter distribution, the 12-counter basin sizes (45/32), the 15- and 21-counter runs and maxima, the cycle structure for n = 3..17 and all 120 rows of the appendix tables were recomputed exhaustively by code before editing; no mathematical error was found. The edits below fix layout defects, guidance violations on the student pages, places where a child or adult would have to guess, missing recording space, and three missing hints, plus the layout consequences of those changes. Original copies of the sources are in `before-edit/`.

---

1. **File:** `week-grades-4-5.tex` (Problem 7)
   **Original:**
   `\RunTable[0.3]{4}{5}{1.3}\hspace{.3in}\RunTable[0.3]{5}{6}{1.3}\hspace{.3in}\RuledBox{7}{2.3in}`
   **Replacement:**
   `\RunTable[0.3]{4}{5}{1.45}\hspace{.3in}\RunTable[0.3]{5}{6}{1.45}\hspace{.3in}\RuledBox{7}{2.1in}`
   **Reason:** layout defect seen on the rendered page: the bold header "Piles, biggest first" overflows the 1.3-inch column and crosses the table border; 1.45 in is the width at which it fits (Problems 2 and 8). The ruled box is narrowed to keep the row within the text width.

2. **File:** `week-grades-4-5.tex` (Problem 15, problem text)
   **Original:**
   `\Problem{15}{The loop for 7 counters is 4 2 1, then 3 3 1, then 3 2 2, then 3 2 1 1, then back to 4 2 1. Each of these four arrangements is the stairs 3--2--1 with one extra counter added to one pile or added as a new pile of 1. Write all five arrangements that are the stairs 4--3--2--1 with one extra counter (11 counters). Then start 11 counters at 5, 3, 2, 1 and make 6 moves. Does the game stay inside your list? Finally, write all six arrangements that are the stairs 3--2--1 with one extra counter on each of two different steps (a new pile of 1 counts as a step), and compare them with the two loops from Problems 4 and 5.}`
   **Replacement:**
   `\Problem{15}{Build the stairs 3--2--1 with 6 counters. Add one extra counter to the pile of 3 and write the piles, biggest first, in the first blank. Move the extra counter to the pile of 2 instead and write that; then to the pile of 1; then put it down as a new pile of 1. Compare your four arrangements with the loop for 7 counters in Problem 9. Then write all five arrangements that are the stairs 4--3--2--1 with one extra counter (11 counters). Start 11 counters at 5, 3, 2, 1 and make 6 moves. Does the game stay inside your list? Finally, write all six arrangements that are the stairs 3--2--1 with one extra counter on each of two different steps (a new pile of 1 counts as a step), and compare them with the two loops from Problems 4 and 5.}`
   **Reason:** guidance "Do not put explanations of the mathematics on student pages" and "act → record → compare → explain": the sentence "Each of these four arrangements is the stairs 3–2–1 with one extra counter…" handed the child the structural insight of the session. The child now builds the four stairs-plus-one arrangements with counters, records them, and compares them with the loop they found in Problem 9; the representation gets its own concrete action before it is used for 11 and 12 counters.

3. **File:** `week-grades-4-5.tex` (Problem 15, first blanks line)
   **Original:**
   `Stairs 4--3--2--1 plus one: \Blank{0.7in}\ \Blank{0.7in}\ \Blank{0.7in}\ \Blank{0.7in}\ \Blank{0.7in}`
   **Replacement:**
   `Stairs 3--2--1 plus one: \Blank{0.7in}\ \Blank{0.7in}\ \Blank{0.7in}\ \Blank{0.7in}`
   **Reason:** recording space for the four arrangements asked for in edit 2 ("where to record it"); these must be the first blanks on the page because the problem text says "in the first blank". The five 4–3–2–1 blanks move into the note beside the run table (edit 4).

4. **File:** `week-grades-4-5.tex` (Problem 15, run table and note)
   **Original:**
   `\RunTable[0.3]{5 3 2 1}{6}{1.7}\hspace{.5in}\Note{Stairs 3--2--1 plus two: \Blank{0.6in}\ \Blank{0.6in}\ \Blank{0.6in}\ \Blank{0.6in}\ \Blank{0.6in}\ \Blank{0.6in}\par\vspace{.2in} Compared with the loops for 8 counters: \RuledBox{3}{3.3in}}`
   **Replacement:**
   `\RunTable[0.3]{5 3 2 1}{6}{1.7}\hspace{.5in}\Note{Stairs 4--3--2--1 plus one: \Blank{0.6in}\ \Blank{0.6in}\ \Blank{0.6in}\ \Blank{0.6in}\ \Blank{0.6in}\par\vspace{.15in} Stairs 3--2--1 plus two: \Blank{0.6in}\ \Blank{0.6in}\ \Blank{0.6in}\ \Blank{0.6in}\ \Blank{0.6in}\ \Blank{0.6in}\par\vspace{.15in} Compared with the loops for 8 counters: \RuledBox{3}{3.3in}}`
   **Reason:** consequence of edits 2–3: the five blanks for the 11-counter list are kept, now beside the 5 3 2 1 run table, so that Problems 15 and 16 still share page 8 (with the extra line of text and the extra blanks line, Problem 16's tables had spilled onto a tenth page).

5. **File:** `week-grades-4-5.tex` (preamble, `\Note` macro)
   **Original:**
   `\newcommand{\Note}[1]{\begin{tikzpicture}[baseline=(current bounding box.north)]\node[anchor=north west,text width=3.3in] at (0,0) {#1};\end{tikzpicture}}`
   **Replacement:**
   `\newcommand{\Note}[1]{\begin{tikzpicture}[baseline=(current bounding box.north)]\node[anchor=north west,text width=3.9in] at (0,0) {#1};\end{tikzpicture}}`
   **Reason:** consequence of edit 4: the wider note holds the three blank lines and the ruled box without growing taller than the run table beside it. The notes of Problems 1, 4 and 11 are one short line each and are unaffected; every row stays within the 7.2 in text width.

6. **File:** `week-grades-4-5.tex` (Problem 16, run tables)
   **Original:**
   `\RunTable[0.3]{5 4 2 1}{6}{1.7}\hspace{.4in}\RunTable[0.3]{5 3 3 1}{6}{1.7}`
   **Replacement:**
   `\RunTable[0.27]{5 4 2 1}{6}{1.7}\hspace{.4in}\RunTable[0.27]{5 3 3 1}{6}{1.7}`
   **Reason:** consequence of edits 2–3: the slightly shorter rows (the height already used in Problems 14 and 17) keep Problem 16 complete on page 8; the packet stays at 9 pages as stated in the facilitator guide's materials list.

7. **File:** `week-grades-4-5.tex` (Problem 12)
   **Original:**
   `Then find one that turns into 2, 2, 2, 2.}`
   **Replacement:**
   `Then try to find one that turns into 2, 2, 2, 2.}`
   **Reason:** no arrangement turns into 2 2 2 2 (it is a Garden of Eden state, as the guide's answer says); a problem must not assert the existence of something that does not exist. "Try to" matches the impossibility instances elsewhere in the packet (K–1 Problem 4 "try to put your 4 counters on the stairs").

8. **File:** `week-grades-4-5.tex` (Problem 16, problem text)
   **Original:**
   `Are they in the same loop? Find a start outside your list that ends in the second loop.}`
   **Replacement:**
   `Are they in the same loop? Find a start outside your list that ends in the same loop as 5, 3, 3, 1.}`
   **Reason:** "a child should never have to guess the task": the page never says which loop is "the second"; naming it by the start the child has just run removes the guess.

9. **File:** `week-grades-4-5.tex` (Problem 16, answer line)
   **Original:**
   `Same loop? \Blank{0.8in}\hspace{.3in} A start outside the list that ends in the second loop: \Blank{1.4in}`
   **Replacement:**
   `Same loop? \Blank{0.8in}\hspace{.3in} A start outside the list, in the loop of 5 3 3 1: \Blank{1.4in}`
   **Reason:** same as edit 8; the blank's label must match the task.

10. **File:** `week-grades-4-5.tex` (Problem 17)
    **INSERT AFTER:**
    `\RunTable[0.27]{5 5 5}{18}{1.9}\hspace{.4in}\RunTable[0.27]{4 4 3 2 1 1}{21}{1.9}`
    **Inserted text (as its own paragraph):**
    `Moves from 5 5 5: \Blank{0.6in}\hspace{.6in} Moves from 4 4 3 2 1 1: \Blank{0.6in}`
    **Reason:** the problem asks "How many moves does it take…" but gave nowhere to write the two counts (17 and 20); every other counting problem on these pages (2, 8, 11) has such a line.

11. **File:** `week-grades-2-3.tex` (Problem 9)
    **Original:**
    `\Problem{9}{Fill in the table for 3, 4, 5, 6 and 7 counters: does the game stop, or go round and round? If it goes round, how many different arrangements are in the loop? For 3 counters, start with three piles of 1 and find out.}`
    **Replacement (the problem text, followed by its own paragraph with the run table):**
    `\Problem{9}{Fill in the table for 3, 4, 5, 6 and 7 counters: does the game stop, or go round and round? If it goes round, how many different arrangements are in the loop? For 3 counters, start with three piles of 1, write each row in the small table, and find out.}`

    `\RunTable{1 1 1}{3}{1.6}`
    **Reason:** "act → record": the 3-counter run (1 1 1 → 3 → 2 1 → 2 1) is the only run on the grades 2–3 pages with no space made for it; three rows are exactly what it needs (the guide's answer for Problem 9 already gives this run).

12. **File:** `week-grades-2-3.tex` (Problem 13)
    **Original:**
    `find the picture of the result, and draw an arrow from the first picture to the second. Then answer the three questions under the map.}`
    **Replacement:**
    `find the picture of the result, and draw an arrow from the first picture to the second. If the result is the same picture, draw a small arrow from that picture back to itself. Then answer the three questions under the map.}`
    **Reason:** at K (3 2 1) the move gives the same picture and the printed instruction did not say what to draw; the guide's answer assumes a loop arrow from K to itself, and that fixed-point arrow is the point of the map. The child should not have to guess.

13. **File:** `week-k-1.tex` (Problem 10)
    **Original:**
    `Fill in the rows for 7 and for 10 after Problems 12 and 13.}`
    **Replacement:**
    `Fill in the row for 10 after Problem 12 and the row for 7 after Problem 13.}`
    **Reason:** the original pairs 7 with 12 and 10 with 13 by word order, but Problem 12 is the 10-counter game and Problem 13 the 7-counter game; the adult reading aloud should not have to untangle it.

14. **File:** `week-facilitator.tex` (Answers, grades 4–5, Problem 15)
    **Original:**
    `\item \textbf{Problem 15}: the five arrangements are 5 3 2 1, 4 4 2 1, 4 3 3 1, 4 3 2 2, 4 3 2 1 1, and`
    **Replacement:**
    `\item \textbf{Problem 15}: stairs 3 2 1 plus one gives 4 2 1, 3 3 1, 3 2 2, 3 2 1 1 (extra on the 3, the 2, the 1, as a new pile): exactly the loop for 7 counters from Problem 9, in the order it is visited. For 11 counters the five arrangements are 5 3 2 1, 4 4 2 1, 4 3 3 1, 4 3 2 2, 4 3 2 1 1, and`
    **Reason:** "complete answers for every problem": edit 2 added a step to Problem 15; its answer (checked by code: 4 2 1 → 3 3 1 → 3 2 2 → 3 2 1 1 → 4 2 1) is now in the guide.

15. **File:** `week-facilitator.tex` (Answers, grades 4–5, Problem 16)
    **Original:**
    `Not the same loop. Starts outside the list that end in the second loop:`
    **Replacement:**
    `Not the same loop. Starts outside the list that end in the loop of 5 3 3 1 (the second loop):`
    **Reason:** consistency with edits 8–9: the answer names the loop the way the page now does.

16. **File:** `week-facilitator.tex` (Hints, K–1)
    **INSERT AFTER:**
    `\item Round and round is hard to see: put a finger on box 1 and ask ``where is this picture again?''`
    **Inserted text:**
    `\item For the moves circle (Problems 7--9): ``Which box is the first one with the stairs? That number goes in the circle.'' The last box only repeats it and does not count.`
    **Reason:** the guide's answers (4, 4, 6 moves) use the convention that the box which merely repeats the stairs is not a move, but the pages tell the child to draw "until a box looks the same as the box before it", so a kindergartner will naturally count the boxes (5, 5, 7); the adult needs the hint, in the order of the other hints.

17. **File:** `week-facilitator.tex` (Hints, grades 2–3)
    **INSERT AFTER:**
    `\item A child does not notice a repeat: ``Read row 1 aloud. Now find it lower down.''`
    **Inserted text:**
    `\item Problem 4, if the repeated row is counted as a move: ``Which row is the first one that shows 3 2 1? That is the number of moves; the next move changed nothing.''`
    **Reason:** same convention as edit 16 for the "Moves until it stopped" column of Problem 4 (answers 5, 3, 4, 4, 6, where the tables have 6, 4, 5, 5, 7 rows).

18. **File:** `week-facilitator.tex` (Hints, grades 4–5)
    **INSERT AFTER:**
    `\item Wrong rows (usually a forgotten pile): ``The new pile equals the number of piles before the move. Check that first.''`
    **Inserted text:**
    `\item Problem 3, to speed up: ``When a run reaches an arrangement you have already run, stop and add its number of moves'' (from 4 1 1: one move to 3 3, then the four moves of 3 3, five in all). The number of moves is the number of the first row that shows 3 2 1; the row that only repeats it does not count.`
    **Reason:** Problem 3 asks for seven more runs of 6 counters with no tables, inside the 8 minutes allotted to Problems 1–3; the shortcut is the only way it fits and is what makes the complete list a proof in reasonable time. The guide gave the shortcut only for Problem 6. The same counting convention as edits 16–17 is stated for this table.

19. **File:** `week-facilitator.tex` (References paragraph)
    **Original (start and end of the paragraph):**
    `References. J. Brandt, Cycles of partitions,` … `College Math. J. 43 (2012).`
    **Replacement:**
    `{\small References. J. Brandt, Cycles of partitions,` … `College Math. J. 43 (2012).\par}`
    **Reason:** layout consequence of edits 14–18 (about seven added lines): the references had moved onto a page of their own before the appendix, making the guide 13 pages; set small, as a reference list usually is.

20. **File:** `week-facilitator.tex` (appendix description)
    **Original (start and end of the paragraph):**
    `Each table lists every arrangement (Start),` … `one that no move produces.`
    **Replacement:**
    `{\small Each table lists every arrangement (Start),` … `one that no move produces.\par}`
    **Reason:** same as edit 19; a caption-like paragraph.

21. **File:** `week-facilitator.tex` (before the appendix heading)
    **Original:**
    `\newpage`
    `\section*{Tables: every arrangement, its successor, and its distance}`
    **Replacement:**
    `\section*{Tables: every arrangement, its successor, and its distance}`
    **Reason:** same as edit 19: the appendix now starts below the references instead of leaving a nearly empty page; with edit 22 the guide is 12 pages again.

22. **File:** `week-facilitator.tex` (appendix tables: regroup the four centred rows of tables into three rows, 6|7|8, 9a|9b, 10a|10b, with slightly tighter columns)
    (a) All four occurrences of
    `\begin{center}\footnotesize\setlength{\tabcolsep}{4pt}\renewcommand{\arraystretch}{1.1}`
    become
    `\begin{center}\footnotesize\setlength{\tabcolsep}{2.5pt}\renewcommand{\arraystretch}{1.0}`
    (after the regrouping only three of them remain).
    (b) Between the 7-counter and 8-counter tables, the original
    `\bottomrule\end{tabular}` / `\end{center}` / `\begin{center}…{1.0}` / `\begin{tabular}[t]{l l c c c}` / `\multicolumn{5}{l}{\textbf{8 counters, 22 arrangements}}`
    becomes
    `\bottomrule\end{tabular}` / `\hspace{.1in}` / `\begin{tabular}[t]{l l c c c}` / `\multicolumn{5}{l}{\textbf{8 counters, 22 arrangements}}`,
    and the `\hspace{.15in}` between the 6- and 7-counter tables becomes `\hspace{.1in}`.
    (c) Between the 8-counter table and "9 counters (1 of 2)", `\hspace{.15in}` becomes `\end{center}` / `\begin{center}\footnotesize\setlength{\tabcolsep}{2.5pt}\renewcommand{\arraystretch}{1.0}`.
    (d) Between "9 counters (1 of 2)" and "9 counters (2 of 2)", `\end{center}` / `\begin{center}…{1.0}` becomes `\hspace{.15in}`.
    (e) Between "9 counters (2 of 2)" and "10 counters (1 of 2)", `\hspace{.15in}` becomes `\end{center}` / `\begin{center}\footnotesize\setlength{\tabcolsep}{2.5pt}\renewcommand{\arraystretch}{1.0}`.
    (f) Between "10 counters (1 of 2)" and "10 counters (2 of 2)", `\end{center}` / `\begin{center}…{1.0}` becomes `\hspace{.15in}`.
    The table rows themselves are untouched (all 120 rows re-verified by code after the change).
    **Reason:** same as edit 19: with the references above them, the appendix tables fit on two pages only in this grouping (6|7|8 on the page with the references, 9 and 10 on the last page); the guide is 12 pages and every table is still set in `\footnotesize`.
