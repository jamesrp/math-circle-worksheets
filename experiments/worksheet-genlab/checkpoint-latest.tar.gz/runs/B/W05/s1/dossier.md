# Week 1 dossier — Bulgarian solitaire (mathematician's groundwork)

**Rule, stated once, precisely.** Counters sit in piles. A *move*: take exactly one counter from *every* pile (a pile of 1 disappears), and put all the counters you took together as one new pile. Only pile *sizes* matter: 3-1 and 1-3 are the same picture. Notation: a picture is its pile sizes, largest first, hyphenated (`4-2`, `3-2-1`); n = number of counters; the *stairs* `k-(k-1)-…-1` has T_k = 1+2+…+k counters (T_1..T_6 = 1, 3, 6, 10, 15, 21). "Picture" is my word for a configuration; the writer may prefer "position".

Two facts every adult should keep in front of them: (i) the new pile has exactly as many counters as there were piles before the move; (ii) the number of piles after a move = (piles that had at least 2 counters) + 1. Both follow at once from the rule, and both catch nearly every handling error.

Every number below was computed by `bulgarian.py` in this directory (`python3 bulgarian.py`), which also asserts the theorems of Section 1 against brute force for n ≤ 24.

---

## 1. The real questions

**Q1. Dynamics: what can happen?** *Idea:* a deterministic map on a finite set (the p(n) partitions of n) is eventually periodic: every start ends in a loop, possibly of length 1 (a *stuck* picture). *Elementary form:* "There are only 11 pictures with 6 counters. Every move gives one of them, so within 11 moves a picture repeats, and since the rule always does the same thing to the same picture, from then on it repeats forever."

**Q2. Existence: which pictures are stuck?** *Theorem:* stuck ⇔ stairs; so a stuck picture exists ⇔ n triangular. *Elementary proof (grades 4–5 can give it with prompting):* Let B be the biggest pile of a stuck picture. After the move every old pile is smaller than B, so the size-B pile of the (identical) new picture must be the new pile; the new pile's size is the number of piles, so B = number of piles. The old B-pile became B−1, so the picture has a pile of size B−1; that one becomes B−2, so there is a B−2; … down to 1. That is B piles of sizes B, …, 1, and there are only B piles: the stairs. Conversely `3-2-1` → `2-1-0` plus a new 3.

**Q3. Completeness (Brandt 1982): does every start end in the same place?** For n = T_k every start reaches the stairs. For other n every start reaches a loop of length ≥ 2; the loop pictures are exactly "stairs plus wanderers" (below); and for some n (first: n = 8) different starts reach *different* loops. *Full proof (the diagonal argument standard in the literature; cf. Akin–Davis 1985, Etienne 1991, Griggs–Ho 1998):*

Draw a picture as rows of counters, longest row on top, left-aligned (a Young diagram); the counter in row i, column j gets *diagonal number* i + j − 1. Diagonal d has room for at most d counters, at (1,d), (2,d−1), …, (d,1). Let Φ = sum of the diagonal numbers of all counters. The stairs `k-…-1` is the unique picture with T_k counters and diagonals 1..k full, and it has the least Φ (= 1²+…+k²) among pictures with T_k counters.

*Lemma: a move never increases Φ, and leaves it unchanged exactly when (number of piles) ≥ (biggest pile) − 1.* Do the move in two steps. Step 1 ("unsorted move"): remove the first column and lay it as a new *top* row, the counter from row i going to column i; every other counter slides down one row and left one column. So (i,1) → (1,i) and (i,j) → (i+1, j−1): every counter keeps its diagonal number and Φ is unchanged. The rows are now in the order (m, λ₁−1, λ₂−1, …), m = old number of piles. Step 2: sort rows longest-first by swapping adjacent out-of-order rows. Swapping a row of length a sitting above a longer row of length b sends the a short-row counters down one diagonal (+1 each) and the b long-row counters up one (−1 each): Φ changes by a − b < 0. So Φ drops iff sorting is needed iff m < λ₁ − 1. ∎

*Theorem.* On a loop Φ is constant, so on the loop every move is already sorted after Step 1; hence every counter keeps its diagonal number forever and rotates along its diagonal, (1,d) → (2,d−1) → … → (d,1) → (1,d), with period d. Suppose diagonal d+1 carries a counter. Every d+1 moves it sits at (1, d+1), and since rows are left-aligned, (1, d) is occupied at those moments. The occupied set of diagonal d rotates with period d, and gcd(d, d+1) = 1, so the moments t ≡ t₀ (mod d+1) meet every rotation offset of diagonal d: every position of diagonal d is occupied. By downward induction the loop picture is diagonals 1..k full plus r ≤ k counters on diagonal k+1, i.e. n = T_k + r, 0 ≤ r ≤ k. For triangular n this is the stairs. ∎

*Loop pictures = stairs plus wanderers.* "Diagonals 1..k full plus r counters on diagonal k+1" means: the stairs `k-…-1` with a phantom empty row k+1, and r of the k+1 rows lengthened by one counter (a *wanderer*), at most one per row. For n = 8 = 6+2, two wanderers on `3-2-1-(0)`: rows {1,2} `4-3-1`, {1,3} `4-2-2`, {1,4} `4-2-1-1`, {2,3} `3-3-2`, {2,4} `3-3-1-1`, {3,4} `3-2-2-1`. *Elementary check that these loop (grades 4–5):* subtracting 1 from every row shifts the stairs down one row, carrying each wanderer down one step; the new pile has k counters, plus one exactly when the phantom bottom row had a wanderer. So wanderers walk down the stairs in lock-step and the one that steps off the bottom reappears on top. Loop length = period of the wanderer pattern, a divisor of k+1; loop pictures number C(k+1, r); loops number the binary necklaces of length k+1 with r ones. At n = 8 the pattern "rows 1,3" has period 2 (`4-2-2` ↔ `3-3-1-1`) and "rows 1,2" has period 4: two loops.

**Q4. Optimality: how long until the stairs?** *Theorem (Igusa 1985; Etienne 1991):* from any picture with T_k counters the stairs arrives within k² − k moves. Verified sharp for k ≤ 8 (maxima 0, 2, 6, 12, 20, 30, 42, 56), and the stairs `(k−1)-…-1` with one extra pile of k−1 and one extra pile of 1 (`2-2-1-1`, `3-3-2-1-1`, `4-4-3-2-1-1`, …) attains k² − k for every k ≤ 12 tested. Two exact facts within children's reach: from a single pile of T_k the stairs arrives in exactly T_{k−1} moves (3 → 1, 6 → 3, 10 → 6, 15 → 10, 21 → 15), from all singles one more. *Proof:* after t moves the picture is (T_k − t) together with a small picture μ_t of t counters, and μ_{t+1} is the move applied to μ_t with the new pile one bigger (the big pile contributes a counter). By induction μ_{T_j + r} = stairs j with its top r rows lengthened, 0 ≤ r ≤ j (subtract 1 from each row — the bottom row of length 1 vanishes unless r = j — and add a new top row of length j+1). At t = T_{k−1}, μ = stairs k−1 and the big pile is T_k − T_{k−1} = k: the stairs. Earlier the big pile exceeds k. Children see it: `10 → 9-1 → 8-2 → 7-2-1 → 6-3-1 → 5-3-2 → 4-3-2-1`, the stairs growing from the small end.

**Q5. Impossibility: Garden of Eden pictures.** *Theorem:* a picture has a predecessor iff (biggest pile) ≥ (number of piles) − 1; the number of predecessors is the number of *distinct* sizes p with p ≥ (piles) − 1. *Elementary form (undo a move):* choose one pile to have been the new pile; it must hand one counter back to every other pile, and its leftovers were piles of 1 that vanished; so it needs at least (piles − 1) counters. If no pile is big enough, nothing leads here. `1-1-1-1-1-1` and `2-2-1-1` are Gardens of Eden for 6; `3-2-1` has exactly two predecessors, `4-2` and itself. Counts for n = 3..10: 1, 1, 2, 3, 5, 7, 10, 14 (partitions with Dyson rank ≤ −2; Hopkins–Sellers 2007).

**Q6. Invariants.** Counters are conserved (recount after every move); facts (i) and (ii) of the preamble are exact predictions to make before each move. The real monovariant is Φ, and it is lazy — on the longest 6-counter game it stays at 15 for five moves and drops once — so it proves convergence, not speed.

**Q7. Counting.** Pictures with n counters = partitions p(n): 1, 2, 3, 5, 7, 11, 15, 22, 30, 42 for n = 1..10. Systematic listing (by biggest pile, then next) is a real task with a checkable answer.

**Q8. Structure of the map.** Trees flowing into loops. For 6 it is a Y: `1-1-1-1-1-1 → 6 → 5-1 → 4-2 → 3-2-1`, with `2-1-1-1-1 → 5-1` joining, and `2-2-1-1 → 4-1-1 → 3-3 → 2-2-2 → 3-1-1-1 → 4-2`. For 8 the basins have 15 and 7 pictures, and no simple rule (parity of pile count, of biggest pile, all-even, Φ parity) separates them — checked. An honest open exploration.

---

## 2. Instances

Layout for all tables: each pile is a **row** of counters, rows stacked longest-on-top, left-aligned. A move = sweep the left column into your hand, slide everything left, lay the swept counters as a new row, re-sort. "Same picture?" becomes visible, the stairs look like stairs, and this is the diagram of Q3. At K–1, heaps are fine for the taking; the adult re-lays the result as sorted rows. All games named here are written out in Section 3.

### K–1 (two kindergartners, one first grader; adult reads aloud). Core 1–5, reserves 6–9.

1. **3 counters, start `3`** → `2-1` → `2-1`. *Finds:* "it doesn't change any more" (stuck). *Why:* the move and the word "stuck" in two steps.
2. **3 counters, start `1-1-1`** → `3` → `2-1`. *Finds:* same ending from a different start; piles of 1 vanish.
3. **6 counters, start `6`** → `5-1` → `4-2` → `3-2-1`, stuck after 3 moves. Lay `3-2-1` as rows: it *is* a staircase. *Why:* the hero object.
4. **6 counters, each child chooses a start** (offer `3-3` 4 moves, `2-2-2` 3, `1-1-1-1-1-1` 4, `4-1-1` 5, `2-2-1-1` 6). All reach `3-2-1`; all 11 pictures do. *Why:* Brandt's theorem, experienced.
5. **4 counters, start `4`** → `3-1` → `2-2` → `2-1-1` → `3-1` … *Finds:* "it came back!" — three pictures round and round, no stairs. Keep every picture on the table on its own sheet (5 × 4 counters) so the repeat is seen by matching. *Why:* 6 settles, 4 circles.
6. (reserve) **Build the stairs** `1`, `2-1`, `3-2-1`, `4-3-2-1` and count: 1, 3, 6, 10. *Why:* the stairs numbers; leads to 10.
7. (reserve, first grader) **10 counters, start `10`**: 6 moves to `4-3-2-1`, the little piles growing into stairs while the big pile shrinks; or `5-5`, also 6 moves.
8. (reserve) **5 counters, start `5`**: loop of 3 (`3-2`, `2-2-1`, `3-1-1`) after 2 moves. **2 counters**: `2` ↔ `1-1`. **1 counter**: stuck. *Why:* the stuck numbers are 1, 3, 6.
9. (reserve) **7 counters, start `7`**: loop of 4 after 3 moves; every loop picture is `3-2-1` plus one extra counter walking around.

### Grades 2–3 (four third graders). Core 1–5, reserves 6–9.

1. **6 counters, own start, record every picture as numbers, largest first.** All reach `3-2-1`; compare move counts (1 to 6).
2. **List all pictures with 6 counters** (11: `6; 5-1; 4-2, 4-1-1; 3-3, 3-2-1, 3-1-1-1; 2-2-2, 2-2-1-1, 2-1-1-1-1; 1-1-1-1-1-1`), compute each one's next picture (split four ways), draw the arrows. *Finds:* the Y-shaped river map; longest route `2-2-1-1` (6). *Why:* the table-of-all-cases proof for 6.
3. **4 counters: all 5 pictures and arrows.** One loop of 3, no stuck picture. Then **5 counters** (7 pictures, loop of 3). *Why:* numbers with no stuck picture, proved by exhaustion.
4. **Which pictures are stuck?** Test `2-1`, `3-2-1`, `4-3-2-1` and non-stairs guesses (`2-2`, `4-2`, `3-3`). *Finds:* stairs; stairs numbers 1, 3, 6, 10, 15; a child says *why* `3-2-1` is stuck.
5. **10 counters, own start** (different starts; the adult has the 42-row table). All reach `4-3-2-1`; `10` takes exactly 6; the longest possible is 12 (`3-3-2-1-1`, `3-2-2-2-1`, `3-2-2-1-1-1`). *Why:* the theorem beyond exhaustive checking.
6. (reserve) **8 counters: two loops.** `8` reaches the 4-loop `4-3-1 → 3-3-2 → 3-2-2-1 → 4-2-1-1` in 4 moves; `2-2-2-2` reaches the 2-loop `4-2-2 ↔ 3-3-1-1` in 3. *Finds:* not everyone ends in the same place. Only 7 of 22 starts reach the 2-loop (`2-2-2-2, 2-2-1-1-1-1, 4-1-1-1-1, 6-1-1, 5-3, 4-2-2, 3-3-1-1`): assign one deliberately.
7. (reserve) **7 counters**: the 4-loop `4-2-1 → 3-3-1 → 3-2-2 → 3-2-1-1`; each loop picture is `3-2-1` plus one wanderer that walks down and jumps to the top.
8. (reserve) **Predict before you move**: size of the new pile; number of piles after.
9. (reserve) **On the 6-map, which pictures have no arrow into them?** `1-1-1-1-1-1`, `2-1-1-1-1`, `2-2-1-1`. Why can six singles never be produced? (New pile of size 1 ⇒ one pile before ⇒ `6` ⇒ gives `5-1`.)

### Grades 4–5 (two fourth graders, one fifth grader). Core 1–5, reserves 6–10.

1. **6 counters: full map of 11 pictures** (about 8 minutes). Everything reaches `3-2-1`; longest 6 from `2-2-1-1`.
2. **Stuck ⇒ stairs.** Children produce the argument of Q2 (wording in Section 4). Stairs numbers = triangular numbers.
3. **8 counters: full map of 22 pictures**, split three ways, then assembled. *Finds:* loops of length 4 and 2, basins 15 and 7, no obvious rule for which start goes where. *Why:* the first n where "same place?" fails, in a table they own.
4. **10 counters.** (a) `10`: exactly 6 moves, stairs growing from the small end; (b) all singles: 7; (c) longest: 12 from `3-3-2-1-1`; (d) maxima 0, 2, 6, 12 for 1, 3, 6, 10 counters — conjecture k(k−1) (true: 20 for 15); single-pile counts 0, 1, 3, 6 — conjecture T_{k−1} (true, Q4).
5. **Loop lengths and loop pictures for 4, 5, 7, 8, 9, 11 counters**: 3, 3, 4, {4, 2}, 4, 5. *Finds:* between T_k and T_{k+1} the loops have length k+1 or a divisor; loop pictures are stairs plus r wanderers, at most one per row, stepping down in lock-step (argument in Q3).
6. (reserve) **Garden of Eden.** Undo moves on the 6- and 8-maps; find "no predecessor iff biggest pile ≤ piles − 2"; counts 3, 5, 7, 10, 14 for n = 6..10; `5-3-2` has three predecessors (`6-4`, `6-3-1`, `4-3-1-1-1`).
7. (reserve) **How many pictures?** 1, 2, 3, 5, 7, 11, 15, 22, 30, 42; "how do you know you found them all?"
8. (reserve, mathematician-led) **Counters ride their diagonals.** Playing cards as counters, rank = diagonal number. Start `4-4-2` as rows A,2,3,4 / 2,3,4,5 / 3,4. Move with the *new row on top*: `3-3-3-1` (A,2,3 / 2,3,4 / 3,4,5 / 4), every card still on its diagonal; then `4-2-2-2` (A,2,3,4 / 2,3 / 3,4 / 4,5); `4-3-1-1-1`; `5-3-2` (A,2,3,4,5 / 2,3,4 / 3,4). Next the unsorted rows are (3, 4, 2, 1); swapping the top two moves four cards up a diagonal and three down — the rank sum drops by 1 — giving the stairs with ranks scrambled. *Finds:* the rank sum never rises; when no re-sorting is ever needed, the cards just circulate. *Why:* the proof, seen.
9. (reserve) **15 counters from `15`**: exactly 10 moves.
10. (reserve) **12 counters**: two 5-loops (Section 3.3).

**Launch (organizer):** show the rule on 6 large counters from `3-3` → `2-2-2` → `3-1-1-1`, stop, and ask "will it ever stop changing? does it matter how we start?" Do not reach `3-2-1` in the launch; every table's first job is to find it. **Share:** K–1 "6 makes stairs, 4 goes round"; 2–3 the river map for 6 and the loop for 4; 4–5 stuck pictures are stairs and why, and 8 has two loops. The organizer closes with the theorem (Brandt 1982) and the bound k(k−1).

---

## 3. Verified data

Program: `bulgarian.py` (enumerates all partitions, iterates the move, finds loops, transients, predecessors; asserts Q2–Q6 for n ≤ 24). "Moves until loop" = moves before a loop picture (or the stairs) first appears.

### 3.1 Summary, n = 1..21

| n | pictures p(n) | k, r (n = T_k + r) | loops (lengths) | loop pictures | longest run before the loop | Garden of Eden pictures |
|---|---|---|---|---|---|---|
| 1 | 1 | 1, 0 | 1 (1) | 1 | 0 | 0 |
| 2 | 2 | 1, 1 | 1 (2) | 2 | 0 | 0 |
| 3 | 3 | 2, 0 | 1 (1) | 1 | 2 (from 1-1-1) | 1 |
| 4 | 5 | 2, 1 | 1 (3) | 3 | 2 (from 1-1-1-1) | 1 |
| 5 | 7 | 2, 2 | 1 (3) | 3 | 3 (from 1-1-1-1-1) | 2 |
| 6 | 11 | 3, 0 | 1 (1) | 1 | 6 (from 2-2-1-1) | 3 |
| 7 | 15 | 3, 1 | 1 (4) | 4 | 4 (from 1-1-1-1-1-1-1) | 5 |
| 8 | 22 | 3, 2 | 2 (4, 2) | 6 | 5 (from 1-1-1-1-1-1-1-1) | 7 |
| 9 | 30 | 3, 3 | 1 (4) | 4 | 7 (from 3-2-2-1-1) | 10 |
| 10 | 42 | 4, 0 | 1 (1) | 1 | 12 (from 3-3-2-1-1, 3-2-2-2-1, 3-2-2-1-1-1) | 14 |
| 11 | 56 | 4, 1 | 1 (5) | 5 | 8 | 20 |
| 12 | 77 | 4, 2 | 2 (5, 5) | 10 | 8 | 27 |
| 13 | 101 | 4, 3 | 2 (5, 5) | 10 | 9 | 37 |
| 14 | 135 | 4, 4 | 1 (5) | 5 | 14 | 49 |
| 15 | 176 | 5, 0 | 1 (1) | 1 | 20 (16 starts, e.g. 4-4-3-2-1-1) | 66 |
| 16 | 231 | 5, 1 | 1 (6) | 6 | 15 | 86 |
| 17 | 297 | 5, 2 | 3 (6, 6, 3) | 15 | 12 | 113 |
| 18 | 385 | 5, 3 | 4 (6, 6, 6, 2) | 20 | 13 | 147 |
| 19 | 490 | 5, 4 | 3 (6, 6, 3) | 15 | 16 | 190 |
| 20 | 627 | 5, 5 | 1 (6) | 6 | 23 | 243 |
| 21 | 792 | 6, 0 | 1 (1) | 1 | 30 (65 starts, e.g. 5-5-4-3-2-1-1) | 311 |

Longest game to the stairs for T_k counters, k = 1..8: 0, 2, 6, 12, 20, 30, 42, 56 = k² − k, attained by 1, 1, 1, 3, 16, 65, 293, 1267 starts. From the single pile: 0, 1, 3, 6, 10, 15, 21, 28 moves (= T_{k−1}); from all singles one more. Distribution for 10 counters (moves : starts): 0:1, 1:1, 2:3, 3:5, 4:5, 5:3, 6:4, 7:4, 8:4, 9:3, 10:3, 11:3, 12:3.

### 3.2 Complete maps (printable)

**n = 3.** `1-1-1 → 3 → 2-1` (stuck). Garden of Eden: `1-1-1`.

**n = 4: 5 pictures, one loop of length 3: `3-1 → 2-2 → 2-1-1 → 3-1`.**

| picture | next | moves until loop | comes from |
|---|---|---|---|
| 1-1-1-1 | 4 | 2 | nothing (Garden of Eden) |
| 4 | 3-1 | 1 | 1-1-1-1 |
| 3-1 | 2-2 | 0 | 4, 2-1-1 |
| 2-2 | 2-1-1 | 0 | 3-1 |
| 2-1-1 | 3-1 | 0 | 2-2 |

**n = 5: 7 pictures, one loop of length 3: `3-2 → 2-2-1 → 3-1-1 → 3-2`.**

| picture | next | moves until loop | comes from |
|---|---|---|---|
| 1-1-1-1-1 | 5 | 3 | nothing (Garden of Eden) |
| 5 | 4-1 | 2 | 1-1-1-1-1 |
| 2-1-1-1 | 4-1 | 2 | nothing (Garden of Eden) |
| 4-1 | 3-2 | 1 | 5, 2-1-1-1 |
| 3-2 | 2-2-1 | 0 | 4-1, 3-1-1 |
| 3-1-1 | 3-2 | 0 | 2-2-1 |
| 2-2-1 | 3-1-1 | 0 | 3-2 |

**n = 6: 11 pictures, stuck picture `3-2-1`.**

| picture | next | moves to stairs | comes from |
|---|---|---|---|
| 2-2-1-1 | 4-1-1 | 6 | nothing (Garden of Eden) |
| 4-1-1 | 3-3 | 5 | 2-2-1-1 |
| 3-3 | 2-2-2 | 4 | 4-1-1 |
| 1-1-1-1-1-1 | 6 | 4 | nothing (Garden of Eden) |
| 6 | 5-1 | 3 | 1-1-1-1-1-1 |
| 2-2-2 | 3-1-1-1 | 3 | 3-3 |
| 2-1-1-1-1 | 5-1 | 3 | nothing (Garden of Eden) |
| 5-1 | 4-2 | 2 | 6, 2-1-1-1-1 |
| 3-1-1-1 | 4-2 | 2 | 2-2-2 |
| 4-2 | 3-2-1 | 1 | 5-1, 3-1-1-1 |
| 3-2-1 | 3-2-1 | 0 | 4-2, 3-2-1 |

Every full game with 6 counters: `6 → 5-1 → 4-2 → 3-2-1` (3 moves); `5-1 → 4-2 → 3-2-1` (2); `4-2 → 3-2-1` (1); `4-1-1 → 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1` (5); `3-3 → …` (4); `3-1-1-1 → 4-2 → 3-2-1` (2); `2-2-2 → 3-1-1-1 → …` (3); `2-2-1-1 → 4-1-1 → …` (6); `2-1-1-1-1 → 5-1 → 4-2 → 3-2-1` (3); `1-1-1-1-1-1 → 6 → …` (4).

Φ (sum of diagonal numbers) for 6 counters: `3-2-1`: 14; `4-2`, `4-1-1`, `3-3`, `3-1-1-1`, `2-2-2`, `2-2-1-1`: 15; `5-1`, `2-1-1-1-1`: 17; `6`, `1-1-1-1-1-1`: 21.

**n = 7: 15 pictures, one loop of length 4: `4-2-1 → 3-3-1 → 3-2-2 → 3-2-1-1 → 4-2-1`.**

| picture | next | moves until loop | comes from |
|---|---|---|---|
| 1-1-1-1-1-1-1 | 7 | 4 | nothing (Garden of Eden) |
| 7 | 6-1 | 3 | 1-1-1-1-1-1-1 |
| 2-2-2-1 | 4-1-1-1 | 3 | nothing (Garden of Eden) |
| 2-2-1-1-1 | 5-1-1 | 3 | nothing (Garden of Eden) |
| 2-1-1-1-1-1 | 6-1 | 3 | nothing (Garden of Eden) |
| 6-1 | 5-2 | 2 | 7, 2-1-1-1-1-1 |
| 5-1-1 | 4-3 | 2 | 2-2-1-1-1 |
| 4-1-1-1 | 4-3 | 2 | 2-2-2-1 |
| 3-1-1-1-1 | 5-2 | 2 | nothing (Garden of Eden) |
| 5-2 | 4-2-1 | 1 | 6-1, 3-1-1-1-1 |
| 4-3 | 3-2-2 | 1 | 5-1-1, 4-1-1-1 |
| 4-2-1 | 3-3-1 | 0 | 5-2, 3-2-1-1 |
| 3-3-1 | 3-2-2 | 0 | 4-2-1 |
| 3-2-2 | 3-2-1-1 | 0 | 4-3, 3-3-1 |
| 3-2-1-1 | 4-2-1 | 0 | 3-2-2 |

Single-pile games for the K–1 reserves: `4 → 3-1 → 2-2 → 2-1-1 → 3-1`; `5 → 4-1 → 3-2 → 2-2-1 → 3-1-1 → 3-2`; `7 → 6-1 → 5-2 → 4-2-1 → 3-3-1 → 3-2-2 → 3-2-1-1 → 4-2-1`.

**n = 8: 22 pictures, two loops. Loop A (length 4): `4-3-1 → 3-3-2 → 3-2-2-1 → 4-2-1-1 → 4-3-1`. Loop B (length 2): `4-2-2 → 3-3-1-1 → 4-2-2`.**

| picture | next | moves until loop | loop | comes from |
|---|---|---|---|---|
| 1-1-1-1-1-1-1-1 | 8 | 5 | A | nothing (Garden of Eden) |
| 8 | 7-1 | 4 | A | 1-1-1-1-1-1-1-1 |
| 2-1-1-1-1-1-1 | 7-1 | 4 | A | nothing (Garden of Eden) |
| 7-1 | 6-2 | 3 | A | 8, 2-1-1-1-1-1-1 |
| 3-1-1-1-1-1 | 6-2 | 3 | A | nothing (Garden of Eden) |
| 2-2-2-2 | 4-1-1-1-1 | 3 | B | nothing (Garden of Eden) |
| 2-2-2-1-1 | 5-1-1-1 | 3 | A | nothing (Garden of Eden) |
| 2-2-1-1-1-1 | 6-1-1 | 3 | B | nothing (Garden of Eden) |
| 6-2 | 5-2-1 | 2 | A | 7-1, 3-1-1-1-1-1 |
| 6-1-1 | 5-3 | 2 | B | 2-2-1-1-1-1 |
| 5-1-1-1 | 4-4 | 2 | A | 2-2-2-1-1 |
| 4-1-1-1-1 | 5-3 | 2 | B | 2-2-2-2 |
| 3-2-1-1-1 | 5-2-1 | 2 | A | nothing (Garden of Eden) |
| 5-3 | 4-2-2 | 1 | B | 6-1-1, 4-1-1-1-1 |
| 5-2-1 | 4-3-1 | 1 | A | 6-2, 3-2-1-1-1 |
| 4-4 | 3-3-2 | 1 | A | 5-1-1-1 |
| 4-3-1 | 3-3-2 | 0 | A | 5-2-1, 4-2-1-1 |
| 4-2-2 | 3-3-1-1 | 0 | B | 5-3, 3-3-1-1 |
| 4-2-1-1 | 4-3-1 | 0 | A | 3-2-2-1 |
| 3-3-2 | 3-2-2-1 | 0 | A | 4-4, 4-3-1 |
| 3-3-1-1 | 4-2-2 | 0 | B | 4-2-2 |
| 3-2-2-1 | 4-2-1-1 | 0 | A | 3-3-2 |

Basins: A has 15 pictures, B has 7 (`2-2-2-2, 2-2-1-1-1-1, 4-1-1-1-1, 6-1-1, 5-3, 4-2-2, 3-3-1-1`). Two games to show both: `8 → 7-1 → 6-2 → 5-2-1 → 4-3-1 → 3-3-2 → 3-2-2-1 → 4-2-1-1 → 4-3-1`; `2-2-2-2 → 4-1-1-1-1 → 5-3 → 4-2-2 → 3-3-1-1 → 4-2-2`.

**n = 9: 30 pictures, one loop of length 4: `4-3-2 → 3-3-2-1 → 4-2-2-1 → 4-3-1-1 → 4-3-2`.** Moves until loop (next picture in parentheses): 0: the four loop pictures. 1: `5-4 (4-3-2)`, `5-3-1 (4-3-2)`, `5-2-2 (4-3-1-1)`. 2: `6-3 (5-2-2)`, `6-2-1 (5-3-1)`, `6-1-1-1 (5-4)`, `5-1-1-1-1 (5-4)`, `4-2-1-1-1 (5-3-1)`, `3-3-1-1-1 (5-2-2)`. 3: `7-2 (6-2-1)`, `7-1-1 (6-3)`, `4-1-1-1-1-1 (6-3)`, `3-2-2-2 (4-2-1-1-1)`, `3-2-1-1-1-1 (6-2-1)`, `2-2-2-2-1 (5-1-1-1-1)`, `2-2-2-1-1-1 (6-1-1-1)`. 4: `8-1 (7-2)`, `3-3-3 (3-2-2-2)`, `3-1-1-1-1-1-1 (7-2)`, `2-2-1-1-1-1-1 (7-1-1)`. 5: `9 (8-1)`, `4-4-1 (3-3-3)`, `2-1-1-1-1-1-1-1 (8-1)`. 6: `5-2-1-1 (4-4-1)`, `1-1-1-1-1-1-1-1-1 (9)`. 7: `3-2-2-1-1 (5-2-1-1)`.

**n = 10: 42 pictures, all reach `4-3-2-1`.** Moves to the stairs (next picture in parentheses; GoE = nothing leads to it):

| moves | pictures |
|---|---|
| 0 | 4-3-2-1 |
| 1 | 5-3-2 (4-3-2-1) |
| 2 | 6-4 (5-3-2); 6-3-1 (5-3-2); 4-3-1-1-1 (5-3-2) |
| 3 | 7-2-1 (6-3-1); 7-1-1-1 (6-4); 5-1-1-1-1-1 (6-4); 4-2-2-2 (4-3-1-1-1); 4-2-1-1-1-1 (6-3-1) GoE |
| 4 | 8-2 (7-2-1); 3-3-3-1 (4-2-2-2); 3-2-1-1-1-1-1 (7-2-1) GoE; 2-2-2-2-2 (5-1-1-1-1-1) GoE; 2-2-2-1-1-1-1 (7-1-1-1) GoE |
| 5 | 9-1 (8-2); 4-4-2 (3-3-3-1); 3-1-1-1-1-1-1-1 (8-2) GoE |
| 6 | 10 (9-1); 5-5 (4-4-2); 5-3-1-1 (4-4-2); 2-1-1-1-1-1-1-1-1 (9-1) GoE |
| 7 | 6-2-2 (5-3-1-1); 6-1-1-1-1 (5-5); 4-2-2-1-1 (5-3-1-1); 1-1-1-1-1-1-1-1-1-1 (10) GoE |
| 8 | 7-3 (6-2-2); 3-3-2-2 (4-2-2-1-1); 3-3-1-1-1-1 (6-2-2) GoE; 2-2-2-2-1-1 (6-1-1-1-1) GoE |
| 9 | 8-1-1 (7-3); 4-3-3 (3-3-2-2); 4-1-1-1-1-1-1 (7-3) GoE |
| 10 | 5-4-1 (4-3-3); 4-4-1-1 (4-3-3); 2-2-1-1-1-1-1-1 (8-1-1) GoE |
| 11 | 6-2-1-1 (5-4-1); 5-2-2-1 (4-4-1-1); 5-2-1-1-1 (5-4-1) |
| 12 | 3-3-2-1-1 (5-2-2-1) GoE; 3-2-2-2-1 (5-2-1-1-1) GoE; 3-2-2-1-1-1 (6-2-1-1) GoE |

Selected full games with 10 counters: `10 → 9-1 → 8-2 → 7-2-1 → 6-3-1 → 5-3-2 → 4-3-2-1`; `5-5 → 4-4-2 → 3-3-3-1 → 4-2-2-2 → 4-3-1-1-1 → 5-3-2 → 4-3-2-1`; `2-2-2-2-2 → 5-1-1-1-1-1 → 6-4 → 5-3-2 → 4-3-2-1`; `7-3 → 6-2-2 → 5-3-1-1 → 4-4-2 → 3-3-3-1 → 4-2-2-2 → 4-3-1-1-1 → 5-3-2 → 4-3-2-1`; `3-3-2-1-1 → 5-2-2-1 → 4-4-1-1 → 4-3-3 → 3-3-2-2 → 4-2-2-1-1 → 5-3-1-1 → 4-4-2 → 3-3-3-1 → 4-2-2-2 → 4-3-1-1-1 → 5-3-2 → 4-3-2-1` (12; `3-2-2-2-1 → 5-2-1-1-1 → 5-4-1 → 4-3-3 → …` and `3-2-2-1-1-1 → 6-2-1-1 → 5-4-1 → 4-3-3 → …` join it there).

**n = 15 from the single pile (10 moves):** `15 → 14-1 → 13-2 → 12-2-1 → 11-3-1 → 10-3-2 → 9-3-2-1 → 8-4-2-1 → 7-4-3-1 → 6-4-3-2 → 5-4-3-2-1`.

### 3.3 Loop pictures for n = 11..14 (k = 4, loops of length 5)

11: `5-3-2-1 → 4-4-2-1 → 4-3-3-1 → 4-3-2-2 → 4-3-2-1-1 →`. 12: `5-4-2-1 → 4-4-3-1 → 4-3-3-2 → 4-3-2-2-1 → 5-3-2-1-1 →` and `5-3-3-1 → 4-4-2-2 → 4-3-3-1-1 → 5-3-2-2 → 4-4-2-1-1 →`. 13: `5-4-3-1 → 4-4-3-2 → 4-3-3-2-1 → 5-3-2-2-1 → 5-4-2-1-1 →` and `5-4-2-2 → 4-4-3-1-1 → 5-3-3-2 → 4-4-2-2-1 → 5-3-3-1-1 →`. 14: `5-4-3-2 → 4-4-3-2-1 → 5-3-3-2-1 → 5-4-2-2-1 → 5-4-3-1-1 →`.

### 3.4 Undo table, 6 counters

`6 ← 1-1-1-1-1-1`; `5-1 ← 6, 2-1-1-1-1`; `4-2 ← 5-1, 3-1-1-1`; `4-1-1 ← 2-2-1-1`; `3-3 ← 4-1-1`; `3-2-1 ← 4-2, 3-2-1`; `3-1-1-1 ← 2-2-2`; `2-2-2 ← 3-3`; `2-2-1-1`, `2-1-1-1-1`, `1-1-1-1-1-1` ← nothing.

---

## 4. Arguments children can give

**K–1** (recognition, not proof). "Is this the same as the one before? Put them next to each other, row under row." (Stuck.) "Have we seen this picture already? Look at all the sheets." (Loop.) "Count all the counters again — still six? So nothing got lost." "Before you put the new pile down: how many piles did we take from? So how many are in your hand?" "Everybody started differently. Where did everybody end?"

**Grades 2–3.** *Table of all cases:* "How do you know there isn't a twelfth picture? Start with the biggest pile 6, then 5, then 4 … what can go with it?" *Following arrows:* "You listed every picture and every arrow. Can a game with 6 counters avoid `3-2-1`? Point to where it could escape." *Why stuck:* "Say what happens to `3-2-1` out loud: three becomes two, two becomes one, one disappears, and the three you took make … a three." *Why a loop is forever:* "If a picture repeats, what happens next? Why the same thing?" *Counterexample:* "Someone says every number ends at a stairs. What number breaks that?" (4.) *Prediction:* "Before you move, tell me the size of the new pile. Now check."

**Grades 4–5.** *Stuck ⇒ stairs*, in this order: "In a stuck picture, call the biggest pile B. After the move, is any old pile still as big as B? So which pile is the size-B pile of the new picture? How big is the new pile always? So B equals what? The old B-pile shrank — to what? Is that size in the picture? Keep going: B, B−1, … down to what? How many piles is that? How many piles are there? So what are all the piles?" *Wanderers:* "Draw the stairs `3-2-1` and mark the extra counter of `4-2-1`. Move. Where is the extra now? Again. What happens when it reaches the bottom?" *Garden of Eden by undoing:* "Pretend `2-2-1-1` just got made. One pile is the new one. Take it apart and give a counter back to every other pile. Enough? Try another pile." *Pigeonhole:* "With 8 counters there are 22 pictures. How long can a game go without repeating? Then what?" *Same reason on a bigger one:* "You proved 6 by listing all cases. For 10 there are 42, for 15 there are 176. Is there a reason that does not need the list?" (Lead to wanderers/diagonals if a mathematician is at the table; otherwise leave it open and name the theorem.)

---

## 5. Pitfalls

**Rule misstatements.** (1) Forgetting that piles of 1 also give up their counter and vanish — the commonest error; say "one from every pile, even the tiny ones". (2) Putting the collected counters onto an existing pile instead of a new one. (3) Taking from the new pile during the same move: collect into a hand or cup first, then set the new pile down. (4) "Which pile do I take from?" — all of them; there are no choices, only the start. (5) Treating `3-1` and `1-3` as different; always record largest first. (6) "Stuck" means same *sizes*, not the same counters in the same spots.

**Recording.** One line per move, largest first; loop detection means comparing with *all* earlier lines. Recount the total after each move; check the new pile equals the old number of piles. The listing of all pictures for 6 is usually short by one or two (`4-1-1`, `2-2-1-1` are the usual omissions); 11 is the check.

**Wrong conclusions to expect.** "Every number ends in a loop, so 6 does too" — fine if a loop of length 1 counts; agree on words. "`2-2` is stuck" — test it (→ `2-1-1`). "Every start takes the same number of moves" — no (1 to 6 for 6 counters). "8 is like 7" — only if nobody tries a 2-loop start; 15 of 22 starts go to the 4-loop, so hand out `2-2-2-2` or `5-3`. "The single pile is the slowest start" — `10` takes 6, `3-3-2-1-1` takes 12. "Loops always have length 3" — 4 and 5 counters give 3, but 7 gives 4 and 8 gives 4 and 2. In the diagonal demonstration (4–5 reserve 8) the pictures are the same as in the ordinary game; only the bookkeeping of where the new row is laid differs — say so, or a child will think the rule changed.

**Physical and time.** A move takes roughly 40–60 s at K–1 (with re-laying), 20–30 s with recording at 2–3, 15–20 s at 4–5; a 12-move game with 10 counters is 4–6 minutes. Rows of 10 need about 25 cm; counters about 2 cm; towers above 5 fall, so rows or flat heaps. Keeping every picture on the table (K–1 loop) costs (moves+1) × n counters — 20 for the 4-counter loop, 42 for the 6-move game with 6 — so have 100+ counters per table or draw past pictures as dots. The 6-map takes a third grader 5–8 minutes on a full sheet (draw the Y of Q8); the 8-map needs a large sheet — lay out both loops first, then attach feeders. Playing cards slide; use them for the diagonal demonstration, not as ordinary counters. The K–1 page for the adult must carry the full 3-, 4-, 5- and 6-counter maps, since that adult may be the parent; do not start 10 at K–1 unless the first grader is comfortable (6 moves plus re-laying is 6–8 minutes).

---

## 6. Where it leads (for the two mathematicians)

- **J. Brandt, "Cycles of partitions", Proc. AMS 85 (1982) 483–486**: fixed point iff triangular, the cycle description, every start reaching the stairs. **Martin Gardner, Scientific American, Aug. 1983** popularized it under this name.
- **Bound k² − k**: K. Igusa, "Solution of the Bulgarian solitaire conjecture", Math. Mag. 58 (1985) 259–271; G. Etienne, "Tableaux de Young et solitaire bulgare", J. Combin. Theory A 58 (1991) 181–197. E. Akin & M. Davis, "Bulgarian solitaire", Amer. Math. Monthly 92 (1985) 237–250, is the readable exposition; also H. J. Bentz, Ars Combin. 23 (1987). (Citations from memory; check years and pages before printing.)
- **Cycles as shifts, necklaces**: J. R. Griggs & C.-C. Ho, "The cycling of partitions and compositions under repeated shifts", Adv. Appl. Math. 21 (1998) 205–227; B. Hopkins & M. A. Jones, "Shift-induced dynamical systems on partitions and compositions", Electron. J. Combin. 13 (2006). Counting loops is a first real use of Burnside/Pólya.
- **Garden of Eden**: B. Hopkins & J. A. Sellers, "Exact enumeration of Garden of Eden partitions", Integers 7(2) (2007): GoE iff Dyson rank λ₁ − ℓ(λ) ≤ −2. The term is from cellular automata (Moore's Garden of Eden theorem).
- **Survey**: V. Drensky, "The Bulgarian solitaire and the mathematics around it", arXiv:1503.00885 (2015): history, generalizations (Carolina/Austrian solitaire, σ-shifts of compositions), random Bulgarian solitaire (S. Popov, Random Structures & Algorithms 2005), limit shapes (H. Eriksson & M. Jonsson, Adv. Appl. Math. 2012).
- **Courses and open ends**: integer partitions and Young's lattice (Andrews, *The Theory of Partitions*; Stanley, EC1 §1.8); finite dynamical systems (functional graphs, transients, basins); monovariant arguments (Φ of Q3 is a textbook one). For a strong student: characterize the basins at n = 8 or 12; the distribution of transient lengths; the average number of moves to the stairs.
