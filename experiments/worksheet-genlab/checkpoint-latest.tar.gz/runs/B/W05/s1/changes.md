# Changes to the Week 1 packet (rewriter stage)

The previous version (four sources, `week-macros.tex`, `genlab-common.tex`, and the PDFs) is preserved in `before-rewrite/`. All four files recompile with `pdflatex -interaction=nonstopmode` with no errors and no overfull or underfull boxes; every page was rendered with `pdftoppm -r 60` and checked. Page counts: K–1 10 pages (unchanged), grades 2–3 10 pages (was 9), grades 4–5 13 pages (was 11), guide 15 pages (was 14). Every new answer was checked with `bulgarian.py` (move counts for the six Problem 5 games, the 7-1-1-1 card layout and its totals, the undo answers for 1-1-1-1-1-1 / 2-2-1-1 / 2-1-1-1-1, the 12-counter basins 45 and 32, the partition lists for 4, 5 and 7).

All 28 review items were accepted. What changed, by item:

## Facilitator guide (`week-facilitator.tex`)

1. Section 7: core is now Problem 1, Problem 2, Problem 3 (a)–(d) (13 + 12 + 15 ≈ 40 min); reserves in this order: 3 (e)(f) 12, 4 20, 6 10, 5 25, 7 8, 8 15–18, 9 15. The timing table is rewritten with the P3 row split and a "Reserves, in this order" divider. The clause about Problem 5 as the share item is gone; it now says "if Problem 3 runs long, stop after (d) and share loops A and B from the table without the map". The stall/finish paragraph follows the same order.
2. Section 6: core is Problems 1–4 and the 4-counter half of Problem 5 (10 + 10 + 10 + 8 ≈ 40 min); reserves in this order: 5 (5-counter half) 8, 6 12, 8 10, 9–10 12, 7 15, 11 6, 12 6, with those minutes in the table. The old "if the table is slow …" fallback sentence is removed (it is now the plan); the stall/finish paragraph names the reserve order.
3. Section 5: "Counting moves is done by counting colored boxes" replaced by the correct rule (first box that shows the stairs; box 0 is the start; in Problem 3 the boxes start at 1).
8. Section 1: adults assigned to tables (parent at K–1, second mathematician at 2–3, organizer at 4–5 and away for launch and close).
15. Problem 12 answer rewritten for parts (a), (b), (c), with the 2-1-1-1-1 case.
19. Problem 8 answer extended with part (e): grid 7 = A 2 3 4 / 2 3 4 5 6 7 (total 37, unchanged, out of order at once), grid 8 = 2 3 4 5 6 7 / A 2 3 4 (6-4), all ten cards break the rule, totals 37 and 35, difference 2 = 6 − 4; the contrast stated (special move keeps the total, each swap drops it by long minus short, so it never rises). Section 7 intro says Problem 8 is handed out only after hint 7. Materials: cards A to 7 of three suits.
21. "(for n ≥ 2)" added in Section 9 and Section 10 (from all singles one move more).
22. Close: "0, 2, 6, 12, 20 for 1, 3, 6, 10, 15 counters; the 6 for 6 counters is exactly the longest game you found today."
23. Materials: one small cup per child (10); counters at most 2 cm across at K–1 (mats hold a row of four); grades 4–5 counters 80 → 100 with the reason; cards A to 7.
26. Problem 9 answer: let the 12-counter search run two or three starts, then give the fact (all 77 pictures reach loop A or B; 45 and 32) and the stairs-plus-wanderers reason.
27. `\newpage` before Section 5, so its heading, paragraph and table sit together.
28. Section 5: Problem 4 row is 20 minutes (two starts for the kindergartners, three for the first grader); core estimate "about 45 minutes; if Problem 4 runs long, the two kindergartners go to Problem 5 after start B"; note under Problems 9–10 about the stairs icon for 1 counter.

Also: the intro line gives the new page counts; the Problem 5 (2–3) answer now covers the new printed question (no picture with 4 or 5 counters gives itself back, shown by the list); the Problem 6 (2–3) answer is lettered (a)–(e) to match the page; the Problem 9 (2–3) answer gives the new blanks (rows 1, 2, 3, 4); the Problem 7 (4–5) answer lists the pictures for 4 and 5 that go in the new box.

## K–1 pages (`week-k-1.tex`)

9. Problem 4: "Color box 0 on the next page … fill the boxes marked start B … start C."
10. Problem 6: "Now build the staircase with 4 rows on the table with 10 counters and make a move. Put the longest row on top. Is it the same picture as before the move?"
11. Problem 11: "draw a line around a stairs with rows of 3, 2 and 1, and put a ring around the circle that is left over" (no crayon over crayon).
12. Problem 7: the undersized row of ten printed circles is gone; "Put 10 counters in one row on the table, like the picture", with a `\MidDots{10}` reference picture.

## Grades 2–3 pages (`week-grades-2-3.tex`)

5. Problem 7 gets a "Problem 7, continued" page with four more strips (Games E–H, 13 rows each) for the search; the "Moves: A … H" line and the "start that takes more than 8 moves" line moved there. Page 6 now says the search uses games E to H on the next page.
13. Problem 9: "Which row is the ringed dot in? box 1 … box 4" (answers 1, 2, 3, 4).
14. Problem 5: added "Is there a picture with 4 counters that gives itself back? __ With 5 counters? __ Tell the adult how your list shows it."
15. Problem 12 rewritten as (a), (b), (c) with ruled answer lines (2, 3, 2); the printed reasoning removed; 2-1-1-1-1 used.
18. Problems 6, 8 and 11: the tasks that stood below the tables are now lettered parts of the problem text; below the tables only blanks and boxes remain ((c) and (d) lines in Problem 6; the loop lines, the same-loop line and the box in Problem 8).
20. Problem 7: "the stuck picture" instead of "the picture that gives itself back" (after Problem 6's definition), so the guide's "Words" claim is true.

## Grades 4–5 pages (`week-grades-4-5.tex`)

4. Problem 5: six strips before the loop table, in two rows of three (`7 from 7` 8 rows, `8 from 8` 9, `8 from 2-2-2-2` 6; `9 from 9` 10, `11 from 11` 12, `12 from 12` 13, i.e. moves + 1 spare, the packet's convention); the 4- and 5-counter games go straight into the table. The loop table and the mats for (b), (c), (d) are on a "Problem 5, continued" page.
6. Problem 4: page 6 ends "(f) Guess both numbers for 15 counters and write them in the table."; page 7 says "(f, continued) Play from one pile of 15 in the column headed '15, one pile' … (g) …".
7. Problem 7: the sentence "Write your lists for 4, 5 and 7 counters in the box, each list in order of biggest pile" and a 6 cm box after the table.
16. Problem 1 (g) ends with a colon and three ruled lines; the map page is now `\Problem{1, continued}{…}` with the map box enlarged to 15 cm.
17. Problem 3: the "biggest 2 or 1" table is stacked under "biggest 5 to 8", the "biggest 4 or 3" table beside them, picture columns 3.4 cm and one-move-later columns 3.2 cm.
19. Problem 8 gets a "Problem 8, continued" page with part (e): the 7-1-1-1 start printed in a 7 × 4 card grid (new `\CardGridW` macro), grid 7 and grid 8 (sorted), blanks for the cards that break the rule, the two totals and the difference, and a line recording the lengths of the swapped rows and the drop for grid 6 and for grid 8, so the two instances can be compared.
20. Problem 4: "the stuck picture" instead of "the picture that gives itself back".
24. Problem 1 (d): "how many moves it takes to reach the picture that gives itself back"; the table header and the map-page instruction say the same (the header column widened so the page-1 table still fits on one page).
25. Problem 6 opens "Pretend 4-2-1 was just made by a move and undo it: …"; (d) says "check against your table or map from Problem 3", since the map is now a reserve.
26. Problem 9 (c): "Play these on the large sheet, numbers only. Write the starts you tried and the loop length each one reached in the small table."

## Review points rejected

None. Two small things were done differently from the letter of the review, for layout reasons: the map box on the 4–5 map page is 15 cm (not 14.5) because the ruled lines for (g) left room; and the new Problem 8 (e) sits on its own continuation page rather than on page 10 (11 now), which was already full.
