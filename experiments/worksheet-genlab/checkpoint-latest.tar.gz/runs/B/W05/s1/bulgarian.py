#!/usr/bin/env python3
"""Bulgarian solitaire: exhaustive small-case data for the Week 1 dossier.

State = partition of n (tuple, decreasing).  Move: subtract 1 from every part,
drop zeros, append a new part equal to the old number of parts.

Run:  python3 bulgarian.py            (prints all tables used in dossier.md)
"""
from collections import defaultdict
from math import gcd
from functools import lru_cache
import sys

def partitions(n, maxpart=None):
    """All partitions of n as decreasing tuples."""
    if maxpart is None or maxpart > n:
        maxpart = n
    if n == 0:
        yield ()
        return
    for first in range(maxpart, 0, -1):
        for rest in partitions(n - first, first):
            yield (first,) + rest

def move(p):
    m = len(p)
    new = [x - 1 for x in p if x > 1] + [m]
    return tuple(sorted(new, reverse=True))

def name(p):
    return "-".join(str(x) for x in p)

def phi(p):
    """Sum over cells of (row + column - 1), rows = parts, top row = largest."""
    return sum((i + j - 1) for i, part in enumerate(p, start=1) for j in range(1, part + 1))

def triangular(k):
    return k * (k + 1) // 2

def analyse(n):
    states = list(partitions(n))
    succ = {p: move(p) for p in states}
    # find cycles
    in_cycle = {}
    cycles = []
    for p in states:
        if p in in_cycle:
            continue
        path = []
        seen = {}
        q = p
        while q not in seen and q not in in_cycle:
            seen[q] = len(path)
            path.append(q)
            q = succ[q]
        if q in in_cycle:
            cyc = in_cycle[q]
        else:
            start = seen[q]
            cyc_states = path[start:]
            cycles.append(cyc_states)
            cyc = len(cycles) - 1
            for s in cyc_states:
                in_cycle[s] = cyc
        for s in path:
            in_cycle[s] = cyc
    # distance to cycle (transient length)
    cycset = set()
    for c in cycles:
        cycset.update(c)
    dist = {}
    def d(p):
        if p in dist:
            return dist[p]
        if p in cycset:
            dist[p] = 0
            return 0
        dist[p] = 1 + d(succ[p])
        return dist[p]
    for p in states:
        d(p)
    indeg = defaultdict(int)
    for p in states:
        indeg[succ[p]] += 1
    return states, succ, cycles, in_cycle, dist, indeg

def predecessors(p, n):
    return [q for q in partitions(n) if move(q) == p]

def necklaces(L, r):
    """Number of binary necklaces of length L with r ones."""
    from math import comb
    g = gcd(L, r) if r > 0 else L
    tot = 0
    def phi_euler(d):
        res, x = d, d
        f = 2
        while f * f <= x:
            if x % f == 0:
                while x % f == 0:
                    x //= f
                res -= res // f
            f += 1
        if x > 1:
            res -= res // x
        return res
    for dd in range(1, g + 1):
        if g % dd == 0:
            tot += phi_euler(dd) * comb(L // dd, r // dd)
    return tot // L

def brandt_cycle_states(n):
    """Predicted cycle states: staircase (k,...,1,0) plus 0/1 on r of the k+1 entries."""
    k = 0
    while triangular(k + 1) <= n:
        k += 1
    r = n - triangular(k)
    assert 0 <= r <= k
    from itertools import combinations
    base = list(range(k, -1, -1))  # k, k-1, ..., 1, 0
    out = set()
    for pos in combinations(range(k + 1), r):
        v = base[:]
        for i in pos:
            v[i] += 1
        out.add(tuple(sorted([x for x in v if x > 0], reverse=True)))
    return k, r, out

def trajectory(p, limit=200):
    traj = [p]
    seen = {p: 0}
    q = p
    while True:
        q = move(q)
        if q in seen:
            return traj, seen[q]  # returns path and index where cycle starts
        seen[q] = len(traj)
        traj.append(q)
        if len(traj) > limit:
            return traj, None

def print_full_map(n):
    states, succ, cycles, in_cycle, dist, indeg = analyse(n)
    print(f"\n=== n = {n}: {len(states)} pictures, {len(cycles)} cycle(s) ===")
    for ci, c in enumerate(cycles):
        print(f"  cycle {ci}: length {len(c)}: " + " -> ".join(name(s) for s in c) + f" -> {name(c[0])}")
    print(f"  {'picture':<16}{'next':<16}{'moves to cycle':<16}{'lands in':<10}{'#preds':<8}GoE?")
    for p in sorted(states, key=lambda q: (-dist[q], q)):
        goe = "GoE" if indeg[p] == 0 else ""
        print(f"  {name(p):<16}{name(succ[p]):<16}{dist[p]:<16}{in_cycle[p]:<10}{indeg[p]:<8}{goe}")
    basins = defaultdict(int)
    for p in states:
        basins[in_cycle[p]] += 1
    print("  basin sizes:", dict(basins))
    print("  max moves to cycle:", max(dist.values()),
          "attained by:", [name(p) for p in states if dist[p] == max(dist.values())])
    goes = [name(p) for p in states if indeg[p] == 0]
    print(f"  Garden of Eden states ({len(goes)}):", goes)

def check_theory(nmax):
    print("\n=== Checks against theory, n = 1..%d ===" % nmax)
    print(f"{'n':>3} {'p(n)':>5} {'k':>2} {'r':>2} {'#cycles':>7} {'lengths':<14} {'#cyc states':>11} {'C(k+1,r)':>8} {'necklaces':>9} {'max transient':>13} {'#GoE':>5} {'GoE rule ok':>11} {'Phi ok':>6}")
    for n in range(1, nmax + 1):
        states, succ, cycles, in_cycle, dist, indeg = analyse(n)
        k, r, pred = brandt_cycle_states(n)
        actual = set()
        for c in cycles:
            actual.update(c)
        assert actual == pred, (n, actual, pred)
        from math import comb
        assert len(actual) == comb(k + 1, r)
        assert len(cycles) == necklaces(k + 1, r), (n, len(cycles), necklaces(k + 1, r))
        for c in cycles:
            # cycle length must divide k+1
            assert (k + 1) % len(c) == 0
        # Garden of Eden rule: no predecessor iff largest part <= (#parts) - 2
        goe_ok = all((indeg[p] == 0) == (p[0] <= len(p) - 2) for p in states)
        # number of predecessors = number of distinct part sizes >= (#parts)-1
        npred_ok = all(indeg[p] == len({x for x in p if x >= len(p) - 1}) for p in states)
        assert npred_ok, n
        # Phi monovariant: phi(move(p)) <= phi(p), equality iff #parts >= largest - 1
        phi_ok = all((phi(succ[p]) <= phi(p)) and ((phi(succ[p]) == phi(p)) == (len(p) >= p[0] - 1)) for p in states)
        ngoe = sum(1 for p in states if indeg[p] == 0)
        lengths = ",".join(str(len(c)) for c in cycles)
        print(f"{n:>3} {len(states):>5} {k:>2} {r:>2} {len(cycles):>7} {lengths:<14} {len(actual):>11} {comb(k+1,r):>8} {necklaces(k+1,r):>9} {max(dist.values()):>13} {ngoe:>5} {str(goe_ok):>11} {str(phi_ok):>6}")

def longest_games_triangular(kmax):
    print("\n=== Triangular n: moves to reach the staircase ===")
    for k in range(1, kmax + 1):
        n = triangular(k)
        states, succ, cycles, in_cycle, dist, indeg = analyse(n)
        assert len(cycles) == 1 and len(cycles[0]) == 1
        mx = max(dist.values())
        worst = [name(p) for p in states if dist[p] == mx]
        hist = defaultdict(int)
        for p in states:
            hist[dist[p]] += 1
        print(f"k={k} n={n} p(n)={len(states)} max moves={mx} (k^2-k={k*k-k}) attained by {len(worst)} start(s): {worst[:8]}{' ...' if len(worst)>8 else ''}")
        print("   #starts needing t moves:", " ".join(f"{t}:{hist[t]}" for t in sorted(hist)))

def print_trajectories(n, starts):
    print(f"\n=== Selected trajectories, n = {n} ===")
    for s in starts:
        traj, cyc_at = trajectory(s)
        line = " -> ".join(name(p) for p in traj)
        if cyc_at is not None:
            line += f" -> {name(traj[cyc_at])} [loop back to step {cyc_at}]"
        moves_to_cycle = cyc_at if cyc_at is not None else None
        print(f"  start {name(s)}: {line}")
        print(f"     ({len(traj)-1} moves shown; enters loop at step {cyc_at}; loop length {len(traj)-cyc_at if cyc_at is not None else '?'})")

def print_all_trajectories(n):
    print(f"\n=== Every start, n = {n} ===")
    for s in partitions(n):
        traj, cyc_at = trajectory(s)
        line = " -> ".join(name(p) for p in traj)
        line += f" -> {name(traj[cyc_at])}"
        print(f"  {name(s)}: {line}   [{cyc_at} moves to loop, loop length {len(traj)-cyc_at}]")

def diagonal_check(n):
    """On a cycle, with the 'new row on top' convention, verify every cell keeps its diagonal."""
    states, succ, cycles, in_cycle, dist, indeg = analyse(n)
    for c in cycles:
        for p in c:
            m = len(p)
            unsorted = [m] + [x - 1 for x in p if x > 1]
            assert unsorted == sorted(unsorted, reverse=True), (n, p, unsorted)
    return True

# ---------------------------------------------------------------------------
# Extra checks used in the dossier.
# ---------------------------------------------------------------------------
def moves_to_fixed(p):
    t = 0
    while move(p) != p:
        p = move(p)
        t += 1
    return t

def extra():
    print("\n=== Families of starts, triangular n = T_k ===")
    print(" k   n  single pile (n)   all ones 1^n   (k-1,k-1,k-2,...,1,1)   k^2-k   T_{k-1}")
    for k in range(2, 13):
        n = triangular(k)
        fam = tuple([k-1, k-1] + list(range(k-2, 0, -1)) + [1])
        assert sum(fam) == n
        print(f"{k:>2} {n:>3} {moves_to_fixed((n,)):>16} {moves_to_fixed((1,)*n):>13} {moves_to_fixed(fam):>22} {k*k-k:>7} {triangular(k-1):>8}")

    print("\n=== n = 8: is there a simple rule for which loop a start lands in? ===")
    states, succ, cycles, in_cycle, dist, indeg = analyse(8)
    two = [p for p in states if len(cycles[in_cycle[p]]) == 2]
    four = [p for p in states if len(cycles[in_cycle[p]]) == 4]
    print("  lands in 2-loop:", [name(p) for p in two])
    print("  lands in 4-loop:", [name(p) for p in four])
    tests = {
        "#piles even": lambda p: len(p) % 2 == 0,
        "largest even": lambda p: p[0] % 2 == 0,
        "all piles even": lambda p: all(x % 2 == 0 for p_ in [p] for x in p_),
        "phi even": lambda p: phi(p) % 2 == 0,
        "#odd piles even": lambda p: sum(x % 2 for x in p) % 2 == 0,
        "largest-#piles even": lambda p: (p[0] - len(p)) % 2 == 0,
    }
    for label, f in tests.items():
        a = {f(p) for p in two}
        b = {f(p) for p in four}
        print(f"  {label:<22} values on 2-loop basin {sorted(a)}, on 4-loop basin {sorted(b)} -> {'separates' if a.isdisjoint(b) else 'does not separate'}")

    print("\n=== n = 10: the three longest games (12 moves) ===")
    for s in [(3,3,2,1,1), (3,2,2,2,1), (3,2,2,1,1,1), (2,2,1,1,1,1,1,1), (5,2,2,1), (6,2,1,1), (5,2,1,1,1)]:
        traj, cyc_at = trajectory(s)
        print(f"  {name(s)} ({cyc_at} moves): " + " -> ".join(name(p) for p in traj))

    print("\n=== Predecessors ('undo' table), n = 6 ===")
    for p in partitions(6):
        preds = predecessors(p, 6)
        print(f"  {name(p):<14} <- {', '.join(name(q) for q in preds) if preds else '(nothing: Garden of Eden)'}")

    print("\n=== Phi (sum of diagonal numbers) for all pictures with 6 counters ===")
    for p in sorted(partitions(6), key=phi):
        print(f"  {name(p):<14} phi={phi(p):>3}  moves to staircase={moves_to_fixed(p)}")

    print("\n=== Diagonal bookkeeping example: 4-2 -> 3-2-1 (new row on top, then sort) ===")
    p = (4,2)
    cells = {}
    for i, part in enumerate(p, 1):
        for j in range(1, part+1):
            cells[(i,j)] = i+j-1
    print("  before:", {k: v for k, v in sorted(cells.items())})
    m = len(p)
    after = {}
    for (i,j), d in cells.items():
        if j == 1:
            after[(1, i)] = d
        else:
            after[(i+1, j-1)] = d
    print("  after move, unsorted rows (2,3,1):", {k: v for k, v in sorted(after.items())})
    print("  Phi before =", phi(p), " Phi after sorting to 3-2-1 =", phi(move(p)))

    print("\n=== Loop lengths for n = T_k + r, k = 2..6 (predicted: divisors of k+1; number of loops = binary necklaces of length k+1 with r ones) ===")
    for k in range(2, 7):
        for r in range(1, k+1):
            n = triangular(k) + r
            states, succ, cycles, in_cycle, dist, indeg = analyse(n)
            print(f"  n={n:>2} (k={k}, r={r}): loops of length {sorted(len(c) for c in cycles)}; loop pictures: {', '.join(name(s) for c in cycles for s in c) if n <= 14 else str(sum(len(c) for c in cycles)) + ' pictures'}")


def main():
    check_theory(24)
    for n in range(1, 11):
        print_full_map(n)
    longest_games_triangular(8)
    print_all_trajectories(6)
    print_all_trajectories(4)
    print_all_trajectories(5)
    print_all_trajectories(7)
    print_all_trajectories(8)
    print_trajectories(10, [(10,), (1,)*10, (5,5), (2,2,2,2,2), (4,3,2,1), (3,3,3,1), (2,2,2,2,1,1), (6,4), (4,4,2), (7,3), (3,3,2,2), (2,2,2,1,1,1,1), (3,3,2,1,1)])
    print_trajectories(15, [(15,), (5,4,3,2,1)])
    for n in range(1, 25):
        diagonal_check(n)
    print("\nDiagonal check (cycle states are already sorted with new row on top): OK for n<=24")
    # phi values for n=6 trajectory
    print("\nPhi along the longest n=6 game:")
    p = (2,2,1,1)
    for _ in range(7):
        print(f"  {name(p):<10} phi={phi(p)}  (#parts={len(p)}, largest-1={p[0]-1})")
        p = move(p)
    extra()


if __name__ == "__main__":
    main()
