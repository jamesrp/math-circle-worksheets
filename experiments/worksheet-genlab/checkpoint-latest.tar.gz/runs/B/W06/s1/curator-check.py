#!/usr/bin/env python3
"""Curator's verification of every answer printed in plan.md (Week 1, Bulgarian solitaire).

Run:  python3 curator-check.py > curator-check.txt
Every claim is asserted; the script stops with an AssertionError if any printed answer is wrong.
Independent of bs.py (same brute force, rewritten), so the two act as cross-checks.
"""
from itertools import combinations
from math import lcm

def parts(n, m=None):
    m = n if m is None else m
    if n == 0:
        yield ()
        return
    for f in range(min(n, m), 0, -1):
        for r in parts(n - f, f):
            yield (f,) + r

def mv(p):
    return tuple(sorted([x - 1 for x in p if x > 1] + [len(p)], reverse=True))

def s(p):
    return "-".join(map(str, p))

def P(t):
    return tuple(int(x) for x in t.split("-"))

def orbit(p):
    seen, traj = {}, []
    while p not in seen:
        seen[p] = len(traj); traj.append(p); p = mv(p)
    return seen[p], len(traj) - seen[p], traj          # transient, loop length, states to first repeat

def show(start, extra=0):
    """Trajectory written up to and including the first repeated state (so a rest shows twice
    and a loop shows its closing arrow)."""
    t, c, traj = orbit(P(start))
    full = traj + [mv(traj[-1])]
    for _ in range(extra):
        full.append(mv(full[-1]))
    return " -> ".join(s(q) for q in full), t, c

def parents(q, n):
    return [p for p in parts(n) if mv(p) == q]

def tri(k):
    return k * (k + 1) // 2

out = []
def say(*a):
    print(*a)

say("=== 1. Runs quoted on the K-1 pages ===")
runs_k = {
    "1-1-1": ("1-1-1 -> 3 -> 2-1 -> 2-1", 2, 1),
    "3": ("3 -> 2-1 -> 2-1", 1, 1),
    "2-1": ("2-1 -> 2-1", 0, 1),
    "4": ("4 -> 3-1 -> 2-2 -> 2-1-1 -> 3-1", 1, 3),
    "1-1-1-1": ("1-1-1-1 -> 4 -> 3-1 -> 2-2 -> 2-1-1 -> 3-1", 2, 3),
    "6": ("6 -> 5-1 -> 4-2 -> 3-2-1 -> 3-2-1", 3, 1),
    "1-1-1-1-1-1": ("1-1-1-1-1-1 -> 6 -> 5-1 -> 4-2 -> 3-2-1 -> 3-2-1", 4, 1),
    "3-3": ("3-3 -> 2-2-2 -> 3-1-1-1 -> 4-2 -> 3-2-1 -> 3-2-1", 4, 1),
    "2-2-2": ("2-2-2 -> 3-1-1-1 -> 4-2 -> 3-2-1 -> 3-2-1", 3, 1),
    "4-2": ("4-2 -> 3-2-1 -> 3-2-1", 1, 1),
    "5-1": ("5-1 -> 4-2 -> 3-2-1 -> 3-2-1", 2, 1),
    "2-2-1-1": ("2-2-1-1 -> 4-1-1 -> 3-3 -> 2-2-2 -> 3-1-1-1 -> 4-2 -> 3-2-1 -> 3-2-1", 6, 1),
    "5": ("5 -> 4-1 -> 3-2 -> 2-2-1 -> 3-1-1 -> 3-2", 2, 3),
    "1-1-1-1-1": ("1-1-1-1-1 -> 5 -> 4-1 -> 3-2 -> 2-2-1 -> 3-1-1 -> 3-2", 3, 3),
    "10": ("10 -> 9-1 -> 8-2 -> 7-2-1 -> 6-3-1 -> 5-3-2 -> 4-3-2-1 -> 4-3-2-1", 6, 1),
}
for st, (txt, t, c) in runs_k.items():
    got, gt, gc = show(st)
    assert got == txt, (st, got)
    assert (gt, gc) == (t, c), (st, gt, gc)
    say(f"  {got}   [{gt} moves to the loop/rest, loop length {gc}]")

say("\n  four counters, six moves from one pile:")
traj = [P("4")]
for _ in range(6):
    traj.append(mv(traj[-1]))
say("  " + " -> ".join(s(q) for q in traj))
assert [s(q) for q in traj] == ["4", "3-1", "2-2", "2-1-1", "3-1", "2-2", "2-1-1"]
say("  pictures after 1 and 4 moves agree, 2 and 5, 3 and 6:", traj[1] == traj[4] and traj[2] == traj[5] and traj[3] == traj[6])
say("\n  five counters, six moves from one pile:")
traj = [P("5")]
for _ in range(6):
    traj.append(mv(traj[-1]))
say("  " + " -> ".join(s(q) for q in traj))
assert [s(q) for q in traj] == ["5", "4-1", "3-2", "2-2-1", "3-1-1", "3-2", "2-2-1"]

say("\n=== 2. All arrangements of 3, 4, 5, 6 and where one move sends them ===")
for n in (3, 4, 5, 6):
    ps = list(parts(n))
    say(f"  n={n}: {len(ps)} ways: " + ", ".join(s(p) for p in ps))
    say("        one move: " + "; ".join(f"{s(p)} -> {s(mv(p))}" for p in ps))
    fixed = [p for p in ps if mv(p) == p]
    say("        fixed:", [s(p) for p in fixed] or "none")
    images = {mv(p) for p in ps}
    say("        never the result of a move:", [s(p) for p in ps if p not in images])
assert len(list(parts(3))) == 3 and len(list(parts(4))) == 5 and len(list(parts(5))) == 7 and len(list(parts(6))) == 11
assert [p for p in parts(4) if mv(p) == p] == []
assert [s(p) for p in parts(4) if p not in {mv(q) for q in parts(4)}] == ["1-1-1-1"]
assert [s(p) for p in parts(3) if p not in {mv(q) for q in parts(3)}] == ["1-1-1"]
assert sum(1 for p in parts(4) if mv(p) == P("3-1")) == 2

say("\n=== 3. Six counters: moves to reach 3-2-1 for all eleven starts; the map ===")
ps6 = list(parts(6))
moves6 = {p: orbit(p)[0] for p in ps6}
for p in sorted(ps6, key=lambda q: (moves6[q], q)):
    say(f"  {s(p):>12}: {moves6[p]} moves; becomes {s(mv(p))}; parents {[s(q) for q in parents(p, 6)] or 'none'}")
assert all(orbit(p)[2][-1] == P("3-2-1") and orbit(p)[1] == 1 for p in ps6)
exp6 = {"3-2-1": 0, "4-2": 1, "5-1": 2, "3-1-1-1": 2, "6": 3, "2-2-2": 3, "2-1-1-1-1": 3,
        "1-1-1-1-1-1": 4, "3-3": 4, "4-1-1": 5, "2-2-1-1": 6}
assert {s(p): m for p, m in moves6.items()} == exp6
assert sorted(s(p) for p in ps6 if not parents(p, 6)) == sorted(["2-2-1-1", "2-1-1-1-1", "1-1-1-1-1-1"])
assert sorted(s(p) for p in ps6 if len(parents(p, 6)) == 2) == sorted(["4-2", "5-1", "3-2-1"])
assert [s(q) for q in parents(P("3-2-1"), 6)] and set(parents(P("3-2-1"), 6)) == {P("4-2"), P("3-2-1")}
assert set(parents(P("4-2"), 6)) == {P("5-1"), P("3-1-1-1")}
assert set(parents(P("5-1"), 6)) == {P("6"), P("2-1-1-1-1")}
assert set(parents(P("3-3"), 6)) == {P("4-1-1")}
assert set(parents(P("3"), 3)) == {P("1-1-1")}
# 4-2 lies on every run of six counters except the start 3-2-1 itself
for p in ps6:
    if p != P("3-2-1"):
        assert P("4-2") in orbit(p)[2], p
say("  4-2 lies on the run of every start except 3-2-1 itself: True")
say("  number of starts needing exactly 3 moves:", sum(1 for m in moves6.values() if m == 3))
assert sum(1 for m in moves6.values() if m == 3) == 3

say("\n=== 4. Number of piles before a move = size of the new pile (law) ===")
for st in ("2-2-2", "3-3", "2-2-1-1", "4-4-2"):
    p = P(st); rows = []
    for _ in range(6):
        q = mv(p); rows.append((s(p), len(p), len(p) if True else None, s(q)))
        assert len(p) in q  # the new pile really is there
        p = q
    say(f"  from {st}: " + "; ".join(f"{a} ({b} piles) -> new pile {b}, giving {d}" for a, b, _, d in rows[:5]))
# stronger check of the law on every partition up to 12
for n in range(1, 13):
    for p in parts(n):
        assert len(p) in mv(p)
say("  law checked for every arrangement of 1..12 counters")
assert show("4-4-2")[0] == "4-4-2 -> 3-3-3-1 -> 4-2-2-2 -> 4-3-1-1-1 -> 5-3-2 -> 4-3-2-1 -> 4-3-2-1"

say("\n=== 5. Fixed points are exactly the staircases (n <= 30) ===")
for n in range(1, 31):
    fixed = [s(p) for p in parts(n) if mv(p) == p]
    k = next((k for k in range(1, 9) if tri(k) == n), None)
    if k:
        assert fixed == [s(tuple(range(k, 0, -1)))], (n, fixed)
    else:
        assert fixed == [], (n, fixed)
say("  numbers up to 30 with a resting arrangement:", [n for n in range(1, 31) if any(mv(p) == p for p in parts(n))])
assert [n for n in range(1, 31) if any(mv(p) == p for p in parts(n))] == [1, 3, 6, 10, 15, 21, 28]
for k in range(1, 6):
    say(f"  staircase {s(tuple(range(k,0,-1)))} has {tri(k)} counters")

say("\n=== 6. Rest or loop, for 1..10 counters; loop lengths ===")
for n in range(1, 11):
    A = [orbit(p) for p in parts(n)]
    ends = {tuple(sorted(set(traj[t:]))) for t, c, traj in A}
    lens = sorted({c for t, c, traj in A})
    mx = max(t for t, c, traj in A)
    say(f"  n={n:2d}: {len(A):2d} starts; distinct loops {len(ends)}; loop lengths {lens}; longest way in {mx}")
RL = {n: ("R" if any(mv(p) == p for p in parts(n)) else "L") for n in range(1, 11)}
say("  R/L:", RL)
assert RL == {1: "R", 2: "L", 3: "R", 4: "L", 5: "L", 6: "R", 7: "L", 8: "L", 9: "L", 10: "R"}
assert show("2")[0] == "2 -> 1-1 -> 2"
assert show("1")[0] == "1 -> 1"

say("\n=== 7. Seven counters ===")
ps7 = list(parts(7)); assert len(ps7) == 15
say("  the fifteen ways:", ", ".join(s(p) for p in ps7))
got, t, c = show("7", extra=0)
say("  ", got, f"[{t} moves to the loop, loop length {c}]")
assert got == "7 -> 6-1 -> 5-2 -> 4-2-1 -> 3-3-1 -> 3-2-2 -> 3-2-1-1 -> 4-2-1" and (t, c) == (3, 4)
for st, txt, tt in [("4-3", "4-3 -> 3-2-2 -> 3-2-1-1 -> 4-2-1 -> 3-3-1 -> 3-2-2", 1),
                    ("2-2-2-1", "2-2-2-1 -> 4-1-1-1 -> 4-3 -> 3-2-2 -> 3-2-1-1 -> 4-2-1 -> 3-3-1 -> 3-2-2", 3),
                    ("3-1-1-1-1", "3-1-1-1-1 -> 5-2 -> 4-2-1 -> 3-3-1 -> 3-2-2 -> 3-2-1-1 -> 4-2-1", 2),
                    ("2-2-1-1-1", "2-2-1-1-1 -> 5-1-1 -> 4-3 -> 3-2-2 -> 3-2-1-1 -> 4-2-1 -> 3-3-1 -> 3-2-2", 3),
                    ("2-1-1-1-1-1", "2-1-1-1-1-1 -> 6-1 -> 5-2 -> 4-2-1 -> 3-3-1 -> 3-2-2 -> 3-2-1-1 -> 4-2-1", 3),
                    ("1-1-1-1-1-1-1", "1-1-1-1-1-1-1 -> 7 -> 6-1 -> 5-2 -> 4-2-1 -> 3-3-1 -> 3-2-2 -> 3-2-1-1 -> 4-2-1", 4)]:
    g, gt, gc = show(st)
    assert g == txt and gt == tt and gc == 4, (st, g, gt, gc)
    say("  ", g, f"[{gt} moves to the loop]")
loop7 = {P("4-2-1"), P("3-3-1"), P("3-2-2"), P("3-2-1-1")}
for p in ps7:
    t, c, traj = orbit(p)
    assert c == 4 and set(traj[t:]) == loop7, p
say("  every one of the 15 starts reaches the loop 4-2-1 -> 3-3-1 -> 3-2-2 -> 3-2-1-1")
mv7 = {s(p): orbit(p)[0] for p in ps7}
say("  moves to enter the loop:", mv7)
assert max(mv7.values()) == 4 and [k for k, v in mv7.items() if v == 4] == ["1-1-1-1-1-1-1"]
goe7 = [s(p) for p in ps7 if not parents(p, 7)]
say("  no parent:", goe7)
assert sorted(goe7) == sorted(["3-1-1-1-1", "2-2-2-1", "2-2-1-1-1", "2-1-1-1-1-1", "1-1-1-1-1-1-1"])
say("  parents of every arrangement of 7:")
for p in ps7:
    say(f"     {s(p):>14} <- {[s(q) for q in parents(p, 7)] or 'none'}")

say("\n=== 8. Eight counters ===")
ps8 = list(parts(8)); assert len(ps8) == 22
say("  the 22 ways:", ", ".join(s(p) for p in ps8))
for st, txt, tt, cc in [("8", "8 -> 7-1 -> 6-2 -> 5-2-1 -> 4-3-1 -> 3-3-2 -> 3-2-2-1 -> 4-2-1-1 -> 4-3-1", 4, 4),
                        ("5-3", "5-3 -> 4-2-2 -> 3-3-1-1 -> 4-2-2", 1, 2),
                        ("4-4", "4-4 -> 3-3-2 -> 3-2-2-1 -> 4-2-1-1 -> 4-3-1 -> 3-3-2", 1, 4),
                        ("2-2-2-2", "2-2-2-2 -> 4-1-1-1-1 -> 5-3 -> 4-2-2 -> 3-3-1-1 -> 4-2-2", 3, 2),
                        ("6-1-1", "6-1-1 -> 5-3 -> 4-2-2 -> 3-3-1-1 -> 4-2-2", 2, 2)]:
    g, gt, gc = show(st)
    assert g == txt and (gt, gc) == (tt, cc), (st, g, gt, gc)
    say("  ", g, f"[{gt} moves to the loop, loop length {gc}]")
loopA = [P("4-3-1"), P("3-3-2"), P("3-2-2-1"), P("4-2-1-1")]
loopB = [P("4-2-2"), P("3-3-1-1")]
basinA, basinB = [], []
for p in ps8:
    t, c, traj = orbit(p)
    if set(traj[t:]) == set(loopA):
        basinA.append(p)
    else:
        assert set(traj[t:]) == set(loopB), p
        basinB.append(p)
say(f"  loop of 4 reached by {len(basinA)}: " + ", ".join(f"{s(p)}({orbit(p)[0]})" for p in basinA))
say(f"  loop of 2 reached by {len(basinB)}: " + ", ".join(f"{s(p)}({orbit(p)[0]})" for p in basinB))
assert len(basinA) == 15 and len(basinB) == 7
assert sorted(s(p) for p in basinB) == sorted(["3-3-1-1", "4-2-2", "5-3", "4-1-1-1-1", "6-1-1", "2-2-1-1-1-1", "2-2-2-2"])
goe8 = [s(p) for p in ps8 if not parents(p, 8)]
say("  no parent (8):", goe8)
assert sorted(goe8) == sorted(["3-2-1-1-1", "3-1-1-1-1-1", "2-2-2-2", "2-2-2-1-1", "2-2-1-1-1-1", "2-1-1-1-1-1-1", "1-1-1-1-1-1-1-1"])
two8 = [s(p) for p in ps8 if len(p) == 2]; three8 = [s(p) for p in ps8 if len(p) == 3]
say("  two piles:", two8, " three piles:", three8)
assert two8 == ["7-1", "6-2", "5-3", "4-4"] and three8 == ["6-1-1", "5-2-1", "4-3-1", "4-2-2", "3-3-2"]

say("\n=== 9. Parents: specific answers and the rule ===")
for q, n, exp in [("5-3-2", 10, {"6-4", "6-3-1", "4-3-1-1-1"}), ("4-4", 8, {"5-1-1-1"}), ("2-2-2-2", 8, set()),
                  ("4-3-2-1", 10, {"5-3-2", "4-3-2-1"}), ("3-3", 6, {"4-1-1"}), ("2-2-1-1", 6, set()),
                  ("4-2", 6, {"5-1", "3-1-1-1"}), ("5-1", 6, {"6", "2-1-1-1-1"}), ("3", 3, {"1-1-1"}),
                  ("3-2-1", 6, {"4-2", "3-2-1"}), ("4-2-1", 7, {"5-2", "3-2-1-1"}), ("3-1", 4, {"4", "2-1-1"})]:
    got = {s(p) for p in parents(P(q), n)}
    assert got == exp, (q, got)
    say(f"  parents of {q}: {sorted(got) or 'none'}")

def rule_parents(q):
    L = len(q); out = set()
    for m in set(q):
        if m >= L - 1:
            r = list(q); r.remove(m)
            out.add(tuple(sorted([x + 1 for x in r] + [1] * (m - (L - 1)), reverse=True)))
    return out
for n in range(1, 19):
    for q in parts(n):
        assert set(parents(q, n)) == rule_parents(q), (n, q)
        assert (not parents(q, n)) == (q[0] <= len(q) - 2), (n, q)
say("  rule 'choose the new pile m >= piles-1; remove it; add 1 to the others; add m-(piles-1) singles' checked for n <= 18")
say("  rule 'no parent <=> biggest pile <= number of piles - 2' checked for n <= 18")
say("  no-parent counts n=3..10:", [sum(1 for q in parts(n) if not parents(q, n)) for n in range(3, 11)])
assert [sum(1 for q in parts(n) if not parents(q, n)) for n in range(3, 11)] == [1, 1, 2, 3, 5, 7, 10, 14]
# every arrangement has at most 3 parents for n <= 10? (just informative)
say("  most parents any arrangement of <=10 counters has:", max(len(parents(q, n)) for n in range(1, 11) for q in parts(n)))

say("\n=== 10. Ten counters ===")
ps10 = list(parts(10)); assert len(ps10) == 42
m10 = {s(p): orbit(p)[0] for p in ps10}
for p in ps10:
    assert orbit(p)[2][-1] == P("4-3-2-1") and orbit(p)[1] == 1
say("  all 42 starts rest at 4-3-2-1; distribution of moves:", {m: sum(1 for v in m10.values() if v == m) for m in range(13)})
for st, tt in [("10", 6), ("5-5", 6), ("7-3", 8), ("4-4-1-1", 10), ("9-1", 5), ("8-2", 4), ("6-4", 2), ("4-4-2", 5), ("3-3-2-2", 8), ("5-3-2", 1)]:
    g, gt, gc = show(st)
    assert gt == tt, (st, gt)
    say(f"  {g}   [{gt} moves]")
slow = sorted(k for k, v in m10.items() if v == 12)
say("  twelve-move starts:", slow, " max =", max(m10.values()))
assert slow == sorted(["3-3-2-1-1", "3-2-2-2-1", "3-2-2-1-1-1"]) and max(m10.values()) == 12
say("  eleven-move starts:", sorted(k for k, v in m10.items() if v == 11))
say("  two-pile starts of 10:", {k: m10[k] for k in ("9-1", "8-2", "7-3", "6-4", "5-5")})
assert show("3-3-2-1-1")[0] == "3-3-2-1-1 -> 5-2-2-1 -> 4-4-1-1 -> 4-3-3 -> 3-3-2-2 -> 4-2-2-1-1 -> 5-3-1-1 -> 4-4-2 -> 3-3-3-1 -> 4-2-2-2 -> 4-3-1-1-1 -> 5-3-2 -> 4-3-2-1 -> 4-3-2-1"
say("  moves-to-rest for every start of 10 (used as the K-1/2-3 lookup table):")
for p in sorted(ps10, key=lambda q: (m10[s(q)], q)):
    say(f"     {s(p):>20}: {m10[s(p)]:2d}")

say("\n=== 11. Single piles of triangular numbers; all-ones ===")
for k in range(2, 7):
    n = tri(k)
    t1 = orbit((n,))[0]; t2 = orbit((1,) * n)[0]
    say(f"  one pile of {n:2d}: {t1:2d} moves; all ones: {t2:2d} moves; bound k^2-k = {k*k-k}")
    assert t1 == tri(k - 1) and t2 == t1 + 1
g, t, c = show("15")
say("  ", g, f"[{t} moves]")
assert g == "15 -> 14-1 -> 13-2 -> 12-2-1 -> 11-3-1 -> 10-3-2 -> 9-3-2-1 -> 8-4-2-1 -> 7-4-3-1 -> 6-4-3-2 -> 5-4-3-2-1 -> 5-4-3-2-1"
traj15 = orbit((15,))[2]
for m, tail in [(1, (1,)), (3, (2, 1)), (6, (3, 2, 1)), (10, (4, 3, 2, 1))]:
    assert traj15[m][1:] == tail, (m, traj15[m])
say("  small piles after 1, 3, 6, 10 moves: 1; 2-1; 3-2-1; 4-3-2-1  (checked)")
mx15 = max(orbit(p)[0] for p in parts(15))
say("  slowest start with 15 counters needs", mx15, "moves; with 3:", max(orbit(p)[0] for p in parts(3)),
    "; with 6:", max(orbit(p)[0] for p in parts(6)), "; with 10:", max(orbit(p)[0] for p in parts(10)))
assert mx15 == 20

say("\n=== 12. Nine and twelve counters; loops as staircase plus extras ===")
g, t, c = show("9")
say("  ", g, f"[{t} moves to the loop, loop length {c}]")
assert g == "9 -> 8-1 -> 7-2 -> 6-2-1 -> 5-3-1 -> 4-3-2 -> 3-3-2-1 -> 4-2-2-1 -> 4-3-1-1 -> 4-3-2" and (t, c) == (5, 4)
for p in parts(9):
    t9, c9, tr9 = orbit(p)
    assert c9 == 4 and set(tr9[t9:]) == {P("4-3-2"), P("3-3-2-1"), P("4-2-2-1"), P("4-3-1-1")}
say("  every start of 9 reaches the loop 4-3-2 -> 3-3-2-1 -> 4-2-2-1 -> 4-3-1-1")

def extras(p, k):
    """epsilon vector: p listed biggest first, position i has base k-i (i=0..k)."""
    q = list(p) + [0] * (k + 1 - len(p))
    e = [q[i] - (k - i) for i in range(k + 1)]
    assert all(x in (0, 1) for x in e), (p, e)
    return e
for n, k in [(7, 3), (8, 3), (9, 3), (12, 4)]:
    A = [orbit(p) for p in parts(n)]
    loops = {}
    for t, c, tr in A:
        cyc = tr[t:]
        loops[tuple(sorted(cyc))] = cyc
    for cyc in loops.values():
        es = [extras(q, k) for q in cyc]
        for i in range(len(cyc)):
            e, e2 = es[i], es[(i + 1) % len(cyc)]
            assert e2 == [e[-1]] + e[:-1], (n, cyc, e, e2)      # rotation by one place
        say(f"  n={n}: loop " + " -> ".join(s(q) for q in cyc) + "   extras " + " -> ".join("".join(map(str, e)) for e in es))
say("  (extras rotate one place to the right each move; checked)")
A12 = [orbit(p) for p in parts(12)]
loops12 = {tuple(sorted(tr[t:])) for t, c, tr in A12}
say("  twelve: number of loops", len(loops12), "lengths", [len(l) for l in loops12])
assert len(loops12) == 2 and all(len(l) == 5 for l in loops12)
g, t, c = show("12"); say("  ", g, f"[{t} moves, loop {c}]")
assert t == 7 and c == 5
g, t, c = show("4-4-4"); say("  ", g, f"[{t} moves, loop {c}]")
assert t == 5 and c == 5
loops11 = {tuple(sorted(tr[t:])) for t, c, tr in [orbit(p) for p in parts(11)]}
say("  eleven: number of loops", len(loops11), "lengths", [len(l) for l in loops11])
assert len(loops11) == 1
for n in range(2, 21):
    A = [orbit(p) for p in parts(n)]
    ls = {tuple(sorted(tr[t:])) for t, c, tr in A}
    say(f"  n={n:2d}: loops {len(ls)} of lengths {sorted(len(l) for l in ls)}")

say("\n=== 13. Cards: the staircase rests but the cards move ===")
def card_move(piles):
    tops = [p[0] for p in piles]
    rest = [p[1:] for p in piles if len(p) > 1]
    return [tops] + rest
for k, n in [(3, 6), (4, 10)]:
    c = iter(range(1, n + 1))
    piles = [[next(c) for _ in range(size)] for size in range(k, 0, -1)]
    pos0 = {cd: (i, j) for i, pile in enumerate(piles) for j, cd in enumerate(pile)}
    cur = [list(p) for p in piles]; period = {}
    L = lcm(*range(1, k + 1))
    for step in range(1, L + 1):
        cur = card_move(cur)
        assert [len(p) for p in cur] == list(range(k, 0, -1))
        for i, pile in enumerate(cur):
            for j, cd in enumerate(pile):
                if pos0[cd] == (i, j) and cd not in period:
                    period[cd] = step
        if step == 1:
            say(f"  {n} cards, after 1 move: {cur}")
        if step in (2, 3, 4, 6, 12):
            back = sorted(cd for i, pile in enumerate(cur) for j, cd in enumerate(pile) if pos0[cd] == (i, j))
            say(f"     after {step:2d} moves, cards in their starting place: {back}")
    assert all(period[cd] == i + j + 1 for cd, (i, j) in pos0.items())
    say(f"  {n} cards: periods {period}; everything back after {L} moves")
    assert cur == piles

say("\n=== 13b. Facts quoted only in the mathematics section ===")
mx21 = max(orbit(p)[0] for p in parts(21))
say("  slowest start with 21 counters needs", mx21, "moves (bound k^2-k = 30)")
assert mx21 == 30
goe = [sum(1 for q in parts(n) if not parents(q, n)) for n in range(3, 13)]
pn3 = [len(list(parts(n - 3))) for n in range(3, 13)]
say("  no-parent counts n=3..12:", goe, "  p(n-3):", pn3)
assert goe == [1, 1, 2, 3, 5, 7, 10, 14, 20, 27]
for n, lens in [(13, [5, 5]), (17, [3, 6, 6]), (18, [2, 6, 6, 6])]:
    ls = sorted(len(l) for l in {tuple(sorted(tr[t:])) for t, c, tr in [orbit(p) for p in parts(n)]})
    assert ls == lens, (n, ls)
say("  loops for 13, 17, 18 agree with the necklace count (two of 5; 3,6,6; 2,6,6,6)")

say("\n=== 14. Partition counts ===")
say("  p(1..10):", [len(list(parts(n))) for n in range(1, 11)])
assert [len(list(parts(n))) for n in range(1, 11)] == [1, 2, 3, 5, 7, 11, 15, 22, 30, 42]

say("\nALL CHECKS PASSED")
