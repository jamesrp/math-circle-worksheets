# Copyedits, Week 1 (Bulgarian solitaire) — stage `copyeditor`

Originals are in `before-copyedit/`. Every change is editorial: no problem, diagram, recording space or answer was added, removed, reordered or changed mathematically. All four files recompile with pdflatex with no errors, no overfull or underfull boxes, and the same page counts as before (K–1 21 pp., grades 2–3 13 pp., grades 4–5 19 pp., guide 15 pp.).

## week-k-1.tex

- No changes: every problem is already a plain read-aloud instruction with its own frames or blanks; nothing forbidden (titles, labels, praise, exclamation marks, notes to the adult) is printed.

## week-grades-2-3.tex

- Problem 4: "write R next to each number of counters ... and L next to each number" → "write R under each number ... and L under each number" (the numbers are the table's column headings, so the child writes under them).
- Problem 5: "Share the list out at your table." → "Split the eleven starts between you." (plain, says what to do).
- Problem 8: "Say in your own words why there is none." → "Write why there is none." (the answer lines under the table are for this).
- Problem 13: "write what you think one pile of fifteen will take" → "write how many moves you think one pile of fifteen will take" (says what is predicted).

## week-grades-4-5.tex

- Problem 2: "Write each other arrangement in a box above the arrangement it becomes after one move, and draw an arrow from it to that arrangement." → "For each other arrangement, draw a box above the arrangement it becomes after one move, write it in the box, and draw an arrow from the box to that arrangement." (the map page is blank except for 3-2-1; the child draws the boxes).
- Problem 4: "which pile of the new picture must be the new pile" → "which pile after the move must be the new pile" (the pages say "arrangement", not "picture").
- Problem 5: "Share them out at your table." → "Split them between you."
- Problem 6: "Write the arrangements of each loop in a ring of its own, in the order they come." → "Write the arrangements of each loop as a ring in a box of its own on the next page, in the order they come." (says where to record).
- Problem 7: "all 22 ways" → "all twenty-two ways" (counts of ways are spelled out elsewhere: eleven, fifteen).
- Problem 11: "One pile of six stopped after 3 moves (Problem 1) and one pile of ten after 6 moves (Problem 10)." → "Look back at how many moves one pile of six took (Problem 1) and one pile of ten took (Problem 10)." (the page printed the answers to Problems 1 and 10; the child now uses their own recorded runs, and the prediction is unchanged).

## week-facilitator.tex

- Section 1: "one colour" → "one color" (American spelling, as on the student pages).
- Section 3: "Problems 1--9 are the must-do" → "are the core" (the term the other two sections use).
- Section 4, Problem 3: "First repeat: 3-1, after 3 moves." → "The first arrangement to appear a second time is 3-1: after 1 move and again after 4 moves." (the old line read as if the repeat came after 3 moves; checked by code).
- Section 4, Problem 6: "left of centre" → "left of center".
- Section 5, Problem 1: "All stop at 3-2-1, and each run contains the previous one." → "All stop at 3-2-1 through 4-2; the 4-1-1 run contains the 3-3 run, and the 2-2-1-1 run contains the 4-1-1 run." (the 3-3 run does not contain the 6 run; checked by code).
- Section 5, Problem 4: "new picture" / "old picture" → "new arrangement" / "old arrangement" (four places in that paragraph; matches the student page's term).
- Section 6: closing script "you proved it today for 3, 6 and 10 by trying every start" → "for 3 and 6" (every start of ten is tried only in the grades 4--5 finish-early activity, so it is not something the whole group did).
- Section 7: the five cross-references of the form "(Problems K--1 9, 2--3 8, 4--5 4)" rewritten as "(K--1 Problem 9, grades 2--3 Problem 8, grades 4--5 Problem 4)" and likewise for the other four.

## Also

- `render/` text dumps and page PNGs regenerated from the recompiled PDFs (same page names and counts).
- Checked and left as is: no exclamation marks, headings, Name/Date lines, praise or notes to the adult on any student page; no spelling errors found; facts spot-checked by brute force (ten-counter move counts and distribution, parentless counts for 3–12 counters, slowest starts for 3, 6, 15, 21 counters) agree with the guide.
