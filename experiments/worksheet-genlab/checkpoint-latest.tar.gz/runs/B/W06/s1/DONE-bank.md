bank.md complete (47 problems + coverage notes + mathematics section) when the agent was cut by the Fable rate limit before writing its DONE marker; accepted by the orchestrator
