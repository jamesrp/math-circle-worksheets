# Week 1 problem bank: Bulgarian solitaire

Stage: bank. Input to the curator (selects and sequences) and the formatter (typesets). Nothing here is a worksheet; the wording under "action" is written so that it could be printed as a `Problem N:` text with at most light editing.

## 0. How to read this bank

**The move.** Counters sit in piles. One move: take one counter from every pile and put all the counters you took together as one new pile. A pile that becomes empty is gone. The move is deterministic, so from any start the game either reaches an arrangement that does not change (it "rests") or goes round a loop.

**Notation.** An arrangement is written biggest pile first, with hyphens: `4-2` is a pile of 4 and a pile of 2; `1-1-1-1` is four single counters. `3-2-1` is the staircase with 6 counters. The same notation is proposed for the grades 2–3 and 4–5 pages; the K–1 pages use pictures only.

**Verification.** Every answer below was computed by brute force with `bs.py` (in this directory); its output is `bs-results.txt`. Sections of that output are cited as §A … §Q. The two theorems quoted from the literature (Brandt; Igusa–Etienne) were checked against the brute-force results for all n ≤ 20 (§D) and n ≤ 21 (§C). Nothing in the answers depends on the literature.

**Levels.** K–1 (two kindergartners, one first grader; adult reads aloud and scribes), 2–3 (four third graders), 4–5 (two fourth graders, one fifth grader). Ids: K = K–1, M = grades 2–3, U = grades 4–5. Many problems suit more than one level; the level line says which.

**Boards referred to below** (exact sizes so the formatter can draw them):

- *Plate mat* (K–1): one Letter page with six circles of 7 cm diameter ("plates"), two rows of three. Piles are built on plates; a move takes one counter off every plate that has counters and puts them together on an empty plate. Six plates are enough for every problem with 6 counters (when there are six piles they are all single counters, and all six plates are free after the move). Counters 2–2.5 cm.
- *Tower frame* (K–1 recording): a grid of 6 columns × 6 rows of 1.2 cm squares (or circles). The child colors one square per counter, one column per pile, from the bottom up, tallest tower on the left, next tallest next to it, and so on. Because the towers are always drawn tallest-first, two pictures of the same arrangement look the same. A run of m moves needs m + 1 frames, labelled "start", "after 1 move", "after 2 moves", …; two frames per row fit on a page with the labels. The adult may also write the tower sizes under each frame.
- *Staircase boards* (K–1, 2–3): outlines of the staircases 1; 2-1; 3-2-1; 4-3-2-1 (and 5-4-3-2-1 for 2–3) drawn as rows of circles the size of a counter, rows left-aligned, longest row on top, with a blank row underneath the bottom row (for the new pile).
- *Arrow strip* (2–3, 4–5 recording): boxes about 2.6 cm wide and 1.4 cm high joined by arrows, six boxes per line, continuing on the next line; the child writes one arrangement per box. Strip lengths are given per problem (a run of m moves needs m + 1 boxes, plus one box to show the repeat).
- *Run table* (2–3, 4–5): rows = starts; columns: start, the run (a row of small boxes), number of moves, where it ended.
- *Map board* (2–3, 4–5): for the "map" of all arrangements of n counters: either (a) a page with p(n) empty boxes placed in the tree shape with the arrows pre-drawn (the child fills the boxes; the shape is a hint but not the answer), or (b) a page of p(n) + 1 empty boxes in a grid with room to draw arrows. p(5) = 7, p(6) = 11, p(7) = 15, p(8) = 22.
- *Card mat* (4–5 reserve): four positions in a row, labelled left to right, for piles of playing cards.

## 1. Verified facts used throughout

| counters n | arrangements p(n) | what happens to every start | loop arrangements | most moves to get there | arrangements no move can make |
|---|---|---|---|---|---|
| 1 | 1 | rests at 1 | 1 | 0 | 0 |
| 2 | 2 | loop of 2: 2 ↔ 1-1 | 2 | 0 | 0 |
| 3 | 3 | rests at 2-1 | 1 | 2 | 1 (1-1-1) |
| 4 | 5 | loop of 3: 3-1 → 2-2 → 2-1-1 → 3-1 | 3 | 2 | 1 (1-1-1-1) |
| 5 | 7 | loop of 3: 3-2 → 2-2-1 → 3-1-1 → 3-2 | 3 | 3 | 2 |
| 6 | 11 | rests at 3-2-1 | 1 | 6 | 3 |
| 7 | 15 | loop of 4: 4-2-1 → 3-3-1 → 3-2-2 → 3-2-1-1 → 4-2-1 | 4 | 4 | 5 |
| 8 | 22 | TWO loops: a loop of 4 (4-3-1 → 3-3-2 → 3-2-2-1 → 4-2-1-1) reached by 15 starts, and a loop of 2 (4-2-2 ↔ 3-3-1-1) reached by 7 starts | 6 | 5 | 7 |
| 9 | 30 | loop of 4: 4-3-2 → 3-3-2-1 → 4-2-2-1 → 4-3-1-1 → 4-3-2 | 4 | 7 | 10 |
| 10 | 42 | rests at 4-3-2-1 | 1 | 12 | 14 |
| 11 | 56 | loop of 5 | 5 | 8 | 20 |
| 12 | 77 | two loops of 5 | 10 | 8 | 27 |
| 13 | 101 | two loops of 5 | 10 | 9 | 37 |
| 14 | 135 | loop of 5 | 5 | 14 | 49 |
| 15 | 176 | rests at 5-4-3-2-1 | 1 | 20 | 66 |

(§A, §B, §C, §D.) Only staircases 1, 2-1, 3-2-1, 4-3-2-1, 5-4-3-2-1, … stay unchanged under the move (§H, proof in section 4), so the game can rest only when n is a triangular number 1, 3, 6, 10, 15, 21, 28, ….

**Complete maps** (arrangement → what it becomes; in brackets the number of moves needed to enter the rest/loop). From §B.

- n = 3: 1-1-1 → 3 (2); 3 → 2-1 (1); 2-1 → 2-1 (0).
- n = 4: 1-1-1-1 → 4 (2); 4 → 3-1 (1); loop 3-1 → 2-2 → 2-1-1 → 3-1.
- n = 5: 1-1-1-1-1 → 5 (3); 5 → 4-1 (2); 2-1-1-1 → 4-1 (2); 4-1 → 3-2 (1); loop 3-2 → 2-2-1 → 3-1-1 → 3-2.
- n = 6 (a tree with root 3-2-1):
  - 2-2-1-1 → 4-1-1 → 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1 (6, 5, 4, 3, 2, 1, 0 moves)
  - 1-1-1-1-1-1 → 6 → 5-1 → 4-2 (4, 3, 2 moves)
  - 2-1-1-1-1 → 5-1 (3 moves)
  - Parents: 3-2-1 ← {4-2, 3-2-1}; 4-2 ← {5-1, 3-1-1-1}; 5-1 ← {6, 2-1-1-1-1}; 3-1-1-1 ← {2-2-2}; 2-2-2 ← {3-3}; 3-3 ← {4-1-1}; 4-1-1 ← {2-2-1-1}; 6 ← {1-1-1-1-1-1}. No parent: 2-2-1-1, 2-1-1-1-1, 1-1-1-1-1-1.
  - Moves needed: 0: 3-2-1; 1: 4-2; 2: 5-1, 3-1-1-1; 3: 6, 2-2-2, 2-1-1-1-1; 4: 1-1-1-1-1-1, 3-3; 5: 4-1-1; 6: 2-2-1-1.
- n = 7 (loop 4-2-1 → 3-3-1 → 3-2-2 → 3-2-1-1 → 4-2-1): 1-1-1-1-1-1-1 → 7 → 6-1 → 5-2 → 4-2-1 (4, 3, 2, 1 moves); 2-1-1-1-1-1 → 6-1 (3); 3-1-1-1-1 → 5-2 (2); 2-2-2-1 → 4-1-1-1 → 4-3 → 3-2-2 (3, 2, 1); 2-2-1-1-1 → 5-1-1 → 4-3 (3, 2). No parent: 3-1-1-1-1, 2-2-2-1, 2-2-1-1-1, 2-1-1-1-1-1, 1-1-1-1-1-1-1.
- n = 8, loop of 4 (4-3-1 → 3-3-2 → 3-2-2-1 → 4-2-1-1 → 4-3-1), reached by: 1^8 → 8 → 7-1 → 6-2 → 5-2-1 → 4-3-1 (5, 4, 3, 2, 1); 2-1-1-1-1-1-1 → 7-1 (4); 3-1-1-1-1-1 → 6-2 (3); 3-2-1-1-1 → 5-2-1 (2); 2-2-2-1-1 → 5-1-1-1 → 4-4 → 3-3-2 (3, 2, 1). Loop of 2 (4-2-2 ↔ 3-3-1-1), reached by: 2-2-2-2 → 4-1-1-1-1 → 5-3 → 4-2-2 (3, 2, 1); 2-2-1-1-1-1 → 6-1-1 → 5-3 (3, 2). (§L.) No parent: 3-2-1-1-1, 3-1-1-1-1-1, 2-2-2-2, 2-2-2-1-1, 2-2-1-1-1-1, 2-1-1-1-1-1-1, 1^8.
- n = 10: 42 arrangements, all reach 4-3-2-1; moves needed: 0: 1 start; 1: 1 (5-3-2); 2: 3 (6-4, 6-3-1, 4-3-1-1-1); 3: 5; 4: 5; 5: 3; 6: 4 (10, 5-5, 5-3-1-1, 2-1^8); 7: 4; 8: 4; 9: 3; 10: 3 (4-4-1-1, 5-4-1, 2-2-1^6); 11: 3; 12: 3 (3-3-2-1-1, 3-2-2-2-1, 3-2-2-1-1-1). Full list in §B.

**Single pile of n counters, moves to rest/loop** (§P): n = 3: 1; 4: 1; 5: 2; 6: 3; 7: 3; 8: 4; 9: 5; 10: 6; 11: 6; 12: 7; 15: 10; 21: 15. All-ones always takes exactly one more move than the single pile (its first move makes the single pile).

**Runs quoted in problems** (§F, §N):

- 6 → 5-1 → 4-2 → 3-2-1 (3 moves). 1^6 → 6 → … (4). 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1 (4). 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1 (3). 2-2-1-1 → 4-1-1 → 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1 (6). 4-2 → 3-2-1 (1). 5-1 → 4-2 → 3-2-1 (2).
- 4 → 3-1 → 2-2 → 2-1-1 → 3-1 → 2-2 → 2-1-1 → 3-1. 5 → 4-1 → 3-2 → 2-2-1 → 3-1-1 → 3-2 → 2-2-1.
- 7 → 6-1 → 5-2 → 4-2-1 → 3-3-1 → 3-2-2 → 3-2-1-1 → 4-2-1. 4-3 → 3-2-2. 2-2-2-1 → 4-1-1-1 → 4-3 → 3-2-2.
- 8 → 7-1 → 6-2 → 5-2-1 → 4-3-1 → 3-3-2 → 3-2-2-1 → 4-2-1-1 → 4-3-1. 5-3 → 4-2-2 → 3-3-1-1 → 4-2-2. 4-4 → 3-3-2. 2-2-2-2 → 4-1-1-1-1 → 5-3 → 4-2-2. 6-1-1 → 5-3.
- 9 → 8-1 → 7-2 → 6-2-1 → 5-3-1 → 4-3-2 → 3-3-2-1 → 4-2-2-1 → 4-3-1-1 → 4-3-2.
- 10 → 9-1 → 8-2 → 7-2-1 → 6-3-1 → 5-3-2 → 4-3-2-1 (6). 5-5 → 4-4-2 → 3-3-3-1 → 4-2-2-2 → 4-3-1-1-1 → 5-3-2 → 4-3-2-1 (6). 4-4-2: 5 moves. 2-2-2-2-2 → 5-1-1-1-1-1 → 6-4 → 5-3-2 → 4-3-2-1 (4). 3-3-2-2 → 4-2-2-1-1 → 5-3-1-1 → 4-4-2 → … (8). 4-4-1-1 → 4-3-3 → 3-3-2-2 → … (10). 7-3 → 6-2-2 → 5-3-1-1 → 4-4-2 → … (8). 9-1: 5; 8-2: 4; 6-4 → 5-3-2 → 4-3-2-1: 2. 3-3-2-1-1 → 5-2-2-1 → 4-4-1-1 → 4-3-3 → 3-3-2-2 → 4-2-2-1-1 → 5-3-1-1 → 4-4-2 → 3-3-3-1 → 4-2-2-2 → 4-3-1-1-1 → 5-3-2 → 4-3-2-1 (12).
- 12 → 11-1 → 10-2 → 9-2-1 → 8-3-1 → 7-3-2 → 6-3-2-1 → 5-4-2-1 → 4-4-3-1 → 4-3-3-2 → 4-3-2-2-1 → 5-3-2-1-1 → 5-4-2-1 (loop of 5 after 7 moves). 4-4-4 → 3-3-3-3 → 4-2-2-2-2 → 5-3-1-1-1-1 → 6-4-2 → 5-3-3-1 → 4-4-2-2 → 4-3-3-1-1 → 5-3-2-2 → 4-4-2-1-1 → 5-3-3-1 (a different loop of 5, after 5 moves).
- 15 → 14-1 → 13-2 → 12-2-1 → 11-3-1 → 10-3-2 → 9-3-2-1 → 8-4-2-1 → 7-4-3-1 → 6-4-3-2 → 5-4-3-2-1 (10 moves). 8-7: 14 moves; 5-5-5: 17 moves; 4-4-3-2-1-1: 20 moves (the maximum for 15).

## 2. Problems

Format of every entry: id and name / levels / materials and exact setup / the child's action as it would be printed / expected result and answer, with how it was verified / the mathematical question and the distinction it reveals / minutes of real work / what it needs before it and what it opens.

---

### K1. Three plates, one counter each

- **Levels:** K–1 (the first instance of the move; also the whole-group launch action).
- **Setup:** plate mat; 3 counters; four tower frames labelled start, after 1 move, after 2 moves, after 3 moves. Adult reads aloud and may write tower sizes under the frames.
- **Action:** Put one counter on each of three plates. Color the start picture: one square for each counter, one tower for each plate, tallest tower first. Now make the move: take one counter off every plate that has counters, and put all the counters you took together on an empty plate. Color the picture after 1 move. Make the move again and color the picture. Make the move a third time and color the picture. Count all the counters on the mat. Is it still three? Point to the first picture that looks just like the picture after it.
- **Result:** 1-1-1 → 3 → 2-1 → 2-1. The picture after 2 moves (towers 2 and 1) is the first one that repeats; the move on 2-1 gives 2-1 again. The number of counters is always 3. (§B n = 3; §F.)
- **Question:** dynamics; existence of a resting arrangement (a fixed point); the counters are conserved. First instance, nothing to compare with yet.
- **Minutes:** 4.
- **Before/after:** needs nothing. Opens K2 (other starts with 3), K3 (4 counters never rest).

### K2. Every start with three counters

- **Levels:** K–1.
- **Setup:** plate mat; 3 counters; two rows of three tower frames (start, after 1 move, after 2 moves) for the two new starts; the K1 frames at hand.
- **Action:** Put all three counters on one plate. Make the move and color the picture. Make the move again and color the picture. Now start with two counters on one plate and one counter on another. Make the move and color the picture. Try to find another way to put three counters on plates that you have not tried yet. Point to the picture where each start stopped changing.
- **Result:** 3 → 2-1 → 2-1 (rests after 1 move). 2-1 → 2-1 (already resting). With K1, all three ways to arrange 3 counters (3, 2-1, 1-1-1) end at 2-1, and there is no fourth way. (§B n = 3.)
- **Question:** completeness (all cases) and "every start ends in the same place"; this is Brandt's theorem for 3 counters, proved by trying every start. The distinction from K1: not one start but all of them.
- **Minutes:** 5.
- **Before/after:** needs K1. Opens K3/K4 (4 counters), K8 (which arrangement rests), K12 (nobody can make 1-1-1).

### K3. Four counters on one plate: round and round

- **Levels:** K–1 (also a fast opener for 2–3 as M3).
- **Setup:** plate mat; 4 counters; seven tower frames (start and after 1 … 6 moves).
- **Action:** Put four counters on one plate. Make the move and color the picture. Keep making moves and coloring a picture after every move until you have made six moves. Find two pictures that look the same. Put a mark under each of them. Does the picture ever stop changing?
- **Result:** 4 → 3-1 → 2-2 → 2-1-1 → 3-1 → 2-2 → 2-1-1. The pictures after 1 and 4 moves are the same (3-1), also 2 and 5, 3 and 6. It never rests: three pictures come round again and again. (§B n = 4; §F.)
- **Question:** dynamics; a loop instead of a resting arrangement. Distinction from 3 counters: same move, no rest.
- **Minutes:** 6.
- **Before/after:** needs K1. Opens K4, K8 (no resting arrangement with 4), K14 (5 counters).

### K4. Four plates, one counter each

- **Levels:** K–1.
- **Setup:** plate mat; 4 counters; five tower frames; the K3 frames at hand.
- **Action:** Put one counter on each of four plates. Make the move and color the picture. Make three more moves, coloring a picture after each one. Look at the pictures from the four-on-one-plate run. Point to the picture in this run that is the same as the start of that run. Do the two runs go round the same three pictures?
- **Result:** 1-1-1-1 → 4 → 3-1 → 2-2 → 2-1-1. After one move it is the K3 start, then the same loop. In fact all five arrangements of 4 counters (4, 3-1, 2-2, 2-1-1, 1-1-1-1) end in this one loop. (§B n = 4.)
- **Question:** different starts join the same loop ("does every start end in the same place?" for 4: yes, the same loop). Distinction from K3: a run can flow into another run.
- **Minutes:** 4.
- **Before/after:** needs K3. Opens K11 (all five ways for 4).

### K5. Six counters on one plate

- **Levels:** K–1 (also M1 for 2–3, U1 for 4–5).
- **Setup:** plate mat; 6 counters; five tower frames.
- **Action:** Put six counters on one plate. Make the move and color the picture. Keep making moves and coloring until the picture stops changing. Count how many moves you made before it stopped changing and tell the adult. Look at the last picture: how tall are the three towers?
- **Result:** 6 → 5-1 → 4-2 → 3-2-1 → 3-2-1. Rests after 3 moves at the staircase 3-2-1. (§F.)
- **Question:** dynamics; existence of the resting arrangement for 6. Distinction from K3: 4 never rests, 6 does, and at a staircase.
- **Minutes:** 5.
- **Before/after:** needs K1–K3. Opens K6, K7, K8, K9, K13.

### K6. Six plates, one counter each

- **Levels:** K–1.
- **Setup:** plate mat; 6 counters; six tower frames; the K5 frames at hand.
- **Action:** Put one counter on each of six plates. Make the move and color the picture. Keep going until the picture stops changing. Count the moves. Put the last picture of this run next to the last picture of the six-on-one-plate run. Are they the same? Which run took more moves, and by how many?
- **Result:** 1-1-1-1-1-1 → 6 → 5-1 → 4-2 → 3-2-1: rests after 4 moves, at the same staircase. One more move than K5, because the first move makes "six on one plate", which is the K5 start. (§F.)
- **Question:** same ending from a different start; the reason for "one more move" is a run flowing into another run (as in K4).
- **Minutes:** 5.
- **Before/after:** needs K5. Opens K7, K13.

### K7. Three and three; two, two and two

- **Levels:** K–1 (also in M2/U1).
- **Setup:** plate mat; 6 counters; two strips of six tower frames.
- **Action:** Put three counters on one plate and three on another. Make moves and color a picture after each one until the picture stops changing. Count the moves. Now start again with two counters on each of three plates. Make moves and color until it stops changing. Count the moves. Find the picture in the first run that is the same as the start of the second run.
- **Result:** 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1 (4 moves). 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1 (3 moves). Both end at 3-2-1; the second run is the first run after its first move. (§F.)
- **Question:** the same ending for a fourth and fifth start; runs merge. Sets up "does every start with six counters end at 3-2-1?" (answered completely in M5/U2; for K–1 the adult can say that all eleven ways have been checked).
- **Minutes:** 7.
- **Before/after:** needs K5. Opens K8, K13.

### K8. Which arrangement stays still?

- **Levels:** K–1 (the 2–3 version with an argument is M8).
- **Setup:** plate mat; 3, then 6, then 4 counters; tower frames for the tries (at least six frames for the 4-counter tries).
- **Action:** Build two counters on one plate and one on another. Make the move. Did anything change? Now build three, two and one on three plates. Make the move. Did anything change? Now take four counters. Try to build an arrangement of four counters that does not change when you make the move. Color every arrangement you try, and next to it what it became. When you have tried every way there is, tell the adult how many ways you tried and whether any of them stayed still.
- **Result:** 2-1 stays; 3-2-1 stays. With 4 counters none of the five ways stays: 4 → 3-1, 3-1 → 2-2, 2-2 → 2-1-1, 2-1-1 → 3-1, 1-1-1-1 → 4. "We tried all five ways" is the complete proof. (§H; §B n = 4.)
- **Question:** invariance (fixed points): existence for 3 and 6, impossibility for 4 by exhaustion. Distinction: a resting arrangement exists for some numbers of counters and not others.
- **Minutes:** 7.
- **Before/after:** needs K2, K5. Opens K9 (staircases), K11 (the same list of five ways).

### K9. Staircases

- **Levels:** K–1 (2–3 version with 5-4-3-2-1 is M14).
- **Setup:** staircase boards for 1; 2-1; 3-2-1; 4-3-2-1, each with a blank row under it; 10 counters.
- **Action:** Cover every circle of the smallest staircase with a counter. Count the counters and tell the adult. Do the same for the next staircase, then the next, then the biggest. Now leave the counters on the biggest staircase and make the move: take one counter from the end of each row and put them together in the blank row. Do the rows look the same as before? How many counters does each staircase have more than the one before it?
- **Result:** 1, 3, 6, 10 counters. On 4-3-2-1 the move gives rows 3-2-1 and a new row of 4: the same staircase. Each staircase is the one before plus a new row: 1, 1+2, 1+2+3, 1+2+3+4. (§H.)
- **Question:** counting (triangular numbers) and invariance; the family of resting arrangements. The distinction "only these rest" is argued in M8/U4.
- **Minutes:** 6.
- **Before/after:** needs K8. Opens K16 (ten on one plate reaches 4-3-2-1), M14.

### K10. Guess the new pile

- **Levels:** K–1 (2–3 version M7).
- **Setup:** plate mat; 6 counters; a two-column strip, "plates with counters" and "size of the new pile", six rows; the adult scribes.
- **Action:** Build two counters on each of three plates. Before you make the move, count the plates that have counters on them and say the number. Now make the move and count the counters on the new plate. Say the number. Do this four more times: count the plates first, make the move, count the new pile. Then build three and three, and before each of four moves, tell the adult how big the new pile is going to be. Then check.
- **Result:** The new pile always has exactly as many counters as there were plates with counters, because one counter was taken from each of them. 2-2-2: 3 plates → new pile 3 (3-1-1-1); 4 plates → 4 (4-2); 2 → 2 (3-2-1); 3 → 3 (3-2-1); 3 → 3. 3-3: 2 → 2 (2-2-2); 3 → 3 (3-1-1-1); 4 → 4 (4-2); 2 → 2 (3-2-1). (§K.)
- **Question:** the one law of the system (new pile = number of piles). It is the tool for every "why" later (K12, M8, M10, M11, U4).
- **Minutes:** 5.
- **Before/after:** needs K5–K7. Opens K12, K13, K15.

### K11. All the ways to put down four counters

- **Levels:** K–1 (2–3 version with 5 counters is M4).
- **Setup:** 4 counters; plate mat; a page with six tower frames in a left column ("a way") and six frames in a right column ("after one move").
- **Action:** Find every way to put four counters on plates. Three and one is the same way as one and three. Color each way you find in its own frame on the left. When you think you have found them all, count them and tell the adult. Then, for each way, build it, make one move, and color what you get in the frame on the right. Now look only at the right-hand pictures. Which of the ways on the left never appears on the right?
- **Result:** Five ways: 4, 3-1, 2-2, 2-1-1, 1-1-1-1. After one move: 4 → 3-1; 3-1 → 2-2; 2-2 → 2-1-1; 2-1-1 → 3-1; 1-1-1-1 → 4. Only 1-1-1-1 never appears on the right; 3-1 appears twice. (§B n = 4.) Why there are no more ways: the tallest tower is 4 (one way), 3 (one way), 2 (two ways: 2-2, 2-1-1) or 1 (one way).
- **Question:** counting and completeness (the five partitions of 4), and a first impossibility: 1-1-1-1 cannot come out of a move. A child's reason: the new pile is as big as the number of plates you had; to get four single counters the new pile is 1, so there was one plate with all four counters, and that becomes 3-1, not 1-1-1-1.
- **Minutes:** 8.
- **Before/after:** needs K3, K4, K10. Opens K12, M4, M11.

### K12. Nobody can make one-one-one

- **Levels:** K–1.
- **Setup:** 3 counters; plate mat; three pairs of tower frames (a way, after one move).
- **Action:** There are three ways to put down three counters: all three on one plate; two and one; one and one and one. Build each way, make one move, and color what you get. Look at the three results. Which way of putting down three counters can never come out of a move?
- **Result:** 3 → 2-1; 2-1 → 2-1; 1-1-1 → 3. Nobody can make 1-1-1. (§B n = 3.) The child's reason: "we tried every start"; or with the K10 law: the new pile would be 1, so there was one plate, holding 3, and that gives 2-1.
- **Question:** impossibility by a complete case check (a "Garden of Eden" arrangement). Distinction from K11: the unreachable arrangement is again the all-ones one; this suggests a pattern (true for all n ≥ 3: all-ones has no parent).
- **Minutes:** 4.
- **Before/after:** needs K2 (and K11 if done). Opens M11, U9.

### K13. The race: fastest and slowest start with six

- **Levels:** K–1 (the full table of all eleven starts is M5).
- **Setup:** 6 counters for each child; two or three children run side by side; strips of eight tower frames; the adult keeps a tally of moves.
- **Action:** Everyone starts with six counters. First race: one of you starts with four and two, another with one counter on each of six plates. Make moves at the same time until you reach 3-2-1. Who got there in fewer moves? Second race: two, two, one, one against three and three. Count the moves for each. Now find a start that reaches 3-2-1 in only one move. Then find a start that takes more moves than any other start you have seen.
- **Result:** 4-2 takes 1 move; 1-1-1-1-1-1 takes 4; 2-2-1-1 takes 6 (the most of all eleven starts); 3-3 takes 4. The only one-move start is 4-2. (§C n = 6.)
- **Question:** optimality (fastest and slowest over all starts). "How do you know 2-2-1-1 is the slowest?" belongs to the adult, who holds the complete list of eleven starts (section 1).
- **Minutes:** 8.
- **Before/after:** needs K5–K7. Opens M5, M10.

### K14. Five counters (reserve)

- **Levels:** K–1 (2–3: M4).
- **Setup:** plate mat; 5 counters; a strip of seven tower frames and a strip of five.
- **Action:** Put five counters on one plate. Make moves and color a picture after each one until you have made six moves. Find pictures that are the same and mark them. Then start with one counter on each of five plates and make four moves. Point to the picture where this run joins the first run.
- **Result:** 5 → 4-1 → 3-2 → 2-2-1 → 3-1-1 → 3-2 → 2-2-1: after 2 moves it goes round three pictures (3-2, 2-2-1, 3-1-1) forever. 1-1-1-1-1 → 5 → 4-1 → 3-2 → 2-2-1 joins after one move. (§F.) Overall: 3 rests, 4 goes round, 5 goes round, 6 rests.
- **Question:** dynamics across sizes 3, 4, 5, 6: rest, loop, loop, rest.
- **Minutes:** 7.
- **Before/after:** needs K3, K5. Opens M9, M14.

### K15. Which start came before? (reserve)

- **Levels:** K–1, first grader especially (2–3: M10).
- **Setup:** plate mat; 6 counters; tower frames for tries.
- **Action:** Find a start that becomes three counters on one plate after one move. Find a start that becomes five and one after one move. Find a different start that also becomes five and one. Find a start that becomes 3-2-1 after one move but is not 3-2-1 itself.
- **Result:** 1-1-1 → 3. 6 → 5-1 and 2-1-1-1-1 → 5-1. 4-2 → 3-2-1, and it is the only one besides 3-2-1. (§B n = 3, n = 6.) Hint from the K10 law: the new pile tells how many plates there were; pick which pile is the new one.
- **Question:** reversibility: undoing a move is sometimes impossible (K12), sometimes possible in one way, sometimes in two ways.
- **Minutes:** 6.
- **Before/after:** needs K10, K11. Opens M10, U8.

### K16. Ten counters on one plate (reserve)

- **Levels:** K–1 (2–3: M13).
- **Setup:** plate mat; 10 counters; the adult writes the tower sizes after each move (towers up to 10 high do not fit a tower frame); the 4-3-2-1 staircase board.
- **Action:** Put ten counters on one plate. Make moves until the picture stops changing. After each move, tell the adult the tower sizes so the adult can write them down. How many moves did it take? Build the last arrangement on the staircase board. Is it a staircase?
- **Result:** 10 → 9-1 → 8-2 → 7-2-1 → 6-3-1 → 5-3-2 → 4-3-2-1: 6 moves; it lands on the 4-staircase. Compare: 3 on one plate takes 1 move, 6 takes 3, 10 takes 6. (§F, §G.)
- **Question:** dynamics for the next staircase number; the single-pile counts 1, 3, 6 are the staircase numbers again (explained in U10).
- **Minutes:** 8.
- **Before/after:** needs K5, K9. Opens M13, U10.

---

### M1. Six in one pile

- **Levels:** 2–3 (and 4–5 as U1).
- **Setup:** 6 counters; an arrow strip of six boxes.
- **Action:** Put six counters in one pile. The move: take one counter from every pile and put those counters together as a new pile. A pile that becomes empty is gone. Make the move and write the pile sizes in the next box, biggest first, like 5-1. Keep making moves and writing until the same numbers appear in two boxes in a row. How many moves did that take?
- **Result:** 6 → 5-1 → 4-2 → 3-2-1 → 3-2-1: 3 moves; rests at 3-2-1. (§F.)
- **Question:** dynamics; existence of a resting arrangement.
- **Minutes:** 4.
- **Before/after:** needs nothing. Opens M2, M3.

### M2. Four more starts with six

- **Levels:** 2–3 (4–5: U1).
- **Setup:** 6 counters; four arrow strips of seven boxes; a run table with four rows (start, moves, ending).
- **Action:** Run these starts the same way: 1-1-1-1-1-1; 3-3; 2-2-2; 2-2-1-1. Write every arrangement in the boxes. In the table write how many moves each start took and where it ended. Which start took the most moves? Find an arrangement that appears in two different runs and mark it in both.
- **Result:** 1-1-1-1-1-1: 4 moves; 3-3: 4; 2-2-2: 3; 2-2-1-1: 6 (2-2-1-1 → 4-1-1 → 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1). All end at 3-2-1. The 3-3 run is inside the 2-2-1-1 run; the 2-2-2 run inside the 3-3 run; the 6 run (M1) inside the all-ones run. (§F.)
- **Question:** same ending from different starts; runs merge (the flow is a tree, not separate paths).
- **Minutes:** 8.
- **Before/after:** needs M1. Opens M5 (all eleven), M6 (the map).

### M3. Four counters go round

- **Levels:** 2–3 (K–1: K3/K4).
- **Setup:** 4 counters; an arrow strip of eight boxes and two strips of five.
- **Action:** Put four counters in one pile and make the move seven times, writing every arrangement. Circle the first arrangement that appears a second time. How many different arrangements are in the loop? Then run 1-1-1-1 for four moves and 2-2 for three moves. Do they get into the same loop?
- **Result:** 4 → 3-1 → 2-2 → 2-1-1 → 3-1 → 2-2 → 2-1-1 → 3-1; 3-1 is the first repeat, after 3 moves; loop of three arrangements: 3-1, 2-2, 2-1-1. 1-1-1-1 → 4 → 3-1 → 2-2 → 2-1-1; 2-2 → 2-1-1 → 3-1 → 2-2. All five arrangements of 4 end in this one loop. (§B n = 4.)
- **Question:** dynamics: a loop. Distinction from M1: 6 rests, 4 never does.
- **Minutes:** 6.
- **Before/after:** needs M1. Opens M4, M8, M9.

### M4. All seven ways with five counters

- **Levels:** 2–3 (K–1: K14 without the listing).
- **Setup:** 5 counters; a list box with seven lines; seven arrow strips of five boxes.
- **Action:** List every way to split five counters into piles, biggest pile first: 5; 4-1; and so on. There are more than five ways. Then run each way until an arrangement repeats. Write the runs. Circle the arrangements that are in the loop. For each start write how many moves it took to get into the loop.
- **Result:** Seven ways: 5, 4-1, 3-2, 3-1-1, 2-2-1, 2-1-1-1, 1-1-1-1-1. One loop of 3: 3-2 → 2-2-1 → 3-1-1 → 3-2. Moves to reach the loop: 3-2, 2-2-1, 3-1-1: 0; 4-1: 1; 5: 2; 2-1-1-1: 2; 1-1-1-1-1: 3. (§B n = 5.) Completeness by biggest pile: 5 | 4-1 | 3-2, 3-1-1 | 2-2-1, 2-1-1-1 | 1-1-1-1-1.
- **Question:** counting (the seven partitions of 5), completeness, and a loop of 3 again. Distinction: 5 behaves like 4 (a loop of 3), not like 6.
- **Minutes:** 10.
- **Before/after:** needs M3. Opens M5, M9.

### M5. All eleven starts with six

- **Levels:** 2–3 (4–5: U2/U3).
- **Setup:** 6 counters per child; a list box with eleven lines; a run table with eleven rows (start, the run, moves to reach 3-2-1). The four children share the eleven starts.
- **Action:** List every way to split six counters into piles, biggest pile first. There are eleven. Share the list out at your table. Run each start until it stops changing and write the run and the number of moves in the table. Check: does every start stop at 3-2-1? Which start takes the most moves? Which starts take exactly two moves?
- **Result:** Eleven ways: 6, 5-1, 4-2, 4-1-1, 3-3, 3-2-1, 3-1-1-1, 2-2-2, 2-2-1-1, 2-1-1-1-1, 1-1-1-1-1-1. Moves: 3-2-1: 0; 4-2: 1; 5-1 and 3-1-1-1: 2; 6, 2-2-2 and 2-1-1-1-1: 3; 1-1-1-1-1-1 and 3-3: 4; 4-1-1: 5; 2-2-1-1: 6. Every start stops at 3-2-1. (§C n = 6.)
- **Question:** completeness: this table is a complete proof that every arrangement of six counters rests at 3-2-1 (Brandt's theorem for 6); optimality (2-2-1-1 is the slowest).
- **Minutes:** 12 (shared among four children).
- **Before/after:** needs M2, M4. Opens M6, M10, M11, M15.

### M6. The map of six

- **Levels:** 2–3 (4–5: U2).
- **Setup:** map board for n = 6 (eleven boxes in the tree shape with arrows pre-drawn, or a grid of twelve boxes); the M5 table.
- **Action:** Write every arrangement of six counters in a box so that each arrow points from an arrangement to what it becomes after one move. Every arrangement goes in exactly one box. Then answer: which boxes have no arrow coming in? Which boxes have two arrows coming in? How many arrows are on the longest path to 3-2-1?
- **Result:** The map is the tree in section 1: the long path 2-2-1-1 → 4-1-1 → 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1, the branch 1-1-1-1-1-1 → 6 → 5-1 → 4-2, and the twig 2-1-1-1-1 → 5-1. No arrow in: 2-2-1-1, 2-1-1-1-1, 1-1-1-1-1-1. Two arrows in: 4-2 (from 5-1 and 3-1-1-1), 5-1 (from 6 and 2-1-1-1-1), and 3-2-1 (from 4-2 and from itself). Longest path: 6 arrows. (§B n = 6.)
- **Question:** the structure of the whole system: one tree flowing into the fixed point. The map is a new representation, introduced after the question it answers (M5) has been met.
- **Minutes:** 10.
- **Before/after:** needs M5. Opens M10, M11, U8, U9.

### M7. The size of the new pile

- **Levels:** 2–3 (K–1: K10; 4–5 use it inside U4).
- **Setup:** the strips already filled; a two-column table (piles before the move, size of the new pile) with eight rows; 10 counters.
- **Action:** Go back to any run you wrote. For each move, count the piles before the move and find the size of the new pile after it. Write both numbers in the table for eight moves. What do you notice? Then build 4-4-2 and, before each of five moves, say what size the new pile will be. Then make the move and check.
- **Result:** The two numbers are always equal: the new pile has one counter from each pile. 4-4-2 (3 piles) → new pile 3, giving 3-3-3-1 (4 piles) → new 4, giving 4-2-2-2 (4) → new 4, giving 4-3-1-1-1 (5) → new 5, giving 5-3-2 (3) → new 3, giving 4-3-2-1. (§K.)
- **Question:** the law of the move, stated so it can be used in arguments (M8, M10, M11).
- **Minutes:** 5.
- **Before/after:** needs M1–M3. Opens M8, M10, M11.

### M8. Why 3-2-1 stays, and why four counters can never rest

- **Levels:** 2–3 (4–5: U4 with the full argument).
- **Setup:** 6, 10 and 4 counters; answer lines; the list of the five ways for 4.
- **Action:** Build 3-2-1 and make the move. Write what the pile of 3 became, what the pile of 2 became, what happened to the pile of 1, and how big the new pile is. Now build an arrangement of ten counters that does not change when you make the move, and write it. Then try to find an arrangement of four counters that does not change. Write every arrangement of four you tried and what it became. Tell the adult in your own words why there is none.
- **Result:** 3 → 2, 2 → 1, 1 → gone, new pile 3: 3-2-1 again. Ten: 4-3-2-1. Four: none of the five arrangements stays (4 → 3-1, 3-1 → 2-2, 2-2 → 2-1-1, 2-1-1 → 3-1, 1-1-1-1 → 4). The argument a child can give, with the M7 law: for the picture to stay the same, the new pile must be the biggest pile, because every old pile got smaller; so the biggest pile equals the number of piles; the old biggest pile lost one and must now be the second biggest, and so on down to a pile of 1; so the piles are a staircase, and 4 is not 1, 1+2 or 1+2+3. (§H; full proof in section 4.)
- **Question:** invariance: which arrangements are fixed, and impossibility of rest for non-staircase numbers. Distinction from K8: an exhaustive check for 4 versus a reason that works for every number.
- **Minutes:** 8.
- **Before/after:** needs M3, M7. Opens M14, U4.

### M9. Seven counters: a loop of four

- **Levels:** 2–3 (4–5: U5 does all fifteen starts).
- **Setup:** 7 counters; an arrow strip of ten boxes and two strips of seven.
- **Action:** Put seven counters in one pile and run the move until an arrangement repeats. Circle the loop. How many arrangements are in it? Then run 4-3 and 2-2-2-1. Do they reach the same loop? How many moves does each take to get into it?
- **Result:** 7 → 6-1 → 5-2 → 4-2-1 → 3-3-1 → 3-2-2 → 3-2-1-1 → 4-2-1: a loop of four (4-2-1, 3-3-1, 3-2-2, 3-2-1-1), entered after 3 moves. 4-3 → 3-2-2 (1 move). 2-2-2-1 → 4-1-1-1 → 4-3 → 3-2-2 (3 moves). Every one of the fifteen arrangements of 7 reaches this loop. (§F; §B n = 7.) Each loop arrangement is 3-2-1 with one extra counter added somewhere (on the 3, on the 2, on the 1, or as a new pile of 1).
- **Question:** dynamics; loop lengths grow: 3 for 4 and 5 counters, 4 for 7. Distinction from 6: the staircase number rests, its neighbour loops.
- **Minutes:** 8.
- **Before/after:** needs M3, M4. Opens M12, U5, U11.

### M10. Exactly one move away

- **Levels:** 2–3 (4–5: U8 with the general method).
- **Setup:** 6 and 10 counters; answer lines with four labelled blanks.
- **Action:** Which arrangements of six counters become 3-2-1 after exactly one move? Find them all and write them. Which arrangements of six become 4-2 after one move? Which become 5-1? Then, with ten counters: which arrangements become 4-3-2-1 after one move?
- **Result:** Becoming 3-2-1: 4-2 (and 3-2-1 itself). Becoming 4-2: 5-1 and 3-1-1-1. Becoming 5-1: 6 and 2-1-1-1-1. Becoming 4-3-2-1: 5-3-2 (and 4-3-2-1 itself). (§B n = 6, n = 10.) Method: the new pile is one of the piles you see, and its size says how many piles there were before.
- **Question:** predecessors (reversibility); undoing a move gives one answer, two answers, or none.
- **Minutes:** 8.
- **Before/after:** needs M6, M7. Opens M11, U8, U15.

### M11. Arrangements no move can make

- **Levels:** 2–3 (4–5: U9 finds the rule).
- **Setup:** the M6 map; 7 counters; answer lines.
- **Action:** From the map of six, write the arrangements that no arrow points to. There are three. Explain why no arrangement can become 2-2-1-1 after a move. Then find all the arrangements of seven counters that no move can make. There are five.
- **Result:** Six: 2-2-1-1, 2-1-1-1-1, 1-1-1-1-1-1. Seven: 3-1-1-1-1, 2-2-2-1, 2-2-1-1-1, 2-1-1-1-1-1, 1-1-1-1-1-1-1. (§B.) Argument for 2-2-1-1: the new pile is one of the piles, so it has at most 2 counters, so there were at most 2 piles before; a move from at most 2 piles leaves at most 3 piles; 2-2-1-1 has four. The same argument works whenever the biggest pile is smaller than the number of piles minus 1 (the rule in U9).
- **Question:** impossibility with a general argument (Garden of Eden arrangements). Distinction from K12: not a case check but a reason.
- **Minutes:** 8.
- **Before/after:** needs M6, M7, M10. Opens U9.

### M12. Eight counters: two different loops

- **Levels:** 2–3 (4–5: U6 sorts all 22 starts).
- **Setup:** 8 counters; four arrow strips of ten boxes.
- **Action:** Run eight counters in one pile until an arrangement repeats and circle the loop. Run 5-3 the same way and circle its loop. Then run 4-4 and 2-2-2-2. Which starts end in which loop? How long is each loop?
- **Result:** 8 → 7-1 → 6-2 → 5-2-1 → 4-3-1 → 3-3-2 → 3-2-2-1 → 4-2-1-1 → 4-3-1: a loop of 4 after 4 moves. 5-3 → 4-2-2 → 3-3-1-1 → 4-2-2: a loop of 2 after 1 move. 4-4 → 3-3-2: the loop of 4 after 1 move. 2-2-2-2 → 4-1-1-1-1 → 5-3 → 4-2-2: the loop of 2 after 3 moves. Of the 22 arrangements of 8, 15 end in the loop of 4 and 7 in the loop of 2. (§F, §L.)
- **Question:** "does every start end in the same place?" Yes for 3, 4, 5, 6, 7; no for 8. This is the first break in the pattern, and it is reachable by hand in four short runs.
- **Minutes:** 10.
- **Before/after:** needs M9. Opens U6, U11, U12.

### M13. One pile of 3, 6, 10: how many moves?

- **Levels:** 2–3 (K–1: K16; 4–5: U10 tests 15).
- **Setup:** 10 counters; three arrow strips (three, five and eight boxes); one answer line.
- **Action:** Run one pile of three counters until it rests and write the number of moves. Do the same for one pile of six and for one pile of ten. Look at the three numbers. Write what you think one pile of fifteen will take.
- **Result:** 1, 3, 6 moves (10 → 9-1 → 8-2 → 7-2-1 → 6-3-1 → 5-3-2 → 4-3-2-1). The staircase numbers again; the prediction 10 for fifteen counters is right (§G; tested in U10).
- **Question:** a pattern in the dynamics (the single-pile run of the k-th staircase number takes the (k−1)-th staircase number of moves), with a reason in U10.
- **Minutes:** 8.
- **Before/after:** needs M1. Opens U10.

### M14. Staircase counts and which numbers can rest

- **Levels:** 2–3 (K–1: K9).
- **Setup:** staircase boards 1, 2-1, 3-2-1, 4-3-2-1, 5-4-3-2-1; 15 counters; a table with a row for each number of counters from 1 to 10 and a blank next to each.
- **Action:** Cover each staircase with counters and count. Write the five numbers. Then, for every number of counters from 1 to 10, write R if there is an arrangement that does not change under the move, and L if every start goes round a loop. Use your runs and the staircases. For 7, 8 and 9, write your best guess for a resting arrangement, make one move on it, and write what it became.
- **Result:** 1, 3, 6, 10, 15. R for 1, 3, 6, 10; L for 2, 4, 5, 7, 8, 9. Any guess for 7, 8, 9 changes (for example 4-2-1 → 3-3-1, 4-3-1 → 3-3-2, 4-3-2 → 3-3-2-1). Only staircases rest (M8), so only staircase numbers can rest. (§H.)
- **Question:** classification of the numbers of counters; triangular numbers; a reason (M8) rather than a guess.
- **Minutes:** 8.
- **Before/after:** needs M8, M9, M12. Opens U4.

### M15. Two-pile starts (reserve)

- **Levels:** 2–3 (also 4–5).
- **Setup:** 6 and 10 counters; a run table with eight rows.
- **Action:** Run every start with six counters in exactly two piles: 5-1, 4-2, 3-3. Write the moves each takes. Then run every two-pile start with ten counters: 9-1, 8-2, 7-3, 6-4, 5-5. Which is fastest? Which is slowest? Is the fastest one the one with the most equal piles?
- **Result:** 6: 5-1 takes 2, 4-2 takes 1, 3-3 takes 4. 10: 9-1: 5; 8-2: 4; 7-3: 8; 6-4: 2; 5-5: 6. Fastest 6-4, slowest 7-3; the most equal start 5-5 is not the fastest. (§B n = 10; §N.)
- **Question:** optimality inside a family; the guess "more equal is faster" is true for 6 (4-2) and false for 10.
- **Minutes:** 12.
- **Before/after:** needs M5. Opens U7.

### M16. Ten counters: long runs (reserve)

- **Levels:** 2–3 (4–5: U7).
- **Setup:** 10 counters; arrow strips of fourteen boxes.
- **Action:** Run 4-4-2, then 3-3-2-2, then 4-4-1-1 until each one rests. Count the moves. Then find a start with ten counters that takes more than ten moves.
- **Result:** 4-4-2: 5 moves; 3-3-2-2: 8; 4-4-1-1: 10. More than ten moves: 6-2-1-1, 5-2-2-1 and 5-2-1-1-1 take 11; 3-3-2-1-1, 3-2-2-2-1 and 3-2-2-1-1-1 take 12, and nothing takes more. All rest at 4-3-2-1. (§N; §C n = 10.)
- **Question:** optimality (the slowest start with 10); the maxima 2, 6, 12 for 3, 6, 10 counters.
- **Minutes:** 12.
- **Before/after:** needs M13 or M15. Opens U7, U15.

---

### U1. Learn the move with six

- **Levels:** 4–5 (same runs as K5–K7, M1–M2).
- **Setup:** 6 counters; four arrow strips of eight boxes.
- **Action:** The move: take one counter from every pile and put them together as a new pile; a pile that becomes empty is gone. Write an arrangement biggest pile first, like 4-2. Run these four starts until the arrangement stops changing: 6; 2-2-2; 3-3; 2-2-1-1. Write each run and the number of moves it took.
- **Result:** 3, 3, 4, 6 moves; all end at 3-2-1. (§F.)
- **Question:** dynamics; a resting arrangement exists and four starts reach it.
- **Minutes:** 6.
- **Before/after:** needs nothing. Opens U2.

### U2. The complete map of six

- **Levels:** 4–5 (2–3: M5 + M6).
- **Setup:** 6 counters; a list box with eleven lines; a map board with twelve boxes in a grid (arrows to be drawn).
- **Action:** List every way to split six counters into piles. There are eleven; sort them by biggest pile to be sure you have them all. Write each one in a box and draw an arrow from each arrangement to what it becomes after one move. Then check: is there any arrangement whose path of arrows does not reach 3-2-1?
- **Result:** The tree in section 1; every path reaches 3-2-1. (§B n = 6.)
- **Question:** completeness: a proof, for six counters, that every start rests at the staircase; the map is one tree with one root.
- **Minutes:** 10.
- **Before/after:** needs U1. Opens U3, U4, U5, U8, U9.

### U3. Reading the map: how many moves

- **Levels:** 4–5.
- **Setup:** the U2 map; a table with eleven rows.
- **Action:** From the map, write for every arrangement the number of moves it needs to reach 3-2-1. Which needs the most? Write the arrangements along its path. How many arrangements need exactly three moves? Which arrangements have no arrow pointing at them?
- **Result:** 0: 3-2-1; 1: 4-2; 2: 5-1, 3-1-1-1; 3: 6, 2-2-2, 2-1-1-1-1 (three of them); 4: 1-1-1-1-1-1, 3-3; 5: 4-1-1; 6: 2-2-1-1, whose path is 2-2-1-1 → 4-1-1 → 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1. No arrow in: 2-2-1-1, 2-1-1-1-1, 1-1-1-1-1-1. (§C n = 6.)
- **Question:** optimality and counting read off the structure.
- **Minutes:** 5.
- **Before/after:** needs U2. Opens U7, U9, U15.

### U4. Only staircases stand still

- **Levels:** 4–5 (2–3: M8).
- **Setup:** counters; answer lines with labelled blanks.
- **Action:** Build 3-2-1, make the move, and write what happened to each pile and how big the new pile is. Now suppose some arrangement does not change when you make the move. After the move every old pile is smaller than it was. So which pile in the new picture must be the new pile? Write which. Then write, one by one, what the biggest pile, the next pile, and the next must be, down to the smallest. Finally write every number of counters from 1 to 30 that has an arrangement which does not change.
- **Result:** The new pile must be the biggest pile of the new picture (all old piles shrank), so the biggest pile equals the number of piles, p. Exactly one old pile was a single counter (it vanished and the new pile replaced it, so the number of piles stayed p). The old biggest, p, became p−1 and is now the second biggest; the old second biggest became the third; and so on down to 1. So the arrangement is p, p−1, …, 2, 1: a staircase. Numbers up to 30: 1, 3, 6, 10, 15, 21, 28. (§H; the written-out proof is in section 4.)
- **Question:** characterization of the fixed points (invariance) with a complete proof; classification of n. Distinction from U2: a statement about every number of counters at once.
- **Minutes:** 10.
- **Before/after:** needs U1–U3. Opens U11, U13, U14.

### U5. Seven: fifteen starts, one loop

- **Levels:** 4–5 (2–3: M9 does four starts).
- **Setup:** 7 counters; a list box with fifteen lines; a map board with sixteen boxes; arrow strips for runs. The three children share the starts.
- **Action:** List all fifteen ways to split seven counters. Share them out. Run each until an arrangement repeats. Draw the map: an arrow from each arrangement to what it becomes. Circle the loop. How many arrangements are in the loop? How many moves does the farthest start need to enter it? Which arrangements have no arrow pointing at them?
- **Result:** One loop of 4: 4-2-1 → 3-3-1 → 3-2-2 → 3-2-1-1 → 4-2-1. Farthest: 1-1-1-1-1-1-1, 4 moves. No arrow in: 3-1-1-1-1, 2-2-2-1, 2-2-1-1-1, 2-1-1-1-1-1, 1-1-1-1-1-1-1. Full map in section 1. (§B n = 7.)
- **Question:** completeness for a non-staircase number: every start ends in the same loop; the map is a tree hanging on a loop instead of on a point.
- **Minutes:** 12.
- **Before/after:** needs U2. Opens U6, U11.

### U6. Eight: which loop do you land in?

- **Levels:** 4–5 (2–3: M12).
- **Setup:** 8 counters; a list box with 22 lines; arrow strips; a "loop sheet" with two rings of boxes to fill; a table with 22 rows (start, loop reached).
- **Action:** Run 8, 5-3, 4-4, 2-2-2-2 and 6-1-1 until each repeats. Circle the loops. How many different loops did you find? Write every arrangement of each loop in a ring. Then list all 22 ways to split eight counters and find out which loop each one reaches; many of them are already on your runs. Count how many starts reach each loop.
- **Result:** Two loops: 4-3-1 → 3-3-2 → 3-2-2-1 → 4-2-1-1 (length 4) and 4-2-2 → 3-3-1-1 (length 2). The loop of 4 is reached by 15 starts; the loop of 2 by 7: 3-3-1-1, 4-2-2, 5-3, 4-1-1-1-1, 6-1-1, 2-2-1-1-1-1, 2-2-2-2. (§L.) Both loops consist of 3-2-1 plus two extra counters.
- **Question:** "does every start end in the same place?" fails at 8; classification of starts by which loop they reach (basins).
- **Minutes:** 15.
- **Before/after:** needs U5. Opens U11, U12.

### U7. Ten: the slowest start

- **Levels:** 4–5 (2–3: M16).
- **Setup:** 10 counters; arrow strips of fourteen boxes; a run table.
- **Action:** Run 10, 5-5, 7-3 and 4-4-1-1 until they rest and write the number of moves for each. Then search for a start with ten counters that takes twelve moves. Write its whole run.
- **Result:** 6, 6, 8, 10 moves. Twelve moves: 3-3-2-1-1, 3-2-2-2-1 and 3-2-2-1-1-1, for example 3-3-2-1-1 → 5-2-2-1 → 4-4-1-1 → 4-3-3 → 3-3-2-2 → 4-2-2-1-1 → 5-3-1-1 → 4-4-2 → 3-3-3-1 → 4-2-2-2 → 4-3-1-1-1 → 5-3-2 → 4-3-2-1. No start needs more than 12 (checked over all 42 starts; the general bound k² − k is Igusa's and Etienne's theorem). Maxima: 2 for 3 counters, 6 for 6, 12 for 10, 20 for 15. (§C.)
- **Question:** optimality (the longest transient); the pattern 2, 6, 12, 20 = k(k−1).
- **Minutes:** 15.
- **Before/after:** needs U3. Opens U15.

### U8. Parents

- **Levels:** 4–5 (2–3: M10).
- **Setup:** counters; answer lines.
- **Action:** Find every arrangement that becomes 4-2 after one move. Then every arrangement that becomes 5-3-2. Then every arrangement that becomes 3-3. Write them. Then describe a way to find all the parents of any arrangement without guessing.
- **Result:** 4-2: 5-1, 3-1-1-1. 5-3-2: 6-4, 6-3-1, 4-3-1-1-1. 3-3: 4-1-1 only. (§B n = 6, 10.) Method: choose which pile is the new one; its size m is the number of piles there were; remove it, add one counter to every other pile, and add single counters until there are m piles; if the other piles are already more than m, that choice is impossible. Checked against brute force for all n ≤ 20 (§E).
- **Question:** reversibility and predecessor counting (an arrangement can have 0, 1, 2 or 3 parents).
- **Minutes:** 10.
- **Before/after:** needs U2, U3. Opens U9, U15.

### U9. Arrangements without parents

- **Levels:** 4–5 (2–3: M11).
- **Setup:** the maps of 6 and 7; a list of the 22 ways for 8; answer lines.
- **Action:** From the map of six, list the arrangements with no arrow pointing to them. Do the same for seven. For each of them write the biggest pile and the number of piles. Write a rule that tells, from these two numbers, whether an arrangement has a parent. Use the rule to list all arrangements of eight counters with no parent, then check two of them by trying to build a parent.
- **Result:** Six: 2-2-1-1, 2-1-1-1-1, 1-1-1-1-1-1. Seven: 3-1-1-1-1, 2-2-2-1, 2-2-1-1-1, 2-1-1-1-1-1, 1-1-1-1-1-1-1. Rule: an arrangement has no parent exactly when its biggest pile is at most the number of piles minus 2. Eight (seven of them): 3-2-1-1-1, 3-1-1-1-1-1, 2-2-2-2, 2-2-2-1-1, 2-2-1-1-1-1, 2-1-1-1-1-1-1, 1-1-1-1-1-1-1-1. Counts for 3, 4, …, 10 counters: 1, 1, 2, 3, 5, 7, 10, 14. (§B, §E, §O.) Proof of the rule in section 4.
- **Question:** impossibility with a general criterion ("Garden of Eden" arrangements) and counting them.
- **Minutes:** 10.
- **Before/after:** needs U8. Opens the "where it leads" notes (Hopkins–Sellers).

### U10. One pile of fifteen

- **Levels:** 4–5 (2–3: M13).
- **Setup:** 15 counters; an arrow strip of twelve boxes; the K16/M13 runs at hand.
- **Action:** One pile of 3 rests after 1 move, one pile of 6 after 3 moves, one pile of 10 after 6 moves. Write your prediction for one pile of 15. Then run it and write every arrangement. In each arrangement of your run, underline the big pile and look at the rest. What do the small piles look like after 1, 3, 6 and 10 moves? Then predict how many moves 1-1-1-…-1 with fifteen counters takes, and say why.
- **Result:** 10 moves: 15 → 14-1 → 13-2 → 12-2-1 → 11-3-1 → 10-3-2 → 9-3-2-1 → 8-4-2-1 → 7-4-3-1 → 6-4-3-2 → 5-4-3-2-1. The small piles form the staircases 1, 2-1, 3-2-1, 4-3-2-1 after 1, 3, 6, 10 moves. All-ones takes 11 moves (its first move makes the single pile). (§F, §G, §P.) Reason: the big pile loses exactly one counter per move; the small piles play their own game in which the new pile gets one extra counter, and that game builds the staircase one diagonal at a time (proof in section 4).
- **Question:** a pattern that holds (the k-th staircase number takes the (k−1)-th staircase number of moves), with a proof a child can follow on the run itself.
- **Minutes:** 12.
- **Before/after:** needs U1 and a K16/M13-type run. Opens the Young-diagram picture in section 4.

### U11. Loop lengths, and loops are staircases with extras

- **Levels:** 4–5.
- **Setup:** the loops found for 4, 5, 7, 8; 9 counters; an arrow strip of ten boxes; answer lines; the 3-2-1 staircase board and a few counters of a second colour (the "extras").
- **Action:** Run nine counters in one pile until an arrangement repeats and circle the loop. Now write every loop you have found, for 4, 5, 7, 8 and 9 counters, and the length of each. For each loop arrangement of 7, 8 and 9, show how it is 3-2-1 with one, two or three extra counters added, at most one extra on each pile, or as a new pile of one. Then build 4-3-1 with extras of the second colour on the 3-pile and the 2-pile, make the move, and write where the extras are now. Make three more moves and follow the extras.
- **Result:** 9 → 8-1 → 7-2 → 6-2-1 → 5-3-1 → 4-3-2 → 3-3-2-1 → 4-2-2-1 → 4-3-1-1 → 4-3-2: loop of 4 after 5 moves. Loop lengths: 4 and 5 counters: 3; 7: 4; 8: 4 and 2; 9: 4. Loops of 4 and 5 are 2-1 plus one or two extras; loops of 7, 8, 9 are 3-2-1 plus one, two, three extras (all listed in §M). Following the extras: with the piles kept in the order "newest pile first", each extra moves one pile to the right at every move, and the extra on the last pile of one comes back as an extra on the new pile; the loop length is how long it takes the pattern of extras to come round. (§M; proof in section 4.)
- **Question:** the structure of the loop arrangements (Brandt's description); why the loop length divides k+1; for 8 the two loops are the two ways to place two extras around a ring of four places (adjacent or opposite).
- **Minutes:** 12.
- **Before/after:** needs U6 (or M12). Opens U12.

### U12. Twelve: predict two loops (reserve)

- **Levels:** 4–5.
- **Setup:** 12 counters; two arrow strips of fourteen boxes.
- **Action:** Eight counters have two different loops. The next number of counters with two loops is twelve. Run twelve in one pile and run 4-4-4 until each repeats. Are the loops different? How long is each one? Write each loop arrangement as 4-3-2-1 plus two extra counters.
- **Result:** 12 → … → 5-4-2-1 after 7 moves; its loop is 5-4-2-1 → 4-4-3-1 → 4-3-3-2 → 4-3-2-2-1 → 5-3-2-1-1 (length 5). 4-4-4 → 3-3-3-3 → 4-2-2-2-2 → 5-3-1-1-1-1 → 6-4-2 → 5-3-3-1 after 5 moves; its loop is 5-3-3-1 → 4-4-2-2 → 4-3-3-1-1 → 5-3-2-2 → 4-4-2-1-1 (length 5). Different loops. (§F, §M.)
- **Question:** prediction from the pattern (two extras on a ring of five places: adjacent or one apart); a check that the reasoning transfers.
- **Minutes:** 15.
- **Before/after:** needs U11.

### U13. Cards with faces: which card never moves? (reserve)

- **Levels:** 4–5.
- **Setup:** six playing cards A, 2, 3, 4, 5, 6 (then ten cards for the second part); a card mat with positions left, middle, right (four positions for ten cards); a table with columns "after move", "left pile, top to bottom", "middle", "right".
- **Action:** Lay out the staircase with cards face up: a pile of three on the left, A on top, then 2, then 3 at the bottom; a pile of two in the middle, 4 on top of 5; the 6 alone on the right. The move with cards: take the top card of every pile. Stack the three cards you took: the card from the right pile at the bottom, the card from the middle pile on it, the card from the left pile on top. Put this new pile on the left and slide the other piles one place to the right. After each move write which cards are in each pile, top to bottom. Make six moves. Which card never moves? Which cards are back in their place after two moves? After three? After how many moves is every card back where it started? Then do the same with ten cards laid out as 4-3-2-1 (A-2-3-4 on the left, 5-6-7 next, 8-9, then 10) and find after how many moves every card is back.
- **Result:** After one move: left A-4-6, middle 2-3, right 5. The ace never moves; 2 and 4 swap places every move (back after 2); 3, 5, 6 cycle (back after 3); all six back after 6 moves. With ten cards: the ace is fixed; 2 and 5 have period 2; 3, 6, 8 period 3; 4, 7, 9, 10 period 4; all back after 12 moves. (§J.) A card's period is (its pile's position from the left) + (its depth in the pile) − 1.
- **Question:** the arrangement rests but the counters do not: a permutation with orbits of lengths 1, 2, …, k and everything back after lcm(1, …, k) moves. This is the diagonal structure of the Young diagram made visible (section 4).
- **Minutes:** 12.
- **Before/after:** needs U4. Opens the Young-diagram notes in section 4.

### U14. How many arrangements?

- **Levels:** 4–5 (2–3 for n ≤ 6).
- **Setup:** answer table with rows n = 1 … 8; list boxes.
- **Action:** For n = 1, 2, …, 8, write the number of ways to split n counters into piles, listing them systematically by biggest pile so that none is missed. Then for eight counters: how many of the ways have exactly two piles? Exactly three piles?
- **Result:** 1, 2, 3, 5, 7, 11, 15, 22. Eight counters: two piles: 4 ways (7-1, 6-2, 5-3, 4-4); three piles: 5 ways (6-1-1, 5-2-1, 4-3-1, 4-2-2, 3-3-2). (§A, §I; the three-pile list is the complete list of partitions of 8 into three parts.)
- **Question:** counting (partition numbers); supplies the complete lists that U5 and U6 need.
- **Minutes:** 10.
- **Before/after:** needs U2. Opens U5, U6.

### U15. Backwards from the staircase: the longest chain for ten (reserve)

- **Levels:** 4–5.
- **Setup:** a large blank page for a tree; the parent method from U8.
- **Action:** Start at 4-3-2-1 and find its parent that is not itself. Then find all the parents of that arrangement, then all the parents of each of those, and so on, writing every parent above its child. Keep going as far as it goes. How many arrangements did you reach? How long is the longest chain, and which arrangements are at the top of it?
- **Result:** 4-3-2-1 ← 5-3-2 ← {6-4, 6-3-1, 4-3-1-1-1}; 6-4 ← {7-1-1-1, 5-1-1-1-1-1}; 6-3-1 ← {7-2-1, 4-2-1-1-1-1}; 4-3-1-1-1 ← {4-2-2-2}; and so on. All 42 arrangements of 10 are reached, which proves again that every start rests. The longest chains have 12 arrows and end at 3-3-2-1-1, 3-2-2-2-1 and 3-2-2-1-1-1; the full parent lists are in §B (n = 10).
- **Question:** optimality by backward search (the height of the tree); completeness by a second method.
- **Minutes:** 15 or more.
- **Before/after:** needs U7, U8.

## 3. Coverage notes for the curator

- K–1 without reading: K1–K16 (sixteen problems, about 95 minutes including reserves K14–K16). A comfortable spine is K1, K2, K3, K4, K5, K6, K7, K10, K8, K9, K13, K11, with K12, K14, K15, K16 as reserves in that order.
- Grades 2–3: M1–M16 (about 130 minutes including reserves M15, M16). A spine: M1, M2, M3, M4, M5, M6, M7, M8, M9, M12, M14; reserves M10, M11, M13, M15, M16.
- Grades 4–5: U1–U15 (about 165 minutes including reserves U12, U13, U15). A spine: U1, U2, U3, U4, U8, U9, U5, U6, U7, U10, U11; reserves U12, U13, U14 (early if the lists are needed), U15.
- Contrasting instances built in: 3 rests / 4 loops / 5 loops / 6 rests / 7 loops / 8 has two loops / 10 rests; starts that reach the same end in 1, 2, 3, 4, 5, 6 moves; arrangements with 0, 1, 2, 3 parents; single-pile runs for 3, 6, 10, 15.
- Problems that build toward an argument: K8, K11, K12 (exhaustion), M7/M8 and U4 (fixed points), M11 and U9 (no parents), U10 (single pile), U11 (loops are staircases with extras). Pure doing: K1–K7, M1–M3, U1, U7, U12.
- The whole-group launch action is the K1/M1 move; a good launch start is 2-2-2 (three moves to 3-2-1, every move changes the number of piles: 3, 4, 2, 3).

## 4. Mathematics behind the session (for the facilitator guide's section for the two mathematicians)

**Setting.** An arrangement of n counters is a partition of n. The move (Bulgarian solitaire) is a map on the set of partitions of n; since the set is finite, every orbit is eventually periodic: it ends at a fixed point or in a cycle. The one law everybody uses: the new pile has as many counters as there were piles.

**Fixed points are exactly the staircases (complete proof, used in M8/U4).** Let λ = (λ₁ ≥ λ₂ ≥ … ≥ λₚ) be unchanged by the move. After the move the piles are λᵢ − 1 for each λᵢ ≥ 2, plus the new pile p. Every old pile shrank, so the largest pile afterwards, which must again be λ₁, is the new pile: λ₁ = p. The number of piles afterwards is (number of λᵢ ≥ 2) + 1 and must equal p, so exactly one λᵢ equals 1: λₚ = 1 and λₚ₋₁ ≥ 2. Remove the pile p from both the old and the new arrangement: the multisets {λ₁ − 1, …, λₚ₋₁ − 1} and {λ₂, …, λₚ} are equal, so, sorted, λ₁ − 1 = λ₂, λ₂ − 1 = λ₃, …, λₚ₋₁ − 1 = λₚ = 1. Hence λ = (p, p−1, …, 1). Conversely every staircase is fixed. So a fixed point exists exactly when n is triangular, and then it is unique. (Verified for n ≤ 25 in §H.)

**Parents (used in M10, U8, U9).** μ is the result of a move from some λ if and only if μ has a pile of size m ≥ (number of piles of μ) − 1; then the parents are obtained, for each such distinct size m, by removing one pile of size m, adding one counter to every other pile, and adding m − (ℓ(μ) − 1) new single counters. Proof: if λ has m piles, the move creates a pile of size m and leaves at most m other piles, so ℓ(μ) ≤ m + 1; conversely the construction gives a λ with exactly m piles whose move is μ, and every parent arises this way (the new pile is one of the piles of μ and its size fixes ℓ(λ)). Consequently μ has no parent (is a "Garden of Eden" partition) exactly when its largest part is at most ℓ(μ) − 2. Verified against brute force for all n ≤ 20 (§E). Counts of parentless partitions for n = 3, …, 12: 1, 1, 2, 3, 5, 7, 10, 14, 20, 27; they agree with p(n−3) up to n = 8 and then fall behind (§O), a pattern that breaks for anyone who guesses it.

**Brandt's theorem (cited; checked by computer for n ≤ 20).** J. Brandt, "Cycles of partitions", Proc. Amer. Math. Soc. 85 (1982): if n = T_k = k(k+1)/2, every start reaches the staircase (k, k−1, …, 1); if n = T_k + r with 0 < r ≤ k, every start ends in a cycle, and the cycle states are exactly the C(k+1, r) partitions obtained from (k, k−1, …, 1, 0) by adding 1 to r of its k+1 entries. The part of this that can be proved at the table (U11): write such a state as (k+ε₀, k−1+ε₁, …, 1+ε_{k−1}, ε_k) with ε ∈ {0,1}^{k+1}, Σε = r, the piles listed newest first (the entry ε_k is a pile of 1 or nothing). It has k + ε_k piles. The move sends it to (k+ε_k, k−1+ε₀, …, 1+ε_{k−2}, ε_{k−1}): the same form with ε cyclically shifted by one place. So this family is closed under the move, the move acts on it as a rotation of the necklace ε, the cycle lengths divide k+1, and the number of cycles equals the number of binary necklaces of length k+1 with r ones. Hence a single cycle exactly when r ∈ {0, 1, k}: n = 2, 4, 5, 7, 9, 11, 14, 16, 20 have one loop, and n = 8, 12, 13, 17, 18, 19 have several (two loops of 4 and 2 for 8: necklaces 1100 and 1010; two loops of 5 for 12 and 13; loops of 6, 6, 3 for 17; 6, 6, 6, 2 for 18). The hard part of the theorem, that every start reaches this family, is what the exhaustive maps establish for n ≤ 10 in the session; the general proof is in Brandt's paper and in E. Akin and M. Davis, "Bulgarian solitaire", Amer. Math. Monthly 92 (1985).

**Young diagrams and diagonals.** Draw a partition as rows of cells, newest pile on top. The move removes the first cell of every row and lays those cells down as a new top row. Reading the cell in row i, column j: it goes to row i+1, column j−1 (if j ≥ 2) or to row 1, column i (if j = 1); either way i + j is unchanged, so every cell stays on its anti-diagonal. At the staircase the first k anti-diagonals are full and the move rotates each anti-diagonal d cyclically through its d cells; that is U13 (a card in row i at depth j has period i + j − 1; all cards return after lcm(1, …, k) moves: 6 for k = 3, 12 for k = 4, 60 for k = 5, §J). The extras of a cycle state are cells on anti-diagonal k+1, and the rotation of the necklace in the previous paragraph is the rotation of that diagonal.

**How long it takes.** For n = T_k the number of moves from any start is at most k² − k (K. Igusa, "Solution of the Bulgarian solitaire conjecture", Math. Mag. 58 (1985); G. Etienne, "Tableaux de Young et solitaire bulgare", J. Combin. Theory Ser. A 57 (1991)). The bound is attained for k = 2, …, 6: slowest starts 1-1-1 (2 moves), 2-2-1-1 (6), 3-3-2-1-1 and two others (12), sixteen starts with 15 counters (20), 66 starts with 21 counters (30) (§C). Distribution of the number of moves for 6 and 10 counters in section 1.

**The single pile (U10, complete proof).** From one pile of N counters, after m moves the state is {N − m} ∪ τ_m, where τ₀ is empty and τ_{m+1} = {x − 1 : x ∈ τ_m, x ≥ 2} ∪ {|τ_m| + 1} (induction: the big pile loses one counter, the small piles lose one each, and the new pile has one counter from the big pile plus one from each small pile). In the "tail game" τ, starting from the j-staircase, the next j+1 moves give (j+1, j−1, …, 1), (j+1, j, j−2, …, 1), …, (j+1, j, …, 2), (j+1, j, …, 1): the (j+1)-th diagonal fills one cell per move, top to bottom. So τ reaches the (k−1)-staircase after 1 + 2 + … + (k−1) = T_{k−1} moves, and at that moment the state is {T_k − T_{k−1}} ∪ (k−1, …, 1) = (k, k−1, …, 1). It cannot have rested earlier because before that the big pile exceeds k. Hence one pile of T_k takes exactly T_{k−1} moves: 1, 3, 6, 10, 15 for k = 2, …, 6 (§G), and all-ones takes one more.

**Where it leads.** Partitions and Young diagrams; the conjugate description (in the conjugate partition the move deletes the largest part m and adds 1 to the next m parts, a "shift" map studied by J. R. Griggs and C.-C. Ho, "The cycling of partitions and compositions under repeated shifts", Adv. in Appl. Math. 21 (1998)); enumeration of Garden of Eden partitions (B. Hopkins and J. A. Sellers, "Exact enumeration of Garden of Eden partitions", Integers 7 (2007)); the survey B. Hopkins, "30 years of Bulgarian solitaire", College Math. J. 43 (2012); variants (Austrian solitaire in Akin–Davis; Montreal solitaire, J. Cannings and J. Haigh, J. Combin. Theory Ser. A 60 (1992)); random Bulgarian solitaire (S. Popov, Random Structures Algorithms 27 (2005)); the popular account is M. Gardner's column in Scientific American, August 1983. Undergraduate topics touched: finite dynamical systems (transients and cycles, basins), necklaces and Burnside counting, integer partitions and generating functions, orbits of permutations and lcm. The bibliographic details above are from memory and were not checked against the originals in this stage; the mathematical statements were all checked by computation.
