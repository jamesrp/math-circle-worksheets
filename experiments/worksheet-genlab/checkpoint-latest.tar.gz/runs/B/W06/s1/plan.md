# Week 1 plan: Bulgarian solitaire

Stage: curator. Input to the formatter. Part A gives the student pages for the three tables (final printed text of every problem, the recording space to draw, minutes). Part B gives the content of the facilitator guide. Every answer in this file was recomputed by `curator-check.py` in this directory (output `curator-check.txt`, ending in `ALL CHECKS PASSED`); the bank's independent program `bs.py` / `bs-results.txt` agrees.

## 0. Conventions the pages rely on

**Topic name for the header:** `Bulgarian solitaire`. Level names for the header: `Grades K–1`, `Grades 2–3`, `Grades 4–5`.

**The move.** Counters sit in piles. One move: take one counter from every pile and put all the counters you took together as one new pile. A pile that becomes empty is gone. The move is stated inside Problem 1 of every level (K–1 with plates), and not repeated.

**Notation (grades 2–3 and 4–5 only).** An arrangement is written biggest pile first, with hyphens: `4-2`, `3-2-1`, `1-1-1-1-1-1`. Problem 1 of each of these levels says so. K–1 pages use pictures and words only, never hyphen notation, except that the adult writes tower sizes on the blanks provided.

**Boards and recording spaces** (draw exactly these; sizes are physical sizes on the printed Letter page):

- *Plate mat* (K–1). One full page with nothing but the header, the footer and six circles ("plates") of 7 cm diameter, in two columns and three rows, about 1 cm apart, outlined in a 1 pt line. Piles are built on plates. It is page 1 of the K–1 file and carries no problem text. Print one per child.
- *Tower frame for n counters* (K–1 recording). A square grid of n columns by n rows of cells, light grey grid lines, a dark outline; a label above it (for example `start`, `after 1 move`, `before`, `a way`) and a 3 cm blank line under it where the adult writes the tower sizes. Cell sizes: 1.2 cm for the 3-counter and 4-counter frames (four 3-counter frames or three 4-counter frames fit in a row); 1.1 cm for the 6-counter frames (two per row); 1.0 cm for the 5-counter frames (three per row); 0.9 cm for the 4-counter frames of Problem 10, where two before/after pairs share a row. The child colors one cell per counter, one column (tower) per plate, from the bottom up, tallest tower on the left. Consecutive frames of a run are joined by a short arrow; a run may wrap to the next row, and a problem's text stays on the same page as the first row of its frames.
- *Before/after pair* (K–1). Two tower frames side by side with an arrow between them, labelled `before` and `after the move` (or `a way` and `after 1 move`).
- *Staircase board* (K–1 and 2–3). A staircase such as 4-3-2-1 drawn as columns (towers) of circles, tallest column on the left, columns bottom-aligned, circles 2.5 cm in diameter on 2.7 cm centres, so that a real counter covers a circle. The K–1 board for 4-3-2-1 has, at its left, an extra column of four *dotted* circles (empty at the start; the new tower is built there). Every board has a 3 cm blank line under it for the count.
- *Arrow strip of m boxes* (2–3 and 4–5). Boxes 3.2 cm wide and 1.3 cm high joined by 0.5 cm arrows, five boxes per line, continuing on the next line. When a problem names the start, it is printed in the first box; otherwise the first box is blank. A run of m moves needs m + 1 boxes; one more box shows the repeat. Strip lengths below are chosen so that they do not give away run lengths where that matters.
- *Run table*. One row per start; row height 1.2 cm; columns: `start` (2.6 cm), `run` (seven adjacent cells of 1.9 cm, no arrows), `moves` (1.5 cm) and, where the problem asks, `stopped at` (2.6 cm) in place of some run cells.
- *List box of n lines*. Numbered ruled lines, 6 cm long, in two columns when n > 8.
- *Labelled blank*. A short caption followed by a ruled blank of at least 6 cm, such as `Parents of 4-2: ______`.
- *Answer lines*. Ruled lines as the template's `\AnswerLines`.
- *Map of six* (2–3). A tree of eleven boxes (3.2 cm by 1.3 cm) with all arrows pre-drawn, the bottom box printed with `3-2-1` and a small loop arrow from that box back to itself. Positions, with x in cm from the page centre and levels 2.6 cm apart, level 0 at the bottom: level 0: one box at x = 0 (`3-2-1`); level 1: x = 0; level 2: x = −4 and x = +4; level 3: x = −6, x = −2, x = +4; level 4: x = −6, x = +4; level 5: x = +4; level 6: x = +4. Arrows (all pointing down): level 1 → level 0; both level-2 boxes → the level-1 box; level-3 boxes at x = −6 and x = −2 → the level-2 box at x = −4; level-3 box at x = +4 → the level-2 box at x = +4; level-4 box at x = −6 → level-3 box at x = −6; level-4 box at x = +4 → level-3 box at x = +4; level 5 → level 4 at x = +4; level 6 → level 5. All boxes except the bottom one are empty.
- *Blank map page* (4–5). A page that is empty except for one box (3.2 cm by 1.3 cm) printed with `3-2-1` at the bottom centre, with a loop arrow from the box to itself (Problem 2), or entirely empty (Problem 5).
- *Scoreboard* (K–1 Problem 12). Six rows, each with a small tower picture of a start (a 6-by-6 grid with 0.6 cm cells, the cells of the arrangement pre-shaded, tallest tower on the left) and a blank `moves: ______`; then three rows each with an empty 6-counter tower frame (1.1 cm cells) and a blank `moves: ______`.
- *Card table* (4–5 Problem 13). A table whose rows are `after 0 moves` … `after 6 moves` (then a second table with rows `after 0 moves` … `after 12 moves`) and whose columns are the pile positions, `left`, `middle`, `right` (and `far right` in the second table); cells 3.6 cm wide and 1.1 cm high.

**Physical pieces.** Counters 2 to 2.5 cm across. Anything the child places counters on (plate mat, staircase boards) is drawn at that size; tower frames are recording space and are smaller.

---

# Part A. Student pages

## A1. K–1 table (two kindergartners and a first grader; the adult reads aloud and writes)

Each child has a plate mat, ten counters and a crayon. Everything below is read aloud by the adult; the child builds on the mat, colors the frames, and says the answers; the adult writes tower sizes and numbers on the blanks. The ordering is act → record → compare → explain: Problems 1–7 are runs, 8–9 find the law and the arrangements that stay still, 10–12 are the complete list, the staircases and the race; 13–15 are for a fast group.

| # | Source | Minutes |
|---|---|---|
| 1 | K1 | 4 |
| 2 | K2 | 4 |
| 3 | K3 | 6 |
| 4 | K4 | 3 |
| 5 | K5 (shortened) | 5 |
| 6 | K6 (shortened) | 3 |
| 7 | K7 | 7 |
| 8 | K10 | 4 |
| 9 | K8, first part | 4 |
| 10 | K11 + second part of K8 | 8 |
| 11 | K9 | 5 |
| 12 | K13 (three-way races) | 8 |
| 13 | K14 (reserve) | 6 |
| 14 | K16 (reserve) | 7 |
| 15 | K15 (reserve) | 6 |

Core 1–12: 61 minutes; with reserves: 80.

**Page 1 of the K–1 file is the plate mat** (see Conventions). Problems start on page 2.

### Problem 1 (4 min)

Problem 1: Put one counter on each of three plates. Color the start picture: for each plate, color one tower of squares, one square for each counter on that plate, starting at the bottom. Put the tallest tower on the left. Now make the move: take one counter off every plate that has counters, hold them all in one hand, and put them all together on one empty plate. Color the picture after 1 move. Make the move again and color the picture after 2 moves. Make the move a third time and color the picture after 3 moves. Count all the counters on the mat and say the number. Point to the first picture that looks just like the picture after it.

Recording space: one row of four 3-counter tower frames labelled `start`, `after 1 move`, `after 2 moves`, `after 3 moves`, arrows between them, a blank line under each.

### Problem 2 (4 min)

Problem 2: Put all three counters on one plate. Color the start picture. Make the move and color the picture after 1 move. Make the move again and color the picture after 2 moves. Now put two counters on one plate and one counter on another plate. Color the start picture. Make the move and color the picture after 1 move. Is there another way to put three counters on plates that you have not tried in Problems 1 and 2? If you find one, color it, make the move, and color what you get. Point to the picture where each start stopped changing.

Recording space: row A: three 3-counter frames (`start`, `after 1 move`, `after 2 moves`); row B: two 3-counter frames (`start`, `after 1 move`); row C: two 3-counter frames (`another way`, `after 1 move`).

### Problem 3 (6 min)

Problem 3: Put four counters on one plate. Color the start picture. Make the move and color the picture after 1 move. Keep making moves and coloring a picture after each move until you have made six moves. Find two pictures that look the same and put a dot under both of them. Find more pairs. Does the picture ever stop changing?

Recording space: seven 4-counter frames labelled `start`, `after 1 move`, …, `after 6 moves`, three per row (3 + 3 + 1), arrows between consecutive frames, a blank line under each.

### Problem 4 (3 min)

Problem 4: Put one counter on each of four plates. Color the start picture. Make four moves and color a picture after each one. Find the picture in Problem 3 that looks the same as your picture after 1 move, and point to it. Do both runs go round the same three pictures?

Recording space: five 4-counter frames labelled `start`, `after 1 move`, …, `after 4 moves`, three per row (3 + 2).

### Problem 5 (5 min)

Problem 5: Put six counters on one plate. Color the start picture. Make the move and color the picture after 1 move. Keep making moves and coloring until a move changes nothing. Say how many moves you made before the picture stopped changing. Look at the last picture. Say how tall each tower is.

Recording space: four 6-counter frames labelled `start`, `after 1 move`, `after 2 moves`, `after 3 moves`, two per row; then a blank `moves: ______`.

### Problem 6 (3 min)

Problem 6: Put one counter on each of six plates. Make one move and look at the plates. Which problem started like this? Keep making moves until a move changes nothing, and count the moves. Color the last picture. Is it the same as the last picture in Problem 5? Which run took more moves, this one or the one in Problem 5, and how many more?

Recording space: one 6-counter frame labelled `last picture` and a blank `moves: ______`.

### Problem 7 (7 min)

Problem 7: Put three counters on one plate and three counters on another plate. Color the start picture. Make moves and color a picture after each one until a move changes nothing. Count the moves. Now put two counters on each of three plates. Color the start picture. Make moves until a move changes nothing. Count the moves and color the last picture. Find the picture in the first run that looks the same as the start picture of the second run. Which run took more moves, and how many more?

Recording space: five 6-counter frames labelled `start`, `after 1 move`, …, `after 4 moves`, two per row, then a blank `moves: ______`; below, two 6-counter frames labelled `start` and `last picture` side by side, and a blank `moves: ______`.

### Problem 8 (4 min)

Problem 8: Put two counters on each of three plates. Before you make the move, count the plates that have counters on them and say the number. Make the move. Count the counters on the new plate and say the number. Do this before and after every move until a move changes nothing. Now put three counters on one plate and three on another. Before each move, say how many counters the new pile is going to have. Make the move and check. Keep going until a move changes nothing.

Recording space: table A, five rows, two columns headed `plates with counters` and `counters on the new plate`, cells 4 cm wide and 1.1 cm high; table B, five rows, two columns headed `my guess for the new pile` and `the new pile`.

### Problem 9 (4 min)

Problem 9: Put two counters on one plate and one counter on another plate. Color the picture. Make the move and color the picture after the move. Did the picture change? Now put three counters on one plate, two on a second plate and one on a third plate. Color the picture. Make the move and color the picture after the move. Did the picture change? Say what happened to the plate with three counters, to the plate with two, and to the plate with one, and say how many counters the new pile got and why it got that many.

Recording space: a before/after pair of 3-counter frames; a before/after pair of 6-counter frames.

### Problem 10 (8 min)

Problem 10: Find every way to put four counters on plates. Three counters on one plate and one on another plate is the same way as one and three. Color each way you find in its own frame on the left. When you think you have found them all, count the ways and say the number. Now build each way again, make one move, and color what you get in the frame on the right. Look at all the pictures. Did any way stay the same after the move? Which way on the left never appears on the right?

Recording space: six before/after pairs of 4-counter frames with 0.9 cm cells (left label `a way`, right label `after 1 move`), two pairs per row, three rows. Six pairs, not five, so that the count is not given away.

### Problem 11 (5 min)

Problem 11: Cover every circle of the smallest staircase with counters. Count the counters and say the number. Do the same for the next staircase, then the next, then the biggest. Now leave the counters on the biggest staircase and make the move: take the top counter off every tower and build all of them into a new tower on the dotted circles. Do the towers look the same as before the move? Look at the four staircases. How many more counters does each staircase have than the one before it?

Recording space: staircase boards for 1, 2-1 and 3-2-1 in one row (widths 2.7, 5.4 and 8.1 cm), each with a blank line under it; on the next page or below, the board for 4-3-2-1 with its dotted column at the left (five columns, 13.5 cm wide, 10.8 cm tall) and a blank line under it.

### Problem 12 (8 min)

Problem 12: Everyone starts with six counters. First race: one of you starts with four counters on one plate and two on another; one starts with three and three; one starts with one counter on each of six plates. Make moves at the same time until a move changes nothing. Count your moves. Who needed the fewest moves? Second race: two, two, one and one; five and one; two, two and two. Count the moves. Now everyone: try to find a start that takes more moves than any start in the two races. Then find a start that takes only one move.

Recording space: the scoreboard (see Conventions) with the six pre-shaded starts in this order: 4-2, 3-3, 1-1-1-1-1-1, 2-2-1-1, 5-1, 2-2-2, then three rows with empty 6-counter frames for the children's own starts.

### Problem 13 (6 min; reserve)

Problem 13: Put five counters on one plate. Color the start picture. Make moves and color a picture after each one until you have made six moves. Find pictures that are the same and put a dot under each of them. Then put one counter on each of five plates and make four moves, coloring a picture after each one. Point to the picture where this run joins the first run. Now think about three, four, five and six counters: which of them stop changing, and which go round and round?

Recording space: seven 5-counter frames (`start`, `after 1 move`, …, `after 6 moves`), three per row; then five 5-counter frames (`start`, `after 1 move`, …, `after 4 moves`), three per row.

### Problem 14 (7 min; reserve)

Problem 14: Put ten counters on one plate. Make the move. Say how tall each tower is, tallest first, so that it can be written in the next box. Keep making moves and saying the towers until a move changes nothing. How many moves did it take? Build the last picture on the big staircase board from Problem 11. Is it a staircase? One plate of three counters took 1 move to stop changing, and one plate of six took 3 moves. How many did one plate of ten take?

Recording space: an arrow strip of 8 boxes with `10` printed in the first box (the adult writes the sizes); a blank `moves: ______`.

### Problem 15 (6 min; reserve)

Problem 15: Find a start with three counters that becomes three counters on one plate after one move. Find a start with six counters that becomes five and one after one move. Find a different start that also becomes five and one. Find a start with six counters that becomes three, two and one after one move but is not three, two and one itself. Color each start you find on the left and what it became on the right.

Recording space: one before/after pair of 3-counter frames and three before/after pairs of 6-counter frames, labels `start` and `after 1 move`, one pair per row.

---

## A2. Grades 2–3 table (four third graders)

Each child has fifteen counters and a pencil and a full set of pages; Problem 5 is shared across the table. Problems 1–8 are the core (52 minutes); 9–13 continue in order for a fast table (40 minutes).

| # | Source | Minutes |
|---|---|---|
| 1 | M1 | 3 |
| 2 | M2 (starts changed) | 8 |
| 3 | M3 | 5 |
| 4 | new (five and three counters; from K14/M4) | 6 |
| 5 | M5 | 10 |
| 6 | M6 | 8 |
| 7 | M7 | 5 |
| 8 | M8 | 7 |
| 9 | M9 | 7 |
| 10 | M12 | 9 |
| 11 | M14 (+ a run of nine) | 8 |
| 12 | M10 + M11 (merged) | 8 |
| 13 | M13 | 8 |

### Problem 1 (3 min)

Problem 1: Put six counters in one pile. The move: take one counter from every pile and put all the counters you took together as a new pile. A pile with no counters left is gone. Make the move. Write the pile sizes in the next box, biggest pile first, like 5-1. Keep making moves and writing until the same arrangement appears in two boxes in a row. Write how many moves that took.

Recording space: an arrow strip of 6 boxes with `6` printed in the first box; a blank `moves: ______`.

### Problem 2 (8 min)

Problem 2: Run these four starts the same way, one on each strip: 1-1-1-1-1-1; 5-1; 3-3; 2-2-1-1. Write every arrangement. In the table, write the number of moves each start took and the arrangement it stopped at. Which start took the most moves? Which took the fewest? Find one arrangement, other than the one they stop at, that appears in all five runs from Problems 1 and 2, and circle it in every run.

Recording space: four arrow strips of 8 boxes with the starts printed in the first boxes; a table with five rows whose `start` cells are printed `6`, `1-1-1-1-1-1`, `5-1`, `3-3`, `2-2-1-1` and columns `moves` (2 cm) and `stopped at` (3.5 cm); two answer lines.

### Problem 3 (5 min)

Problem 3: Put four counters in one pile. Make the move seven times and write every arrangement. Circle the first arrangement that appears a second time. How many different arrangements come round again and again? Write the number. Then run 1-1-1-1 for four moves and 2-2 for three moves on the next two strips. Do they get into the same loop?

Recording space: an arrow strip of 8 boxes (`4` printed); a blank `arrangements in the loop: ______`; strips of 5 boxes (`1-1-1-1` printed) and 4 boxes (`2-2` printed); one answer line.

### Problem 4 (6 min)

Problem 4: Put five counters in one pile and run the move until an arrangement appears a second time. Circle the loop. Then run 2-1-1-1 the same way. Does it reach the same loop? Then run three counters in one pile until the same arrangement appears twice in a row. In the table, write R next to each number of counters whose runs stop at one arrangement, and L next to each number whose runs go round a loop.

Recording space: arrow strips of 7 boxes (`5` printed), 7 boxes (`2-1-1-1` printed) and 4 boxes (`3` printed); a one-row table with four cells headed `3 counters`, `4 counters`, `5 counters`, `6 counters`, cells 3 cm wide and 1.3 cm high.

### Problem 5 (10 min)

Problem 5: List every way to split six counters into piles, biggest pile first: 6, then 5-1, and so on. There are eleven. Share the list out at your table. Run each start until it stops changing. In the table, write each run and the number of moves it took. Does every start stop at 3-2-1? Which start takes the most moves? Which starts take exactly two moves?

Recording space: a list box of 11 lines; a run table with 11 rows (`start`, `run` of seven cells, `moves`); three answer lines.

### Problem 6 (8 min)

Problem 6: Write every arrangement of six counters in a box of the map so that each arrow points from an arrangement to what it becomes after one move. Every arrangement goes in exactly one box. Use your table from Problem 5. Then write: which boxes have no arrow coming in; which boxes have two arrows coming in; how many arrows are on the longest path to 3-2-1.

Recording space: the map of six (see Conventions); three labelled blanks: `no arrow coming in: ______`, `two arrows coming in: ______`, `arrows on the longest path: ______`.

### Problem 7 (5 min)

Problem 7: Go back to the runs you wrote. Pick eight different moves. For each one, write the arrangement before the move, its number of piles, and the size of the new pile the move made. What do you notice about the last two columns? Then build 4-4-2 with ten counters. Before each move, write the size the new pile is going to be. Make the move and write the arrangement you got. Do five moves.

Recording space: a table of 8 rows with columns `arrangement before the move` (4 cm), `number of piles` (3 cm), `size of the new pile` (3 cm); one answer line; a table of 5 rows with columns `arrangement` (4 cm, the first cell printed `4-4-2`), `my guess for the new pile` (3.5 cm), `after the move` (4 cm).

### Problem 8 (7 min)

Problem 8: Build 3-2-1 and make the move. Write what the pile of 3 became, what the pile of 2 became, what happened to the pile of 1, and how big the new pile is. Now find an arrangement of ten counters that does not change when you make the move. Build it, make the move to check, and write it. Then try to find an arrangement of four counters that does not change. Write every arrangement of four you try and what it became. Say in your own words why there is none.

Recording space: four labelled blanks (`the pile of 3 became: ___`, `the pile of 2 became: ___`, `the pile of 1: ___`, `the new pile has: ___`); a labelled blank `ten counters that do not change: ______`; a table of 5 rows with columns `arrangement of four` and `after the move` (4 cm each); two answer lines.

### Problem 9 (7 min)

Problem 9: Put seven counters in one pile and run the move until an arrangement appears a second time. Circle the loop. How many arrangements are in it? Then run 4-3 and 2-2-2-1 on the next strips. Do they reach the same loop? Write how many moves each of the three starts takes to get into the loop.

Recording space: arrow strips of 9 boxes (`7` printed), 7 boxes (`4-3` printed), 9 boxes (`2-2-2-1` printed); labelled blanks `arrangements in the loop: ___`, `moves to reach the loop, from 7: ___ from 4-3: ___ from 2-2-2-1: ___`.

### Problem 10 (9 min)

Problem 10: Run eight counters in one pile until an arrangement appears a second time and circle the loop. Run 5-3 the same way and circle its loop. Then run 4-4 and 2-2-2-2. In the table, write for each start the arrangements of the loop it reached and how many there are. How many different loops did you find?

Recording space: four arrow strips of 10 boxes (`8`, `5-3`, `4-4`, `2-2-2-2` printed); a table of 4 rows with columns `start` (printed), `arrangements in its loop` (9 cm), `how many` (2 cm); a blank `different loops: ___`.

### Problem 11 (8 min)

Problem 11: Cover each staircase board with counters and count. Write the five numbers under the boards. Run nine counters in one pile on the strip until an arrangement appears a second time. Then, for each number of counters from 1 to 10, write R in the table if there is an arrangement that does not change under the move, and L if every start goes round a loop. Use your runs, the staircases and Problem 8. For 7, 8 and 9 counters, write your best try for an arrangement that does not change, make one move on it, and write what it became.

Recording space: staircase boards for 1, 2-1, 3-2-1 (one row) and 4-3-2-1, 5-4-3-2-1 (one or two more rows; no dotted column), each with a blank line under it; an arrow strip of 10 boxes (`9` printed); a one-row table of ten cells headed `1` to `10`, 1.6 cm wide and 1.3 cm high; a table of 3 rows with columns `counters` (printed `7`, `8`, `9`), `my try` (4 cm), `after one move` (4 cm).

### Problem 12 (8 min)

Problem 12: An arrangement that becomes X after one move is called a parent of X. Use the map from Problem 6. Write every parent of 4-2 and every parent of 5-1. Then find every parent of 4-3-2-1 among the arrangements of ten counters, and write them. Then explain, using the size of the new pile, why 2-2-1-1 has no parent.

Recording space: labelled blanks `parents of 4-2: ______`, `parents of 5-1: ______`, `parents of 4-3-2-1: ______`; three answer lines.

### Problem 13 (8 min)

Problem 13: Run one pile of three counters until it stops changing and write the number of moves. Do the same for one pile of six, then one pile of ten. Look at the three numbers and write what you think one pile of fifteen will take. Then run one pile of fifteen and write every arrangement. Was your prediction right?

Recording space: arrow strips of 4 (`3`), 6 (`6`) and 8 (`10`) boxes, each followed by `moves: ___`; a blank `my prediction for fifteen: ___`; an arrow strip of 12 boxes (`15` printed); a blank `moves: ___`.

---

## A3. Grades 4–5 table (two fourth graders and a fifth grader)

Each child has fifteen counters and a pencil and a full set of pages; Problems 5 and 7 are shared across the table. Problems 1–6 are the core (49 minutes); 7–13 continue in order (66 minutes).

| # | Source | Minutes |
|---|---|---|
| 1 | U1 (starts changed; law added) | 7 |
| 2 | U2 | 9 |
| 3 | U3 | 4 |
| 4 | U4 | 8 |
| 5 | U5 | 12 |
| 6 | U6, first half | 9 |
| 7 | U6, second half | 8 |
| 8 | U8 | 8 |
| 9 | U9 | 8 |
| 10 | U7 | 12 |
| 11 | U10 | 10 |
| 12 | U11 (on paper) | 10 |
| 13 | U13 | 10 |

### Problem 1 (7 min)

Problem 1: The move: take one counter from every pile and put all the counters you took together as a new pile. A pile with no counters left is gone. Write an arrangement biggest pile first, like 4-2. Run these four starts until the arrangement stops changing, one start on each strip, and write the number of moves each took: 6; 3-3; 4-1-1; 2-2-1-1. Then, for every move of the 2-2-1-1 run, write in the table the arrangement before the move, its number of piles, and the size of the new pile the move made.

Recording space: four arrow strips of 8 boxes (`6`, `3-3`, `4-1-1`, `2-2-1-1` printed), each followed by `moves: ___`; a table of 6 rows with columns `before the move` (4 cm), `number of piles` (3 cm), `size of the new pile` (3 cm).

### Problem 2 (9 min)

Problem 2: List every way to split six counters into piles, biggest pile first. There are eleven. Sort them by biggest pile to be sure none is missing. Then make the map on the next page: 3-2-1 is already in its box at the bottom. Write each other arrangement in a box above the arrangement it becomes after one move, and draw an arrow from it to that arrangement. When the map is finished, check every arrangement: does its path of arrows lead to 3-2-1?

Recording space: a list box of 11 lines; a blank map page with `3-2-1` in a box at the bottom centre and a loop arrow on it.

### Problem 3 (4 min)

Problem 3: From your map, write in the table how many moves each of the eleven arrangements needs to reach 3-2-1. Which needs the most? How many arrangements need exactly three moves? Which arrangements have no arrow pointing at them? Which arrangements have two arrows pointing at them?

Recording space: a table of 11 rows with columns `arrangement` (4 cm) and `moves` (2 cm), split into two side-by-side halves of 6 and 5 rows; labelled blanks `most moves: ___`, `exactly three moves: ___ arrangements`, `no arrow in: ______`, `two arrows in: ______`.

### Problem 4 (8 min)

Problem 4: Build 3-2-1 and make the move. Write what happened to the pile of 3, to the pile of 2, to the pile of 1, and how big the new pile is. Now suppose an arrangement does not change when you make the move. After the move, is any old pile as big as it was before? So which pile of the new picture must be the new pile: the biggest, the smallest, or one in between? Write which, and why. Then write what the biggest pile, the next, and the next must be, down to the smallest pile. Finally write every number of counters from 1 to 30 that has an arrangement which does not change.

Recording space: four labelled blanks (`the pile of 3 became: ___`, `the pile of 2 became: ___`, `the pile of 1: ___`, `the new pile has: ___`); two answer lines captioned `the new pile must be`; four answer lines captioned `the piles must be`; a labelled blank `numbers from 1 to 30: ______`.

### Problem 5 (12 min)

Problem 5: List all fifteen ways to split seven counters into piles, biggest pile first. Share them out at your table. Run each one until an arrangement appears a second time. Then draw the map of seven on the blank page: every arrangement in a box, with an arrow from it to what it becomes. Circle the loop. How many arrangements are in the loop? How many moves does the farthest start need to enter it? Which arrangements have no arrow pointing at them?

Recording space: a list box of 15 lines; six arrow strips of 10 boxes with blank first boxes; a blank map page; labelled blanks `arrangements in the loop: ___`, `farthest start: ___ needs ___ moves`, `no arrow in: ______`.

### Problem 6 (9 min)

Problem 6: Run 8, 5-3, 4-4, 2-2-2-2 and 6-1-1 until each one repeats an arrangement, and circle each loop. How many different loops did you find? Write the arrangements of each loop in a ring of its own, in the order they come. How long is each loop? Which of the five starts land in which loop?

Recording space: five arrow strips of 10 boxes (`8`, `5-3`, `4-4`, `2-2-2-2`, `6-1-1` printed); three empty rectangles 8 cm by 4 cm, each captioned `a loop` (three, not two, so the count is not given away); labelled blanks `different loops: ___`, `lengths: ___`; two answer lines.

### Problem 7 (8 min)

Problem 7: List all 22 ways to split eight counters into piles, biggest pile first. Next to each one, write the loop it reaches: most of them are already on your strips from Problem 6; run the rest. Count how many starts reach each loop.

Recording space: a list of 22 numbered lines in two columns, each line with a second short blank headed `loop`; two spare arrow strips of 10 boxes with blank first boxes; a labelled blank `starts reaching each loop: ______`.

### Problem 8 (8 min)

Problem 8: An arrangement that becomes X after one move is called a parent of X. Find every parent of 5-3-2 (ten counters). Then every parent of 4-4 (eight counters). Then every parent of 2-2-2-2. Write them. Then describe a way to find every parent of any arrangement without guessing.

Recording space: labelled blanks `parents of 5-3-2: ______`, `parents of 4-4: ______`, `parents of 2-2-2-2: ______`; four answer lines.

### Problem 9 (8 min)

Problem 9: From the map of six, list the arrangements with no arrow pointing at them, and from the map of seven do the same. For each of them write the biggest pile and the number of piles in the table. Find a rule that tells, from these two numbers, whether an arrangement has a parent. Write the rule. Use it to list every arrangement of eight counters with no parent. Then check two of them by trying to build a parent.

Recording space: a table of 8 rows with columns `arrangement` (4 cm), `biggest pile` (2.5 cm), `number of piles` (2.5 cm); two answer lines captioned `rule`; a list box of 8 lines captioned `eight counters, no parent`; two answer lines.

### Problem 10 (12 min)

Problem 10: Run 10, 5-5, 7-3 and 4-4-1-1 until they stop changing and write the number of moves for each. Then search for a start with ten counters that takes twelve moves. Write its whole run.

Recording space: four arrow strips of 12 boxes (`10`, `5-5`, `7-3`, `4-4-1-1` printed), each followed by `moves: ___`; three arrow strips of 14 boxes with blank first boxes.

### Problem 11 (10 min)

Problem 11: Run one pile of three counters until it stops changing. One pile of six stopped after 3 moves (Problem 1) and one pile of ten after 6 moves (Problem 10). Write your prediction for one pile of fifteen. Then run it and write every arrangement. In each arrangement of your run, underline the biggest pile and look at the rest. What do the small piles look like after 1, 3, 6 and 10 moves? Then predict how many moves 1-1-1-1-1-1-1-1-1-1-1-1-1-1-1 takes and write why.

Recording space: an arrow strip of 4 boxes (`3` printed) with `moves: ___`; a labelled blank `prediction for fifteen: ___`; an arrow strip of 12 boxes (`15` printed) with `moves: ___`; three answer lines; a labelled blank `fifteen ones: ___ moves` and two answer lines.

### Problem 12 (10 min)

Problem 12: Run nine counters in one pile until an arrangement appears a second time, and circle the loop. Copy every loop you have found, for 7, 8 and 9 counters, into the table, one arrangement per row. Try to write each loop arrangement as the staircase 3-2-1 with extra counters added, at most one extra on each step and at most one extra as a new pile of 1, like 4-2-1 = (3+1)-2-1 and 3-2-1-1 = 3-2-1-(0+1). Does it work for every loop arrangement? Follow the extras around each loop: where does each extra go after one move? Use that to explain why the loop for 7 has four arrangements, why 8 has two loops of different lengths, and why 9 has one loop of four.

Recording space: an arrow strip of 10 boxes (`9` printed); a table of 14 rows with columns `counters` (2 cm), `loop arrangement` (4 cm), `as 3-2-1 plus extras` (6 cm); four answer lines.

### Problem 13 (10 min)

Problem 13: Lay out six playing cards face up as the staircase 3-2-1: a pile of three on the left with the ace on top, then the 2, then the 3 at the bottom; a pile of two in the middle with the 4 on top of the 5; the 6 alone on the right. The move with cards: take the top card of every pile. Stack the cards you took, the card from the right pile at the bottom, then the card from the middle pile, then the card from the left pile on top. Put this new pile on the left and slide the other piles one place to the right. After each move, write in the table which cards are in each pile, top to bottom. Make six moves. Which card never moves? Which cards are back in their starting place after two moves? After three? After how many moves is every card back where it started? Then lay out ten cards as 4-3-2-1 (ace, 2, 3, 4 on the left, top to bottom; then 5, 6, 7; then 8, 9; then 10) and find after how many moves every card is back.

Recording space: the card table for 6 cards (rows `after 0 moves` to `after 6 moves`, columns `left`, `middle`, `right`, the first row printed `A 2 3`, `4 5`, `6`); four labelled blanks `never moves: ___`, `back after 2 moves: ___`, `back after 3 moves: ___`, `all back after: ___ moves`; the card table for 10 cards (rows `after 0 moves` to `after 12 moves`, four columns, first row printed `A 2 3 4`, `5 6 7`, `8 9`, `10`); a labelled blank `all ten back after: ___ moves`.

---

# Part B. Facilitator guide content

## B1. Materials and preparation

Materials, with counts:

- Counters, one colour, about 150: ten per K–1 child (30), fifteen per child at the other tables (60 for grades 2–3, 45 for grades 4–5), six for the launch, the rest spare. Flat counters that stack are best.
- One deck of playing cards; only the ace to 10 of one suit are used (grades 4–5, Problem 13).
- Crayons or thick pencils, one per K–1 child; pencils and two erasers per other table.
- Printed pages: the K–1 set (plate mat plus problem pages), one per K–1 child, and one spare; the grades 2–3 set, one per child (four); the grades 4–5 set, one per child (three); this guide, one per adult.
- For the launch: a table or floor space all ten children can see, and a whiteboard or large sheet to write four arrangements on.

Preparation (ten minutes before): put a plate mat, ten counters and a crayon at each K–1 seat; fifteen counters and a pencil at each other seat; the page sets face down. Suggested adults: the parent at the K–1 table (its guide below is a full script; the problems need reading aloud and writing, not mathematics on the spot), the organizer at grades 2–3 (four children, the busiest table), the second mathematician at grades 4–5 (the table with the two written arguments). Each adult reads the launch and the first four problems of their table before the session and keeps the answer tables in this guide open.

Session shape: 0:00–0:05 free handling (children make piles, stack, sort; the K–1 adult shows the plate mat and lets them build any piles on it); 0:05–0:08 the launch; 0:08–0:50 table work; 0:50–0:58 the share; 0:58–1:00 pack up.

## B2. The whole-group launch (two minutes)

Everyone stands round one table. The organizer has six counters in three piles of two.

Say and do: "Here is the one move we will use all hour. Take one counter from every pile" (take them, saying "one, two, three"), "and put all the counters you took together as a new pile." Now there are piles of 3, 1, 1, 1. "Again: one from every pile. Four piles, so four counters. New pile." Now 4 and 2. "Again." Now 3, 2, 1. "Again." Take one from each of the three piles, make a pile of three: it is 3, 2, 1 again. "Nothing changed."

Write on the board, saying "we write the piles biggest first": 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1 → 3-2-1.

Say: "It stopped changing. Does that happen from every start? With every number of counters? How long does it take? Each table is going to find out. Off you go." Do not say the word staircase, do not mention triangular numbers, and do not say what other numbers of counters do.

For the K–1 children, their adult adds at the table: "We will put our piles on plates, and after every move we will color a picture of the towers."

Verified: 2-2-2 has 3 piles, so the new pile is 3; 3-1-1-1 has 4 piles, new pile 4; 4-2 has 2 piles, new pile 2; 3-2-1 has 3 piles, new pile 3, and the picture is unchanged (curator-check §4).

## B3. K–1 table: script, answers, hints

Order: Problems 1–9 are the must-do (about 40 minutes); then 10, 11, 12 in that order; 13–15 for a fast group. Rough clock, with table work starting at 0:08: Problems 1–2 done by 0:16, 3–4 by 0:25, 5–7 by 0:40, 8–9 by 0:48; a group that is ahead goes on to 10, 11, 12. Each child has their own pages, so a faster child can be read the next problem while the others finish. Every problem: read the sentence, wait for the action, then read the next sentence. Write tower sizes under each frame as the child finishes it (for example "2-1"), and write the numbers the child says on the blanks. If coloring gets slow, color the frames yourself while the child says the tower heights, or have the child color only the last picture of a run while you write the sizes under the others. A child may color the towers in any order; write the sizes sorted, biggest first, so pictures can be compared.

The move on plates: "one counter off every plate that has counters, all together on an empty plate." Common slip: taking counters from only some plates, or putting the new pile on a plate that still has counters. Fix: have the child point to each plate with counters before taking, and say "empty plate" out loud.

The point of the whole table, for you: three counters always end at 2-1; four counters never stop and go round three pictures; six counters always end at 3-2-1, from every one of the eleven starts, in zero to six moves; the arrangements that stay still are the staircases 2-1, 3-2-1, 4-3-2-1 with 3, 6, 10 counters; the new pile is always as big as the number of plates that had counters, because one counter came off each plate.

**Complete tables you will need.**

Three counters, three ways: 3 → 2-1; 2-1 → 2-1 (stays); 1-1-1 → 3. Every start ends at 2-1; 1-1-1 takes 2 moves, 3 takes 1, 2-1 takes 0. Nothing becomes 1-1-1.

Four counters, five ways: 4 → 3-1; 3-1 → 2-2; 2-2 → 2-1-1; 2-1-1 → 3-1; 1-1-1-1 → 4. Nothing stays still. Every start goes round the three pictures 3-1, 2-2, 2-1-1 for ever. Nothing becomes 1-1-1-1; 3-1 comes from two starts (4 and 2-1-1).

Five counters, seven ways: 5 → 4-1 → 3-2 → 2-2-1 → 3-1-1 → 3-2 → …, a loop of three pictures (3-2, 2-2-1, 3-1-1) entered after 2 moves; 1-1-1-1-1 → 5 (then as above); 2-1-1-1 → 4-1. Nothing stays still.

Six counters, eleven ways, all end at 3-2-1. Moves to get there: 3-2-1: 0; 4-2: 1; 5-1: 2; 3-1-1-1: 2; 6: 3; 2-2-2: 3; 2-1-1-1-1: 3; 1-1-1-1-1-1: 4; 3-3: 4; 4-1-1: 5; 2-2-1-1: 6. The runs: 6 → 5-1 → 4-2 → 3-2-1. 1-1-1-1-1-1 → 6 → 5-1 → 4-2 → 3-2-1. 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1. 2-2-1-1 → 4-1-1 → 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1. 2-1-1-1-1 → 5-1 → 4-2 → 3-2-1. Every run passes through 4-2 just before 3-2-1.

Ten counters on one plate: 10 → 9-1 → 8-2 → 7-2-1 → 6-3-1 → 5-3-2 → 4-3-2-1, six moves, and 4-3-2-1 stays still.

**Problem 1** (1-1-1). Expect 1-1-1 → 3 → 2-1 → 2-1: pictures "three towers of one", "one tower of three", "towers 2 and 1", "towers 2 and 1". The count is three every time (nothing is lost; counters only move). The first picture that looks just like the one after it is the picture after 2 moves. Ask: "Will it ever change again? Try once more." (It stays 2-1.) Hint if the move goes wrong: "Every plate with counters gives one counter. Point to each one."

**Problem 2** (all starts with three). 3 → 2-1 → 2-1 (stopped after 1 move); 2-1 → 2-1 (stopped before any move). The only other way is one counter on each of three plates, which was Problem 1, so there is no new way: the three ways are 3, 2-1 and 1-1-1, and every one of them ends at 2-1. Say: "We tried every way to put down three counters. Every way ends with towers 2 and 1." This is the whole proof for three counters. If a child proposes "one and two" as new, put 2-1 and 1-2 side by side on plates and ask whether the towers look different.

**Problem 3** (four on one plate). 4 → 3-1 → 2-2 → 2-1-1 → 3-1 → 2-2 → 2-1-1. Same pictures: after 1 and after 4 moves (3-1); after 2 and after 5 (2-2); after 3 and after 6 (2-1-1). It never stops changing; it goes round three pictures for ever. Ask: "If we made a hundred moves, what picture would we see? One of these three." Hint for finding pairs: "Look at the tallest tower in each picture."

**Problem 4** (one on each of four plates). 1-1-1-1 → 4 → 3-1 → 2-2 → 2-1-1. After 1 move it is the start of Problem 3 (four on one plate), so from then on it is the same run, round the same three pictures. Say: "Two different starts, and after one move they are the same. From then on they can never be different again, because the move always does the same thing to the same picture."

**Problem 5** (six on one plate). 6 → 5-1 → 4-2 → 3-2-1, then 3-2-1 again: three moves; towers 3, 2 and 1. Ask: "Four counters never stopped. Six counters did. Where?"

**Problem 6** (one on each of six plates). After one move: six on one plate, which is how Problem 5 started. It stops after 4 moves at 3-2-1, the same last picture; one move more than Problem 5, because the first move made Problem 5's start.

**Problem 7** (3-3, then 2-2-2). 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1: four moves. 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1: three moves (this is the run from the launch). The picture after 1 move in the first run is the start of the second run, so the second run is the first run with its first move cut off: one move fewer. Ask: "So far every start with six counters has ended at 3, 2, 1. Do you think every start does?" Do not answer yet; Problem 12 and the table above answer it.

**Problem 8** (guess the new pile). 2-2-2: 3 plates with counters, new pile 3 (giving 3-1-1-1); 4 plates, new pile 4 (4-2); 2 plates, new pile 2 (3-2-1); 3 plates, new pile 3 (3-2-1, unchanged). Write the pairs 3/3, 4/4, 2/2, 3/3. 3-3: 2 plates, new pile 2 (2-2-2); then 3/3 (3-1-1-1); 4/4 (4-2); 2/2 (3-2-1). The new pile always has exactly as many counters as there were plates with counters. Ask: "Why is it always the same number?" Expected: "because I took one from each plate." That sentence is the law of the game; you will use it in Problems 9, 10 and 15.

**Problem 9** (which arrangement stays still). 2-1: the 2 became 1, the 1 went away, and the new pile is 2 (two plates): 2-1 again, nothing changed. 3-2-1: the 3 became 2, the 2 became 1, the 1 went away, and the new pile has 3 counters because there were three plates: 3-2-1 again. Ask: "So which tower is the new one in the picture after the move?" (The tallest one.) "Why is it the tallest?" (Every old tower got shorter, and the new tower is as tall as the number of plates.)

**Problem 10** (every way with four; which never appears on the right). Five ways: 4; 3-1; 2-2; 2-1-1; 1-1-1-1. After one move: 4 → 3-1; 3-1 → 2-2; 2-2 → 2-1-1; 2-1-1 → 3-1; 1-1-1-1 → 4. No way stays the same. The only way that never appears on the right is 1-1-1-1; 3-1 appears twice. Hints for finding all the ways, in order: (1) "Start with all four on one plate. Take one off and put it somewhere else. Now what else can you do?" (2) "What is the tallest tower? Can it be 4? 3? 2? 1?" (3) The list by tallest tower: 4 (one way); 3 (only 3-1); 2 (2-2 or 2-1-1); 1 (1-1-1-1). Why 1-1-1-1 never appears after a move: the new pile would be a single counter, so there was only one plate with counters, holding all four, and that plate gives 3-1, not 1-1-1-1. Why nothing with four counters stays still: "we tried all five ways" is a complete answer at this age; the deeper reason (only staircases stay still, and 4 is not 1, 3, 6 or 10) is in section B7.

**Problem 11** (staircases). Counts 1, 3, 6, 10. On the big staircase the move takes the top counter off the towers of 4, 3, 2, 1, leaving 3, 2, 1 and nothing, and builds a new tower of 4 on the dotted circles: the towers are 4, 3, 2, 1 again, moved over by one column. Each staircase has one more tower than the one before: 2 more, then 3 more, then 4 more counters. Say: "These are the pictures that stay still: 2-1 with three counters, 3-2-1 with six, 4-3-2-1 with ten." Ask: "How many counters would the next staircase have?" (15: one more tower of 5.)

**Problem 12** (races). First race: 4-2 takes 1 move; 3-3 takes 4; 1-1-1-1-1-1 takes 4. Second race: 2-2-1-1 takes 6; 5-1 takes 2; 2-2-2 takes 3. Nothing beats 2-2-1-1: of all eleven ways to place six counters, it is the slowest (six moves), as the table above shows; children will try 4-1-1 (5 moves), 3-1-1-1 (2), 2-1-1-1-1 (3), 6 (3), 3-2-1 (0). When they have tried them all, say so: "You have now tried every one of the eleven ways, and every one ended at 3, 2, 1." The only start that takes exactly one move is 4-2 (3-2-1 itself takes none). Hint for the one-move start: "What must the picture look like one move before 3-2-1? The new pile is the tower of 2, so there were two plates before." Running the races: have all three children make their moves together on your count ("move one … move two …"), and stop each child when their picture no longer changes; write the number of moves on the scoreboard.

**Problem 13** (five counters; reserve). 5 → 4-1 → 3-2 → 2-2-1 → 3-1-1 → 3-2 → 2-2-1: after 2 moves it goes round three pictures (3-2, 2-2-1, 3-1-1) for ever; pictures after 2 and 5 moves are the same, after 3 and 6. 1-1-1-1-1 → 5 → 4-1 → 3-2 → 2-2-1: it joins the first run after one move (at "five on one plate"). Three counters stop; four go round; five go round; six stop.

**Problem 14** (ten on one plate; reserve). 10 → 9-1 → 8-2 → 7-2-1 → 6-3-1 → 5-3-2 → 4-3-2-1; six moves; the last picture is the big staircase and it stays still. One plate of three took 1 move, of six took 3, of ten took 6: the staircase numbers again.

**Problem 15** (which start came before; reserve). 1-1-1 → 3 (the only way). 6 → 5-1 and 2-1-1-1-1 → 5-1 (both). 4-2 → 3-2-1 (the only start other than 3-2-1 itself). Hint: "The new pile is one of the towers you see, and its height tells how many plates there were before. Which tower is the new one?" For 5-1: if the new pile is the 1, there was one plate holding all six; if the new pile is the 5, there were five plates: 2-1-1-1-1.

**If the table stalls.** A child who does not want to color: you color, the child moves and says the heights. A child who cannot sort the towers by height: let them color in plate order and sort the sizes yourself on the blank line. Restless children: go straight to Problem 12 (the races) and come back. **If the table finishes early:** Problems 13, 14, 15 in that order; then a guessing game: a child builds any start with six counters, everyone guesses how many moves it will take, then run it (use the table of eleven); then seven counters on one plate, with you writing the sizes: 7 → 6-1 → 5-2 → 4-2-1 → 3-3-1 → 3-2-2 → 3-2-1-1 → 4-2-1, which goes round four pictures for ever.

**For the share:** the K–1 children show the loop of Problem 3 (four counters go round and round) and the last pictures of Problems 5, 6, 7 (six counters always end at 3, 2, 1), and say the counts of the staircases, 1, 3, 6, 10.

## B4. Grades 2–3 table: order, answers, arguments, hints

Order and timing: Problems 1–8 are the core (about 52 minutes, more than the 42 minutes of table work, so plan as follows). Rough clock, with table work starting at 0:08: Problems 1–2 by 0:19, 3–4 by 0:30, 5 by 0:40, 6 by 0:48. Problems 7 and 8 are the explain step and should not be dropped: if the map (Problem 6) is not finished by 0:44, stop it there, state the law of Problem 7 orally in two minutes using the children's own strips, and spend the last eight minutes on Problem 8. If the table is slow earlier, give each child only two or three of the eleven starts in Problem 5 and pool the results. Problems 9–13 follow in order for a table that is ahead. Children run the moves with counters and write the arrangements; insist that the starting arrangement is rebuilt with counters before each run and that every box is written before the next move.

Watch for: writing an arrangement in the order the piles happen to lie instead of biggest first (then two boxes can look different while the piles are the same); forgetting that a pile of one vanishes; making the new pile from the counters of only some piles.

**Problem 1.** 6 → 5-1 → 4-2 → 3-2-1 → 3-2-1: 3 moves. 

**Problem 2.** 1-1-1-1-1-1 → 6 → 5-1 → 4-2 → 3-2-1 (4 moves); 5-1 → 4-2 → 3-2-1 (2); 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1 (4); 2-2-1-1 → 4-1-1 → 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1 (6). All stop at 3-2-1. Most moves: 2-2-1-1; fewest: 5-1. The arrangement in all five runs: 4-2 (5-1 is in three of them, 3-3 in two). Why 4-2 must be in every run: the last move before 3-2-1 must come from an arrangement that becomes 3-2-1, and 4-2 is the only such arrangement other than 3-2-1 itself (Problem 12 proves this). Also worth pointing out: the 3-3 run sits inside the 2-2-1-1 run, and the 6 run inside the all-ones run; once two runs share an arrangement they agree for ever, because the move is the same every time.

**Problem 3.** 4 → 3-1 → 2-2 → 2-1-1 → 3-1 → 2-2 → 2-1-1 → 3-1. First repeat: 3-1, after 3 moves. Three arrangements go round: 3-1, 2-2, 2-1-1. 1-1-1-1 → 4 → 3-1 → 2-2 → 2-1-1 and 2-2 → 2-1-1 → 3-1 → 2-2: the same loop. (All five arrangements of four counters end in this loop.)

**Problem 4.** 5 → 4-1 → 3-2 → 2-2-1 → 3-1-1 → 3-2: a loop of three (3-2, 2-2-1, 3-1-1) entered after 2 moves. 2-1-1-1 → 4-1 → 3-2 → 2-2-1 → 3-1-1 → 3-2: the same loop, after 2 moves. 3 → 2-1 → 2-1: stops after 1 move. Table: 3 R, 4 L, 5 L, 6 R. Ask: "Guess: does 7 stop or loop? Does 10?" (Problems 9 and 8 will tell: 7 loops, 10 stops.)

**Problem 5.** The eleven ways, listed by biggest pile: 6; 5-1; 4-2, 4-1-1; 3-3, 3-2-1, 3-1-1-1; 2-2-2, 2-2-1-1, 2-1-1-1-1; 1-1-1-1-1-1. Hint for completeness, in order: (1) "What is the biggest pile? Go down from 6 to 1." (2) "With biggest pile 4, the other two counters can be together or apart." (3) "With biggest pile 3, the other three counters: 3, 2-1 or 1-1-1." Moves to reach 3-2-1: 3-2-1: 0; 4-2: 1; 5-1: 2; 3-1-1-1: 2; 6: 3; 2-2-2: 3; 2-1-1-1-1: 3; 1-1-1-1-1-1: 4; 3-3: 4; 4-1-1: 5; 2-2-1-1: 6. New runs to write (the others are on Problems 1–2): 4-2 → 3-2-1; 4-1-1 → 3-3 → …; 3-2-1 → 3-2-1; 3-1-1-1 → 4-2 → 3-2-1; 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1; 2-1-1-1-1 → 5-1 → 4-2 → 3-2-1. Every start stops at 3-2-1: yes. Most moves: 2-2-1-1 (6). Exactly two moves: 5-1 and 3-1-1-1. Split the six new starts into two lots of three and give each lot to two children, so every run is done twice and checked; then have everyone copy the other lot's rows so that every child holds the complete table. Say when the table is filled: "This table is a proof. There are only eleven starts, and every one of them stops at 3-2-1. Nobody has to guess any more."

**Problem 6.** The finished map (bottom to top): level 0: 3-2-1 (with its loop arrow); level 1: 4-2; level 2: 5-1 (x = −4) and 3-1-1-1 (x = +4); level 3: 6 (x = −6) and 2-1-1-1-1 (x = −2), both into 5-1, and 2-2-2 (x = +4) into 3-1-1-1; level 4: 1-1-1-1-1-1 (x = −6) into 6, and 3-3 (x = +4) into 2-2-2; level 5: 4-1-1 into 3-3; level 6: 2-2-1-1 into 4-1-1. No arrow coming in: 2-2-1-1, 2-1-1-1-1, 1-1-1-1-1-1 (the top boxes). Two arrows coming in: 4-2 (from 5-1 and 3-1-1-1) and 5-1 (from 6 and 2-1-1-1-1); 3-2-1 as well if the loop arrow is counted (from 4-2 and from itself). Longest path: 6 arrows, from 2-2-1-1. Hints, in order: (1) "Which box must 4-2 be in? It is the only arrangement that becomes 3-2-1." (2) "Which two arrangements become 4-2?" (3) "Fill from the bottom up, one arrow at a time, using the table." Ask afterwards: "Why does the map have no separate pieces?" (Every start's run reaches 3-2-1, so every box is connected to the bottom box.)

**Problem 7.** In every row the number of piles equals the size of the new pile, because the new pile got exactly one counter from each pile. 4-4-2 (3 piles) → new pile 3, giving 3-3-3-1; (4 piles) → 4, giving 4-2-2-2; (4 piles) → 4, giving 4-3-1-1-1; (5 piles) → 5, giving 5-3-2; (3 piles) → 3, giving 4-3-2-1. Say the law in one sentence and have the children say it back: "The new pile is as big as the number of piles."

**Problem 8.** 3 became 2; 2 became 1; the pile of 1 vanished; the new pile has 3 counters (three piles): 3-2-1 again. Ten counters: 4-3-2-1 (check: 4, 3, 2, 1 become 3, 2, 1, nothing, and the new pile is 4). Four counters: 4 → 3-1; 3-1 → 2-2; 2-2 → 2-1-1; 2-1-1 → 3-1; 1-1-1-1 → 4; none stays. Why there is none: "I tried all five ways" is a complete argument (Problem 3 and this table list them). The argument that also explains 3-2-1 and 4-3-2-1, to build with the children who are ready: if a picture stays the same, the biggest pile after the move must be the new pile, because every old pile got smaller; so the biggest pile equals the number of piles (the law). The old biggest pile lost one counter and is now the second biggest; the old second biggest is now the third; and so on, down to a pile of 1 that vanished and was replaced by the new pile. So the piles are p, p−1, …, 2, 1: a staircase, and the number of counters is 1 + 2 + … + p. Four is not 1, 3, 6 or 10, so no arrangement of four stays still. (The step "the old biggest is now the second biggest" is where a careful adult fills in the matching argument written out in B7; third graders can take it as seen on the counters.) Hints, in order: (1) "After the move, is any old pile as big as it was?" (2) "So which pile is the biggest one now?" (3) "How big is the new pile?" (the number of piles) (4) "Where did the old biggest pile go?" (5) "Keep going down."

**Problem 9.** 7 → 6-1 → 5-2 → 4-2-1 → 3-3-1 → 3-2-2 → 3-2-1-1 → 4-2-1: a loop of four (4-2-1, 3-3-1, 3-2-2, 3-2-1-1), entered after 3 moves. 4-3 → 3-2-2 → 3-2-1-1 → 4-2-1 → 3-3-1 → 3-2-2: the same loop, after 1 move. 2-2-2-1 → 4-1-1-1 → 4-3 → 3-2-2 → …: the same loop, after 3 moves. (Every one of the fifteen arrangements of seven reaches this loop; the longest way in is from 1-1-1-1-1-1-1, four moves.) Point out: each loop arrangement is 3-2-1 with one more counter somewhere: on the 3 (4-2-1), on the 2 (3-3-1), on the 1 (3-2-2), or as a new pile (3-2-1-1).

**Problem 10.** 8 → 7-1 → 6-2 → 5-2-1 → 4-3-1 → 3-3-2 → 3-2-2-1 → 4-2-1-1 → 4-3-1: a loop of four (4-3-1, 3-3-2, 3-2-2-1, 4-2-1-1), entered after 4 moves. 5-3 → 4-2-2 → 3-3-1-1 → 4-2-2: a loop of two (4-2-2, 3-3-1-1), entered after 1 move. 4-4 → 3-3-2 → …: the loop of four, after 1 move. 2-2-2-2 → 4-1-1-1-1 → 5-3 → 4-2-2 → 3-3-1-1 → 4-2-2: the loop of two, after 3 moves. Two different loops. This is the first number of counters where different starts end in different places; of the 22 arrangements of eight, 15 reach the loop of four and 7 reach the loop of two (the seven: 4-2-2, 3-3-1-1, 5-3, 6-1-1, 4-1-1-1-1, 2-2-1-1-1-1, 2-2-2-2). Say: "So the answer to 'does every start end in the same place?' is yes for 3, 4, 5, 6 and 7 counters, and no for 8."

**Problem 11.** Counts 1, 3, 6, 10, 15. Nine: 9 → 8-1 → 7-2 → 6-2-1 → 5-3-1 → 4-3-2 → 3-3-2-1 → 4-2-2-1 → 4-3-1-1 → 4-3-2, a loop of four entered after 5 moves. Table: R for 1, 3, 6, 10; L for 2, 4, 5, 7, 8, 9. (1: a single counter is a pile of 1 that vanishes and comes back as the new pile: unchanged. 2 → 1-1 → 2: a loop of two.) Any try for 7, 8 or 9 changes, for example 4-2-1 → 3-3-1, 4-3-1 → 3-3-2, 4-3-2 → 3-3-2-1; the reason is Problem 8's argument: only staircases stay still, and 7, 8, 9 are not staircase numbers. Ask: "Which numbers between 10 and 30 will get an R?" (15, 21, 28.)

**Problem 12.** Parents of 4-2: 5-1 and 3-1-1-1. Parents of 5-1: 6 and 2-1-1-1-1. Parents of 4-3-2-1: 5-3-2 and 4-3-2-1 itself. Why 2-2-1-1 has no parent: the new pile is one of the piles, so it has at most 2 counters, so before the move there were at most 2 piles; a move from at most 2 piles leaves at most 3 piles (the old ones, minus any that vanished, plus the new one); 2-2-1-1 has four piles. The general method for parents, if a child wants it: choose which pile is the new one; its size m is the number of piles before the move; take that pile away, give one counter back to every other pile, and add single counters until there are m piles; if there are already more than m other piles, that choice is impossible. For 4-3-2-1: new pile 4 gives 4-3-2 plus one single, 4-3-2-1 itself; new pile 3 gives 5-3-2; new pile 2 or 1 is impossible (three other piles remain, more than 2 or 1).

**Problem 13.** One pile of 3: 1 move; of 6: 3 moves; of 10: 6 moves (10 → 9-1 → 8-2 → 7-2-1 → 6-3-1 → 5-3-2 → 4-3-2-1). The numbers 1, 3, 6 are the staircase numbers, so the prediction is 10, and it is right: 15 → 14-1 → 13-2 → 12-2-1 → 11-3-1 → 10-3-2 → 9-3-2-1 → 8-4-2-1 → 7-4-3-1 → 6-4-3-2 → 5-4-3-2-1, ten moves. Point out on the run: the piles other than the biggest one form 1, then 2-1, then 3-2-1, then 4-3-2-1 after 1, 3, 6 and 10 moves; the reason is in section B7.

**If the table stalls.** On Problem 5, give each child two starts and let the table pool the results. On Problem 6, fill the bottom three boxes together, then let them continue. On Problem 8, accept "we tried all five" and move on; come back to the argument at the share if there is time. **If the table finishes early:** after Problem 13, run every two-pile start with ten counters: 9-1 takes 5 moves, 8-2 takes 4, 7-3 takes 8, 6-4 takes 2, 5-5 takes 6 (the most equal start is not the fastest); then look for a start with ten counters that takes more than ten moves: 6-2-1-1, 5-2-2-1 and 5-2-1-1-1 take 11; 3-3-2-1-1, 3-2-2-2-1 and 3-2-2-1-1-1 take 12, and 12 is the most any start of ten takes (checked over all 42 starts). Example: 3-3-2-1-1 → 5-2-2-1 → 4-4-1-1 → 4-3-3 → 3-3-2-2 → 4-2-2-1-1 → 5-3-1-1 → 4-4-2 → 3-3-3-1 → 4-2-2-2 → 4-3-1-1-1 → 5-3-2 → 4-3-2-1.

**For the share:** this table shows the map of six (every start flows to 3-2-1) and, if reached, the two loops of eight.

## B5. Grades 4–5 table: order, answers, arguments, hints

Order and timing: Problems 1–6 are the core (about 49 minutes; the three children share the fifteen starts of Problem 5, five each); then 7–13 in order. Rough clock, with table work starting at 0:08: Problems 1–2 by 0:24, 3–4 by 0:36, 5 by 0:46, 6 by 0:50 at the latest. If Problem 5 is running long, skip drawing the map of seven: its three questions can be answered from the strips, and the point of Problem 6 (two loops for eight) must be reached. Problems 4, 8, 9 and 12 are where the mathematician pushes for an argument; the others are doing and recording.

**Problem 1.** 6 → 5-1 → 4-2 → 3-2-1 (3 moves); 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1 (4); 4-1-1 → 3-3 → 2-2-2 → 3-1-1-1 → 4-2 → 3-2-1 (5); 2-2-1-1 → 4-1-1 → 3-3 → … → 3-2-1 (6). All stop at 3-2-1, and each run contains the previous one. Table for 2-2-1-1: 2-2-1-1 (4 piles) → new pile 4; 4-1-1 (3) → 3; 3-3 (2) → 2; 2-2-2 (3) → 3; 3-1-1-1 (4) → 4; 4-2 (2) → 2. The number of piles equals the size of the new pile, always: the new pile has exactly one counter from each pile. Have the children say this law aloud; it is used in Problems 4, 8, 9, 12.

**Problem 2.** The eleven ways by biggest pile: 6; 5-1; 4-2, 4-1-1; 3-3, 3-2-1, 3-1-1-1; 2-2-2, 2-2-1-1, 2-1-1-1-1; 1-1-1-1-1-1 (1 + 1 + 2 + 3 + 3 + 1 = 11). Moves: 6 → 5-1; 5-1 → 4-2; 4-2 → 3-2-1; 4-1-1 → 3-3; 3-3 → 2-2-2; 3-2-1 → 3-2-1; 3-1-1-1 → 4-2; 2-2-2 → 3-1-1-1; 2-2-1-1 → 4-1-1; 2-1-1-1-1 → 5-1; 1-1-1-1-1-1 → 6. The map is one tree: above 3-2-1 sits 4-2; above 4-2 sit 5-1 and 3-1-1-1; above 5-1 sit 6 and 2-1-1-1-1; above 6 sits 1-1-1-1-1-1; above 3-1-1-1 the chain 2-2-2, 3-3, 4-1-1, 2-2-1-1. Every path leads to 3-2-1. Say: "That is a complete proof that every arrangement of six counters ends at 3-2-1: there are only eleven, and here they all are." Hints: (1) "Who becomes 3-2-1? Only 4-2. Put it first." (2) "Now who becomes 4-2?"

**Problem 3.** Moves to 3-2-1: 3-2-1: 0; 4-2: 1; 5-1: 2; 3-1-1-1: 2; 6: 3; 2-2-2: 3; 2-1-1-1-1: 3; 1-1-1-1-1-1: 4; 3-3: 4; 4-1-1: 5; 2-2-1-1: 6. Most: 2-2-1-1. Exactly three moves: three arrangements (6, 2-2-2, 2-1-1-1-1). No arrow in: 2-2-1-1, 2-1-1-1-1, 1-1-1-1-1-1. Two arrows in: 4-2, 5-1, and 3-2-1 (from 4-2 and its own loop).

**Problem 4.** The move on 3-2-1: 3 → 2, 2 → 1, 1 vanishes, new pile 3 (three piles). The argument, and the answers expected: no old pile is as big as it was (each lost a counter, and the piles of 1 are gone). So the biggest pile of the new picture cannot be an old pile; it must be the new pile. The new pile's size is the number of piles (the law), so in an arrangement that does not change, the biggest pile equals the number of piles, call it p. Next: the new picture has the new pile p plus every old pile reduced by one, the old piles of 1 having vanished; since the number of piles is still p and one pile was added, exactly one old pile vanished, so there was exactly one pile of 1. Set the new pile p aside from the new picture and the old biggest pile p aside from the old picture; what is left must match: on the new side, every old pile except the 1, each one counter smaller; on the old side, every old pile except the biggest. So the second biggest old pile is the biggest minus one, the third is the second minus one, and so on, down to the smallest, which is the 1. The arrangement is p, p − 1, …, 2, 1, a staircase, with 1 + 2 + … + p counters. Numbers from 1 to 30: 1, 3, 6, 10, 15, 21, 28. Hints, in order: (1) "Can the biggest pile after the move be one of the old piles?" (2) "How big is the new pile?" (3) "Where is the old biggest pile now? Is anything else that big?" (4) "And the old second biggest?" (5) "What happens at the bottom?" The children need only produce the chain "biggest = number of piles; then one less, one less, …, down to 1"; the mathematician supplies the matching step if asked why the second biggest cannot be anything else. The written proof is in B7.

**Problem 5.** The fifteen ways by biggest pile: 7; 6-1; 5-2, 5-1-1; 4-3, 4-2-1, 4-1-1-1; 3-3-1, 3-2-2, 3-2-1-1, 3-1-1-1-1; 2-2-2-1, 2-2-1-1-1, 2-1-1-1-1-1; 1-1-1-1-1-1-1. One loop of four: 4-2-1 → 3-3-1 → 3-2-2 → 3-2-1-1 → 4-2-1. Runs: 7 → 6-1 → 5-2 → 4-2-1 (3 moves in); 1-1-1-1-1-1-1 → 7 (4 moves, the farthest); 2-1-1-1-1-1 → 6-1 (3); 3-1-1-1-1 → 5-2 (2); 5-1-1 → 4-3 → 3-2-2 (2); 2-2-1-1-1 → 5-1-1 (3); 4-1-1-1 → 4-3 (2); 2-2-2-1 → 4-1-1-1 (3); 4-3 → 3-2-2 (1); 5-2 → 4-2-1 (1); 6-1 → 5-2 (2). Every arrangement of seven reaches the loop. No arrow in: 3-1-1-1-1, 2-2-2-1, 2-2-1-1-1, 2-1-1-1-1-1, 1-1-1-1-1-1-1. The map is a tree hanging on a ring of four instead of on a point. Hint for the map: "Draw the loop first, as a ring, then hang each run on the place where it enters."

**Problem 6.** 8 → 7-1 → 6-2 → 5-2-1 → 4-3-1 → 3-3-2 → 3-2-2-1 → 4-2-1-1 → 4-3-1: loop A of four (4-3-1, 3-3-2, 3-2-2-1, 4-2-1-1), entered after 4 moves. 5-3 → 4-2-2 → 3-3-1-1 → 4-2-2: loop B of two, after 1 move. 4-4 → 3-3-2: loop A after 1 move. 2-2-2-2 → 4-1-1-1-1 → 5-3 → 4-2-2: loop B after 3 moves. 6-1-1 → 5-3 → 4-2-2: loop B after 2 moves. Two different loops, of lengths 4 and 2. This breaks the pattern of 3 to 7 counters: where you end depends on where you start.

**Problem 7.** The 22 ways by biggest pile: 8; 7-1; 6-2, 6-1-1; 5-3, 5-2-1, 5-1-1-1; 4-4, 4-3-1, 4-2-2, 4-2-1-1, 4-1-1-1-1; 3-3-2, 3-3-1-1, 3-2-2-1, 3-2-1-1-1, 3-1-1-1-1-1; 2-2-2-2, 2-2-2-1-1, 2-2-1-1-1-1, 2-1-1-1-1-1-1; 1-1-1-1-1-1-1-1. Loop B (of two) is reached by seven starts: 4-2-2 and 3-3-1-1 (0 moves), 5-3 (1), 6-1-1 (2), 4-1-1-1-1 (2), 2-2-2-2 (3), 2-2-1-1-1-1 (3). Loop A (of four) is reached by the other fifteen: 4-3-1, 3-3-2, 3-2-2-1, 4-2-1-1 (0), 5-2-1 (1), 4-4 (1), 6-2 (2), 5-1-1-1 (2), 3-2-1-1-1 (2), 7-1 (3), 3-1-1-1-1-1 (3), 2-2-2-1-1 (3), 8 (4), 2-1-1-1-1-1-1 (4), 1-1-1-1-1-1-1-1 (5). Runs not yet on the strips: 5-1-1-1 → 4-4; 3-2-1-1-1 → 5-2-1; 2-2-2-1-1 → 5-1-1-1; 2-2-1-1-1-1 → 6-1-1; 3-1-1-1-1-1 → 6-2; 2-1-1-1-1-1-1 → 7-1; 1-1-1-1-1-1-1-1 → 8; 7-1 → 6-2; 4-1-1-1-1 → 5-3.

**Problem 8.** Parents of 5-3-2: 6-4, 6-3-1, 4-3-1-1-1. Parents of 4-4: 5-1-1-1 only. Parents of 2-2-2-2: none. The method: the new pile is one of the piles of the child arrangement; choose which. Its size m is the number of piles before the move. Remove that pile, give one counter back to each remaining pile, and add single counters until there are m piles. If more than m piles remain after removing the new pile, that choice is impossible. For 5-3-2: new pile 5 gives 4-3 plus three singles, 4-3-1-1-1; new pile 3 gives 6-3 with three piles needed, so 6-3-1; new pile 2 gives 6-4. For 4-4: new pile 4 gives 5 plus three singles, 5-1-1-1 (both fours give the same). For 2-2-2-2: new pile 2 leaves three piles, more than 2, impossible. Check every answer by building it and making the move. Hints: (1) "The new pile is one of the piles you see. Try each one." (2) "If the new pile is the 3, how many piles were there before?" (3) "Undo the move: give every other pile its counter back."

**Problem 9.** No parent, six counters: 2-2-1-1 (biggest 2, 4 piles), 2-1-1-1-1 (2, 5), 1-1-1-1-1-1 (1, 6). Seven: 3-1-1-1-1 (3, 5), 2-2-2-1 (2, 4), 2-2-1-1-1 (2, 5), 2-1-1-1-1-1 (2, 6), 1-1-1-1-1-1-1 (1, 7). Rule: an arrangement has no parent exactly when its biggest pile is at most the number of piles minus 2 (equivalently: it has a parent exactly when some pile is at least the number of piles minus 1). Why: a move from m piles makes a pile of size m and leaves at most m other piles, so the result has at most m + 1 piles and contains a pile of size m: some pile is at least (number of piles) − 1. Conversely, if a pile of size m is at least (number of piles) − 1, the method of Problem 8 builds a parent. Eight counters, no parent (seven of them): 3-2-1-1-1, 3-1-1-1-1-1, 2-2-2-2, 2-2-2-1-1, 2-2-1-1-1-1, 2-1-1-1-1-1-1, 1-1-1-1-1-1-1-1. Checks: for 3-2-1-1-1, new pile 3 leaves four piles, too many; new pile 2 or 1 leaves four; so no parent. For 2-2-2-2, as in Problem 8. Counts of parentless arrangements for 3, 4, …, 10 counters: 1, 1, 2, 3, 5, 7, 10, 14.

**Problem 10.** 10 → 9-1 → 8-2 → 7-2-1 → 6-3-1 → 5-3-2 → 4-3-2-1: 6 moves. 5-5 → 4-4-2 → 3-3-3-1 → 4-2-2-2 → 4-3-1-1-1 → 5-3-2 → 4-3-2-1: 6. 7-3 → 6-2-2 → 5-3-1-1 → 4-4-2 → …: 8. 4-4-1-1 → 4-3-3 → 3-3-2-2 → 4-2-2-1-1 → 5-3-1-1 → 4-4-2 → …: 10. Twelve moves: 3-3-2-1-1, 3-2-2-2-1 and 3-2-2-1-1-1, and no start of ten counters takes more (checked over all 42). Example: 3-3-2-1-1 → 5-2-2-1 → 4-4-1-1 → 4-3-3 → 3-3-2-2 → 4-2-2-1-1 → 5-3-1-1 → 4-4-2 → 3-3-3-1 → 4-2-2-2 → 4-3-1-1-1 → 5-3-2 → 4-3-2-1. Hints for the search: (1) "A slow start must feed into a slow run: what comes before 4-4-1-1?" (its only parent is 5-2-2-1, which takes 11 moves) (2) "And before that?" (the only parent of 5-2-2-1 is 3-3-2-1-1, which takes 12 and has no parent itself). Eleven-move starts: 6-2-1-1, 5-2-2-1, 5-2-1-1-1; the three twelve-move starts are their parents (3-2-2-1-1-1 → 6-2-1-1, 3-3-2-1-1 → 5-2-2-1, 3-2-2-2-1 → 5-2-1-1-1) and have no parents themselves. The slowest starts for 3, 6, 10 and 15 counters take 2, 6, 12 and 20 moves.

**Problem 11.** 3 → 2-1 → 2-1: 1 move. Prediction: 10 (the pattern 1, 3, 6 is the staircase numbers). Run: 15 → 14-1 → 13-2 → 12-2-1 → 11-3-1 → 10-3-2 → 9-3-2-1 → 8-4-2-1 → 7-4-3-1 → 6-4-3-2 → 5-4-3-2-1: 10 moves. The small piles form 1, 2-1, 3-2-1, 4-3-2-1 after 1, 3, 6, 10 moves: the small piles play their own game in which the new pile gets one extra counter (from the big pile), and that game builds one more diagonal of the staircase every time; meanwhile the big pile loses exactly one counter per move. Fifteen ones: 11 moves, because the first move makes one pile of fifteen and then the run above follows. The proof is in B7.

**Problem 12.** 9 → 8-1 → 7-2 → 6-2-1 → 5-3-1 → 4-3-2 → 3-3-2-1 → 4-2-2-1 → 4-3-1-1 → 4-3-2: a loop of four entered after 5 moves. The loops as staircase plus extras (an extra written +1 on the step it sits on, and a fourth position for "a new pile of 1"):

- Seven: 4-2-1 = (3+1)-2-1; 3-3-1 = 3-(2+1)-1; 3-2-2 = 3-2-(1+1); 3-2-1-1 = 3-2-1-(0+1). One extra, which moves one step to the right each move and, from the last position, comes back to the first: four positions, so a loop of four.
- Eight, loop A: 4-3-1 = (3+1)-(2+1)-1; 3-3-2 = 3-(2+1)-(1+1); 3-2-2-1 = 3-2-(1+1)-(0+1); 4-2-1-1 = (3+1)-2-1-(0+1). Two extras side by side, moving together round four positions: a loop of four. Loop B: 4-2-2 = (3+1)-2-(1+1); 3-3-1-1 = 3-(2+1)-1-(0+1). Two extras opposite each other: after two moves the pattern is back, a loop of two.
- Nine: 4-3-2 = (3+1)-(2+1)-(1+1); 3-3-2-1 = 3-(2+1)-(1+1)-(0+1); 4-2-2-1 = (3+1)-2-(1+1)-(0+1); 4-3-1-1 = (3+1)-(2+1)-1-(0+1). Three extras, one empty position going round: a loop of four.

It works for every loop arrangement. Why the extras move one step to the right: the new pile becomes the new first step (it has 3 counters, plus 1 if there was a pile of 1 made of an extra); the old first step (3 or 4) becomes the second step (2 or 3), keeping its extra; the old second becomes the third; the old third step (1 or 2) becomes nothing or a pile of 1, keeping its extra. So each extra shifts one position, and the extra at the last position reappears at the first. The loop length is the number of moves until the pattern of extras comes back: a single extra or a single gap needs four moves; two adjacent extras need four; two opposite extras need two. Prediction for twelve counters (4-3-2-1 with two extras on five positions): two loops, both of length five, one with the extras side by side and one with the extras one apart; runs: 12 → 11-1 → 10-2 → 9-2-1 → 8-3-1 → 7-3-2 → 6-3-2-1 → 5-4-2-1 (the loop 5-4-2-1, 4-4-3-1, 4-3-3-2, 4-3-2-2-1, 5-3-2-1-1), and 4-4-4 → 3-3-3-3 → 4-2-2-2-2 → 5-3-1-1-1-1 → 6-4-2 → 5-3-3-1 (the loop 5-3-3-1, 4-4-2-2, 4-3-3-1-1, 5-3-2-2, 4-4-2-1-1). Offer this as the next challenge if the table gets here.

**Problem 13.** Start: left A-2-3 (top to bottom), middle 4-5, right 6. After 1 move: left A-4-6, middle 2-3, right 5. After 2: left A-2-5, middle 4-6, right 3. After 3: left A-4-3, middle 2-5, right 6. After 4: left A-2-6, middle 4-3, right 5. After 5: left A-4-5, middle 2-6, right 3. After 6: left A-2-3, middle 4-5, right 6, the start. The ace never moves. Back after 2 moves: 2 and 4 (and the ace). Back after 3: 3, 5, 6. Every card back after 6 moves. A card's period is (its pile's position from the left) + (its depth in the pile) − 1: the ace 1; the 2 and the 4 have period 2; the 3, 5, 6 have period 3. Ten cards: after 1 move the piles are A-5-8-10, 2-3-4, 6-7, 9; the ace is fixed; 2 and 5 have period 2; 3, 6, 8 period 3; 4, 7, 9, 10 period 4; all ten back after 12 moves (the least common multiple of 1, 2, 3, 4). With fifteen cards it would be 60 moves.

**If the table stalls.** On Problem 2, place 4-2 and its two parents for them. On Problem 4, accept the chain "biggest pile = number of piles, then one less each time" and let the mathematician fill the gap about the vanishing pile of 1. On Problem 5, if listing fifteen is slow, give the list and let them run and map. **If the table finishes early:** after Problem 13, the twelve-counter prediction above; then the backward tree of ten: start at 4-3-2-1, find its parent 5-3-2, then the parents of 5-3-2 (6-4, 6-3-1, 4-3-1-1-1), then their parents (6-4 ← 7-1-1-1, 5-1-1-1-1-1; 6-3-1 ← 7-2-1, 4-2-1-1-1-1; 4-3-1-1-1 ← 4-2-2-2), and so on, as far as it goes: all 42 arrangements of ten are reached, the longest chains have 12 arrows and end at 3-3-2-1-1, 3-2-2-2-1 and 3-2-2-1-1-1.

**For the share:** this table explains, with counters, why only staircases stay still (Problem 4), and shows the cards of Problem 13 if it got there.

## B6. The share (eight minutes) and closing

Each table shows one thing, two minutes each: K–1 shows the four-counter loop and the last pictures of the six-counter runs, and says the staircase counts 1, 3, 6, 10; grades 2–3 hold up the map of six and, if they have it, the two loops of eight; grades 4–5 give the argument that a picture that does not change must be a staircase.

The organizer closes in one minute: "Three, six and ten counters always stop, and they stop at a staircase: 2-1, 3-2-1, 4-3-2-1. Four, five, seven, eight and nine never stop; they go round loops, and with eight counters there are two different loops. The numbers that stop are the staircase numbers 1, 3, 6, 10, 15, 21, and so on. That every start with a staircase number of counters ends at the staircase is a theorem proved in 1982 by Jørgen Brandt; you proved it today for 3, 6 and 10 by trying every start."

## B7. The mathematics behind the session (for the two mathematicians)

**Setting.** An arrangement of n counters is a partition of n. The move (Bulgarian solitaire) is a map on the finite set of partitions of n, so every orbit is eventually periodic: it ends at a fixed point or in a cycle. The one law every argument uses: the new pile has as many counters as there were piles.

**Fixed points are exactly the staircases** (Problems K–1 9, 2–3 8, 4–5 4). Let λ = (λ₁ ≥ … ≥ λ_p) be unchanged by the move. After the move the piles are λᵢ − 1 for each λᵢ ≥ 2, plus the new pile p. Every old pile shrank, so the largest pile afterwards, which is again λ₁, must be the new pile: λ₁ = p. The number of piles afterwards is (number of λᵢ ≥ 2) + 1 and must be p, so exactly one λᵢ equals 1: λ_p = 1 and λ_{p−1} ≥ 2. Remove one pile of size p from the old arrangement and the new pile p from the new one; what remains must agree as multisets: {λ₁ − 1, …, λ_{p−1} − 1} = {λ₂, …, λ_p}. Sorted, λ₁ − 1 = λ₂, λ₂ − 1 = λ₃, …, λ_{p−1} − 1 = λ_p = 1. Hence λ = (p, p − 1, …, 1). Conversely every staircase is fixed. So a fixed point exists exactly when n is triangular, and then it is unique. Verified by brute force for n ≤ 30.

**Parents and Garden of Eden states** (Problems 2–3 12, 4–5 8 and 9). μ is the image of some λ if and only if μ has a part m ≥ ℓ(μ) − 1, where ℓ is the number of parts; the parents are obtained, for each such distinct part size m, by removing one part m, adding 1 to every other part, and adding m − (ℓ(μ) − 1) parts equal to 1. Proof: if λ has m parts, the move creates a part m and leaves at most m other parts, so ℓ(μ) ≤ m + 1; conversely the construction gives a λ with exactly m parts whose image is μ, and every parent arises this way, since the new part is one of the parts of μ and its size fixes ℓ(λ). Consequently μ has no parent exactly when its largest part is at most ℓ(μ) − 2. Counts of parentless partitions for n = 3, …, 12: 1, 1, 2, 3, 5, 7, 10, 14, 20, 27; they agree with p(n − 3) up to n = 8 and fall behind from n = 9 (10 against 11). Both rules verified against brute force for n ≤ 18.

**Brandt's theorem** (cited; verified by computer for n ≤ 20). J. Brandt, "Cycles of partitions", Proc. Amer. Math. Soc. 85 (1982): if n = T_k = k(k + 1)/2, every start reaches the staircase (k, …, 1); if n = T_k + r with 0 < r ≤ k, every start ends in a cycle, and the cycle states are exactly the C(k + 1, r) partitions obtained from (k, k − 1, …, 1, 0) by adding 1 to r of its k + 1 entries. The part provable at the table (Problem 4–5 12): write such a state as (k + ε₀, k − 1 + ε₁, …, 1 + ε_{k−1}, ε_k) with ε ∈ {0, 1}^{k+1}, Σε = r, the piles listed newest first (this order is also weakly decreasing, so it is the order the children write). It has k + ε_k piles. The move sends it to (k + ε_k, k − 1 + ε₀, …, 1 + ε_{k−2}, ε_{k−1}): the same form with ε cyclically shifted one place. So this family is closed under the move, the move acts on it as a rotation of the necklace ε, cycle lengths divide k + 1, and the number of cycles is the number of binary necklaces of length k + 1 with r ones. There is a single cycle exactly when r ∈ {0, 1, k}: n = 2, 4, 5, 7, 9, 11, 14, 16, 20 have one loop, and n = 8, 12, 13, 17, 18, 19 have several (8: necklaces 1100 and 1010, loops of 4 and 2; 12 and 13: two loops of 5; 17: loops of 6, 6, 3; 18: loops of 6, 6, 6, 2). The hard half of the theorem, that every start reaches this family, is what the exhaustive maps establish for n ≤ 8 and n = 10 in the session; the general proof is in Brandt's paper and in E. Akin and M. Davis, "Bulgarian solitaire", Amer. Math. Monthly 92 (1985).

**Young diagrams and anti-diagonals** (Problem 4–5 13). Draw a partition as rows of cells, newest pile on top, the first counter of each row at the left. The move removes the first cell of every row and lays those cells down as a new top row, the cell from row i in column i. A cell in row i, column j goes to row i + 1, column j − 1 if j ≥ 2, and to row 1, column i if j = 1; either way i + j is unchanged, so every cell stays on its anti-diagonal. At the staircase the first k anti-diagonals are full and the move rotates the d cells of anti-diagonal d cyclically; a card in pile i (from the left) at depth j has period i + j − 1, and all cards return after lcm(1, …, k) moves: 6 for k = 3, 12 for k = 4, 60 for k = 5. The extras of a cycle state are cells on anti-diagonal k + 1, and the necklace rotation above is the rotation of that diagonal.

**How long it takes.** For n = T_k the number of moves from any start is at most k² − k (K. Igusa, "Solution of the Bulgarian solitaire conjecture", Math. Mag. 58 (1985); G. Etienne, "Tableaux de Young et solitaire bulgare", J. Combin. Theory Ser. A 57 (1991)). The bound is attained for k = 2, …, 6: slowest starts 1-1-1 (2 moves), 2-2-1-1 (6), 3-3-2-1-1 and two others (12), sixteen starts with 15 counters (20), and 30 moves for 21 counters. The distribution for 10 counters, moves: number of starts, is 0:1, 1:1, 2:3, 3:5, 4:5, 5:3, 6:4, 7:4, 8:4, 9:3, 10:3, 11:3, 12:3.

**The single pile** (Problems 2–3 13, 4–5 11). From one pile of N counters, after m moves the state is {N − m} ∪ τ_m, where τ₀ is empty and τ_{m+1} = {x − 1 : x ∈ τ_m, x ≥ 2} ∪ {|τ_m| + 1}, as long as N − m stays the largest pile: the big pile loses one counter, the small piles lose one each, and the new pile has one counter from the big pile plus one from each small pile. In this "tail game", starting from the j-staircase (j, …, 1), the next j + 1 moves give (j + 1, j − 1, …, 1), (j + 1, j, j − 2, …, 1), …, (j + 1, j, …, 2), (j + 1, j, …, 1): the (j + 1)-th diagonal fills one cell per move. So τ reaches the (k − 1)-staircase after 1 + 2 + … + (k − 1) = T_{k−1} moves, and at that moment the state is {T_k − T_{k−1}} ∪ (k − 1, …, 1) = (k, k − 1, …, 1). It cannot have rested earlier, because before that the big pile exceeds k. Hence one pile of T_k takes exactly T_{k−1} moves: 1, 3, 6, 10, 15 for k = 2, …, 6, and all-ones takes one more.

**Where it leads.** Partitions and Young diagrams; the conjugate description (in the conjugate partition the move deletes the largest part m and adds 1 to the next m parts, the "shift" map of J. R. Griggs and C.-C. Ho, "The cycling of partitions and compositions under repeated shifts", Adv. in Appl. Math. 21 (1998)); enumeration of Garden of Eden partitions (B. Hopkins and J. A. Sellers, "Exact enumeration of Garden of Eden partitions", Integers 7 (2007)); the survey B. Hopkins, "30 years of Bulgarian solitaire", College Math. J. 43 (2012); variants (Austrian solitaire in Akin and Davis; Montreal solitaire, J. Cannings and J. Haigh, J. Combin. Theory Ser. A 60 (1992)); random Bulgarian solitaire (S. Popov, Random Structures Algorithms 27 (2005)); the popular account is Martin Gardner's column in Scientific American, August 1983. Undergraduate topics touched: finite dynamical systems (transients, cycles, basins), necklaces and Burnside counting, integer partitions and generating functions, orbits of permutations and least common multiples. The bibliographic details are quoted from memory and were not checked against the originals; every mathematical statement above was checked by computation.

---

# Part C. Verification

`curator-check.py` (this directory) recomputes by brute force every run, count, map, parent list, loop, fixed point and card period printed in Parts A and B, asserts each one, and writes `curator-check.txt`, which ends with `ALL CHECKS PASSED`. Sections used: §1–2 K–1 runs and complete lists; §3 the map of six; §4 the law; §5 fixed points to n = 30; §6 rest/loop for 1..10; §7 seven; §8 eight; §9 parents and the rules (n ≤ 18); §10 ten; §11 single piles and 15; §12 nine, twelve and the necklace rotation; §13 cards; §13b bounds and counts quoted only in B7. The bank's `bs.py` / `bs-results.txt` agree on every shared item.
