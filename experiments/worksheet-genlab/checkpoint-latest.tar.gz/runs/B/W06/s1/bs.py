#!/usr/bin/env python3
"""Verification program for the Week 1 (Bulgarian solitaire) problem bank.

Run:  python3 bs.py > bs-results.txt

Everything quoted as an "answer" in bank.md is computed here by brute force
(partitions of n, one move = take one counter from every pile and make a new
pile out of them).  Nothing below relies on the theorems; the theorems are
checked against the brute-force results where they are mentioned.
"""
from itertools import count
from math import lcm
from functools import reduce

# ---------------------------------------------------------------- basics

def partitions(n, maxpart=None):
    """All partitions of n as tuples in weakly decreasing order."""
    if maxpart is None:
        maxpart = n
    if n == 0:
        yield ()
        return
    for first in range(min(n, maxpart), 0, -1):
        for rest in partitions(n - first, first):
            yield (first,) + rest

def move(p):
    """One Bulgarian-solitaire move."""
    new = [x - 1 for x in p if x > 1] + [len(p)]
    return tuple(sorted(new, reverse=True))

def fmt(p):
    return "-".join(str(x) for x in p) if p else "(empty)"

def run(p, steps):
    """Trajectory: list of states, starting state included, `steps` moves."""
    out = [p]
    for _ in range(steps):
        p = move(p)
        out.append(p)
    return out

def orbit_info(p):
    """(transient_length, cycle_length, trajectory up to and including the
    first repeated state).  transient_length = number of moves before the
    first state that is later repeated (i.e. moves needed to enter the cycle)."""
    seen = {}
    traj = []
    while p not in seen:
        seen[p] = len(traj)
        traj.append(p)
        p = move(p)
    start = seen[p]
    return start, len(traj) - start, traj

def analyse(n):
    parts = list(partitions(n))
    nxt = {p: move(p) for p in parts}
    trans = {}
    cyc_len = {}
    for p in parts:
        t, c, _ = orbit_info(p)
        trans[p] = t
        cyc_len[p] = c
    recurrent = sorted({p for p in parts if trans[p] == 0}, reverse=True)
    # split recurrent states into cycles
    cycles = []
    left = set(recurrent)
    while left:
        p = max(left)
        cyc = []
        q = p
        while q not in cyc:
            cyc.append(q)
            q = nxt[q]
        cycles.append(cyc)
        left -= set(cyc)
    preds = {p: [] for p in parts}
    for p in parts:
        preds[nxt[p]].append(p)
    goe = [p for p in parts if not preds[p]]
    return dict(n=n, parts=parts, nxt=nxt, trans=trans, cyc_len=cyc_len,
                cycles=cycles, preds=preds, goe=goe)

def tri(k):
    return k * (k + 1) // 2

# ------------------------------------------------- theorems to cross-check

def predecessor_rule(p):
    """Predecessors predicted by the rule: for each distinct part m with
    m >= len(p)-1, remove one copy of m, add 1 to every other part, and add
    m-(len(p)-1) new piles of size 1."""
    out = set()
    L = len(p)
    for m in set(p):
        if m >= L - 1:
            q = list(p)
            q.remove(m)
            q = [x + 1 for x in q] + [1] * (m - (L - 1))
            out.add(tuple(sorted(q, reverse=True)))
    return out

def brandt_cycle_states(n):
    """Brandt's description of the recurrent states for T_k <= n < T_{k+1}:
    take the staircase (k, k-1, ..., 1, 0) and add 1 to exactly r = n - T_k
    of its k+1 entries."""
    k = 0
    while tri(k + 1) <= n:
        k += 1
    r = n - tri(k)
    base = list(range(k, -1, -1))  # k, k-1, ..., 1, 0
    from itertools import combinations
    out = set()
    for S in combinations(range(k + 1), r):
        q = [base[i] + (1 if i in S else 0) for i in range(k + 1)]
        out.add(tuple(sorted([x for x in q if x > 0], reverse=True)))
    return out

# ---------------------------------------------------------- card tracking

def card_move(piles):
    """Piles are lists (top card first), ordered newest pile first.
    Take the top card of every pile; the new pile is stacked so that the
    card from the newest (leftmost, largest at the staircase) pile is on top."""
    tops = [pile[0] for pile in piles]
    rest = [pile[1:] for pile in piles if len(pile) > 1]
    return [tops] + rest

# ------------------------------------------------------------------ report

def section(title):
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)

def main():
    section("A. Number of arrangements (partitions) of n counters")
    for n in range(1, 16):
        print(f"n={n:2d}: p(n)={len(list(partitions(n)))}")

    section("B. Full state maps for small n (state -> next state, moves to reach the loop/fixed point, parents)")
    for n in range(1, 11):
        A = analyse(n)
        print(f"\n--- n = {n}: {len(A['parts'])} arrangements; "
              f"{len(A['cycles'])} loop(s) of length(s) {[len(c) for c in A['cycles']]}; "
              f"max moves to loop = {max(A['trans'].values())}; "
              f"Garden-of-Eden (no parent) states: {[fmt(g) for g in A['goe']]}")
        for c in A['cycles']:
            print("   loop: " + " -> ".join(fmt(q) for q in c) + " -> " + fmt(c[0]))
        for p in sorted(A['parts'], key=lambda q: (A['trans'][q], q)):
            print(f"   {fmt(p):>14} -> {fmt(A['nxt'][p]):<14} moves-to-loop={A['trans'][p]:2d}  "
                  f"parents={[fmt(q) for q in A['preds'][p]] or 'NONE'}")

    section("C. Distribution of 'moves to reach the staircase' for triangular n, and the k^2-k bound")
    for k in range(1, 7):
        n = tri(k)
        A = analyse(n)
        assert len(A['cycles']) == 1 and len(A['cycles'][0]) == 1, "not a unique fixed point?"
        fp = A['cycles'][0][0]
        assert fp == tuple(range(k, 0, -1)), fp
        mx = max(A['trans'].values())
        slow = [fmt(p) for p in A['parts'] if A['trans'][p] == mx]
        dist = {}
        for p in A['parts']:
            dist[A['trans'][p]] = dist.get(A['trans'][p], 0) + 1
        print(f"n={n:2d} (k={k}): every one of the {len(A['parts'])} starts reaches {fmt(fp)}; "
              f"max moves = {mx} (bound k^2-k = {k*k-k}); slowest start(s): {slow}")
        print(f"        how many starts need m moves: {dict(sorted(dist.items()))}")
        print(f"        Garden-of-Eden states ({len(A['goe'])}): {[fmt(g) for g in A['goe']]}")

    section("D. Non-triangular n: loops (Brandt's description checked against brute force)")
    for n in range(1, 21):
        A = analyse(n)
        rec = {p for p in A['parts'] if A['trans'][p] == 0}
        assert rec == brandt_cycle_states(n), n
        mx = max(A['trans'].values())
        print(f"n={n:2d}: {len(A['parts']):3d} starts, loops: {[len(c) for c in A['cycles']]}, "
              f"loop states total {len(rec)}, max moves to reach a loop {mx}, "
              f"Garden-of-Eden count {len(A['goe'])}")

    section("E. Predecessor rule and Garden-of-Eden rule checked against brute force (n <= 20)")
    for n in range(1, 21):
        A = analyse(n)
        for p in A['parts']:
            assert set(A['preds'][p]) == predecessor_rule(p), (n, p)
            is_goe = (p[0] <= len(p) - 2)
            assert is_goe == (not A['preds'][p]), (n, p)
    print("OK: parents of P are exactly: pick a pile of size m >= (#piles - 1), remove it, add one counter to")
    print("    every other pile, and add m - (#piles - 1) new single-counter piles.")
    print("OK: P has no parent  <=>  biggest pile <= (#piles) - 2.")

    section("F. Specific trajectories quoted in the bank")
    quoted = [
        (1,1,1), (3,), (2,1),
        (4,), (1,1,1,1), (2,2), (2,1,1), (3,1),
        (5,), (1,1,1,1,1), (2,1,1,1), (4,1), (3,2), (2,2,1), (3,1,1),
        (6,), (1,1,1,1,1,1), (2,2,2), (3,3), (4,2), (5,1), (4,1,1), (2,2,1,1), (3,1,1,1), (2,1,1,1,1), (3,2,1),
        (7,), (4,3), (2,2,2,1), (1,)*7, (3,2,2),
        (8,), (4,4), (1,)*8, (5,3), (6,2), (4,2,2), (4,3,1), (3,3,2), (2,2,2,2), (6,1,1),
        (9,), (5,4), (3,3,3),
        (10,), (1,)*10, (5,5), (4,3,2,1), (5,3,2), (6,4), (2,2,2,2,2), (3,3,3,1), (3,3,2,2), (4,4,2), (3,3,2,1,1), (4,2,2,2), (2,2,2,2,1,1), (3,2,2,2,1), (4,4,1,1),
        (12,), (6,6), (4,4,4), (3,3,3,3),
        (15,), (1,)*15, (5,5,5), (8,7), (6,5,4),
        (21,),
    ]
    for p in quoted:
        t, c, traj = orbit_info(p)
        print(f"{fmt(p):>20} (n={sum(p):2d}): " + " -> ".join(fmt(q) for q in traj)
              + f"  [{t} moves to reach the loop; loop length {c}]")

    section("G. Single pile of a triangular number: moves to reach the staircase")
    for k in range(1, 8):
        n = tri(k)
        t, c, traj = orbit_info((n,))
        print(f"k={k}, n={n:2d}: (single pile) takes {t} moves; all-ones takes {orbit_info((1,)*n)[0]} moves; "
              f"bound k^2-k = {k*k-k}")

    section("H. Which arrangements do not change under a move (fixed points), n <= 25")
    for n in range(1, 26):
        fixed = [fmt(p) for p in partitions(n) if move(p) == p]
        print(f"n={n:2d}: fixed arrangements: {fixed or 'none'}")

    section("I. Arrangements with exactly two piles (n=4..10) and where they go")
    for n in range(4, 11):
        two = [p for p in partitions(n) if len(p) == 2]
        print(f"n={n}: {len(two)} two-pile starts: " + ", ".join(fmt(p) for p in two))

    section("J. Card tracking at the staircase (cards keep identity; new pile stacked newest-pile card on top)")
    for k in range(2, 6):
        # newest pile first = largest pile first at the staircase
        cards = iter(count(1))
        piles = [[next(cards) for _ in range(size)] for size in range(k, 0, -1)]
        start = [list(p) for p in piles]
        pos0 = {}
        for i, pile in enumerate(piles):
            for j, cd in enumerate(pile):
                pos0[cd] = (i + 1, j + 1)
        cur = [list(p) for p in piles]
        periods = {}
        for step in range(1, lcm(*range(1, k + 1)) + 1):
            cur = card_move(cur)
            assert [len(p) for p in cur] == list(range(k, 0, -1))
            for i, pile in enumerate(cur):
                for j, cd in enumerate(pile):
                    if (i + 1, j + 1) == pos0[cd] and cd not in periods:
                        periods[cd] = step
        L = lcm(*range(1, k + 1))
        # verify period equals diagonal index i+j-1 of the starting cell
        for cd, (i, j) in pos0.items():
            assert periods[cd] == i + j - 1, (k, cd, periods[cd], i + j - 1)
        print(f"k={k} (n={tri(k)}): each card returns to its place after (pile number + height - 1) moves; "
              f"all cards back after lcm(1..{k}) = {L} moves. Periods by card: {periods}")
        print(f"      start layout (pile of {k} first, top card first): {start}")
        print(f"      after 1 move: {card_move([list(p) for p in start])}")

    section("K. Number of piles: how it changes (illustration for the 'new pile = number of piles' law)")
    for p in [(6,), (2,2,2), (3,3), (2,2,1,1), (10,), (4,4,2)]:
        traj = run(p, 8)
        print(f"{fmt(p):>10}: piles per state {[len(q) for q in traj]}, sizes of the pile created by each move "
              f"{[len(q) for q in traj[:-1]]}")

    section("L. n = 8: which starts end in which loop")
    A = analyse(8)
    for c in A['cycles']:
        members = [p for p in A['parts'] if A['cyc_len'][p] == len(c)]
        print(f"loop of length {len(c)} ({' -> '.join(fmt(q) for q in c)}): reached by {len(members)} starts: "
              + ", ".join(f"{fmt(p)}({A['trans'][p]})" for p in sorted(members, key=lambda q: (A['trans'][q], q))))
    print("(number in brackets = moves needed to enter the loop)")

    section("M. Loop states for n = 4..14 written as 'staircase + extra counters'")
    for n in range(4, 15):
        A = analyse(n)
        k = 0
        while tri(k + 1) <= n:
            k += 1
        r = n - tri(k)
        for c in A['cycles']:
            print(f"n={n:2d} = {tri(k)} + {r}: staircase {fmt(tuple(range(k,0,-1)))} plus {r} extra counter(s); "
                  f"loop of length {len(c)}: " + " -> ".join(fmt(q) for q in c))

    section("N. More trajectories quoted in the bank")
    for p in [(11,), (13,), (14,), (16,), (7,7), (6,6,2), (5,5,4), (4,4,4,2), (9,), (8,1), (6,3), (2,2,2,2,1),
              (3,3,3,1), (4,4,1,1), (7,3), (8,2), (9,1), (5,5), (6,4), (4,2,2,1,1), (3,2,2,1,1,1), (2,2,1,1,1,1,1,1),
              (3,3,1,1,1,1), (5,3,1,1), (6,2,2), (4,3,3), (5,4,1), (4,3,1,1,1), (4,2,1,1,1,1), (7,1,1,1), (5,1,1,1,1,1),
              (2,2,2,1,1,1,1), (3,2,1,1,1,1,1)]:
        t, c, traj = orbit_info(p)
        print(f"{fmt(p):>18} (n={sum(p):2d}): " + " -> ".join(fmt(q) for q in traj)
              + f"  [{t} moves to reach the loop; loop length {c}]")

    section("O. Garden-of-Eden counts compared with partition numbers p(n-3) (a pattern that breaks at n=9)")
    pn = {n: len(list(partitions(n))) for n in range(0, 20)}
    for n in range(3, 15):
        A = analyse(n)
        print(f"n={n:2d}: Garden-of-Eden states {len(A['goe']):3d}   p(n-3) = {pn[n-3]:3d}   "
              f"{'same' if len(A['goe']) == pn[n-3] else 'DIFFERENT'}")

    section("P. Single pile of n (not only triangular): moves to reach the loop, and the loop length")
    for n in range(1, 22):
        t, c, traj = orbit_info((n,))
        print(f"n={n:2d}: single pile takes {t:2d} moves, loop length {c}; all-ones takes {orbit_info((1,)*n)[0]:2d} moves")

    section("Q. Every arrangement of 6 counters written in tower form (columns = piles), for the K-1 picture check")
    for p in sorted(partitions(6), reverse=True):
        print(f"{fmt(p):>12}: piles {len(p)}, tallest {p[0]}")

if __name__ == "__main__":
    main()
