# Review of the Week 1 packet (The piles game / Bulgarian solitaire)

Scope: read all four `.tex` sources, rendered every page of the four PDFs (`pdftoppm -r 60`, plus 110 dpi spot checks), recompiled all four files in a scratch folder (0 errors, 0 overfull/underfull boxes), and re-derived the mathematics by program. Every one of the 58 run chains written in the facilitator guide and all 120 rows of the appendix tables (successor, moves, loop label, Garden-of-Eden star) are correct, as are the cycle counts (8: loops of 4 and 2; 12 and 13: two loops of 5; 17: 6, 6, 3), the Garden-of-Eden counts 1, 1, 2, 3, 5, 7, 10, 14, 20, 27, 37, 49, 66 for n = 3..15, the 45/32 split for 12 counters, the 17- and 20-move runs for 15 counters, the 15- and 30-move runs for 21, and the k^2 - k extremal starts. The proof sketch (diagonal potential, hole/cell rotation) is sound. The problems below are about pacing, answer leakage, a few student-page wordings and two layout defects, not about the mathematics.

Ordered most important first. Each item says what to change and where.

---

## 1. Every student packet is two to three times too long for 40 minutes of table work, and the core path is not marked

Counting what the pages ask the children to produce:

- K–1 (two kindergartners, a first grader, one non-mathematician adult): 14 problems, 58 film-strip boxes to draw (each box = dots plus rings, up to 10 dots), plus three stair-builds. The guide's own schedule (Problems 1–2 in 7 min, 3–5 in 9 min, 6–9 in 12 min) asks five-year-olds to make and draw a move every 40 seconds. The guide says "12 and 13 are the important ones" but places them last, in "the rest", where they will be cut.
- Grades 2–3 (four third graders): 15 problems, 91 table rows, plus 5 single moves (P6), 11 single moves (P13), and 22 full runs (P14, about 80 moves).
- Grades 4–5 (three children): 17 problems, about 260 moves to run and record (P6 alone is 22 runs, ~70 moves; P17 is 37 moves), plus three written arguments (P7, P10, P13). The schedule gives "4–6 (10 min)" to P4, P5 and all 22 runs of P6, which cannot happen.

What to change (student pages and the facilitator "Order and timing" paragraphs together):

- K–1: core sequence P1 (append P2's stairs test to the end of P1 and delete P2), P3, P6, P7, P11, P12; then the table (current P10, with rows 3, 4, 6, 10 only and an optional "other numbers" row). Move P4, P5, P8, P9, P13, P14 to a last page headed "More games" and say in the guide that they are for a child who is ahead. Renumber. New timing: P1 5 min, P3 6, P6 5, P7 5, P11 6, P12 8 (adult scribes, see item 6), table 3.
- Grades 2–3: core P1, P2, P3 (split across pairs as the guide already suggests), P4, P5, P6, P8, P9, then the map (current P13) immediately after P9, then P10 (predict 10), then P12 (two loops for 8). Move P7, P11, P14, P15 to a "More games" page. The guide already says "if the table is far behind at 25 minutes, skip 11 and 12 and go to the map"; make that the default order instead of a rescue.
- Grades 4–5: core P1, P2, P3 (rewritten, item 3), P4, P5, P7, P8, P9, P10, P12, P13, and P11 reduced to the prediction only (drop its 3 3 3 3 3 run, which 2–3 and K–1 already do). Move P6, P14, P15, P16, P17 to "More games"; keep the guide's note that P14 and P15 are the best of them. P6 can stay as the first extra with the guide's hint "stop when you reach an arrangement someone has already run" printed on the student page.
- Budget the launch at 5 minutes, not 2: everyone makes 4 1 1 and two moves, and the organizer checks tables. 4 + 5 + 40 + 5 = 54 min still fits.

## 2. The recording tables and the instructions give away the answers

Two mechanisms, both systematic:

(a) Every run table has exactly (number of moves + 1) rows, so the row count answers "how many moves" and "does it stop" before the child moves a counter. Worst cases: 4–5 P17 (18 rows for 5 5 5, 21 rows for 4 4 3 2 1 1, i.e. the answers 17 and 20 are printed); 4–5 P14 ("find a start with more than 10 moves" sits above two 13-row tables, so the maximum 12 is printed); 4–5 P8 (7, 7 and 5 rows) and 2–3 P11 (5 and 7 rows) tell which start is fastest before it is run; 2–3 P4's "Moves until it stopped" column can be filled by counting rows. Also, tables with exactly the right number of rows leave no room for the one wrong row the guide says is common.

Fix: give every table in a problem the same number of rows, at least two more than the longest correct run it will hold. Concretely: 2–3 P1/P2/P3 all 8 rows; P5, P7 8; P8 10; P10, P11 9; P12 both 10; P15 8. 4–5 P1, P2 all 8; P4, P5 all 10; P7 both 8; P8 all 9; P9 all 9; P11 8; P14 both 14 with the sentence "you may need every row, or far fewer"; P15, P16 8; P17 both 24. Add "if you run out of rows, continue on a blank sheet" once per packet.

(b) The stopping instruction alternates between "until a row is exactly the same as the row above it" (which presupposes the game stops) and "until a row repeats an earlier row" (which presupposes a loop). So 2–3 P10 asks for a prediction "will 10 counters stop, or go round?" and then instructs "write each row until a row is the same as the row above it"; 4–5 P8 tells the children 10 stops one problem before P9 asks them whether it does; K–1 P12 likewise before the P10 table. Fix: one neutral instruction everywhere, "Keep making moves until a row is the same as an earlier row. If it is the same as the row just above it, the game has stopped." (K–1: "until a box looks the same as an earlier box"). Affected: 2–3 P1, P2, P3, P10, P11, P15; 4–5 P1, P2, P8, P11; K–1 P2, P6, P7, P8, P9, P12. Keep the explicit "stop/loop" phrasing only in the first problem of each packet, where it is teaching the vocabulary.

## 3. Grades 4–5 Problem 3 hands the children the complete list of 11 arrangements, then the guide tells the adult "a complete list is a proof"

The completeness idea is the heart of the organizer's theorem ("does every start end in the same place?"), and this table is the one that is supposed to "argue". Giving them the list makes the proof something they are told. Replace the printed list with: "Find every way to arrange 6 counters in piles. Write each one once, biggest pile first; start with the biggest possible first pile and work down. How do you know you have found them all? (There are 11.) Then write next to each one how many moves it takes to stop." Keep the two-column layout but leave the left column blank (11 ruled blanks). The guide's hint ladder should add: "What is the biggest pile you can have? With a biggest pile of 4, what can the rest be?" Problem 7 already asks them to list the 7 arrangements of 5 themselves, so this is consistent; P6's list of 22 for 8 counters can stay printed.

## 4. Student-page wordings that mislead or are undefined

- 4–5 P12, last sentence: "Then find one that turns into 2, 2, 2, 2." None exists (the guide's answer is "nothing"). Change to "Then try to find one that turns into 2, 2, 2, 2. If you cannot, explain why not."
- 4–5 P16: "Find a start outside your list that ends in the second loop" — "second" is undefined on the student page. Say "the loop that contains 5, 3, 3, 1".
- 2–3 P13: the child is told to draw an arrow from each picture to its result, but K's result is K. Add: "If the result is the same picture, draw a little arrow that loops back to it."
- 2–3 P1 repeats the launch game (4 1 1) that every child has just played through. Either reword it as "Write down the game from the launch: start 4, 1, 1 and one row per move" or change the launch to stop after two moves ("we will find out the rest at your tables").
- 2–3 P9 asks the child to run 1 1 1 "and find out" but gives no table; add a 4-row table or say "with counters only".
- K–1 P10 table has no row for 8 counters although P14 plays 8; add the row (or drop P14 per item 1).
- Two notations for the same object on one page: arrangements are written "3 2 1" but staircases "3–2–1" (4–5 P11, P15, P16; 2–3 P10 says "towers of 3, 2 and 1"). Use one form; "3, 2, 1" with commas is the safest, and it also removes the ambiguity of space-separated sizes once a pile reaches 10 ("10 3 2" in the guide's 15- and 21-counter runs reads as 1 0 3 2 to a parent).

## 5. Layout defects seen in the rendered pages

- 4–5 page 4, Problem 7: the column heading "Piles, biggest first" overflows the right border of both run tables (pile column 1.3 in). Fix: `\RunTable[0.3]{4}{5}{1.5}` and `\RunTable[0.3]{5}{6}{1.5}`, and shrink the `\RuledBox` beside them to 2.0 in; or make `\RunTable` print just "Piles" when the width argument is below 1.45.
- 4–5 page 8, Problem 15: the six 0.6 in blanks inside the 3.3 in `\Note` wrap as 2 + 4. Put them on two deliberate lines of three, or widen the note to 3.6 in and the blanks to 0.5 in.
- K–1 page 2, Problem 4: the text says "the small stairs picture ... Try the big stairs picture", but the page shows the big (3–2–1) stairs above and the small (2–1) stairs below-right of the film strip, neither labelled, and the small one's floor line sits on the strip's baseline. Label both mats ("small stairs", "big stairs") with a `\node` under each floor line, put the ring mat on its own line, and put the two stairs side by side on the next line, small one on the left, above the strip (drop the `\FramesX` extra-drawing argument).
- Minor: 2–3 pages 1, 2, 5 and 4–5 page 2 are half empty while page 8 of 4–5 is packed to the footer. This resolves itself once item 1 moves the extras to their own pages.

## 6. The K–1 recording method does not work for the longer games

The child is asked to draw "one dot per counter and a ring around each pile" in 1.1 in boxes, and to decide whether two boxes "look the same". For 10 counters (P12: 9 1, 8 2, 7 2 1, ...) and 7 counters (P13) a kindergartner cannot draw nine dots in a ring legibly, and comparing two such drawings is unreliable; the guide's hint 3 ("count the piles in each box, then the counters in the biggest pile") only works if the drawings are accurate. The guide's fallback ("write the pile sizes in the box yourself") should be the default for any game with more than 6 counters, stated on the student page under the strip ("Grown-up writes the pile sizes under each box") and in the K–1 section of the guide. For the games of 3–6 counters keep the drawing but make the boxes larger: 1.6 in boxes, four per row (`\Frames` with pitch 1.75 in and `mod(\k,4)`), so a ring of six dots is drawable. Also print a short number line "1 2 3 4 5 6" under the "moves" circle of P7 (and P8–P9 if kept) so the child can count boxes to the first stairs rather than recount from memory.

## 7. Facilitator guide: readability for the parent at K–1, and a few wording slips

- The K–1 answers are written as `1 1 1 → 3 → 2 1 → 2 1` and `2 2 1 1 → 4 1 1 → 3 3 → ...`. The parent is the one adult who will read these under time pressure. In the K–1 section, write each state with commas, or better draw each run as a row of tiny tower pictures using the existing `\State{0.1in}{...}` macro (it is already defined in the file and unused there). In the other sections at least use commas (see item 4) so sizes of 10 or more are unambiguous.
- "During the share, the two mathematicians should each visit the other tables for a minute" (Adults and tables): visiting during a 5-minute share is not possible; say "around the 30-minute mark" instead.
- The share asks grades 4–5 to present "the prediction for 11 counters" (P15), which under item 1 becomes an extra; change it to "why no arrangement of 8 counters can stand still, and the complete list of 11 arrangements of 6".
- US circle, British spellings: "colour" (line 133), "neighbouring" (271, 272), "minimised" (313), "generalisations" (327).
- "Printed packets, one per child: K–1 (7 pages), grades 2–3 (8 pages), grades 4–5 (9 pages)" must be updated after item 1.

## 8. Smaller points, in page order

- K–1 P1: "Point to the boxes that show the same piles" is the right neutral form; use it as the model for the rest of the packet (item 2b).
- K–1 P2 duplicates boxes 1–2 of P1 exactly; merge (item 1).
- 2–3 P6 and P13: say "arrangement" and "picture" for the same thing within one problem; pick one ("picture" is fine for this table).
- 4–5 P9: "using all your runs so far" is good; add "(for 8, list both loops)" so the third column is used as intended.
- 4–5 P13: the rule the children are meant to find is "biggest pile is at least (number of piles) minus 1"; the student page could end with "Check your rule on every row of the 8-counter list in Problem 6" so the rule is tested against more than eight cases.
- Guide, "Answers, K–1" P11 and the share: with 15 counters a child cannot keep the 3-, 6- and 10-stairs on the table at once (19 counters), yet the share asks K–1 to show "the three stairs they built". Either give K–1 20 counters each (60 in all; the total still fits "about 180") or say in the share paragraph that the three children build one staircase each.
- Each of the four sources carries the same 100-line block of drawing macros, most of them unused in that file (the facilitator file uses none of the picture macros; the 2–3 and 4–5 files use none of the K–1 film-strip macros). Harmless for compiling, but if the rewriter edits a macro it must be edited in all four places; moving the block into a fifth `\input` file (allowed by the brief) would remove that trap.

## What is right and should not be touched

The mathematics (student answers, appendix tables, the Brandt/necklace statement, the proof sketch, the Igusa–Etienne bound and its extremal starts, the Garden-of-Eden characterization and counts) is all correct. The 2–3 map of the 11 arrangements of 6 is laid out so that every arrow joins adjacent cells and nothing crosses; keep that layout. The hint ladders, the stall/finish-early plans and the appendix tables are exactly what three adults need at the table. The launch script (only the move, nothing about stairs or loops) is right. All four files compile cleanly to US Letter with no overfull boxes.
