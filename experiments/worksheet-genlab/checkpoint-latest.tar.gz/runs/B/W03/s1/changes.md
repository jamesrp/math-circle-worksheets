# Changes to the Week 1 packet (rewriter stage)

The previous version is preserved in `before-rewrite/`. All four files rebuild with
`pdflatex -interaction=nonstopmode` with 0 errors and 0 overfull/underfull boxes; every
rendered page was inspected. The mathematics was re-derived by a script (fixed points, cycle
structure for 3–17 counters, Garden-of-Eden counts, the 45/32 split for 12, the k²−k extremal
starts, every run quoted in the guide, and the appendix tables) before anything was printed.

## Review item 1 (length, core path) — accepted

- K–1: core is now Problems 1–7 (old P1 with P2's stairs test folded in; old P3, P6, P7, P11,
  P12; then the table with rows 3, 4, 6, 10 and two blank rows). Old P4, P5, P8, P9, P13, P14
  became Problems 8–13 on their own pages. Guide timing: 5, 6, 5, 5, 6, 8, 3 minutes.
- Grades 2–3: core is Problems 1–11 (old 1–6, 8, 9, then the map (old 13), then old 10 and 12).
  Old P7, P11, P14, P15 became Problems 12–15 on the last two pages. The guide's old rescue
  ("skip 11 and 12 and go to the map") is now the default order.
- Grades 4–5: core is Problems 1–12; old P6, P14–P17 became Problems 13–17 on the last three
  pages, old P6 first with the "stop when you reach an arrangement someone has already run" hint
  printed. Old P11 is reduced to the prediction (plus building the next stairs); its 3, 3, 3, 3, 3
  run is in the guide's answer and in the 2–3 and K–1 extras.
- Launch budgeted at 5 minutes: 4 + 5 + 40 + 5 = 54; the organizer checks every table after each
  of the two moves, then stops ("what happens next you find out at your tables").
- Modified rather than followed literally: no page is headed "More games". The brief forbids
  section headings and labels such as "Bonus"/"Go further" on student pages, so the extras simply
  continue the numbering on fresh pages and the guide (materials list and each table section)
  says exactly where the core ends and what the extras are for.
- Modified: the 4–5 core order is 1, 2, 3 (list of 11), 4 (4- and 5-counter loops, pigeonhole),
  5–6 (8 counters), 7 (10 counters), 8 (fixed points), 9 (table 3–10), 10 (prediction), 11 (undo),
  12 (Garden of Eden). The pigeonhole problem moved ahead of the 8-counter pair so loops are met
  on the smallest case first and the "list all 7 arrangements of 5" sits next to "list all 11 of 6";
  the fixed-point problem moved directly after the 10-counter runs that discover 4, 3, 2, 1. This
  also lets the core fit six pages without splitting a problem across pages.

## Review item 2 (answer leakage) — accepted

- Every run table now has at least two rows more than its longest correct run, and all tables in
  one problem have the same count: 2–3 P1–P3 8 rows, P5 8, P7 10, P8 5, P10 9, P11 10, P12 8,
  P13 9, P15 8; 4–5 P1–P2 8, P4 8, P5 10, P6 8, P7 9, P9 9, P14 14 ("you may need every row, or
  far fewer"), P15–P16 8 (fixed 6-move runs), P17 24. "If you run out of rows, continue on a
  blank sheet" appears once per packet (2–3 P1, 4–5 P1). K–1 strips with an open-ended
  instruction have spare boxes where that costs no extra row.
- One neutral stopping instruction everywhere after the first problem of each packet: "Keep making
  moves until a row is the same as an earlier row. If it is the same as the row just above it, the
  game has stopped" (K–1: "until a box looks the same as an earlier box"). Blanks that said
  "Moves until it stopped" now say "What happened / after how many moves" (2–3 P10, P13, P15;
  4–5 P5, P7), and 2–3 P4's summary table has a "Stopped, or went round?" column. The explicit
  stop vocabulary stays only in Problem 1 of each packet.

## Review item 3 (4–5 Problem 3) — accepted

The printed list of 11 is replaced by 11 ruled blanks ("start with the biggest possible first pile
and work down"), the question "How do you know you have found them all?" with answer lines, the
"(There are 11.)" check, a moves blank per arrangement, and the question whether every start ends
at the same arrangement. The guide gives the case-by-biggest-pile count (1+1+2+3+3+1) and a
three-step hint ladder. The list of 22 for 8 counters stays printed (now in Problem 13).

## Review item 4 (wordings) — all accepted

"Try to find one that turns into 2, 2, 2, 2; if you cannot, explain why not" (4–5 P11); "the loop
that contains 5, 3, 3, 1" (4–5 P16); the K-to-K loop arrow instruction (2–3 P9); the launch now
stops after two moves and 2–3 P1 says "like in the launch"; 2–3 P8 has a 5-row table for 1, 1, 1;
the K–1 table has blank rows for 5, 7 and 8 (each extra problem says to fill one); one notation
everywhere, "3, 2, 1" with commas, on all student pages, in the guide and in the appendix tables.

## Review item 5 (layout) — accepted

4–5 P4 (old P7) uses 1.5 in pile columns and a 2.0 in ruled box, and `\RunTable` now prints just
"Piles" when the column is narrower than 1.45 in; 4–5 P15's six blanks are on two deliberate lines
of three in a 3.6 in note; K–1 P8 (old P4) has the ring mat on its own line and the two stairs
mats side by side, labelled "small stairs" and "big stairs", above the strip.

## Review item 6 (K–1 recording) — accepted, with one wording change

Boxes are 1.6 in, four per row (`\FramesCore`, pitch 1.75 in). For games with more than 6
counters (Problems 6, 12, 13) the page says "say the sizes of your piles out loud, biggest first;
your grown-up writes the sizes in the box", and the guide's K–1 section makes this the default.
The sentence is addressed to the child, not the adult, because the brief forbids instructions to
the adult on student pages. A number line 1–7 sits under the moves circle (Problems 4, 10, 11).
Consequence: the K–1 packet is 12 pages (core 6), one problem per page, because a two-row strip
of 1.6 in boxes plus the placing mat fills a 14 pt page; the guide's page counts are updated.

## Review item 7 (guide readability) — accepted

K–1 answers are drawn as rows of tiny tower pictures (`\K`, `\A`, `\Krun`, 0.1 in pitch) for every
run, including the finish-early games; every other run in the guide uses commas; "around the
30-minute mark"; the share asks 4–5 for the no-fixed-point argument and the complete list of 11;
color, neighboring, minimized, generalizations; page counts and the core/extra split are in the
materials list.

## Review item 8 (smaller points) — accepted

K–1 P1's neutral "point to the boxes that show the same piles" is the model; old K–1 P2 merged
into P1; "picture" throughout 2–3 P6 and P9; "(For 8, list both loops.)" in 4–5 P9; "Check your
rule on every row of the list of 22 in Problem 13" in 4–5 P12, with the guide naming the seven
rows the rule marks; K–1 children get 20 counters each (60; about 190 in all) so the three stairs
can stand together for the share; the drawing macros now live in one `\input` file,
`week-macros.tex`, used by all four sources (the only per-file macros are `\st`, `\K`, `\A`,
`\Krun` in the guide).

## Rejected or not done

Nothing in the review was rejected outright. Two suggestions were modified as described above
(no "More games" heading; the adult-scribe sentence phrased to the child), and the 4–5 core order
differs from the review's list by the two swaps explained under item 1. The K–1 10-counter strip
(Problem 6) has exactly the 7 boxes the run needs, with no spare, because an eighth box would add
a whole row and push the table of Problem 7 onto its own page; at K–1 the box count is not a
leak the child can read, and the adult holds the answer anyway.

## Other small changes

2–3 P11 and 4–5 P5 ask "did it stop, or go round?" before asking about loops; 4–5 P10 asks the
children to build the next stairs and count before predicting; the guide's 2–3 answer for P10
mentions the common "9 is next" guess; the guide's stall plans name the problems that can be
dropped under the new numbering.
