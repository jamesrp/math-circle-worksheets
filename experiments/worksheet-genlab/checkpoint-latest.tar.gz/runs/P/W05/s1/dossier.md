# Week 1 dossier: jumping-peg games (peg solitaire and Conway's soldiers)

Prepared for the writer of the student pages and the facilitator guide. Every number in this file was produced by `solitaire_data.py` in this directory (`python3 solitaire_data.py`, about 8 seconds; add the argument `C20` for the five-minute search that finds the 20-soldier army). Section 3 reprints the tables the guide can use.

**Conventions used throughout.** A board is a set of cells. The only move is a *jump*: a peg moves in a straight line (left, right, up or down, never diagonally) over an orthogonally adjacent peg into the empty cell immediately beyond it, and the jumped peg is removed. "Solvable" means: can be reduced to a single peg, anywhere on the board. Strips have cells numbered 1..n from left to right; "hole h" means every cell except h holds a peg. Rectangles use (row, column), row 1 at the top, column 1 at the left; "(1,3)>(1,2)>(1,1)" means the peg on (1,3) jumps over (1,2) into (1,1). For soldiers, rows are counted by height above the line (row 1 is the first row above it, row 0 the row just below it, row -1 the next one down) and columns by offset from the target's column, so the target for "row 3" is (3,0).

---

## 1. The real questions

**(a) Existence / reachability.** Can this board be reduced to one peg? Can a peg reach that cell? Undergraduate form: reachability in the finite state graph of the game; Conway's soldiers asks it on an infinite board. Elementary form: do it with counters and record what happened. The strips 1x4 and 1x6 (from the right holes), the 3x4 rectangle (from its long sides) and rows 1-4 of the soldiers' board all have solutions a child can find.

**(b) Impossibility with a certificate.** When the answer is "never", how can anyone be sure without trying every line of play? Two certificates run through this session.

*Colouring (parity) invariants.* Colour the cells of a strip red, blue, green, red, blue, green, ... Any three consecutive cells carry all three colours, so a jump changes each colour count by exactly one and the three parities flip together. A single peg is one odd count and two even ones. Hence: if the three counts all have the same parity, one peg is unreachable; otherwise the last peg must stand on the colour whose count has the odd-one-out parity. On a square grid the same works with the two diagonal colourings (r+c) mod 3 and (r-c) mod 3, because a horizontal or vertical jump runs through three consecutive values of r+c and of r-c. This is de Bruijn's and Conway's "position class" invariant (sixteen classes on the plane), the classical tool for the English 33-hole board. Elementary version: colour the printed strip, count, jump, count again.

*Potential (pagoda) functions.* Give every cell a number so that no jump ever raises the total of the numbers under the pegs. If the target cell alone is worth more than the whole starting army, the target is unreachable. Conway's choice: with sigma = (sqrt 5 - 1)/2 = 0.618..., which satisfies sigma^2 + sigma = 1, a cell at taxicab distance d from the target weighs sigma^d. A jump straight toward the target replaces sigma^(d+2) + sigma^(d+1) by sigma^d, so the total is unchanged; any other jump lowers it. For a target five rows above the line the whole infinite half-plane weighs exactly 1 = the target, so a finite army weighs less and can never get there. In one dimension the same argument works with *integers*: label the strip 1, 1, 2, 3, 5, 8, 13, 21, Fibonacci numbers growing toward the star. Two neighbouring labels add to the next one, so a jump toward the star keeps the total and a jump away lowers it, while the army's total 1+1+2+3+5+8 = 20 is one less than the star's 21. This is Aigner's "Fibonacci desert" argument and it is within reach of a fifth grader; the sigma version is the same idea with a number whose "two neighbours add to the next" rule works in every direction at once.

**(c) Completeness by exhaustion.** On a tiny board "we tried everything" is a proof, provided the tree of all plays is really written down. The strip 1x5 with any hole has at most two first moves and then a forced one; a block of three or four pegs on a long strip has two mirror-image first moves. A child can draw the whole tree.

**(d) Optimality / extremal questions.** Fewest pegs one can leave on an unsolvable board (block of n pegs on a long strip: half of n, rounded up, for n up to 12; 3x3 with a corner hole: 4). Smallest army that reaches row 1, 2, 3, 4: 2, 4, 8, 20. The weight function gives the lower bounds 2, 4, 8 and 19 immediately (the 1, 3, 7 and 18 heaviest cells weigh 0.618, 0.854, 0.944, 0.979 < 1); the 19 heaviest cells weigh exactly 1, and a finite search shows 19 cannot do it, so 20 is the truth (Berlekamp-Conway-Guy; Bell-Hirschberg-Guerrero-Garcia). The pattern 2, 4, 8 breaks at the fourth case: not 16, not 19, but 20, and then never.

**(e) Conservation.** Every jump removes exactly one peg, so pegs at the start = jumps made + pegs left. This is the kindergarten invariant; the colouring parity and the weight monovariant are its grown-up relatives.

**(f) Reconfiguration and duality.** Where can the last peg end? The colouring restricts it; the data show it is not always forced (1x6 hole 2 can end on 2 or 5). And there is a symmetry: the strip with hole h can be finished with the last peg on k if and only if the strip with hole k can be finished with the last peg on h. Proof: play the winning sequence backwards and swap pegs with holes; an "un-jump" on a position is an ordinary jump on the complementary position. This is the classical reversal principle of solitaire.

**(g) Counting.** Number of winning sequences (1x4 hole 2: 1; 1x6 hole 2: 4; 1x8 hole 2: 10; 1x10 hole 2: 28; 3x4 corner: 852; 4x4 edge: 210,422). Only the tiny cases are for children; the big ones are for the adults to quote.

**(h) Dynamics of the one-dimensional army.** Soldiers on the left of a line on a strip can send one soldier exactly one cell past the line and never two, however many they are. This 1-D shadow of Conway's theorem is the cleanest impossibility of the session: the exploration is quick, the tree for small armies is small, and the Fibonacci labels prove it in general.

---

## 2. Instances

The natural whole-group launch is K1 followed by the two contrasting 1x4 strips of K2 (hole at the end, hole next to the end), since every table starts from exactly that pair. Cell sizes: checkers are about 1.25 in across, pennies 0.75 in. Use 1.4 in cells for the K-1 table (checkers), 1.0 in cells for grades 2-3 (pennies or checkers), 0.8 in cells for grades 4-5 (pennies). The printable width inside the house margins is 7.2 in, so strips longer than five 1.4 in cells should be printed vertically, and the 9-column soldiers' board for the 20-soldier army only fits with cells of at most 0.8 in.

### K-1 (no reading; the adult reads, the child moves checkers; three children)

Core sequence: K1-K7. Reserves: K8-K11.

- **K1. The jump.** Strip 1x3, checkers on cells 1 and 2, cell 3 empty. The child jumps 1 over 2 into 3 and removes the checker from 2. Then the same strip with the empty cell in the middle (checkers on 1 and 3): nothing can move. Finding: the checker jumps over a neighbour into the empty cell right behind it; a lone checker cannot jump into a gap. Answer: one jump, one checker left; middle hole, no move. Why: fixes the rule with the two smallest possible cases.
- **K2. 1x4, four starting holes.** Four printed strips, each with three checkers and the hole at cell 1, 2, 3, 4. Finding: hole at an end (1 or 4): exactly one move is possible (3>2>1, or 2>3>4), leaving two checkers that are not neighbours; hole at 2: 4>3>2 then 1>2>3, one checker left (on cell 3); hole at 3: mirror image, one left on cell 2. The child marks the strips that could be finished. Why: the first impossible case next to the first success, and the reason ("after my jump the two are not next to each other") is one a five-year-old can say.
- **K3. 1x5, five starting holes.** Five strips with four checkers. Finding: none can be finished; the best is two checkers left, for every hole. Hole 1: forced play 3>2>1, 5>4>3, stuck with checkers on 1 and 3. Hole 2: forced 4>3>2, 1>2>3, stuck (3 and 5). Hole 3: 1>2>3 or the mirror 5>4>3, then one forced move, stuck (2 and 5, or 1 and 4). Why: a board where *nothing* works; a child can see all the cases and say "we tried every hole and every jump".
- **K4. 1x6, find a good hole.** Vertical strip of six, five checkers. Finding: the hole must be on cell 2 or 5; then four jumps finish (for hole 2: 4>3>2, 1>2>3, 6>5>4, then 3>4>5 or 4>3>2, so the last checker ends on 5 or on 2). Hole 1 or 6: best three left; hole 3 or 4: best two left. Why: the "one in from the end" pattern of K2 returns; a four-jump puzzle with a genuine choice at the end.
- **K5. Jumps and checkers (runs through everything).** Removed checkers go into a cup. After each game: count the cup, count the board, count the start. Start = cup + board, always. Ask: "you started with 6 and ended with 1; how many jumps, without counting the cup?" (5). Why: a conservation law the child can state and test on every board.
- **K6. 3x3, three kinds of hole.** Three boards, eight checkers each, hole in the centre, in the middle of an edge, in a corner. Finding: centre hole: no move exists; edge hole (1,2): exactly one move, (3,2)>(2,2)>(1,2), then stuck with 7; corner hole: the child can get down to 4, never lower (a line to 4 is in Section 3.4). Why: jumps now go up and down as well; "leave only four" is a real optimisation with a definite answer.
- **K7. Cross the line: rows 1 and 2.** A 5-column board with a thick line, two rows below it and two above, a star in the middle column of row 1 (first board) or row 2 (second board). Soldiers start below the line only; land a soldier on the star with as few soldiers as possible. Finding: row 1 needs 2 (stacked under the star, one jump). Row 2 needs 4, and up to mirror image there is exactly one formation: three in a row in row 0 ending under the star, plus one in row -1 directly under the star. Jumps: (-1,0)>(0,0)>(1,0); (0,-2)>(0,-1)>(0,0); (0,0)>(1,0)>(2,0). Why: the theme; the price doubles; the unique shape ("an L") is a discovery.
- **K8 (reserve). Cross the line: row 3.** Board 5 columns by 7 rows (4 below, 3 above), star in row 3. Needs 8 soldiers, seven jumps; the two formations are in Section 3 (a T and a 5+3 block). With the adult's help.
- **K9 (reserve). 1x7 and 1x8.** 1x7: no hole works (best two left from holes 2, 3, 5, 6; three from holes 1, 4, 7). 1x8: holes 2, 4, 5, 7 work in six jumps.
- **K10 (reserve). The 2x3 board.** Six cells, five checkers. Hole in a middle cell: no move at all; hole in a corner: one move ((1,3)>(1,2)>(1,1)) and stuck. Why: "a jump needs three cells in a line", so two rows allow no up-and-down jumps.
- **K11 (reserve). Soldiers on a strip.** Strip 1x10 with a thick line after cell 6, six checkers on cells 1-6. How far right can a checker get? Cell 7 only. The play is forced: 5>6>7, 3>4>5, 1>2>3, then checkers on 3, 5, 7 and nothing moves.

### Grades 2-3 (four third graders; short printed text is fine)

Core: M1-M6. Reserves: M7-M10.

- **M1. 1x4 and 1x5, every hole, in a table.** Nine strips (four of length 4, five of length 5, pennies). Record per strip: fewest left and, when one is left, its cell. Answers: 1x4: 2, 1 (ends on 3), 1 (ends on 2), 2. 1x5: 2, 2, 2, 2, 2. Then draw the complete tree for 1x5 (the plays in K3). Why: act, record, compare; the first complete case analysis.
- **M2. 1x6, 1x7, 1x8.** Answers: 1x6: holes 2 and 5 work (last peg on 2 or 5; four winning sequences each), holes 1, 6 leave 3 at best, holes 3, 4 leave 2. 1x7: nothing works (2 left from holes 2, 3, 5, 6; 3 from holes 1, 4, 7). 1x8: holes 2, 4, 5, 7 work (six jumps); from hole 2 or 5 the last peg lands on 4 or 7, from hole 4 or 7 on 2 or 5. Why: a pattern to spot (even lengths can be finished from some holes, odd lengths never, apart from 1x3) and data for M3.
- **M3. Three colours.** Colour the cells red, blue, green, red, ... on the strips already played. Count the pegs on each colour, make one jump, count again: each count changed by one. Rule to draw out: if all three counts are odd or all even, one peg is impossible; otherwise the last peg must land on the colour whose count is the odd one out. Checks: 1x6 hole 2 has red 2, blue 1, green 2 (cells 1,4 red; 2,5 blue; 3,6 green): last peg on blue, 2 or 5, as found. 1x4 holes 1, 4: counts 1,1,1, impossible. 1x5 hole 3: 2,2,0, impossible. 1x7 holes 1, 4, 7: 2,2,2, impossible. 1x8 holes 3, 6: 3,3,1, impossible. Where the colours say nothing (1x5 holes 1, 2, 4, 5; 1x6 holes 1, 3, 4, 6; 1x7 holes 2, 3, 5, 6) the tree is the proof. Why: the first invariant, and the first certificate that settles a case without playing it.
- **M4. 3x3 and 3x4.** 3x3: no hole can be finished (K6 data). 3x4 (twelve cells, one hole): a hole in the top or bottom row can be finished in ten jumps; a hole in the middle row allows at most two jumps ever ((2,4)>(2,3)>(2,2) then (2,1)>(2,2)>(2,3) for hole (2,2); one jump for hole (2,1)). From the corner hole the last peg can only end on (1,1) or (1,4); from hole (1,2) only on (1,2) itself. Solutions are in Section 3.4. Why: moving the hole one cell turns a puzzle with 852 solutions into one with none; the "where does it end" question has a crisp answer.
- **M5. Soldiers: rows 1, 2, 3.** Board 7 columns by 7 rows (4 below the line, 3 above), a star in row 1, then row 2, then row 3 (middle column). Fewest soldiers: 2, 4, 8. Row 2 has one formation up to mirror (the L of K7). Row 3 has exactly two up to mirror: the T (five in row 0 centred under the star, three more in column 0 in rows -1, -2, -3) and the block (five in row 0, three in row -1 under the left three); jumps in Section 3.5. Ask for a guess for row 4 (they will say 16); the answer is 20, and row 5 is impossible with any number. Why: the theme, with the pattern that breaks.
- **M6. Soldiers on a strip.** Strip of 12 with the line after cell 8; the child may put pennies on any of cells 1-8. How far right can a penny get? Cell 9 always (two pennies on 7 and 8 suffice), cell 10 never. For a four-penny army the whole tree fits on the page. Why: the one-dimensional impossibility, proved by exhaustion for small armies and (stretch, or at the share) by the Fibonacci labels of U5.
- **M7 (reserve). Blocks on a long strip.** A 1x12 strip with pegs on the middle 3, 4, 5, 6 cells: fewest left 2, 2, 3, 3. Exhaust 3 and 4 (two mirror first moves each).
- **M8 (reserve). How many ways?** 1x6 hole 2 has exactly four winning sequences: 4>3>2, 1>2>3, 6>5>4, then 3>4>5 or 4>3>2; or 4>3>2, 6>5>4, 1>2>3, then 3>4>5 or 4>3>2. 1x8 hole 2 has ten.
- **M9 (reserve). Dead boards.** 2x3 and 2x4 with any hole; the 5-cell plus (middle hole: no move; arm hole: one move); the 9-cell cross (arms of length 2): best two left from any hole.
- **M10 (reserve). 3x5.** Only the hole in the middle of a long side ((1,3) or (3,3)) can be finished (13 jumps, Section 3.4), and the last peg returns to that same cell.

### Grades 4-5 (two fourth graders, one fifth grader)

Core: U1-U6. Reserves: U7-U10.

- **U1. Strips 1x4 to 1x8, every hole.** Same data as M1-M2, recorded as a table (length, hole, fewest left, possible final cells). Why: the raw material for U2 and U3.
- **U2. The colouring theorem.** As M3, but the children give the proof: "every jump uses one cell of each colour, so every count changes by one, so all three parities flip together; one peg is odd-even-even; so the odd-one-out colour never changes." Then two uses: prediction (1x8 hole 2: the odd-one-out colour is red = cells 1, 4, 7; the data show 4 and 7 occur and 1 does not, so the colouring allows more than actually happens) and certification (the cases listed in M3). Why: an invariant proved, not just observed, and an honest look at what a certificate does and does not do.
- **U3. Reversal.** From the table: hole 2 can end on 4 and hole 4 can end on 2; hole 2 on 7 and hole 7 on 2; hole 4 on 5 and hole 5 on 4 (all on 1x8); on 1x6, hole 2 on 5 and hole 5 on 2; on 3x4, (1,1) on (1,4) and (1,4) on (1,1). The children find the symmetry, then the argument: run the film backwards and swap pegs with holes; a reversed jump on the swapped board is a legal jump. Why: a theorem with a one-picture proof.
- **U4. Soldiers: 2, 4, 8, 20, never 5.** Board 9 columns by 8 rows (4 below, 4 above), stars at rows 1-4. Find the 2-, 4- and 8-soldier formations (all listed in Section 3). Guess row 4 (16); the truth is 20 (formation and 19 jumps in Section 3). Say why 16 is hopeless with the weights of U6 (the 16 heaviest cells weigh 0.936 < 1), that 19 fails by a computer search, and that row 5 is impossible for any finite army. Why: the pattern that breaks, with the reason.
- **U5. The Fibonacci strip.** A strip of exactly eight cells labelled 1, 1, 2, 3, 5, 8 | 13 | 21, the line after the 8, a star on 21, six pennies on the first six cells. Task: check that a jump toward the star replaces two neighbouring labels by their sum (5+8 goes to 13, total unchanged) and a jump away lowers the total (8+5 goes to 3); add up the army (20) and compare with the star (21). So the total never reaches 21 and the star is never reached, while cell 13 is reachable because 8+5 = 13. Re-label for seven pennies (star 34, army 33) and eight (55, 54): always one short. Why: a complete impossibility proof done with addition only; it is the exact skeleton of Conway's argument.
- **U6. The golden weights.** sigma = 0.618, sigma^2 = 0.382, sigma + sigma^2 = 1.000 (checked by hand to three places). A cell at distance d from the star weighs sigma^d (table in Section 3.5). A jump toward the star: sigma^(d+2) + sigma^(d+1) = sigma^d exactly, the Fibonacci rule again; sideways or away, the total drops. Weigh the L-army for row 2: 0.382 + 0.236 + 0.236 + 0.146 = 1.000 exactly; the T-army for row 3, the 2-army (0.618 + 0.382) and the 20-army also weigh exactly 1: none of the smallest armies wastes anything. For row 5 the whole half-plane weighs exactly 1 (two-line calculation in Section 3.5), so a finite army is always short. Why: the real proof, in the same shape as U5; it also explains 2, 4, 8 as lower bounds.
- **U7 (reserve). 4x4.** Solvable exactly from the eight edge cells that are not corners (14 jumps, Section 3.4; from hole (1,2) the last peg ends on (1,3) or (4,3)); impossible from the four corners and the four centre cells. Colour by (row + column) mod 3 in diagonal stripes: the classes have 5, 5 and 6 cells; a hole on the 6-cell class (the corners, (2,3) and (3,2)) leaves 5, 5, 5 pegs, all odd, so impossible; (2,2) and (3,3) are mirror images of (2,3) and (3,2).
- **U8 (reserve). Rings and 3x5.** Cells around a circle, one hole: rings of 4, 6, 8, 10, 12 can be finished, rings of 5, 7, 9, 11 cannot. 3x5 as in M10.
- **U9 (reserve). Execute the 20-soldier solution** from the printed list of 19 jumps (Section 3); five minutes, and it shows why row 4 is hard: the three sub-armies must arrive at (3,0), (2,1) and (2,2) in the right order.
- **U10 (reserve). Counting.** Winning sequences from hole 2 on 1x4, 1x6, 1x8, 1x10: 1, 4, 10, 28. Draw the tree for 1x6.

---

## 3. Verified data

### 3.1 Strips 1xn with one hole

Fewest pegs that can be left; cells where a single last peg can end; number of winning sequences; colour counts (A = cells 1,4,7,10; B = cells 2,5,8; C = cells 3,6,9) and what the colour test concludes. Mirror-image holes are grouped.

| strip | hole | fewest left | last peg can end on | ways | pegs on A,B,C | colour test | truth agrees? |
|---|---|---|---|---|---|---|---|
| 1x3 | 1 | 1 | 1 | 1 | 0,1,1 | last on A (cell 1) | yes |
| 1x3 | 2 | 2 | - | 0 | 1,0,1 | last on B (cell 2) | silent: impossible by play |
| 1x4 | 1, 4 | 2 | - | 0 | 1,1,1 | impossible | yes |
| 1x4 | 2 | 1 | 3 | 1 | 2,0,1 | last on C (cell 3) | yes |
| 1x4 | 3 | 1 | 2 | 1 | 2,1,0 | last on B (cell 2) | yes |
| 1x5 | 1, 4 | 2 | - | 0 | 1,2,1 | last on B (2, 5) | silent: impossible by play |
| 1x5 | 2, 5 | 2 | - | 0 | 2,1,1 | last on A (1, 4) | silent: impossible by play |
| 1x5 | 3 | 2 | - | 0 | 2,2,0 | impossible | yes |
| 1x6 | 1, 6 | 3 | - | 0 | 1,2,2 / 2,2,1 | last on A / on C | silent: impossible by play |
| 1x6 | 2, 5 | 1 | 2, 5 | 4 | 2,1,2 | last on B (2, 5) | yes |
| 1x6 | 3, 4 | 2 | - | 0 | 2,2,1 / 1,2,2 | last on C / on A | silent: impossible by play |
| 1x7 | 1, 4, 7 | 3 | - | 0 | 2,2,2 | impossible | yes |
| 1x7 | 2, 5 | 2 | - | 0 | 3,1,2 | last on C (3, 6) | silent: impossible by play |
| 1x7 | 3, 6 | 2 | - | 0 | 3,2,1 | last on B (2, 5) | silent: impossible by play |
| 1x8 | 1 | 4 | - | 0 | 2,3,2 | last on B (2, 5, 8) | silent: impossible by play |
| 1x8 | 8 | 4 | - | 0 | 3,2,2 | last on A (1, 4, 7) | silent: impossible by play |
| 1x8 | 2, 5 | 1 | 4, 7 | 10 | 3,2,2 | last on A (1, 4, 7) | yes, but cell 1 never occurs |
| 1x8 | 3, 6 | 3 | - | 0 | 3,3,1 | impossible | yes |
| 1x8 | 4, 7 | 1 | 2, 5 | 10 | 2,3,2 | last on B (2, 5, 8) | yes, but cell 8 never occurs |
| 1x9 | 1 | 4 | - | 0 | 2,3,3 | last on A | silent: impossible by play |
| 1x9 | 9 | 4 | - | 0 | 3,3,2 | last on C | silent: impossible by play |
| 1x9 | 2..8 | 2 | - | 0 | one count 2, two counts 3 | allowed | silent: impossible by play |
| 1x10 | 1, 4, 7, 10 | 5, 2, 2, 5 | - | 0 | 3,3,3 | impossible | yes |
| 1x10 | 2, 5 | 1 | 6, 9 | 28 | 4,2,3 | last on C (3, 6, 9) | yes, cell 3 never occurs |
| 1x10 | 6, 9 | 1 | 2, 5 | 28 | 4,3,2 | last on B (2, 5, 8) | yes, cell 8 never occurs |
| 1x10 | 3 | 3 | - | 0 | 4,3,2 | last on B | silent: impossible by play |
| 1x10 | 8 | 3 | - | 0 | 4,2,3 | last on C | silent: impossible by play |

Summary for the guide: 1x3 (end hole), 1x4 (holes 2, 3), 1x6 (2, 5), 1x8 (2, 4, 5, 7) and 1x10 (2, 5, 6, 9) can be finished; 1x5, 1x7 and 1x9 never can. The colour test proves the impossibility of 1x4 (ends), 1x5 (hole 3), 1x7 (holes 1, 4, 7), 1x8 (3, 6) and 1x10 (1, 4, 7, 10); every other impossibility needs the tree of plays.

All winning sequences, 1x4 hole 2: 4>3>2, 1>2>3. 1x6 hole 2: {4>3>2, 1>2>3, 6>5>4, 3>4>5}, {4>3>2, 1>2>3, 6>5>4, 4>3>2}, {4>3>2, 6>5>4, 1>2>3, 3>4>5}, {4>3>2, 6>5>4, 1>2>3, 4>3>2}. 1x8 hole 2, one of ten: 4>3>2, 1>2>3, 6>5>4, 3>4>5, 8>7>6, 5>6>7. 1x8 hole 4, one of ten: 6>5>4, 3>4>5, 1>2>3, 8>7>6, 6>5>4, 3>4>5.

Lines reaching the fewest pegs on unsolvable strips: 1x4 hole 1: 3>2>1 (2 left). 1x5 hole 1: 3>2>1, 5>4>3. 1x5 hole 2: 4>3>2, 1>2>3. 1x5 hole 3: 1>2>3, 4>3>2. 1x6 hole 1: 3>2>1, 5>4>3 (3 left). 1x6 hole 3: 1>2>3, 4>3>2, 6>5>4 (2 left). 1x7 hole 2: 4>3>2, 1>2>3, 6>5>4, 3>4>5 (2 left). 1x7 hole 4: 2>3>4, 5>4>3, 7>6>5 (3 left).

### 3.2 A block of n pegs in the middle of a long empty strip (jumps may leave the block)

| n | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| fewest left | 1 | 1 | 2 | 2 | 3 | 3 | 4 | 4 | 5 | 5 | 6 | 6 |

Block of 3: the two first moves are mirror images (2>1>0 or 2>3>4) and both end the game with two pegs. Block of 4 (cells 1-4): 2>1>0, then 3>4>5 or 4>3>2, two pegs; mirror likewise.

### 3.3 One-dimensional army

Pegs on any subset of cells 1..k of a strip that has six empty cells to the left and four to the right of the line (the line is after cell k), for every k up to 12 (4095 starting sets for k = 12): the farthest cell past the line ever occupied is k+1. With no room on the left and six pegs on 1-6 the play is forced: XXXXXX.... , XXXX..X... , XX..X.X... , ..X.X.X... (stuck with 3).

Fibonacci labels (cell k+2 is the star, labelled F(k+2); the army is on cells 1..k labelled F(1)..F(k)):

| k | labels of the army | army total | star | 
|---|---|---|---|
| 4 | 1, 1, 2, 3 | 7 | 8 |
| 5 | 1, 1, 2, 3, 5 | 12 | 13 |
| 6 | 1, 1, 2, 3, 5, 8 | 20 | 21 |
| 7 | 1, 1, 2, 3, 5, 8, 13 | 33 | 34 |
| 8 | 1, 1, 2, 3, 5, 8, 13, 21 | 54 | 55 |
| 9 | ..., 34 | 88 | 89 |
| 10 | ..., 55 | 143 | 144 |

Identity: F(1) + ... + F(k) = F(k+2) - 1 (checked to k = 12). The children's proof needs a strip with no cells beyond the star and none to the left of cell 1. With room to retreat on the left the same proof works with bigger labels: label the star F(N) with N at least 3k, so that every cell a peg could ever reach has a positive label; the army still totals at most F(N) - F(N-k) < F(N).

### 3.4 Small 2-D boards with one hole

| board | hole | fewest left | last peg can end on | winning sequences | note |
|---|---|---|---|---|---|
| 2x3 | corner | 4 | - | 0 | one move only |
| 2x3 | middle of a row | 5 | - | 0 | no move at all |
| 2x4 | any | 5 or 6 | - | 0 | |
| 3x3 | centre | 8 | - | 0 | no move at all |
| 3x3 | edge middle | 7 | - | 0 | one move only |
| 3x3 | corner | 4 | - | 0 | line to 4 below |
| 3x4 | corner (1,1) | 1 | (1,1), (1,4) | 852 | 10 jumps |
| 3x4 | (1,2) or (1,3) | 1 | that cell only | 488 | 10 jumps |
| 3x4 | middle row, end (2,1) | 10 | - | 0 | one move |
| 3x4 | middle row, (2,2) | 9 | - | 0 | two moves at most |
| 3x5 | (1,3) or (3,3) | 1 | that cell only | 17,424 | 13 jumps |
| 3x5 | any other top/bottom cell | 2 | - | 0 | |
| 3x5 | middle row | 12 | - | 0 | |
| 4x4 | corner | 2 | - | 0 | colouring: impossible |
| 4x4 | centre cell | 2 | - | 0 | colouring: impossible |
| 4x4 | edge non-corner, e.g. (1,2) | 1 | (1,3), (4,3) | 210,422 | 14 jumps |
| 4x5 | corners, (1,2)-type, (2,3), (3,3) | 1 | see program | huge | (2,3) ends on (3,3) only |
| 4x5 | the other 10 cells | 2 | - | 0 | colouring: impossible |
| plus, 5 cells | centre | 4 | - | 0 | no move |
| plus, 5 cells | arm | 3 | - | 0 | one move |
| cross, 9 cells (arms of 2) | any | 2 | - | 0 | |
| ring of n cells | any | 1 for n = 3, 4, 6, 8, 10, 12; 2 for n = 5, 7, 9, 11 | | 4, 8, 40, 112, 336 for n = 4, 6, 8, 10, 12 | |

Solutions (one of many; the last jump shows where the last peg ends):
- 3x3 hole (1,1), a line to the minimum of 4: (1,3)>(1,2)>(1,1); (3,2)>(2,2)>(1,2); (1,1)>(1,2)>(1,3); (3,1)>(2,1)>(1,1).
- 3x4 hole (1,1): (1,3)>(1,2)>(1,1); (3,2)>(2,2)>(1,2); (1,1)>(1,2)>(1,3); (1,4)>(1,3)>(1,2); (2,4)>(2,3)>(2,2); (2,1)>(2,2)>(2,3); (3,4)>(3,3)>(3,2); (3,1)>(3,2)>(3,3); (3,3)>(2,3)>(1,3); (1,2)>(1,3)>(1,4).
- 3x4 hole (1,2): (1,4)>(1,3)>(1,2); (1,1)>(1,2)>(1,3); (3,1)>(2,1)>(1,1); (3,2)>(2,2)>(1,2); (1,2)>(1,3)>(1,4); (2,4)>(2,3)>(2,2); (3,4)>(3,3)>(3,2); (3,2)>(2,2)>(1,2); (1,1)>(1,2)>(1,3); (1,4)>(1,3)>(1,2).
- 3x5 hole (1,3): (1,1)>(1,2)>(1,3); (1,4)>(1,3)>(1,2); (3,1)>(2,1)>(1,1); (1,1)>(1,2)>(1,3); (3,2)>(2,2)>(1,2); (1,2)>(1,3)>(1,4); (1,5)>(1,4)>(1,3); (2,4)>(2,3)>(2,2); (3,4)>(3,3)>(3,2); (3,2)>(2,2)>(1,2); (1,2)>(1,3)>(1,4); (3,5)>(2,5)>(1,5); (1,5)>(1,4)>(1,3).
- 4x4 hole (1,2): (1,4)>(1,3)>(1,2); (1,1)>(1,2)>(1,3); (3,1)>(2,1)>(1,1); (2,3)>(2,2)>(2,1); (1,1)>(2,1)>(3,1); (3,4)>(2,4)>(1,4); (1,4)>(1,3)>(1,2); (4,1)>(3,1)>(2,1); (4,2)>(3,2)>(2,2); (1,2)>(2,2)>(3,2); (3,3)>(3,2)>(3,1); (2,1)>(3,1)>(4,1); (4,4)>(4,3)>(4,2); (4,1)>(4,2)>(4,3).

Diagonal colouring facts: on 3x3 and 3x4 every hole passes both colour tests (their impossibilities are geometric); on 4x4 and 4x5 the colour tests fail exactly on the unsolvable holes.

### 3.5 Conway's soldiers

Weights: sigma = 0.6180340, sigma^2 = 0.3819660, sigma^3 = 0.2360680, sigma^4 = 0.1458980, sigma^5 = 0.0901699, sigma^6 = 0.0557281, sigma^7 = 0.0344419, sigma^8 = 0.0212862, sigma^9 = 0.0131556. Exact: sigma^2 = 1 - sigma, sigma^3 = 2 sigma - 1, sigma^4 = 2 - 3 sigma, sigma^5 = 5 sigma - 3, sigma^6 = 5 - 8 sigma, sigma^7 = 13 sigma - 8, sigma^8 = 13 - 21 sigma.

Number of cells below the line at distance d from a target in row L: 1 at d = L, then 3, 5, 7, 9, ... Weight of the m heaviest cells below the line:

| target row | m = 1 | 2 | 3 | 4 | 7 | 8 | 16 | 18 | 19 | 20 |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.618 | 1.000 | | | | | | | | |
| 2 | 0.382 | 0.618 | 0.854 | 1.090 | | | | | | |
| 3 | 0.236 | 0.382 | 0.528 | 0.674 | 0.944 | 1.034 | | | | |
| 4 | 0.146 | 0.236 | 0.326 | 0.416 | 0.584 | 0.639 | 0.936 | 0.979 | 1.000 | 1.021 |
| 5 | 0.090 | 0.146 | 0.202 | 0.257 | 0.361 | 0.395 | | | | (whole half-plane: 1.000) |

Row 4 exact: sigma^4 + 3 sigma^5 + 5 sigma^6 + 7 sigma^7 + 3 sigma^8 = 1 (substitute the exact forms: the sigma terms cancel). Row 5 half-plane: sum over rows below the line of sum over columns = (sigma^5 + sigma^6 + ...) x (1 + 2 sigma + 2 sigma^2 + ...) = (sigma^5 / sigma^2) x (1 + 2/sigma) = sigma^3 + 2 sigma^2 = sigma^2 (sigma + 2) = (1 - sigma)(2 + sigma) = 2 - sigma - sigma^2 = 1.

Smallest armies (every one, up to mirror image; X = soldier, row 0 is just below the line, the target is in column 0):

Row 1, 2 soldiers: (0,0) and (-1,0). Jump: (-1,0)>(0,0)>(1,0).

Row 2, 4 soldiers, the only formation:
```
row  0:  X X X      cells (0,-2) (0,-1) (0,0)
row -1:  . . X      cell (-1,0)
```
Jumps: (-1,0)>(0,0)>(1,0); (0,-2)>(0,-1)>(0,0); (0,0)>(1,0)>(2,0).

Row 3, 8 soldiers, the only two formations:
```
T:   row  0:  X X X X X     (0,-2)..(0,2)        block:  row  0:  X X X X X   (0,-2)..(0,2)
     row -1:  . . X . .     (-1,0)                       row -1:  X X X . .   (-1,-2) (-1,-1) (-1,0)
     row -2:  . . X . .     (-2,0)
     row -3:  . . X . .     (-3,0)
```
T jumps: (-1,0)>(0,0)>(1,0); (0,-2)>(0,-1)>(0,0); (0,0)>(1,0)>(2,0); (0,2)>(0,1)>(0,0); (-3,0)>(-2,0)>(-1,0); (-1,0)>(0,0)>(1,0); (1,0)>(2,0)>(3,0).
Block jumps: (-1,-1)>(0,-1)>(1,-1); (-1,0)>(0,0)>(1,0); (0,2)>(0,1)>(0,0); (-1,-2)>(0,-2)>(1,-2); (0,0)>(1,0)>(2,0); (1,-2)>(1,-1)>(1,0); (1,0)>(2,0)>(3,0).

Row 4: no army of 19 soldiers works. (Any such army weighs at least 1, the 19 heaviest cells weigh exactly 1, so the army would have to be the 16 cells at distance at most 7 plus 3 of the 9 cells at distance 8, and every jump would have to be straight toward the target; the program plays out all 84 such armies, 209,848 positions, and none reaches (4,0).) An army of 20 that works, 9 columns wide, 4 rows deep:
```
row  0:  X X X X X X X X X    columns -4 .. 4
row -1:  . . . X X X X . .    columns -1 .. 2
row -2:  . . . X X X X X .    columns -1 .. 3
row -3:  . . . . X X . . .    columns 0, 1
```
Its weight is exactly 1, so all 19 jumps go straight toward the target. It is not the set of the 20 heaviest cells: all 126 of those armies fail, as do the 444 shapes that drop a distance-7 cell for five distance-8 cells and the 1,000 shapes with two cells at distance 8 and two at distance 9 (counts up to mirror image); the search found this one among the shapes that drop one distance-7 cell and add four at distance 8 and one at distance 9. The 19 jumps:
1. (-1,0)>(0,0)>(1,0)
2. (-3,0)>(-2,0)>(-1,0)
3. (0,-2)>(0,-1)>(0,0)
4. (0,-4)>(0,-3)>(0,-2)
5. (-2,-1)>(-1,-1)>(0,-1)
6. (0,0)>(1,0)>(2,0)  [a soldier stands on (2,0)]
7. (-1,1)>(0,1)>(1,1)
8. (-3,1)>(-2,1)>(-1,1)
9. (0,-2)>(0,-1)>(0,0)
10. (-1,0)>(0,0)>(1,0)
11. (-2,3)>(-2,2)>(-2,1)
12. (-2,1)>(-1,1)>(0,1)
13. (0,1)>(1,1)>(2,1)  [soldier on (2,1)]
14. (-1,2)>(0,2)>(1,2)
15. (0,4)>(0,3)>(0,2)
16. (0,2)>(1,2)>(2,2)  [soldier on (2,2)]
17. (1,0)>(2,0)>(3,0)  [soldier on (3,0); (2,0) is empty again]
18. (2,2)>(2,1)>(2,0)  [refills (2,0) from the side]
19. (2,0)>(3,0)>(4,0)

Number of jumps is always soldiers minus one for a smallest army: 1, 3, 7, 19.

---

## 4. Arguments children can give

**K-1.** Forms: pointing at the picture; "we tried every one"; counting. Wording to draw them out: "Show me every jump you could make from here" (there is one, or none). "Why can't the last two jump?" ("they are not next to each other" / "there is nothing to jump over"). "We tried the hole in every place; which ones worked?" "Before you play, tell me how many jumps this will take if you get down to one" (start minus one). For K6: "Why is nothing moving?" ("every line of three is full, or has the empty square in the middle"). For K7: "Which soldier makes the last jump, and where must the soldier he jumps over be standing?" (this backs into the L formation).

**Grades 2-3.** Forms: a table of all cases; a drawn tree; a colouring on the picture; one counterexample; "the same reason again". Wording: "Draw every first move on the 1x5 strip; then every move after that; how many branches are there?" (a proof that 1x5 is impossible). "Colour the strip; count the pegs on each colour; now jump once and count again; what happened to each number?" ("each went up or down by one"). "So if the three counts are all even now, can they ever be 1, 0, 0?" (no: after each jump they are all odd or all even). "Where must the last peg be if you can finish?" (on the odd-one-out colour). "Is that the same reason that ruled out 1x4 with the hole at the end?" (yes, 1, 1, 1). For the soldiers on a strip: "To reach cell 10 someone must stand on 9 with someone on 8; where did the one on 9 come from, and what did that jump leave behind?" (two empties at 7 and 8) "So who can fill 8 now?" (the chase never ends; the tree for four pennies proves it). For M4: "The hole moved one square; show me why the game is over after two jumps" (all lines of three are full or broken).

**Grades 4-5.** Forms: an invariant stated and proved; a certificate checked; a symmetry with a one-picture proof; a computation with the labels. Wording: "Every jump touches three cells in a row; what colours are they?" (one of each) "So what happens to the three counts? To their parities?" "Write down what one peg looks like in colour counts" (1, 0, 0). "Now say the whole argument in one breath." For reversal: "Play your winning sequence backwards, but call pegs holes and holes pegs; is each backward step a legal jump?" For the Fibonacci strip: "Which pairs of neighbours add to the next label? So what does a jump toward the star do to the total? A jump away? Add up the army. What is the most the total can ever be? Can a peg ever sit on the star?" Then: "If you bring more soldiers, relabel; are you still one short?" (always; the sum identity). For the golden weights: "Check 0.618 + 0.382. Check 0.382 + 0.236. What rule do these weights obey?" (two neighbours toward the star add to the next) "Weigh the T army for row 3; weigh the 20-army for row 4" (both exactly 1) "What does exactly 1 force?" (every jump straight toward the target).

---

## 5. Pitfalls

Rules that get stated or played wrongly: sliding a peg into an adjacent empty cell; jumping over an empty cell or over two pegs; jumping diagonally; jumping off the end of a strip (the printed strip is the whole board); leaving the jumped peg on the board; making a "double jump" in one go (harmless, since a double jump is just two jumps, but children then miscount jumps); for soldiers, placing a soldier above the line at the start, or asking whether "the same soldier" must reach the star (identity is irrelevant: any soldier on the star wins). State the rule once as "hop over a neighbour into the empty square right behind it, and take the neighbour off".

Ambiguities to settle in the guide: "finished" means one peg anywhere; "where does the last peg end" is a separate follow-up. Mirror-image holes (2 and 3 on 1x4; 2 and 5 on 1x6) give mirror-image answers; children may treat them as different cases and that is fine. For "fewest soldiers", unused soldiers count, so remove them. On the Fibonacci strip the star must be the last cell and cell 1 the first; do not print spare cells.

Wrong answers to expect: "1x5 with the hole at the end can be finished" (a jump over an empty cell was made); "3x3 corner can get down to 3" (it cannot: 4 is the minimum, checked by exhausting every reachable position); "row 4 needs 16" (it needs 20; the 16 heaviest cells weigh 0.936 < 1); "the last peg can end on cell 1" for 1x8 hole 2 (the colouring allows it, the game does not; the search over all positions shows only 4 and 7 occur); "the colouring proves 1x5 hole 1 impossible" (it does not; the tree does). Colour the cells, never the pegs. The colouring is a test that can only say "impossible" or "maybe"; it never finds a solution. For the 4x4 the impossibilities need the (row + column) mod 3 diagonal stripes; column stripes do not work, because a vertical jump stays inside one column-colour.

Physical and logistical traps: checkers (1.25 in) on 1 in cells overlap and get knocked; use 1.4 in cells for K-1 and pennies elsewhere. Pennies roll; print a dot in each cell. Keep removed pegs in a cup per child (it is the jump counter of K5). Print every board and strip; children should not draw grids (a 1x8 strip takes a child several minutes to rule). Strips of 6 or more at 1.4 in must run vertically on the page. The 20-soldier board is 9 x 8 cells and needs 0.8 in cells with pennies. Print spares: the strips get marked up. The T army for row 3 needs 4 rows below the line; the block army needs 2. The 4x4 solution (14 jumps) takes a fifth grader ten minutes; the 3x4 (10 jumps) is right for third graders; the row-3 army (7 jumps) is a stretch for K-1 unless the adult narrates the T. The 20-soldier sequence takes about five minutes to execute from the list and is a good finish-early task.

---

## 6. Where it leads

Berlekamp, Conway and Guy, *Winning Ways for your Mathematical Plays*, vol. 4 (2nd ed.), chapter 23 "Purging Pegs Properly": the solitaire army, pagoda functions as certificates, the "rule of three"/position classes, and the 2, 4, 8, 20 story. Honsberger, *Mathematical Gems II* (1976), the chapter on Conway's checker-jumping problem, is the shortest full exposition of the sigma-weight proof. Aigner, "Moving into the desert with Fibonacci", Mathematics Magazine 70 (1997) 11-21: the integer-weight version used in U5 and the one-dimensional and other-lattice variants. Bell, Hirschberg and Guerrero-Garcia, "The minimum size required of a solitaire army", INTEGERS 7 (2007) G07: exact minimal armies (20 for row 4 on the square lattice) and the analogous numbers on hexagonal and other boards. Csakany and Juhasz, "The solitaire army reinspected", Mathematics Magazine 73 (2000) 354-362, and Eriksson and Lindstrom, "Twin jumping checkers in Z^d", European J. Combin. 16 (1995): higher-dimensional and diagonal-move armies. de Bruijn, "A solitaire game and its relation to a finite field", J. Recreational Math. 5 (1972): the sixteen position classes and their algebra. Beasley, *The Ins and Outs of Peg Solitaire* (Oxford): the classical boards, resource counts, and the reversal principle used in U3. Beeler and Hoilman, "Peg solitaire on graphs", Discrete Mathematics 311 (2011) 2198-2202, and the literature it started: which graphs (paths, cycles, stars, complete graphs, products) are solvable from a single hole; the strip and ring data of Section 3 are the smallest cases. Uehara and Iwata, "Generalized Hi-Q is NP-complete" (1990): deciding solvability on general boards is hard, which is why certificates matter. Pagoda functions are dual certificates in the linear-programming relaxation of reachability (the target minus the start must be a nonnegative combination of jump vectors), which is where the golden ratio comes from: among weights that fall off geometrically with distance, sigma is the one ratio for which two consecutive powers add up to the previous one, so toward-jumps cost nothing. The monovariant style of argument is the standard first chapter of olympiad combinatorics (Engel, *Problem-Solving Strategies*, chapter 1) and reappears as potential functions in algorithm analysis and as Lyapunov functions in dynamics. Open or semi-open directions the two mathematicians may enjoy: the exact minimum-pegs-left function for a block of n on a strip (the data suggest half of n rounded up; we did not find a proof), minimal armies with diagonal jumps allowed, and solitaire on other lattices and graphs.
