# Review of the Week 1 packet (jumping-peg games)

Everything below was checked against the sources, the rendered pages (all 66 pages at 60 dpi, several at 110 dpi) and my own exhaustive search program (`.review-tmp/mine/check.py`, `check2.py`, `check3.py`, `extra.py`; outputs `*.out`). Page numbers are the printed page numbers of each PDF.

**Mathematics summary.** I recomputed every strip (lengths 3–10, every hole: fewest left, ending squares, number of winning games, colour test), every block of 1–12, the 2×3, 2×4, 3×3, 3×4, 3×5, 4×4, plus, cross and ring boards (fewest, ending cells, counts of winning games: 852, 488, 17 424, 210 422, rings 4/8/40/112/336, the 14 games on the 3×3 corner), every quoted jump sequence, all minimal armies on the three printed soldier boards (2, 4, 8; the L and its mirror; the T, the block and its mirror; on the K–1 board only the block and its mirror), the 84 weight-exact nineteen-soldier armies (none reaches row 4; 209 848 positions, the same count the dossier gives), the twenty-soldier list (a soldier stands on e8 after 19 jumps), the golden and Fibonacci weight sums (0.854, 0.944, 1.034, 0.936, 0.979, 1.000, 1.021; 79+34+23+8=144; 135; 144), the Fibonacci strips (7/8, 12/13, 20/21, 33/34, 54/55, forced play, star never reached), and the one-dimensional army (farthest cell = one past the line for every army of up to ten pegs). Every answer and claim in the facilitator guide is correct. The student pages contain exactly one false statement (item 1).

## Required changes, most important first

### Mathematics

1. **week-grades-4-5.tex, Problem 20, page 14.** The sentence "After jump 16, three soldiers stand above the line on e7, f6 and g6, with e6 empty; watch how the last three jumps use them" is false. After jump 16 (g4>g5>g6) the four soldiers left are e5, e6, f6, g6; the position described is the one after jump 17 (e5>e6>e7). Change the sentence to: "After jump 16, four soldiers are left, on e5, e6, f6 and g6; watch how the last three jumps use them." (The guide's own description in §7 Reserves, Problem 20, is correct and needs no change.)

2. **week-grades-4-5.tex, Problem 21, page 14.** "Every jump in the list goes straight toward the star, never sideways or away" is misleading: six of the nineteen jumps are horizontal (c4>d4>e4 twice, a4>b4>c4, h2>g2>f2, i4>h4>g4, g6>f6>e6), which a child will call sideways. Replace with: "Every jump in the list brings a soldier two squares closer to the star, counting squares along its row and its column. Using the weights of Problem 19, say why an army that weighs exactly the same as the star can never afford a jump that does not." Change the guide's answer (§7 Reserves, Problem 21) to say "must bring the jumper two steps closer to the star" instead of "must be straight toward the star".

### Enough work and timing

3. **Minutes of real work per table** (my estimates; a problem's number is followed by its minutes):

   - K–1: P1 2 (already played in the launch), P2 4, P3 5, P4 5, P5 4, P6 1, P7 1, P8 5, P9 2, P10 6 = **35 core**; reserves P11 2, P12 7, P13 5 = 14. Adequate with the reserves; P6, P7 and P11 are one-observation pages (see item 6).
   - Grades 2–3: P1 3, P2 3, P3 4, P4 5, P5 5, P6 6, P7 8, P8 3, P9 2, P10 5, P11 4, P12 5, P13 8, P14 8, P15 3, P16 3 = **75 core**; reserves P17 6, P18 4, P19 2, P20 6, P21 4, P22 3, P23 5, P24 8, P25 4, P26 4 = 46. The guide's timing (43 minutes for P1–16, with "Problems 5–7: 8 minutes") is not achievable: the seven- and eight-strips alone (fifteen holes, each replayed for the fewest and for both endings) take 12–15 minutes. Consequence: the table never reaches the soldiers (P14–16) or the numbered strips (P25–26), which the guide itself calls "the proof of 17–19".
   - Grades 4–5: P1 8, P2 10, P3 3, P4 6, P5 6, P6 4, P7 3, P8 6, P9 8, P10 10, P11 3, P12 5, P13 2, P14 5, P15 5, P16 6, P17 5, P18 6, P19 6 = **107 core**; reserves P20 5, P21 3, P22 10, P23 8, P24 10 = 36. The guide's "core sequence is Problems 1–19" in 41 minutes is two and a half times too long; the guide half-admits it ("stop it after the six-strip and give them the results", "start Problem 14 by 0:32").

   No table runs out of work; the defect is the opposite, and it must be fixed by reordering and trimming, not by cutting problems from the packet:

   a. **week-grades-2-3.tex, Problems 6 and 7 (pages 4–5).** Print rows 1–4 only in the seven-strip table and rows 1–4 only in the eight-strip table, and add to Problem 6: "Holes 5, 6, 7 are holes 3, 2, 1 seen from the other end." and to Problem 7: "Holes 5 to 8 are holes 4 to 1 seen from the other end." Then change the eight/5 strip in Problem 10 (page 7) to eight/4 (counts 2, 3, 2; yes; blue; ends on 2 or 5), so every strip of Problem 10 has a row in the child's tables, and change the guide's Problem 10 answer line accordingly. Saves about 7 minutes.

   b. **week-grades-2-3.tex, renumber.** Move Problems 25–26 (the numbered strips, page 19) to directly after Problem 19, as Problems 20–21, and renumber 20–24 as 22–26. The guide's own stall/finish plan already prescribes the order 17–19, 25–26, 21, 20, 24; the printed order should match it.

   c. **week-facilitator.tex §6 "Timing".** Replace with honest figures: "Problems 1–2: 5. Problems 3–4: 8. Problems 5–7: 14 (two pairs: one pair takes the six- and seven-strips, the other the eight-strip; they swap records at the end). Problems 8–11: 10. Problems 14–16: 8. Core ends at about 45 minutes; Problems 12–13 (the square boards) become reserves, taken after 17–19 and the numbered strips."

   d. **week-grades-4-5.tex, reorder the core.** The printed order should be the order a 40-minute table actually follows: P1–2 (data, split three ways), P3–5 (colouring and theorem), P10–11 (soldiers, stars 1–3), P14 then P16 then P15 (numbered strips: act, compare, explain; see item 5), then reserves in this order: P17 (star-2 weights), P19 (the whole-number weights, which answers the guess of P11), P18, P6–9 (colouring limits and reversal), P12–13, P20–24. Concretely: new Problems 1–5 = present 1–5; 6–7 = present 10–11; 8 = present 14; 9 = present 16; 10 = present 15; 11 = present 17; 12 = present 19; 13 = present 18; 14–17 = present 6–9; 18–19 = present 12–13; 20–24 unchanged. Present Problems 6–7 leave page 5 (which keeps Problem 5 alone) and present 12–13 leave page 8. Update every cross-reference ("the boards of Problem 11", "the coordinates of the big board", "the weights of Problem 19", "the strip of Problem 14", "your table of Problem 2", "the board of Problem 10").

   e. **week-facilitator.tex §7 "Timing".** Replace with (present numbering): "Problems 1–2: 10 (one child takes the four- and five-strips, one the six-strip, one the seven- and eight-strips; pool at 0:18). Problems 3–5: 9. Problems 10–11: 8. Problems 14, 16, 15: 13. That is the forty minutes; everything else is reserve in the order 17, 19, 18, 6–9, 12–13, 20–24, and the star-2 weights (17) can be shown orally at the share if the table never reaches them." Delete the sentence "The core sequence is Problems 1–19" and rewrite the §7 subsections in the new order.

4. **week-grades-4-5.tex, Problem 1, page 1, and week-grades-2-3.tex, Problems 1 and 5–7.** Data collection is the same experiment repeated (eight or sixteen rows of "set up, play, record"). The contrast that matters (even lengths work from the hole next to the end, odd lengths never work) appears only after all rows. Add to 4–5 Problem 2 and to 2–3 Problem 7 a one-line summary blank that forces the comparison before moving on: "Lengths that could be finished: ______  Holes that worked: ______  Lengths that never could: ______".

5. **week-grades-4-5.tex, Problems 15 and 16, pages 9–10.** Problem 15 asks for the explanation after a single strip (Problem 14); the four further instances that make the pattern visible (7/8, 12/13, 33/34, 54/55) come afterwards in Problem 16. Swap them: the present Problem 16 becomes Problem 15 and the present Problem 15 ("Explain, using only what happens to the total…") becomes Problem 16, and its text should start "Look at the five differences in your table."

6. **week-k-1.tex, Problems 6 and 7, pages 6–7, and Problem 11, page 11.** Each is one board followed by one observation (0 jumps; 1 jump; 0 and 1 jumps) and takes under two minutes. Put Problems 6 and 7 on one page (two 1.3-inch boards fit, as page 8 shows) as Problem 6 with the text: "Now the board is a square. A jump can go left, right, up or down, never slantwise. Put a checker on every dot except the grey square. On the top board, point to every jump you could make. On the bottom board, point to every jump you could make. Make them. Draw a circle where each leftover checker stood, and write in the box how many jumps you made." with a box after each board. Renumber 8–13 as 7–12. In the guide, merge the answers of Problems 6 and 7 and change the timing line.

7. **week-k-1.tex, Problem 4, page 4.** Three strips for six possible X squares: a child who chooses squares 1, 3 and 6 can never "find an X square that lets you end with one checker". Either print four strips (four 1.3-inch vertical strips fit across the 7.2-inch text width with 0.6-inch gaps) or, better, keep three and add to the guide (§5, Problem 4): "Before they start, share out the X squares: one child tries 1, 2, 3 from the top, another 4, 5, 6, the third 2, 3, 4, so that the table covers every square; then pool: 'which X squares worked?'"

### Concreteness, order, recording space

8. **week-grades-2-3.tex, Problem 19, page 13.** "How many different first jumps are there? Is there any choice at all before the game ends?" has no recording space. Add under the strip: `\LBox{different first jumps}{1.0in}{0.45in}\hspace{0.5in}\LBox{jumps where there was a choice}{1.4in}{0.45in}`.

9. **week-grades-4-5.tex, Problem 8, page 6.** The second half ("Then do the same with a game on the strip of six from hole 2 ending on 5") has no strip and no table. Add a six-strip (`\StripH{0.8}{6}{0}{1}`) and a four-row copy of the same two-column table (jump 1–4, ends on); move Problem 9 to its own page if page 6 overflows.

10. **week-grades-4-5.tex, Problem 14, page 9.** (a) and (b) each ask three things (add before, jump, add after) but the "after" cells of the table have no width (the trailing `\hspace{0.8in}` in the last cell is discarded by `\\`; on the rendered page the cell is about 0.15 in wide). Replace the two-row table by `\begin{tabular}{|l|c|c|}\hline \RT & total before & total after\\\hline \RT (a) & \makebox[1in]{} & \makebox[1in]{}\\\hline \RT (b) & & \\\hline\end{tabular}` (`\makebox`, not `\hspace`, so the width survives the `\\`). Also (d) ("Can any army … reach the star? Try several armies.") has no recording space: add three blank ten-cell mini strips (`\MiniArmyAt`) with a "farthest square" box each, as on 2–3 page 12.

11. **week-grades-4-5.tex, Problem 16, page 10.** "Which square past the line can the army always reach?" has no place to write. Add a fifth column "farthest square reached" to the table.

12. **week-grades-4-5.tex, Problem 19, page 13.** Part (c) asks "What does this say about your guess for star 4?" and there is no blank for the conclusion. Add a line: "(c) sixteen soldiers can / cannot reach star 4, because ____________________".

13. **week-k-1.tex, Problem 8 (page 8) and Problem 13 (page 13).** "Count the circles" and "get a penny onto the star with as few pennies as you can" have no box. Add `\LBox{circles}{0.9in}{0.5in}` under each board of Problem 8 and `\LBox{pennies}{0.9in}{0.5in}` beside the top strip of Problem 13.

14. **week-grades-2-3.tex, Problems 25–26, page 19.** The tables have columns "after jump 3" (Problem 25) and "after jump 3", "after jump 4" (Problem 26) that never get used: both games end after two forced jumps. Keep the columns (the number of jumps is a discovery) but add to Problem 25: "Leave a column empty if the game ends before it." The guide's answer already says the play is forced.

15. **week-grades-4-5.tex, Problem 24, page 17, and week-grades-2-3.tex, Problems 18 and 21, pages 13 and 15.** The pre-drawn trees give away the answer to "How many games are there?" (four leaves are drawn). For grades 2–3 this is acceptable scaffolding; for grades 4–5 replace the tree of Problem 24 by a 3×4 grid of blank six-cell mini strips with writing lines and the instruction "Draw your own arrows", so the count is the child's.

16. **week-grades-4-5.tex, Problem 6, page 5.** The predictions for a strip of ten (hole 1) and nine (hole 5) cannot be tested: no such strips are printed. Add below the answer lines `\StripH{0.7}{9}{5}{1}` and `\StripH{0.7}{10}{1}{1}` (7.0 in wide, fits) and the sentence "Then play them." The guide's answers (5 left at best; 2 left at best) are correct.

### Next action, rules outside the problem text, ambiguities

17. **All four files, every board macro in week-boards.tex** (`\StripH`, `\StripV`, `\RectBoard`, `\PlusBoard`, `\ColourStripH`). A grey dot is printed inside the grey hole square, so "Put a checker on every dot. The grey square stays empty" (K–1 Problem 1) contradicts itself, and K–1 Problems 2, 3, 6, 7, 8 and 11 say only "Put a checker on every dot". Change each macro so that `\BoardDot` is drawn only when `\ifhole` is false (`\ifhole … \else \BoardDot{…}\fi`), as `\Ring` already does. Then "every dot" means exactly the pegs to place.

18. **week-grades-4-5.tex, Problem 9, page 6.** The 4–5 packet never states that jumps on a board go along rows and columns only; the rule appears only in the K–1 and 2–3 packets and in the launch. Add to Problem 9 after "The same on a rectangle.": "A jump goes along a row or a column, never diagonally."

19. **week-k-1.tex, Problem 6, page 6.** "Find every jump you can make. Make the jumps" on a board where no jump exists is a trap for a five-year-old (and for the parent reading aloud). Use the wording of item 6 ("point to every jump you could make … make them"), which is satisfied by "none".

20. **week-grades-2-3.tex, Problem 9, page 6.** "Now put pennies on every square except 5" refers to the strip of Problem 8, whose square 2 is printed grey; a child will also leave 2 empty. Add "(square 2 gets a penny this time)" or print a second colour strip `\ColourStripH{1}{6}{5}` above the table of Problem 9.

21. **week-grades-4-5.tex, Problem 12, page 8.** "highest row reached: ___" is ambiguous between the board's row numbers (5–8) and the star numbers (1–4); the guide's answer "highest row reached: 3" uses the star numbering. Change the blank to "highest star reached: ___".

22. **week-grades-4-5.tex, Problem 22, page 15.** "Colour the board in diagonal stripes as in pattern 1" — pattern 1 shows digits, not colours. Change to "Copy the digits of pattern 1 onto the big board, one in each corner, and count the pennies standing on squares marked 0, marked 1 and marked 2."

23. **week-grades-4-5.tex, Problem 7, page 5.** "Find every pair of squares $a$, $b$ such that the hole on $a$ can end on $b$ and the hole on $b$ can end on $a$" is a general statement with variables. Change to: "Find every pair of squares such that each one, used as the hole, can end on the other. Write the pairs."

24. **week-k-1.tex, Problem 5, page 5.** "the grown-up writes that number in the first box" is an instruction to the adult on a student page. Change to "and write that number in the first box" (the guide already says the adult scribes).

25. **week-grades-2-3.tex, Problem 2, page 1.** The "hole on 1" row offers two arrows and two strips but the game has one jump; a child will try to fill the second strip. Add "You may not need every strip." to the problem text, or print one arrow and one strip for that row.

### Level fit

26. **week-facilitator.tex §4 (launch) and every table's Problem 1.** The launch plays the four-strip with the hole at the end (stuck) and then the hole on 2 (finished) — which is exactly the first problem at all three tables (K–1 Problem 2, 2–3 Problem 1, 4–5 Problem 1, hole 2). Stop the launch after step 3 (the stuck strip) and end with: "The empty square is in the wrong place. At your table, find where it has to be." Delete step 4 and the first sentence of step 5, and change the K–1 timing note "partly done in the launch" accordingly.

27. **week-grades-2-3.tex, Problem 22, page 16.** Four boards with 0 or 1 possible jump, recorded as "jumps at the start / pennies left", are below the table's level (the same observation was made on 3×3 boards A and B in Problem 12) and teach nothing new. Replace the page by the 2×4 board (`\RectBoard{0.9}{2}{4}{0/0}{1}`, holes A and B: fewest 6 with one move, 5 with two moves) with the question "Why can no penny ever jump up or down on this board?", or drop the problem and move Problem 23 (the cross) here.

28. **week-grades-2-3.tex, Problem 1, page 1.** After the launch (as printed) the four-strips are solved; with item 26 the problem is fine as the entry problem. No other 2–3 or 4–5 problem is too easy for the whole table, and none states a rule with a variable except item 23.

### Page slop

29. **week-k-1.tex, Problem 5 (item 24)** is the only adult-facing remark on a student page. There are no titles, teasers, headings, boxes, Name/Date lines, exclamation marks, encouragement or fun facts on any student page; the only labels are the ones the tasks need (A/B/C, star 1/2/3, pattern 1/2, hole on 1/2, box labels).

30. **week-grades-2-3.tex, Problem 4, page 3, and week-grades-4-5.tex, Problems 1 (page 1) and 7 (page 5).** "Holes 4 and 5 are holes 2 and 1 seen from the other end, so you do not need to draw them", "because a hole past the middle is the mirror image of one before it", "(holes 5 and 7 are the mirror images of holes 4 and 2)" are explanations of the mathematics printed for the child. They are needed to make the tables usable, so keep the fact but drop the justification: "Holes 4 and 5 are holes 2 and 1 seen from the other end." / "The table stops at the middle of each strip." / "(hole 5 is hole 4 seen from the other end, hole 7 is hole 2)".

### Facilitator guide: missing pieces

31. **§7 Reserves, Problem 24.** "ten on eight from hole 2" is a bare count; the adult cannot check a child's tree. Add: "From hole 2 the eight-strip has fifteen complete games, ten winning and five stuck with pennies on 2 and 6. By first three jumps: 4>3>2, 1>2>3, 6>5>4: four winning games (then 3>4>5 and 8>7>6 in either order, then 5>6>7 ending on 7 or 6>5>4 ending on 4); 4>3>2, 6>5>4, 1>2>3: four more, the same way; 4>3>2, 6>5>4, 8>7>6: two (1>2>3, 3>4>5, then 5>6>7 or 6>5>4). The five stuck games are the ones that play 4>3>2 a second time before 3>4>5."

32. **§7 Reserves, Problem 23 (rings) and §10.** Give a winning sequence for the rings that can be finished and a best line for those that cannot, with cells numbered 1–n clockwise from the hole: ring 5: 3>2>1, 5>1>2, stuck on 1 and 3. Ring 6: 3>2>1, 5>4>3, 6>1>2, 2>3>4. Ring 7: 3>2>1, 5>4>3, 7>1>2, 2>3>4, stuck on 3 and 5. Ring 8: 3>2>1, 5>4>3, 7>6>5, 8>1>2, 2>3>4, 4>5>6. Add the reason odd rings fail: "the strip's three-colouring closes up around a ring only when n is a multiple of 3, and on the ring of 9 it is silent (counts 3, 3, 2), so for 5 and 7 the proof is the exhaustive tree: 4 complete games on the ring of 5, 12 on the ring of 7, none finishes."

33. **§6 Reserves, Problem 23 (the cross).** "Two left at best from any hole" needs a line and a certificate. Add: "Hole at the end of the right arm: centre>right1>right2, down2>down1>centre, left1>centre>right1, up2>up1>centre, right1>centre>left1, left2>left1>centre leaves two (centre and right2). Hole in the centre: down2>down1>centre, up1>centre>down1, left2>left1>centre, down1>centre>up1, right2>right1>centre, up1>centre>down1 leaves two. Why never one: from an arm-end hole there are only nine complete games (four leave 2, four leave 3, one leaves 6), from the centre thirty-two (sixteen leave 2); a pair can list the nine. The diagonal colouring certifies the centre hole (classes 1, 4, 4 with the centre removed: 0, 4, 4, all even) but is silent for the arm-end hole."

34. **§6 Reserves, Problem 24 (3×5) and §10.** Add best lines for the holes that fail, so the adult can show that 2 is reachable: hole A: C>B>A, E>D>C, L>G>B, B>C>D, I>H>G, F>G>H, N>M>L, K>L>M, M>H>C, D>C>B, A>B>C, O>J>E leaves C and E. Hole B: D>C>B, A>B>C, K>F>A, L>G>B, B>C>D, E>D>C, I>H>G, N>M>L, L>G>B, B>C>D, O>J>E, E>D>C leaves A and C.

35. **§6 Problems 5–7 and §7 Problems 1–2.** The failing holes are given without lines. Add: eight-strip hole 1: 3>2>1, 5>4>3, 7>6>5 leaves 1, 3, 5, 8 (the only game); hole 3: 1>2>3, 4>3>2, 6>5>4, 8>7>6 leaves 2, 4, 6. Seven-strip hole 1: 3>2>1, 5>4>3, 7>6>5 leaves 1, 3, 5; hole 3: 5>4>3, 2>3>4, 7>6>5, 4>5>6 leaves 1, 6; hole 4: 2>3>4, 5>4>3, 7>6>5 leaves 1, 3, 5.

36. **§7 Reserves, Problem 22 (4×4).** Add a two-left line for a corner and for a centre hole, since a child will ask for one: hole A: C>B>A, J>F>B, A>B>C, D>C>B, H>G>F, B>F>J, I>E>A, K>J>I, M>I>E, A>E>I, O>N>M, M>I>E, P>L>H leaves E and H. Hole F: H>G>F, E>F>G, M>I>E, A>E>I, C>B>A, K>G>C, D>C>B, A>B>C, I>J>K, O>K>G, C>G>K, L>K>J, N>J>F leaves F and P.

37. **§7 Problems 10–13.** There is a hint for star 2 (in §5) but none for star 3, the hardest search of the session. Add: "Hint for star 3, in order: 'the last jump is vertical in the star's column; what two squares must be full just before it?'; 'the soldier on row 6 got there by a jump from row 4 over row 5; that emptied e4 and e5, so e5 must be refilled'; 'five in a row just below the line, plus three more: try a column, then try a second row'."

38. **§2 Materials.** "Any crayons at K–1 (they colour the square where a piece stood)" is wrong: the K–1 pages ask for circles, and crayons are used for the small army boards (Problems 9, 10, 12) and the farthest square (Problem 13). Change the parenthesis to "(for the small army boards and Problem 13)". Also state the counter size needed by item 42: "pennies (0.75 in) fit cells of 0.8 in and up; for the weight boards of the 4–5 packet use the smaller counters (0.5 in) or the enlarged boards".

39. **§7, Problem 12.** Say what to record: "'highest star reached' is the star number, 3 at best with sixteen" (see item 21).

40. **§1 and §5–7.** State in one line per table what the last printed problem of the core is and what a child does while others finish (the K–1 section has "the cup question on every board"; add to 2–3: "a child who finishes a strip early tries to end on the other square"; to 4–5: "a child waiting for the pooled data writes the ending squares of the mirror holes").

### Production

41. **week-grades-2-3.tex, Problem 22, page 16.** The two box labels run together as "jumps at the start pennies left" (the labels are wider than the 0.7-in boxes they sit on). Put `\hspace{0.3in}` between the two `\LBox`es (four places) or widen the boxes to 1.1 in.

42. **Cells smaller than a penny (0.75 in).** Pennies overlap or will not sit on the dots on: week-grades-2-3.tex Problems 17, 19, 20 (ten-cell strips at 0.7 in, pages 12–14); week-k-1.tex Problem 13 (0.7 in, page 13); week-grades-4-5.tex Problem 16 (0.66 in, page 10), Problem 17 (0.7 in, page 11), Problem 18 (0.62 in, page 12), Problem 19 (0.6 in, page 13), Problem 22 (0.7 in, page 15). Fix: the ten-cell strips become nine-cell strips at 0.78 in (square 10 is never reached; the star is on 8; make the ten-cell mini strips of 2–3 Problems 17, 18 and 20 nine cells too, and K–1 Problem 13's `\ArmyStrip{0.7}{10}{6}{7}{0}` becomes `\ArmyStrip{0.78}{9}{6}{7}{0}`), Problem 17's board 0.85 in (4.25 in square), Problem 18's 0.8 in (5.6 in), Problem 19's 0.75 in (6.75 × 6.0 in; the text and blanks still fit in the 9.75 in of height), Problem 22's board 0.85 in with the two pattern diagrams shrunk to 0.38-in cells so the three fit across the page, Problem 16's strips 0.8 in (the tallest is 8.0 in; fits with the header). If a board cannot be enlarged, the guide must supply 0.5-inch counters for it (item 38).

43. **week-k-1.tex, Problems 9, 10, 12 (pages 9, 10, 12).** The recording boards have 0.32-, 0.32- and 0.26-inch cells; a kindergartner cannot colour a 0.26-inch square. Make the recording boards of Problems 9 and 10 0.4 in (the big boards are 4.2 and 5.6 in tall; there is room) and the one of Problem 12 0.36 in (big board 6.25 in at the present 1.25-in cells, which equal the checker diameter and should not shrink further, plus 1.8 in for the recording board plus 1.2 in of header and text = 9.25 in, fits).

44. **week-grades-4-5.tex, Problem 11, page 8.** The three recording boards at 0.22 in are hard to read (the stars are about 4 pt). Print seven-column boards (columns b–h; every minimal army lies in c–g) at 0.3 in: three boards of 2.1 in fit across the page.

45. **week-grades-4-5.tex, Problem 17, page 11.** Row (a) of the table prints "0.618 + 0.382 =" in a 1-inch cell, leaving about 0.1 in to write the sum. Give the answers their own row (`\RT sum & & & & \\\hline`) or drop the "=" text from the cells and print the four sums above the table.

46. **week-facilitator.tex, pages 16–17.** The heading "Small boards with one hole." is stranded at the foot of page 16 with its table on page 17. Put `\newpage` before the heading (or `\nopagebreak` after it and let the strip table float).

47. **week-grades-2-3.tex, page 7 (Problem 10).** Eight strips at 0.42 in with numbers and letters are legible at 110 dpi and print fine; the "colour of the last square: ____" blank is 0.5 in, too short for "green". Make it 0.8 in.

## Keep as is

- All mathematics in the facilitator guide (§5–§10): every answer, sequence, count, weight sum, minimal army, colour test and reference table checks out, including the 84-army search for nineteen soldiers and the twenty-soldier list.
- The overall architecture: strips with every hole → complete trees → three-colour parity certificate with its silent cases shown honestly → reversal → soldiers 2, 4, 8 → the Fibonacci strip as the integer skeleton → golden weights → integer weights for row 4 → the theorem for row 5 at the share. This is the right extraction of the real questions (existence, impossibility, invariants, optimality, completeness, counting) and the instances are well chosen (the 2–4–8 pattern breaking at 20; the five-strip and seven-strip failing; the four-strip hole 1 counts 1,1,1; ten/1 all odd but nine/5 silent).
- The K–1 pages: large cells matched to the checkers, no reading, circles and X marks as the record, the cup as the jump counter, the ladder of strips 3, 4, 5, 6, and the soldiers with a small board to draw the army.
- The house style: plain sentences, no headings, no praise, no exclamation marks, rules inside the problem text, recording space for almost every task.
- The whole-number weights (star 144) for row 4, with the explicit reason (three-place decimals sum to 0.997 for the twenty-army).
- §9 of the guide: the pagoda-function / dual-certificate framing, the exact half-plane computation, the references (Aigner 1997, Bell–Hirschberg–Guerrero-García 2007, Beeler–Hoilman 2011, de Bruijn 1972, Uehara–Iwata 1990, Berlekamp–Conway–Guy, Honsberger, Beasley, Engel) and the "where it leads" paragraph.
- The share plan (§8) and the "how the rule goes wrong" list (§3), which is the most useful page for the parent.
