#!/usr/bin/env python3
"""solitaire_data.py -- exhaustive checks behind the Week 1 dossier (jumping-peg games).

Run:  python3 solitaire_data.py            (prints all tables; takes a minute or two)

Part A: finite boards (strips, rectangles, crosses, rings): every position reachable
        from a one-hole start, fewest pegs that can remain, where a last peg can end,
        number of distinct winning jump sequences, and the 3-colouring parity test.
Part B: the one-dimensional army (pegs on cells 1..k of a strip, how far right can one go).
Part C: Conway's soldiers -- smallest armies for rows 1,2,3,4 and the row-5 weight identity.
"""
import sys, math, itertools, time
sys.setrecursionlimit(1000000)

# ----------------------------------------------------------------------------
# Part A: generic solver.  A board is a list of cells and a list of jump triples
# (a, b, c): a peg on a jumps over a peg on b into the empty cell c.
# ----------------------------------------------------------------------------
class Board:
    def __init__(self, name, cells, triples):
        self.name = name
        self.cells = list(cells)
        self.index = {c: i for i, c in enumerate(self.cells)}
        self.triples = [(self.index[a], self.index[b], self.index[c]) for a, b, c in triples]

def grid_triples(cells):
    S = set(cells)
    T = []
    for (r, c) in cells:
        for dr, dc in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            b = (r + dr, c + dc); t = (r + 2 * dr, c + 2 * dc)
            if b in S and t in S:
                T.append(((r, c), b, t))
    return T

def grid_board(name, cells):
    cells = sorted(cells)
    return Board(name, cells, grid_triples(cells))

def strip(n):
    return grid_board("1x%d" % n, [(0, c) for c in range(1, n + 1)])

def rect(m, n):
    return grid_board("%dx%d" % (m, n), [(r, c) for r in range(1, m + 1) for c in range(1, n + 1)])

def plus(arm):
    cells = {(0, 0)}
    for k in range(1, arm + 1):
        cells |= {(k, 0), (-k, 0), (0, k), (0, -k)}
    return grid_board("plus arm %d (%d cells)" % (arm, len(cells)), cells)

def ring(n):
    cells = list(range(n))
    T = []
    for i in range(n):
        T.append((i, (i + 1) % n, (i + 2) % n))
        T.append((i, (i - 1) % n, (i - 2) % n))
    return Board("ring %d" % n, cells, T)

def popcount(x):
    return bin(x).count("1")

def reachable(board, start):
    """All positions (bitmasks) reachable from start by jumps."""
    triples = board.triples
    seen = {start}
    stack = [start]
    while stack:
        s = stack.pop()
        for (a, b, c) in triples:
            if (s >> a) & 1 and (s >> b) & 1 and not (s >> c) & 1:
                t = (s & ~(1 << a) & ~(1 << b)) | (1 << c)
                if t not in seen:
                    seen.add(t)
                    stack.append(t)
    return seen

def count_wins(board, start):
    """Number of distinct jump sequences from start that end with exactly one peg."""
    triples = board.triples
    memo = {}
    def f(s):
        if s in memo:
            return memo[s]
        total = 0
        moved = False
        for (a, b, c) in triples:
            if (s >> a) & 1 and (s >> b) & 1 and not (s >> c) & 1:
                moved = True
                total += f((s & ~(1 << a) & ~(1 << b)) | (1 << c))
        if not moved:
            total = 1 if popcount(s) == 1 else 0
        memo[s] = total
        return total
    return f(start)

def one_solution(board, start):
    """One winning jump sequence (list of (from, over, to) cells) or None."""
    triples = board.triples
    dead = set()
    def f(s, path):
        if popcount(s) == 1:
            return path
        if s in dead:
            return None
        for (a, b, c) in triples:
            if (s >> a) & 1 and (s >> b) & 1 and not (s >> c) & 1:
                r = f((s & ~(1 << a) & ~(1 << b)) | (1 << c),
                      path + [(board.cells[a], board.cells[b], board.cells[c])])
                if r is not None:
                    return r
        dead.add(s)
        return None
    return f(start, [])

def all_solutions(board, start, limit=50):
    """Every winning jump sequence (up to limit) as lists of (from, over, to) cells."""
    triples = board.triples
    out = []
    def f(s, path):
        if len(out) >= limit:
            return
        moved = False
        for (a, b, c) in triples:
            if (s >> a) & 1 and (s >> b) & 1 and not (s >> c) & 1:
                moved = True
                f((s & ~(1 << a) & ~(1 << b)) | (1 << c),
                  path + [(board.cells[a], board.cells[b], board.cells[c])])
        if not moved and popcount(s) == 1:
            out.append(path)
    f(start, [])
    return out

def line_to_min(board, start):
    """A line of play that reaches the fewest possible pegs."""
    triples = board.triples
    best = [None, 10 ** 9]
    seen = set()
    def f(s, path):
        if s in seen:
            return
        seen.add(s)
        moved = False
        for (a, b, c) in triples:
            if (s >> a) & 1 and (s >> b) & 1 and not (s >> c) & 1:
                moved = True
                f((s & ~(1 << a) & ~(1 << b)) | (1 << c),
                  path + [(board.cells[a], board.cells[b], board.cells[c])])
        if not moved and popcount(s) < best[1]:
            best[0] = path; best[1] = popcount(s)
    f(start, [])
    return best[0], best[1]

def analyze(board, start):
    seen = reachable(board, start)
    n = len(board.cells)
    min_left = min(popcount(s) for s in seen)
    finals = sorted(board.cells[i] for s in seen if popcount(s) == 1 for i in range(n) if (s >> i) & 1)
    wins = count_wins(board, start) if min_left == 1 else 0
    return dict(n_states=len(seen), min_left=min_left, finals=finals, wins=wins)

def full_minus(board, hole_cells):
    s = (1 << len(board.cells)) - 1
    for h in hole_cells:
        s &= ~(1 << board.index[h])
    return s

# 3-colouring parity test.  colour(cell) must take all three values on every jump triple.
def parity_verdict(board, start, colour):
    counts = [0, 0, 0]
    for i, cell in enumerate(board.cells):
        if (start >> i) & 1:
            counts[colour(cell)] += 1
    par = [c % 2 for c in counts]
    if par[0] == par[1] == par[2]:
        return counts, "impossible (all three counts have the same parity)", []
    odd_one = [k for k in range(3) if par.count(par[k]) == 1][0]
    allowed = [cell for cell in board.cells if colour(cell) == odd_one]
    return counts, "last peg must be on colour %d" % odd_one, allowed

def strip_colour(cell):          # 1-D: colour by column mod 3
    return cell[1] % 3

def diag_colour_plus(cell):      # 2-D: (r+c) mod 3
    return (cell[0] + cell[1]) % 3

def diag_colour_minus(cell):     # 2-D: (r-c) mod 3
    return (cell[0] - cell[1]) % 3

def fmt_cells_1d(cells):
    return ",".join(str(c) for (_, c) in cells) if cells else "-"

def fmt_cells_2d(cells):
    return " ".join("(%d,%d)" % (r, c) for (r, c) in cells) if cells else "-"

def part_A():
    print("=" * 78)
    print("PART A1.  STRIPS 1xn, all but one cell filled (hole at cell h, cells numbered 1..n)")
    print("=" * 78)
    print("For each hole: fewest pegs that can remain; cells where a single last peg can end;")
    print("number of distinct winning jump sequences; verdict of the 3-colouring test")
    print("(colour cells by number mod 3: cell 1,4,7.. = colour 1; 2,5,8.. = colour 2; 3,6,9.. = colour 0).")
    for n in range(3, 11):
        b = strip(n)
        print("\n1x%d:" % n)
        for h in range(1, n + 1):
            start = full_minus(b, [(0, h)])
            A = analyze(b, start)
            counts, verdict, allowed = parity_verdict(b, start, strip_colour)
            print("  hole %2d: min left %d | last peg can end at: %-8s | winning sequences: %5d | colours %s -> %s %s"
                  % (h, A["min_left"], fmt_cells_1d(A["finals"]), A["wins"], counts, verdict,
                     ("[cells " + fmt_cells_1d(allowed) + "]") if allowed else ""))
    # sample solutions
    print("\nSample solutions (from, over, to) by cell number:")
    for n, h in [(4, 2), (6, 2), (7, 2), (7, 3), (8, 2), (8, 3), (8, 4), (9, 2), (10, 2), (10, 5)]:
        b = strip(n)
        sol = one_solution(b, full_minus(b, [(0, h)]))
        if sol:
            print("  1x%d hole %d: " % (n, h) + "; ".join("%d over %d to %d" % (a[1], o[1], t[1]) for a, o, t in sol))
        else:
            print("  1x%d hole %d: no solution" % (n, h))

    print("\nAll winning sequences on the small solvable strips:")
    for n, h in [(4, 2), (6, 2), (8, 2), (8, 4)]:
        b = strip(n)
        sols = all_solutions(b, full_minus(b, [(0, h)]))
        print("  1x%d hole %d: %d sequences" % (n, h, len(sols)))
        for sol in sols:
            print("     " + "; ".join("%d>%d>%d" % (a[1], o[1], t[1]) for a, o, t in sol) + "   (ends at %d)" % sol[-1][2][1])
    print("\nLines of play reaching the fewest pegs on unsolvable strips:")
    for n, h in [(4, 1), (5, 1), (5, 2), (5, 3), (6, 1), (6, 3), (7, 2), (7, 4)]:
        b = strip(n)
        path, left = line_to_min(b, full_minus(b, [(0, h)]))
        print("  1x%d hole %d -> %d left: " % (n, h, left) + "; ".join("%d>%d>%d" % (a[1], o[1], t[1]) for a, o, t in path))

    print("\n" + "=" * 78)
    print("PART A2.  A BLOCK OF n PEGS IN THE MIDDLE OF A LONG STRIP (jumps may leave the block)")
    print("=" * 78)
    for n in range(1, 13):
        b = strip(3 * n + 2)
        pegs = 0
        for c in range(n + 2, 2 * n + 2):
            pegs |= 1 << b.index[(0, c)]
        A = analyze(b, pegs)
        print("  block of %2d: fewest pegs left = %d%s" % (n, A["min_left"],
              "   (solvable)" if A["min_left"] == 1 else ""))

    print("\n" + "=" * 78)
    print("PART A3.  SMALL 2-D BOARDS, one hole (cells written (row,col), rows/cols from 1)")
    print("=" * 78)
    boards = [rect(2, 3), rect(2, 4), rect(3, 3), rect(3, 4), rect(3, 5), rect(4, 4), rect(4, 5),
              plus(1), plus(2)]
    for b in boards:
        print("\n%s (%d cells):" % (b.name, len(b.cells)))
        done = set()
        for h in b.cells:
            # canonical representative under the board's symmetry (only for rectangles/plus): report all anyway
            start = full_minus(b, [h])
            A = analyze(b, start)
            c1, v1, al1 = parity_verdict(b, start, diag_colour_plus)
            c2, v2, al2 = parity_verdict(b, start, diag_colour_minus)
            both = sorted(set(al1) & set(al2)) if (al1 and al2) else []
            if "impossible" in v1 or "impossible" in v2:
                colour_note = "colouring: impossible"
            else:
                colour_note = "colouring allows last peg at " + fmt_cells_2d(both)
            print("  hole %s: min left %d | last peg can end at: %-28s | wins %6d | %s"
                  % ("(%d,%d)" % h, A["min_left"], fmt_cells_2d(A["finals"]), A["wins"], colour_note))
    print("\nSample 2-D solutions:")
    for b, h in [(rect(3, 3), (1, 1)), (rect(3, 3), (1, 2)), (rect(4, 4), (1, 1)), (rect(4, 4), (1, 2)),
                 (rect(4, 4), (2, 2)), (rect(3, 4), (1, 1)), (rect(3, 4), (1, 2)), (rect(3, 4), (2, 2)),
                 (rect(3, 5), (1, 1)), (rect(3, 5), (1, 2)), (rect(3, 5), (1, 3)), (rect(3, 5), (2, 2)),
                 (rect(3, 5), (2, 3)), (plus(2), (0, 0)), (plus(2), (1, 0)), (plus(2), (2, 0))]:
        sol = one_solution(b, full_minus(b, [h]))
        if sol:
            print("  %s hole (%d,%d): " % (b.name, h[0], h[1]) +
                  "; ".join("(%d,%d)>(%d,%d)>(%d,%d)" % (a + o + t) for a, o, t in sol))
        else:
            print("  %s hole (%d,%d): no solution" % (b.name, h[0], h[1]))

    print("\nLines of play reaching the fewest pegs on unsolvable 2-D boards:")
    for b, h in [(rect(2, 3), (1, 1)), (rect(3, 3), (1, 1)), (rect(3, 3), (1, 2)), (rect(3, 3), (2, 2)),
                 (rect(3, 4), (2, 2)), (rect(3, 4), (2, 1)), (plus(1), (1, 0)), (plus(2), (0, 0)), (plus(2), (1, 0))]:
        path, left = line_to_min(b, full_minus(b, [h]))
        print("  %s hole (%d,%d) -> %d left: " % (b.name, h[0], h[1], left) +
              ("; ".join("(%d,%d)>(%d,%d)>(%d,%d)" % (a + o + t) for a, o, t in path) if path else "no move at all"))

    print("\n" + "=" * 78)
    print("PART A4.  RINGS (cells in a circle, jumps go around), one hole")
    print("=" * 78)
    for n in range(3, 13):
        b = ring(n)
        start = ((1 << n) - 1) & ~1
        A = analyze(b, start)
        print("  ring of %2d: min left %d | last peg can end at cells %s (hole at 0) | wins %d"
              % (n, A["min_left"], ",".join(str(c) for c in A["finals"]) if A["finals"] else "-", A["wins"]))

# ----------------------------------------------------------------------------
# Part B: the one-dimensional army
# ----------------------------------------------------------------------------
def part_B():
    print("\n" + "=" * 78)
    print("PART B.  ONE-DIMENSIONAL ARMY.  Strip of cells -6..k+4; the line is between cell k and k+1;")
    print("         pegs on ANY subset of cells 1..k (so jumps to the left are also available).")
    print("=" * 78)
    for k in range(1, 13):
        b = grid_board("army", [(0, c) for c in range(-6, k + 5)])
        far_all = 0; n_sub = 0; reach1 = 0
        for sub in range(1, 1 << k):
            pegs = 0
            for j in range(k):
                if (sub >> j) & 1:
                    pegs |= 1 << b.index[(0, j + 1)]
            seen = reachable(b, pegs)
            far = 0
            for s in seen:
                for c in range(k + 1, k + 5):
                    if (s >> b.index[(0, c)]) & 1:
                        far = max(far, c - k)
            far_all = max(far_all, far)
            n_sub += 1
            if far >= 1:
                reach1 += 1
        print("  k=%2d: %5d starting sets tried; farthest cell past the line ever occupied: %d; sets reaching cell k+1: %d"
              % (k, n_sub, far_all, reach1))
    print("\n  The forced play from a solid block of 6 (cells 1..6, line after 6, no room on the left):")
    b = strip(10)
    pegs = 0
    for c in range(1, 7):
        pegs |= 1 << b.index[(0, c)]
    seen = reachable(b, pegs)
    for s in sorted(seen, key=lambda x: -popcount(x)):
        print("    " + "".join("X" if (s >> b.index[(0, c)]) & 1 else "." for c in range(1, 11)) + "   (%d pegs)" % popcount(s))
    print("\nFibonacci labels: sum F_1+...+F_k versus F_(k+2)")
    F = [0, 1, 1]
    while len(F) < 20:
        F.append(F[-1] + F[-2])
    for k in range(1, 13):
        print("  k=%2d: labels %-45s sum = %4d, star F_%d = %4d, sum = star - 1: %s"
              % (k, str(F[1:k + 1]), sum(F[1:k + 1]), k + 2, F[k + 2], sum(F[1:k + 1]) == F[k + 2] - 1))

# ----------------------------------------------------------------------------
# Part C: Conway's soldiers
# ----------------------------------------------------------------------------
SIG = (math.sqrt(5) - 1) / 2          # sigma^2 + sigma = 1

def soldiers_search(L, m, rmin=-9, cmax=9, want_all=False, verbose=True):
    """Reverse search: start with one peg on the target (L,0), apply m-1 'unjumps',
    look for a final position lying entirely in rows <= 0 (below the line).
    Pruning: (1) weight: total weight never decreases in reverse; a final army of m pegs
    has weight at most the m heaviest cells below the line, so the accumulated loss
    is bounded;  (2) every peg above the line still has to be removed: a peg on row r
    needs at least g(r) further unjumps, g(1)=1, g(2)=2, g(r)=1+g(r-1)+g(r-2)."""
    target = (L, 0)
    def dist(p): return abs(p[0] - L) + abs(p[1])
    def w(p): return SIG ** dist(p)
    below = [(r, c) for r in range(rmin, 1) for c in range(-cmax, cmax + 1)]
    heaviest = sorted((w(p) for p in below), reverse=True)
    budget = sum(heaviest[:m]) - 1.0 + 1e-9
    if budget < 0:
        if verbose:
            print("  row %d with %d pegs: impossible by the weight bound alone (max army weight %.4f < 1)"
                  % (L, m, sum(heaviest[:m])))
        return None
    g = {}
    def gfun(r):
        if r <= 0: return 0
        if r not in g:
            g[r] = 1 + gfun(r - 1) + gfun(r - 2)
        return g[r]
    dirs = ((-1, 0), (0, 1), (0, -1), (1, 0))   # try downward first
    visited = set()
    found = []
    nodes = [0]
    def dfs(state, loss, path):
        remaining = m - len(state)
        if remaining == 0:
            if all(r <= 0 for (r, c) in state):
                found.append((frozenset(state), list(path)))
                return True
            return False
        need = sum(gfun(r) for (r, c) in state if r > 0)
        if need > remaining:
            return False
        key = frozenset(state)
        if key in visited:
            return False
        visited.add(key)
        nodes[0] += 1
        for cpos in list(state):
            r, c = cpos
            for dr, dc in dirs:
                b = (r + dr, c + dc); a = (r + 2 * dr, c + 2 * dc)
                if a[0] < rmin or a[0] > L + 1 or abs(a[1]) > cmax:
                    continue
                if b in state or a in state:
                    continue
                nl = loss + w(a) + w(b) - w(cpos)
                if nl > budget:
                    continue
                state.remove(cpos); state.add(a); state.add(b)
                path.append((a, b, cpos))      # forward move: a over b into cpos
                ok = dfs(state, nl, path)
                path.pop()
                state.remove(a); state.remove(b); state.add(cpos)
                if ok and not want_all:
                    return True
        return False
    t0 = time.time()
    dfs({target}, 0.0, [])
    if verbose:
        print("  row %d with %d pegs: %s  (%d positions examined, %.1fs)"
              % (L, m, ("FOUND %d army/armies" % len(found)) if found else "no army", nodes[0], time.time() - t0))
    return found

def show_army(army, L, path):
    rows = sorted({r for r, c in army}); cols = sorted({c for r, c in army})
    rmin, rmax = min(rows), L
    cmin, cmax = min(cols + [0]) , max(cols + [0])
    print("    board (row %d at top, row 0 = last row below the line, * = target, X = peg):" % rmax)
    for r in range(rmax, rmin - 1, -1):
        line = ""
        for c in range(cmin, cmax + 1):
            if (r, c) == (L, 0): line += " *"
            elif (r, c) in army: line += " X"
            else: line += " ."
        print("    row %2d:%s" % (r, line))
        if r == 1:
            print("    -------" + "--" * (cmax - cmin + 1) + "   <- the line")
    # forward jump sequence: reverse of the unjump path
    seq = list(reversed(path))
    print("    %d jumps (from) over (over) into (to):" % len(seq))
    for i, (a, b, c) in enumerate(seq, 1):
        print("      %2d. (%d,%d) over (%d,%d) into (%d,%d)" % (i, a[0], a[1], b[0], b[1], c[0], c[1]))
    # verify the sequence forward
    pegs = set(army)
    for (a, b, c) in seq:
        assert a in pegs and b in pegs and c not in pegs, "bad move"
        assert (a[0] == b[0] == c[0] and abs(a[1] - b[1]) == 1 and b[1] - a[1] == c[1] - b[1]) or \
               (a[1] == b[1] == c[1] and abs(a[0] - b[0]) == 1 and b[0] - a[0] == c[0] - b[0]), "not a jump"
        pegs -= {a, b}; pegs.add(c)
    assert (L, 0) in pegs
    print("    verified: after the jumps a peg stands on (%d,0); %d peg(s) remain." % (L, len(pegs)))

def nineteen_check():
    """Any 19-peg army reaching row 4 would have weight exactly 1, hence be the 19 heaviest
    cells (with 3 of the 9 cells at distance 8), and every jump would have to be geodesic.
    Exhaust those 84 armies with geodesic jumps only."""
    L = 4
    def dist(p): return abs(p[0] - L) + abs(p[1])
    below = [(r, c) for r in range(-8, 1) for c in range(-8, 9)]
    core = [p for p in below if dist(p) <= 7]
    d8 = [p for p in below if dist(p) == 8]
    assert len(core) == 16 and len(d8) == 9
    reached = False
    total_states = 0
    for extra in itertools.combinations(d8, 3):
        army = frozenset(core) | frozenset(extra)
        seen = {army}
        stack = [army]
        while stack:
            s = stack.pop()
            if (L, 0) in s:
                reached = True
            for (r, c) in s:
                for dr, dc in ((0, 1), (0, -1), (1, 0), (-1, 0)):
                    b = (r + dr, c + dc); t = (r + 2 * dr, c + 2 * dc)
                    if b in s and t not in s and dist(t) == dist((r, c)) - 2 and dist(b) == dist((r, c)) - 1:
                        n = (s - {(r, c), b}) | {t}
                        if n not in seen:
                            seen.add(n); stack.append(n)
        total_states += len(seen)
    print("  19-peg check: %d candidate armies, %d positions in all, row 4 reached: %s" % (84, total_states, reached))

def forward_search(army, L, budget, stop_at_first=True):
    """Forward DFS from a given army: all jumps allowed as long as the accumulated weight
    loss stays within budget.  Returns a winning jump list or None."""
    def dist(p): return abs(p[0] - L) + abs(p[1])
    def w(p): return SIG ** dist(p)
    visited = set()
    nodes = [0]
    def dfs(state, loss, path):
        if (L, 0) in state:
            return list(path)
        if state in visited:
            return None
        visited.add(state)
        nodes[0] += 1
        for (r, c) in state:
            for dr, dc in ((1, 0), (0, 1), (0, -1), (-1, 0)):
                b = (r + dr, c + dc); t = (r + 2 * dr, c + 2 * dc)
                if b in state and t not in state:
                    nl = loss + w((r, c)) + w(b) - w(t)
                    if nl > budget + 1e-9:
                        continue
                    path.append(((r, c), b, t))
                    res = dfs((state - {(r, c), b}) | {t}, nl, path)
                    path.pop()
                    if res is not None:
                        return res
        return None
    res = dfs(frozenset(army), 0.0, [])
    return res, nodes[0]

def twenty_search():
    """Candidate 20-armies: any 20-peg army reaching (4,0) has weight >= 1.  The 16 cells at
    distance <= 7 weigh 1 - 3 sigma^8; enumerating how the missing 3 sigma^8 can be made up
    by the other cells gives exactly the families below (sigma^9 + sigma^10 = sigma^8 and
    sigma^7 = sigma^8 + sigma^9 give the ties).  Each army is searched forward with loss
    budget = weight - 1.  Takes about 5 minutes; run with argument C20."""
    L = 4
    def dist(p): return abs(p[0] - L) + abs(p[1])
    def w(p): return SIG ** dist(p)
    below = [(r, c) for r in range(-10, 1) for c in range(-10, 11)]
    core = [p for p in below if dist(p) <= 7]
    d7 = [p for p in below if dist(p) == 7]
    d8 = [p for p in below if dist(p) == 8]
    d9 = [p for p in below if dist(p) == 9]
    d10 = [p for p in below if dist(p) == 10]
    far = [p for p in below if 9 <= dist(p) <= 12]
    C = frozenset(core)
    families = [
        ("1: core16 + four d8", [C | frozenset(x) for x in itertools.combinations(d8, 4)]),
        ("5: core16 minus one d7 + five d8", [(C - {q}) | frozenset(x) for q in d7 for x in itertools.combinations(d8, 5)]),
        ("3: core16 + two d8 + two d9", [C | frozenset(x) | frozenset(y) for x in itertools.combinations(d8, 2)
                                          for y in itertools.combinations(d9, 2)]),
        ("6: core16 minus one d7 + four d8 + one d9", [(C - {q}) | frozenset(x) | {y} for q in d7
                                                        for x in itertools.combinations(d8, 4) for y in d9]),
        ("4: core16 + two d8 + one d9 + one d10", [C | frozenset(x) | {y, z} for x in itertools.combinations(d8, 2)
                                                    for y in d9 for z in d10]),
        ("2: core16 + three d8 + one cell at distance 9..12", [C | frozenset(x) | {f} for x in itertools.combinations(d8, 3)
                                                                for f in far]),
    ]
    def mirror(a): return frozenset((r, -c) for (r, c) in a)
    t0 = time.time()
    for name, armies in families:
        seen = set(); tried = 0; total_nodes = 0
        for army in armies:
            key = min(tuple(sorted(army)), tuple(sorted(mirror(army))))
            if key in seen:
                continue
            seen.add(key)
            W = sum(w(p) for p in army)
            if W < 1 - 1e-9:
                continue
            tried += 1
            res, nodes = forward_search(army, L, W - 1)
            total_nodes += nodes
            if res is not None:
                print("  20-peg army found in family '%s' after %d armies (up to mirror), %d positions, %.1fs"
                      % (name, tried, total_nodes, time.time() - t0))
                return army, res
        print("  family '%s': %d armies of weight >= 1 (up to mirror), %d positions, none reaches row 4 (%.1fs)"
              % (name, tried, total_nodes, time.time() - t0))
    return None, None

# The army found by twenty_search (family 6: it omits the distance-7 cell (-1,-2) and uses
# the distance-9 cell (-2,3)); its weight is exactly 1, so all 19 jumps are geodesic.
ARMY20 = frozenset([(0, c) for c in range(-4, 5)] + [(-1, c) for c in range(-1, 3)] +
                   [(-2, c) for c in range(-1, 4)] + [(-3, 0), (-3, 1)])

def all_minimal_armies(L, m):
    """Every m-peg army (up to mirror) that sends a peg to row L, by weight filter + forward search.
    Only meant for L=2,m=4 and L=3,m=8 (the weight filter leaves few candidates)."""
    def dist(p): return abs(p[0] - L) + abs(p[1])
    def w(p): return SIG ** dist(p)
    below = [(r, c) for r in range(-8, 1) for c in range(-8, 9)]
    below.sort(key=lambda p: -w(p))
    # a cell can only be in a winning army if it plus the m-1 heaviest OTHER cells weigh >= 1
    def others(p):
        lst = [q for q in below if q != p]
        return sum(w(q) for q in lst[:m - 1])
    cand = [p for p in below if w(p) + others(p) >= 1 - 1e-9]
    def mirror(a): return frozenset((r, -c) for (r, c) in a)
    found = []
    seen = set()
    for army in itertools.combinations(cand, m):
        a = frozenset(army)
        if sum(w(p) for p in a) < 1 - 1e-9:
            continue
        key = min(tuple(sorted(a)), tuple(sorted(mirror(a))))
        if key in seen:
            continue
        seen.add(key)
        res, _ = forward_search(a, L, sum(w(p) for p in a) - 1)
        if res is not None:
            found.append((a, res))
    return found, len(cand)

def army_picture(army, L):
    rows = sorted({r for r, c in army}); cols = sorted({c for r, c in army})
    lines = []
    for r in range(0, min(rows) - 1, -1):
        lines.append("row %2d: " % r + " ".join("X" if (r, c) in army else "." for c in range(min(cols), max(cols) + 1)))
    return lines

def part_C():
    print("\n" + "=" * 78)
    print("PART C.  CONWAY'S SOLDIERS (target (L,0); rows <= 0 are below the line)")
    print("=" * 78)
    s = SIG
    print("  sigma = %.6f, sigma^2 + sigma = %.6f" % (s, s * s + s))
    print("  weight of the m heaviest cells below the line, target row L:")
    for L in (1, 2, 3, 4, 5):
        below = [(r, c) for r in range(-12, 1) for c in range(-12, 13)]
        ws = sorted((s ** (abs(r - L) + abs(c)) for (r, c) in below), reverse=True)
        line = "    L=%d: " % L
        for m in (1, 2, 3, 4, 7, 8, 18, 19, 20):
            line += "m=%d:%.4f  " % (m, sum(ws[:m]))
        print(line)
    print("  exact: sigma^4+3sigma^5+5sigma^6+7sigma^7+3sigma^8 = %.12f" % (s**4 + 3*s**5 + 5*s**6 + 7*s**7 + 3*s**8))
    print("  whole half-plane for L=5: sum_{k>=5} sigma^k * (1 + 2 sum_{j>=1} sigma^j) = %.9f" %
          ((s**5 / (1 - s)) * (1 + 2 * s / (1 - s))))
    print("\n  Smallest armies by reverse search:")
    for L, m in [(1, 1), (1, 2), (2, 3), (2, 4), (3, 7), (3, 8)]:
        res = soldiers_search(L, m)
        if res:
            show_army(res[0][0], L, res[0][1])
    print("\n  All smallest armies (up to mirror image):")
    for L, m in [(2, 4), (3, 8)]:
        found, ncand = all_minimal_armies(L, m)
        print("  row %d, %d pegs: %d candidate cells after the weight filter, %d distinct armies:" % (L, m, ncand, len(found)))
        for a, res in found:
            for line in army_picture(a, L):
                print("      " + line)
            print("      jumps: " + "; ".join("(%d,%d)>(%d,%d)>(%d,%d)" % (x + y + z) for x, y, z in res))
            print()
    print("\n  Row 4:")
    t0 = time.time()
    nineteen_check()
    print("  (%.1fs)" % (time.time() - t0))
    print("  The 20-peg army found by the family search (verified again here by a forward search):")
    res, nodes = forward_search(ARMY20, 4, sum(SIG ** (abs(r - 4) + abs(c)) for (r, c) in ARMY20) - 1)
    assert res is not None
    show_army(ARMY20, 4, list(reversed(res)))
    print("  weight of this army = %.9f" % sum(SIG ** (abs(r - 4) + abs(c)) for (r, c) in ARMY20))

def part_C20():
    army, seq = twenty_search()
    if army is not None:
        show_army(army, 4, list(reversed(seq)))

if __name__ == "__main__":
    which = sys.argv[1:] or ["A", "B", "C"]
    if "A" in which: part_A()
    if "B" in which: part_B()
    if "C" in which: part_C()
    if "C20" in which: part_C20()
