# Changes made by the rewriter stage (Week 1, jumping-peg games)

The previous version of all sources is in `before-rewrite/`. Review item numbers refer to `review.md`.
Every new sequence, count and colour test below was re-checked by an exhaustive search before printing
(script in the rewriter's scratch space; the facts it confirmed are listed under "Checked" at the end).

## week-boards.tex

- Item 17: `\StripH`, `\StripV`, `\RectBoard`, `\PlusBoard`, `\ColourStripH` no longer draw the grey dot
  inside a hole cell, so "put a piece on every dot" is exactly the starting position on every board.

## week-k-1.tex (13 pages -> 12 pages)

- Item 24: Problem 5 says "and write that number in the first box" (no instruction to the adult).
- Items 6, 19: old Problems 6 and 7 (3x3, centre hole / edge hole) merged into one page as Problem 6,
  boards 1.25 in with a "jumps" box beside each, wording "point to every jump you could make, then make
  them" (satisfied by "none"). Old 8-13 renumbered 7-12.
- Item 13: Problem 7 (old 8) has a "circles" box beside each board; Problem 12 (old 13) has a "pennies"
  box under the top strip.
- Item 10 (old 11, the 2x3 boards) uses the same "point ... then make them" wording and gets a "jumps"
  box per board.
- Item 43: recording boards of Problems 8, 9 are 0.4 in cells, of Problem 11 0.36 in.
- Item 42: Problem 12 strips are nine cells of 0.78 in (pennies fit); the star stays on 7 / 8.
- Item 7: handled in the guide (share out the X squares of Problem 4 between the three children).
- Layout: label boxes beside boards are raised so each tabular row is exactly the board height
  (otherwise the centred box added depth and pushed the boards to the next page).

## week-grades-2-3.tex (19 pages -> 19 pages)

- Item 3a: Problems 6 and 7 print holes 1-4 only, with "Holes 5, 6 and 7 are holes 3, 2 and 1 seen from the
  other end" / "Holes 5 to 8 are holes 4 to 1 seen from the other end". Problem 10's eight/5 strip became
  eight/4 (counts 2, 3, 2; yes; blue; ends on 2 or 5), so every strip of Problem 10 has a row in the
  child's tables; Problem 11's "eight squares, hole on 4" row (now already in the table) became hole 5
  (counts 3, 2, 2; the colours say red; it ends on 4 or 7), so all four prediction strips are new to the child.
- Item 4: Problem 7 ends with three summary lines (lengths finished / holes that worked / lengths that never could).
- Item 3b/3c: reordered so the printed order is the order the guide's plan follows. New numbering:
  12-14 = soldiers (old 14-16), 15-17 = the army on the strip (old 17-19), 18-19 = the numbered strips
  (old 25-26), 20 = winning games on six/2 (old 21), 21 = blocks (old 20), 22-23 = the square boards
  (old 12-13, now reserves as item 3c asks), 24 = 3x5 (old 24), 25 = the cross (old 23), 26 = rings (new,
  replacing the dead boards of old 22; item 27). Problem 12 states the row/column rule since it is now the
  first square board; Problem 22 restates it.
- Item 27: old Problem 22 (four boards with 0 or 1 jumps) replaced by rings of 5, 6, 7, 8 cells (fewest
  2, 1, 2, 1; checked), a real "which ones can be finished" question; the guide has the lines. The 2x4
  board the review suggested teaches the same "no vertical jumps on two rows" fact as the old boards,
  so I chose the rings instead.
- Item 8: Problem 17 (old 19) has boxes for "different first jumps" and "jumps where there was a choice".
- Item 14: Problem 18 (old 25) says "Leave a column empty if the game ends before it."
- Item 20: Problem 9 prints its own colour strip with the hole on 5.
- Item 25: Problem 2 says "You may not need every strip" and has a "games: __" blank per row.
- Item 30: Problem 4 keeps the mirror fact without the justification.
- Item 41/47: label boxes of the 3x3 page separated (0.9 in boxes, 0.3 in gap); Problem 10's colour blank is 0.8 in.
- Item 42: the ten-cell strips of Problems 15, 16, 17, 21 (old 17-20) are nine cells of 0.78 in; the
  mini strips match. Blocks of 3-6 on the nine-strip still leave 2, 2, 3, 3 at best (checked).
- Layout: Problem 1 strips and the vertical eight-strip are 0.95 in so pages 1 and 5 hold their problems.

## week-grades-4-5.tex (17 pages -> 21 pages)

- Item 3d: reordered exactly as the review specifies. New 1-5 = old 1-5; 6-7 = old 10-11 (soldiers);
  8 = old 14 (numbered strip); 9 = old 16 (the five strips); 10 = old 15 (the explanation); 11 = old 17
  (star-2 weights); 12 = old 19 (whole-number weights for star 4); 13 = old 18 (star-3 weights);
  14-17 = old 6-9; 18-19 = old 12-13; 20-24 unchanged. Every cross-reference updated ("the first board of
  Problem 7", "the strip of Problem 8", "the board of Problem 6", "the weights of Problem 12",
  "your table of Problem 2"). Problem 6 now states the row/column rule (it is the first square board).
- Item 1: Problem 20 says "After jump 16, four soldiers are left, on e5, e6, f6 and g6" (checked by replay).
- Item 2: Problem 21 says every jump brings a soldier two squares closer to the star along its row and
  column, and asks why an army weighing exactly the star cannot afford a jump that does not (checked: all
  nineteen jumps reduce the taxicab distance by 2; six of them are horizontal).
- Item 4: Problem 2 ends with the three summary lines.
- Item 5: the explanation (now Problem 10) comes after the five strips (Problem 9) and starts "Look at the
  five differences in your table."
- Item 9: Problem 16 (old 8) has the six-strip and a four-row table for the second reversal.
- Item 10: Problem 8 (old 14) has a proper before/after table (`\makebox` widths) and three blank
  eight-cell mini strips with a "farthest square" box for part (d).
- Item 11: Problem 9 (old 16) has a fifth column "farthest square".
- Item 12: Problem 12 (old 19) has the line "(c) sixteen soldiers can / cannot reach star 4, because ___".
- Item 15: Problem 24's pre-drawn tree replaced by a 3x4 grid of blank six-cell strips (start position
  given) with "draw your own arrows", so the count is the child's.
- Item 16: Problem 14 (old 6) prints the nine-strip (hole 5) and ten-strip (hole 1) at 0.7 in with
  "Then play them." (0.7 in is the widest a ten-strip can be; the guide tells the adult to use the small
  counters on it).
- Item 18: Problems 6 and 17 state "a jump goes along a row or a column, never diagonally".
- Item 21: "highest star reached" in Problem 18 (old 12), which also says "the fewest soldiers you now
  think star 4 really needs" since it follows the weights.
- Item 22: Problem 22 (b) says to copy the digits of pattern 1 onto the big board and count by digit.
- Item 23: Problem 15 (old 7) asks for "every pair of squares such that each one, used as the hole, can
  end on the other" (no variables).
- Item 30: Problem 1 "The table stops at the middle of each strip."; Problem 15's parenthesis is the bare
  mirror fact.
- Item 42: weight boards are 0.85 in (star 2), 0.8 in (star 3), 0.75 in (star 4); the 4x4 board is 0.85 in
  with 0.38 in pattern diagrams; the five vertical strips are 0.8 in (tallest 8.0 in).
- Item 44: the three recording boards of Problem 7 are seven columns (b-h) at 0.3 in.
- Item 45: Problem 11's table gives the four sums their own row.

## week-facilitator.tex (17 pages -> 19 pages)

- Header and Section 1 carry the new page counts (12 / 19 / 21) and one line per table naming the last
  core problem (K-1: 9, grades 2-3: 14, grades 4-5: 10) and the printed order of the reserves (item 40;
  repeated in each table section with what a child does while others finish).
- Item 26: the launch stops after the stuck four-strip and ends "The empty square is in the wrong place.
  At your table, find where it has to be."; the K-1 timing note says Problem 1 was played in the launch.
- Item 38: materials say pennies fit every cell of 0.78 in and up, name the one exception (the two 0.7 in
  prediction strips of 4-5 Problem 14) and tell the adult to use the small counters there; the crayon
  remark names the small army boards and the farthest square.
- Section 5 (K-1): renumbered 7-12; Problems 6 and 7 merged with both answers and the box values;
  item 7's sharing-out of the X squares added to Problem 4; timing per the review's estimates (36 core).
- Section 6 (grades 2-3): renumbered throughout; timing per item 3c (45 minutes, square boards as
  reserves); item 35 best lines for every failing hole of the six-, seven- and eight-strips; answers for
  the summary lines, the "games" boxes, the empty columns of the numbered strips, the new rows of
  Problems 10 and 11 (with lines for all four prediction strips); item 34 lines for 3x5 holes A and B;
  item 33 lines, game counts and colouring note for the cross; item 32 lines, counts and the reason the
  colours are silent for the rings (new Problem 26). The ring 5 and ring 7 lines leave 2, 4 and 4, 6,
  not 1, 3 and 3, 5 as the review wrote (replayed).
- Section 7 (grades 4-5): rewritten in the new order with the timing of item 3e (Problem 8 must start by
  0:35, which is where that schedule puts it); item 37 hints for star 3; item 35 lines; the new "farthest
  square" answers (5, 8, 13, 21, 34); item 39 ("highest star reached" is the star number, 3 at best);
  item 1 and item 2 answer changes (taxicab "two closer", six horizontal jumps named); item 31 tree of the
  eight-strip from hole 2 (15 complete games, 10 winning, 5 stuck on 2 and 6); item 36 two-left lines on
  the 4x4 for holes A and F; item 32 ring lines; the played answers for the ten/1 and nine/5 strips.
- Item 46: `\newpage` before Section 10 and before "Small boards with one hole", so neither heading is
  stranded. Sections 3, 8, 9 and the reference tables are unchanged.

## Review points not followed exactly

- Item 3b asked only to move the numbered strips next to the army strip; I also moved the two square
  boards (old 12-13) behind them, because item 3c makes them reserves and the review's own principle is
  that the printed order should match the guide's order. The two problems themselves are unchanged.
- Item 27 offered a 2x4 board or dropping the problem; I put rings there instead (see above).
- Item 25 offered printing one strip for the hole-on-1 row; I kept two strips and added the sentence,
  which also matches item 14's "leave a column empty" convention, and added a "games" blank the problem
  asked for without recording space.
- Item 16's two strips are printed at 0.7 in as the review suggested (a ten-strip cannot be wider on the
  page), so item 42's penny-size rule is met by the guide's instruction to use small counters there.

## Checked by exhaustive search before printing

Strips 4-10 (fewest, endings, counts, every quoted line, including the only-game claims for hole 1 of
eight and ten); eight/2 complete-game tree by first three jumps; colour counts of every strip quoted;
blocks of 3-6 on the nine-strip; every army on cells 1-6 of the nine-strip (farthest 7; 3456 has four
games; 1-6 is forced); rings 5-8 (4/12/12/64 complete games, 0/8/0/40 winning, every quoted line);
3x3 (0 / 1 jump; corner: 14 games, fewest 4), 2x3, 2x4; 3x5 lines for A, B, C; 4x4 lines for A, B, F and
fewest 2 for A and F by search; the cross (9 and 32 complete games, the two lines, the colouring
classes); the twenty-soldier sequence (position after jumps 16 and 17, every jump two closer in
taxicab distance, six horizontal); Fibonacci totals 7/8, 12/13, 20/21, 33/34, 54/55 and the forced
plays; the integer weights (twenty-army 144, sixteen heaviest 135, nineteen heaviest 144, rows 79+34+23+8).
