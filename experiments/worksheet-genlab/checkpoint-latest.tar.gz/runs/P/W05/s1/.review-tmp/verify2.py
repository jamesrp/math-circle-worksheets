#!/usr/bin/env python3
"""Replay the narrated soldier sequences in the facilitator guide."""
from verify import make_lines, soldier_board, replay, coord

# K-1 Problem 12 narrative: columns 1..5, rows -1, 0 below the line, 1..3 above (star at (3,3)).
# Map to board rows: row -1 -> 1, row 0 -> 2, row k -> 2+k.  Board: 5 cols, 2 below, 3 above.
cells = soldier_board(5, 2, 3)
lines = set(make_lines(cells))
def rc(row, col):
    return (row + 2, col)
block = [rc(0, 1), rc(0, 2), rc(0, 3), rc(0, 4), rc(0, 5), rc(-1, 1), rc(-1, 2), rc(-1, 3)]
seq = [(rc(-1, 2), rc(0, 2), rc(1, 2)), (rc(-1, 3), rc(0, 3), rc(1, 3)), (rc(0, 5), rc(0, 4), rc(0, 3)),
       (rc(-1, 1), rc(0, 1), rc(1, 1)), (rc(0, 3), rc(1, 3), rc(2, 3)), (rc(1, 1), rc(1, 2), rc(1, 3)),
       (rc(1, 3), rc(2, 3), rc(3, 3))]
end = replay(block, seq, lines)
print("K-1 Problem 12 block narrative ends with:", sorted(end), "(star is (5,3))")

# K-1 Problem 10 narrative (L): three in the row just below the line ending in the star's column, plus one below the end.
cells = soldier_board(5, 2, 2)
lines = set(make_lines(cells))
L = [(2, 1), (2, 2), (2, 3), (1, 3)]
seq = [((1, 3), (2, 3), (3, 3)), ((2, 1), (2, 2), (2, 3)), ((2, 3), (3, 3), (4, 3))]
print("K-1 Problem 10 L narrative ends with:", sorted(replay(L, seq, lines)), "(star is (4,3))")

# Grades 2-3 Problems 14-16: columns 1-5 (star col 3), rows -3..0 below the line; board 7 cols, 4 below, 3 above.
# The guide's narration uses columns 1-5 with the star in column 3; on the printed 7-column board the star is column 4,
# so shift columns by +1.  Rows: -3 -> 1, -2 -> 2, -1 -> 3, 0 -> 4, k -> 4+k.
cells = soldier_board(7, 4, 3)
lines = set(make_lines(cells))
def rc2(row, col):
    return (row + 4, col + 1)
T = [rc2(0, 1), rc2(0, 2), rc2(0, 3), rc2(0, 4), rc2(0, 5), rc2(-1, 3), rc2(-2, 3), rc2(-3, 3)]
seqT = [(rc2(-1, 3), rc2(0, 3), rc2(1, 3)), (rc2(0, 1), rc2(0, 2), rc2(0, 3)), (rc2(0, 3), rc2(1, 3), rc2(2, 3)),
        (rc2(0, 5), rc2(0, 4), rc2(0, 3)), (rc2(-3, 3), rc2(-2, 3), rc2(-1, 3)), (rc2(-1, 3), rc2(0, 3), rc2(1, 3)),
        (rc2(1, 3), rc2(2, 3), rc2(3, 3))]
print("2-3 T narrative ends with:", sorted(replay(T, seqT, lines)), "(star is (7,4))")
B = [rc2(0, 1), rc2(0, 2), rc2(0, 3), rc2(0, 4), rc2(0, 5), rc2(-1, 1), rc2(-1, 2), rc2(-1, 3)]
seqB = [(rc2(-1, 2), rc2(0, 2), rc2(1, 2)), (rc2(-1, 3), rc2(0, 3), rc2(1, 3)), (rc2(0, 5), rc2(0, 4), rc2(0, 3)),
        (rc2(-1, 1), rc2(0, 1), rc2(1, 1)), (rc2(0, 3), rc2(1, 3), rc2(2, 3)), (rc2(1, 1), rc2(1, 2), rc2(1, 3)),
        (rc2(1, 3), rc2(2, 3), rc2(3, 3))]
print("2-3 block narrative ends with:", sorted(replay(B, seqB, lines)), "(star is (7,4))")

# Grades 4-5 Problems 10-13 in board coordinates (9 cols a-i, rows 1-8, star e8 is row 4 above; star 1 = e5, 2 = e6, 3 = e7)
cells = soldier_board(9, 4, 4)
lines = set(make_lines(cells))
def js(s):
    return [tuple(coord(t) for t in j.split('>')) for j in s.split()]
print("4-5 star 1:", sorted(replay([coord('e4'), coord('e3')], js("e3>e4>e5"), lines)))
print("4-5 star 2 L:", sorted(replay([coord(x) for x in "c4 d4 e4 e3".split()], js("e3>e4>e5 c4>d4>e4 e4>e5>e6"), lines)))
print("4-5 star 3 T:", sorted(replay([coord(x) for x in "c4 d4 e4 f4 g4 e3 e2 e1".split()],
                                    js("e3>e4>e5 c4>d4>e4 e4>e5>e6 g4>f4>e4 e1>e2>e3 e3>e4>e5 e5>e6>e7"), lines)))
print("4-5 star 3 block:", sorted(replay([coord(x) for x in "c4 d4 e4 f4 g4 c3 d3 e3".split()],
                                        js("d3>d4>d5 e3>e4>e5 g4>f4>e4 c3>c4>c5 e4>e5>e6 c5>d5>e5 e5>e6>e7"), lines)))
print("(e5 = (5,5), e6 = (6,5), e7 = (7,5))")

# Problem 8 (4-5) six-strip reversal and the K-1 stall idea: star two rows up in the corner column
cells = soldier_board(5, 2, 2)
# star in column 1 instead of 3: build lines on the same board, star at (4,1)
lines = set(make_lines(cells))
Lc = [(2, 1), (2, 2), (2, 3), (1, 1)]
seq = [((1, 1), (2, 1), (3, 1)), ((2, 3), (2, 2), (2, 1)), ((2, 1), (3, 1), (4, 1))]
print("K-1 stall: L against the edge, star at (4,1):", sorted(replay(Lc, seq, lines)))
