#!/usr/bin/env python3
"""Independent recomputation of the claims in the Week 1 packet."""
import sys
from functools import lru_cache
from itertools import combinations
from math import sqrt

sys.setrecursionlimit(100000)

# ---------------------------------------------------------------- generic engine
# A board is a set of cells (tuples). Lines are triples (x, y, z) meaning a peg at x jumps over y into z.

def make_lines(cells):
    cells = set(cells)
    lines = []
    for (r, c) in cells:
        for dr, dc in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            y = (r + dr, c + dc)
            z = (r + 2 * dr, c + 2 * dc)
            if y in cells and z in cells:
                lines.append(((r, c), y, z))
    return lines


def ring_lines(n):
    lines = []
    for i in range(n):
        lines.append((i, (i + 1) % n, (i + 2) % n))
        lines.append((i, (i - 1) % n, (i - 2) % n))
    return lines


def moves(pos, lines):
    return [(x, y, z) for (x, y, z) in lines if x in pos and y in pos and z not in pos]


def apply(pos, m):
    x, y, z = m
    return (pos - {x, y}) | {z}


def analyse(start, lines, count_games=True):
    """Return (fewest left, set of final single cells, number of winning sequences, number of complete games,
    dict of final-count -> number of complete games)."""
    start = frozenset(start)
    memo = {}

    def rec(pos):
        if pos in memo:
            return memo[pos]
        ms = moves(pos, lines)
        if not ms:
            res = (len(pos), frozenset(pos) if len(pos) == 1 else frozenset(), 1 if len(pos) == 1 else 0, 1, {len(pos): 1})
            memo[pos] = res
            return res
        fewest = 10 ** 9
        finals = set()
        wins = 0
        games = 0
        dist = {}
        for m in ms:
            f, fin, w, g, d = rec(apply(pos, m))
            fewest = min(fewest, f)
            finals |= fin
            wins += w
            games += g
            for k, v in d.items():
                dist[k] = dist.get(k, 0) + v
        res = (fewest, frozenset(finals), wins, games, dist)
        memo[pos] = res
        return res

    return rec(start)


def fewest_only(start, lines):
    start = frozenset(start)
    seen = {}

    def rec(pos):
        if pos in seen:
            return seen[pos]
        ms = moves(pos, lines)
        if not ms:
            seen[pos] = len(pos)
            return len(pos)
        best = min(rec(apply(pos, m)) for m in ms)
        seen[pos] = best
        return best

    return rec(start)


def can_reach_cell(start, lines, target):
    """Can some sequence of jumps put a peg on target?"""
    start = frozenset(start)
    seen = set()
    stack = [start]
    while stack:
        pos = stack.pop()
        if target in pos:
            return True
        if pos in seen:
            continue
        seen.add(pos)
        for m in moves(pos, lines):
            stack.append(apply(pos, m))
    return False


def farthest_reached(start, lines, key):
    start = frozenset(start)
    seen = set()
    stack = [start]
    best = max(key(c) for c in start)
    while stack:
        pos = stack.pop()
        if pos in seen:
            continue
        seen.add(pos)
        best = max(best, max(key(c) for c in pos))
        for m in moves(pos, lines):
            stack.append(apply(pos, m))
    return best


def replay(start, seq, lines_set, verbose=False):
    pos = set(start)
    for i, (x, y, z) in enumerate(seq, 1):
        assert (x, y, z) in lines_set, f"jump {i} {x}>{y}>{z} is not a line of the board"
        assert x in pos and y in pos and z not in pos, f"jump {i} {x}>{y}>{z} illegal in position {sorted(pos)}"
        pos = (pos - {x, y}) | {z}
        if verbose:
            print(i, x, y, z, sorted(pos))
    return pos


# ---------------------------------------------------------------- strips
def strip_cells(n):
    return [(0, i) for i in range(1, n + 1)]


def colour_test(n, hole):
    counts = [0, 0, 0]
    for i in range(1, n + 1):
        if i != hole:
            counts[(i - 1) % 3] += 1
    par = [c % 2 for c in counts]
    if par == [0, 0, 0] or par == [1, 1, 1]:
        return "impossible", counts
    odd = [k for k in range(3) if sum(par) == 1 and par[k] == 1] + [k for k in range(3) if sum(par) == 2 and par[k] == 0]
    return "says " + "RBG"[odd[0]], counts


print("=" * 70)
print("STRIPS 3..10, every hole: fewest, ending cells, winning games, complete games, colour test")
strip_results = {}
for n in range(3, 11):
    lines = make_lines(strip_cells(n))
    for h in range(1, n + 1):
        start = [(0, i) for i in range(1, n + 1) if i != h]
        f, fin, w, g, dist = analyse(start, lines)
        ct, counts = colour_test(n, h)
        strip_results[(n, h)] = (f, sorted(c for (_, c) in fin), w, g, dist)
        print(f"n={n:2d} hole={h:2d} fewest={f} ends={sorted(c for (_, c) in fin)} winning={w} games={g} dist={dict(sorted(dist.items()))} colour={ct} {counts}")

print()
print("Which lengths can be finished at all (n=3..14):")
for n in range(3, 15):
    lines = make_lines(strip_cells(n))
    ok = [h for h in range(1, n + 1) if fewest_only([(0, i) for i in range(1, n + 1) if i != h], lines) == 1]
    print(f"  n={n}: holes that finish: {ok}")

# ---------------------------------------------------------------- blocks on a long strip and on the strip of ten
print()
print("Blocks of n pegs on a long empty strip (length 40), fewest left:")
lines40 = make_lines(strip_cells(40))
for n in range(1, 13):
    start = [(0, 15 + i) for i in range(n)]
    print(f"  n={n}: fewest={fewest_only(start, lines40)}")
print("Blocks on the printed strip of ten (grades 2-3 Problem 20): block 4,5,6 / 4..7 / 3..7 / 3..8")
lines10 = make_lines(strip_cells(10))
for cells in ([4, 5, 6], [4, 5, 6, 7], [3, 4, 5, 6, 7], [3, 4, 5, 6, 7, 8]):
    f, fin, w, g, dist = analyse([(0, i) for i in cells], lines10)
    print(f"  block {cells}: fewest={f}, complete games={g}, dist={dict(sorted(dist.items()))}")

# ---------------------------------------------------------------- army on the strip of 10, line after 6
print()
print("Army on strip of 10 (line after 6): farthest cell reachable over all subsets of 1..6; smallest army past line")
best_far = 0
for k in range(1, 7):
    for army in combinations(range(1, 7), k):
        far = farthest_reached([(0, i) for i in army], lines10, key=lambda c: c[1])
        best_far = max(best_far, far)
        if far >= 8:
            print("  !! reaches 8:", army)
print(f"  farthest over all armies: {best_far}")
small = [army for k in range(1, 7) for army in combinations(range(1, 7), k) if farthest_reached([(0, i) for i in army], lines10, key=lambda c: c[1]) >= 7]
print(f"  smallest armies past the line: {[a for a in small if len(a) == min(len(x) for x in small)]}")
f, fin, w, g, dist = analyse([(0, i) for i in (3, 4, 5, 6)], lines10)
print(f"  Problem 18 army 3,4,5,6: complete games={g} dist={dict(sorted(dist.items()))}")
pos = frozenset((0, i) for i in range(1, 7))
seq = []
while moves(pos, lines10):
    ms = moves(pos, lines10)
    seq.append((len(ms), ms))
    pos = apply(pos, ms[0])
print(f"  Problem 19 all six: choices at each step: {[k for k, _ in seq]}, jumps: {[m[0][0][1] for _, m in seq]}, final: {sorted(c for _, c in pos)}")
print("  Army on longer strip (length 20, line after 12), every army on cells 1..12 (k<=12): farthest reachable:")
lines20 = make_lines(strip_cells(20))
best_far = 0
for k in range(1, 13):
    for army in combinations(range(1, 13), k):
        far = farthest_reached([(0, i) for i in army], lines20, key=lambda c: c[1])
        best_far = max(best_far, far)
print(f"    farthest = {best_far} (line after 12)")

# ---------------------------------------------------------------- rectangular boards
def rect(rows, cols):
    return [(r, c) for r in range(1, rows + 1) for c in range(1, cols + 1)]


def letter(rows, cols, cell):
    r, c = cell
    return chr(ord('A') + (r - 1) * cols + (c - 1))


def cell_of(rows, cols, L):
    k = ord(L) - ord('A')
    return (k // cols + 1, k % cols + 1)


print()
print("RECTANGULAR BOARDS, every hole: fewest, ending cells (letters), winning games")
for rows, cols in ((2, 3), (2, 4), (3, 3), (3, 4), (3, 5), (4, 4)):
    cells = rect(rows, cols)
    lines = make_lines(cells)
    for hole in cells:
        start = [c for c in cells if c != hole]
        if (rows, cols) == (4, 4):
            f = fewest_only(start, lines)
            fin = set()
            w = g = None
            dist = {}
        else:
            f, fin, w, g, dist = analyse(start, lines)
        print(f"  {rows}x{cols} hole {letter(rows, cols, hole)}{hole}: fewest={f} ends={sorted(letter(rows, cols, x) for x in fin)} winning={w} games={g} dist={dict(sorted(dist.items()))}")

print()
print("4x4 detail: winning games and ending cells from hole B and hole A, F (this takes a moment)")
cells = rect(4, 4)
lines44 = make_lines(cells)
for L in "B":
    hole = cell_of(4, 4, L)
    f, fin, w, g, dist = analyse([c for c in cells if c != hole], lines44, count_games=False)
    print(f"  4x4 hole {L}: fewest={f} ends={sorted(letter(4, 4, x) for x in fin)} winning games={w}")

# given sequences
def seq_letters(rows, cols, s):
    return [tuple(cell_of(rows, cols, L) for L in j.split('>')) for j in s.split()]


print()
print("Replaying the printed sequences:")
lines34 = set(make_lines(rect(3, 4)))
s = "C>B>A J>F>B A>B>C D>C>B H>G>F E>F>G L>K>J I>J>K K>G>C B>C>D"
end = replay([c for c in rect(3, 4) if c != (1, 1)], seq_letters(3, 4, s), lines34)
print("  3x4 hole A ending on D:", sorted(letter(3, 4, x) for x in end))
s2 = "C>B>A J>F>B A>B>C D>C>B H>G>F E>F>G L>K>J I>J>K K>G>C C>B>A"
end = replay([c for c in rect(3, 4) if c != (1, 1)], seq_letters(3, 4, s2), lines34)
print("  3x4 hole A ending on A:", sorted(letter(3, 4, x) for x in end))
s = "D>C>B A>B>C I>E>A J>F>B B>C>D H>G>F L>K>J J>F>B A>B>C D>C>B"
end = replay([c for c in rect(3, 4) if c != (1, 2)], seq_letters(3, 4, s), lines34)
print("  3x4 hole B:", sorted(letter(3, 4, x) for x in end))
# reversed sequence from hole D
rev = list(reversed(seq_letters(3, 4, "C>B>A J>F>B A>B>C D>C>B H>G>F E>F>G L>K>J I>J>K K>G>C B>C>D")))
end = replay([c for c in rect(3, 4) if c != (1, 4)], rev, lines34)
print("  3x4 hole D, reversed list:", sorted(letter(3, 4, x) for x in end))
lines35 = set(make_lines(rect(3, 5)))
s = "A>B>C D>C>B K>F>A A>B>C L>G>B B>C>D E>D>C I>H>G N>M>L L>G>B B>C>D O>J>E E>D>C"
end = replay([c for c in rect(3, 5) if c != (1, 3)], seq_letters(3, 5, s), lines35)
print("  3x5 hole C:", sorted(letter(3, 5, x) for x in end))
lines44s = set(lines44)
s = "D>C>B A>B>C I>E>A G>F>E A>E>I L>H>D D>C>B M>I>E N>J>F B>F>J K>J>I E>I>M P>O>N M>N>O"
end = replay([c for c in rect(4, 4) if c != (1, 2)], seq_letters(4, 4, s), lines44s)
print("  4x4 hole B:", sorted(letter(4, 4, x) for x in end))
# 3x3 line to four
lines33 = set(make_lines(rect(3, 3)))
s = "C>B>A H>E>B A>B>C G>D>A"
end = replay([c for c in rect(3, 3) if c != (1, 1)], seq_letters(3, 3, s), lines33)
print("  3x3 corner hole, line to four:", sorted(letter(3, 3, x) for x in end))
# strips
def seq_nums(s):
    return [tuple((0, int(k)) for k in j.split('>')) for j in s.split()]


for n, h, s in ((8, 2, "4>3>2 1>2>3 6>5>4 3>4>5 8>7>6 5>6>7"), (8, 2, "4>3>2 1>2>3 6>5>4 3>4>5 8>7>6 6>5>4"),
                (8, 4, "6>5>4 3>4>5 1>2>3 8>7>6 6>5>4 3>4>5"), (8, 4, "6>5>4 3>4>5 1>2>3 8>7>6 6>5>4 4>3>2"),
                (6, 2, "4>3>2 1>2>3 6>5>4 3>4>5"), (6, 2, "4>3>2 1>2>3 6>5>4 4>3>2"),
                (7, 2, "4>3>2 1>2>3 6>5>4 3>4>5"), (6, 1, "3>2>1 5>4>3"), (6, 3, "1>2>3 4>3>2 6>5>4"),
                (5, 1, "3>2>1 5>4>3"), (5, 2, "4>3>2 1>2>3"), (5, 3, "1>2>3 4>3>2"), (5, 3, "5>4>3 2>3>4")):
    ln = set(make_lines(strip_cells(n)))
    end = replay([(0, i) for i in range(1, n + 1) if i != h], seq_nums(s), ln)
    print(f"  strip {n} hole {h}: {s} -> left on {sorted(c for _, c in end)}")
# reversal on strips
for n, h, s in ((8, 4, "6>5>4 8>7>6 3>4>5 6>5>4 1>2>3 4>3>2"), (6, 5, "3>4>5 6>5>4 1>2>3 4>3>2")):
    ln = set(make_lines(strip_cells(n)))
    end = replay([(0, i) for i in range(1, n + 1) if i != h], seq_nums(s), ln)
    print(f"  reversed: strip {n} hole {h}: {s} -> left on {sorted(c for _, c in end)}")

# ---------------------------------------------------------------- plus, cross, rings
print()
plus = [(0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)]
cross = plus + [(2, 0), (-2, 0), (0, 2), (0, -2)]
for name, cells in (("plus", plus), ("cross", cross)):
    lines = make_lines(cells)
    for hole in cells:
        f, fin, w, g, dist = analyse([c for c in cells if c != hole], lines)
        print(f"  {name} hole {hole}: fewest={f} ends={sorted(fin)} winning={w} games={g}")
print("Rings:")
for n in range(3, 13):
    lines = ring_lines(n)
    f, fin, w, g, dist = analyse(list(range(1, n)), lines)
    print(f"  ring {n}: fewest={f} winning sequences={w}")

# ---------------------------------------------------------------- soldiers
def soldier_board(cols, below, above):
    """rows 1..below are below the line; rows below+1..below+above above; star column is the middle."""
    return [(r, c) for r in range(1, below + above + 1) for c in range(1, cols + 1)]


def min_armies(cols, below, above, star_row_above, max_size, exact=None):
    """All armies (subsets of the cells below the line) of size <= max_size that get a soldier onto the star.
    Uses golden-weight pruning: only armies with weight >= 1 - 1e-9 can work."""
    sigma = (sqrt(5) - 1) / 2
    cells = soldier_board(cols, below, above)
    lines = make_lines(cells)
    star = (below + star_row_above, (cols + 1) // 2)
    belowcells = [(r, c) for (r, c) in cells if r <= below]
    w = {c: sigma ** (abs(c[0] - star[0]) + abs(c[1] - star[1])) for c in belowcells}
    belowcells.sort(key=lambda c: -w[c])
    found = {}
    sizes = [exact] if exact else range(1, max_size + 1)
    for k in sizes:
        res = []
        # enumerate subsets of size k with weight >= 1 - eps, pruning by best possible completion
        def rec(idx, chosen, weight):
            if len(chosen) == k:
                if weight >= 1 - 1e-9:
                    if can_reach_cell(chosen, lines, star):
                        res.append(tuple(sorted(chosen)))
                return
            need = k - len(chosen)
            if idx + need > len(belowcells):
                return
            # upper bound on achievable weight
            ub = weight + sum(w[c] for c in belowcells[idx: idx + need])
            if ub < 1 - 1e-9:
                return
            rec(idx + 1, chosen + [belowcells[idx]], weight + w[belowcells[idx]])
            rec(idx + 1, chosen, weight)
        rec(0, [], 0.0)
        found[k] = res
        if res and not exact:
            break
    return found


print()
print("SOLDIERS (K-1 board: 5 cols, 2 rows below)")
for above, star in ((1, 1), (2, 2), (3, 3)):
    found = min_armies(5, 2, above, star, 10)
    for k, res in found.items():
        if res:
            print(f"  star {star} rows up: minimal size {k}, armies: {res}")
print("SOLDIERS (grades 2-3 board: 7 cols, 4 rows below, 3 above)")
for star in (1, 2, 3):
    found = min_armies(7, 4, 3, star, 10)
    for k, res in found.items():
        if res:
            print(f"  star {star}: minimal size {k}, armies (rows from bottom, line above row 4): {res}")
print("SOLDIERS (grades 4-5 board: 9 cols, 4 rows below, 4 above)")
for star in (1, 2, 3):
    found = min_armies(9, 4, 4, star, 10)
    for k, res in found.items():
        if res:
            print(f"  star {star}: minimal size {k}, armies: {res}")

# the twenty-soldier army and its 19 jumps
print()
print("Twenty-soldier army on the 9x8 board (a-i, rows 1-8, star e8):")
def coord(s):
    return (int(s[1]), ord(s[0]) - ord('a') + 1)


army = "a4 b4 c4 d4 e4 f4 g4 h4 i4 d3 e3 f3 g3 d2 e2 f2 g2 h2 e1 f1".split()
jumps = ("e3>e4>e5 e1>e2>e3 c4>d4>e4 a4>b4>c4 d2>d3>d4 e4>e5>e6 f3>f4>f5 f1>f2>f3 c4>d4>e4 e3>e4>e5 "
         "h2>g2>f2 f2>f3>f4 f4>f5>f6 g3>g4>g5 i4>h4>g4 g4>g5>g6 e5>e6>e7 g6>f6>e6 e6>e7>e8").split()
cells98 = soldier_board(9, 4, 4)
lines98 = set(make_lines(cells98))
pos = set(coord(a) for a in army)
assert len(pos) == 20
weights = {}
for (r, c) in cells98:
    d = abs(r - 8) + abs(c - 5)
    fib = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]
    weights[(r, c)] = fib[12 - d]
print("  army weight:", sum(weights[c] for c in pos))
for i, j in enumerate(jumps, 1):
    x, y, z = (coord(s) for s in j.split('>'))
    assert (x, y, z) in lines98, f"jump {i} {j} not a line"
    assert x in pos and y in pos and z not in pos, f"jump {i} {j} illegal; pos={sorted(pos)}"
    pos = (pos - {x, y}) | {z}
    if i == 16:
        above = sorted((r, c) for (r, c) in pos if r >= 5)
        print("  after jump 16, soldiers above the line:", [chr(ord('a') + c - 1) + str(r) for (r, c) in above], "e6 empty:", (6, 5) not in pos)
    assert sum(weights[c] for c in pos) == 144, f"weight changed at jump {i}"
print("  final position:", [chr(ord('a') + c - 1) + str(r) for (r, c) in sorted(pos)])
print("  16 heaviest below line:", sum(sorted((weights[c] for c in cells98 if c[0] <= 4), reverse=True)[:16]),
      " 19 heaviest:", sum(sorted((weights[c] for c in cells98 if c[0] <= 4), reverse=True)[:19]),
      " 20 heaviest:", sum(sorted((weights[c] for c in cells98 if c[0] <= 4), reverse=True)[:20]))

# 19 soldiers cannot reach row 4: on an infinite board only armies of weight 144 matter; those are the 16 cells at
# distance <= 7 plus 3 of the 9 cells at distance 8 (row 0 included). Use a board with 5 rows below and 11 columns.
print("  Checking that no 19-soldier army reaches row 4 (weight-exact armies only; jumps must preserve weight):")
cellsL = [(r, c) for r in range(0, 9) for c in range(0, 12)]  # rows 0..4 below line, 5..8 above; star (8,5)... use col 5
star = (8, 5)
linesL = make_lines(cellsL)
fib = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233]
wL = {}
for (r, c) in cellsL:
    d = abs(r - 8) + abs(c - 5)
    wL[(r, c)] = fib[12 - d] if 12 - d >= 1 else 0
below = [(r, c) for (r, c) in cellsL if r <= 4]
d7 = [x for x in below if abs(x[0] - 8) + abs(x[1] - 5) <= 7]
d8 = [x for x in below if abs(x[0] - 8) + abs(x[1] - 5) == 8]
print("   cells at distance <=7:", len(d7), " at distance 8:", len(d8))
count = 0
reached = 0
for extra in combinations(d8, 3):
    army = frozenset(d7) | frozenset(extra)
    assert sum(wL[c] for c in army) == 144
    count += 1
    # search over weight-preserving jumps only (any other jump drops the weight below 144 forever)
    seen = set()
    stack = [army]
    ok = False
    while stack:
        p = stack.pop()
        if star in p:
            ok = True
            break
        if p in seen:
            continue
        seen.add(p)
        for m in moves(p, linesL):
            q = apply(p, m)
            if sum(wL[c] for c in q) == 144:
                stack.append(q)
    if ok:
        reached += 1
        print("   !! army reaches star:", sorted(army))
print(f"   armies checked: {count}, reaching the star: {reached}")

# ---------------------------------------------------------------- weights
print()
sigma = (sqrt(5) - 1) / 2
print("sigma^d:", [round(sigma ** d, 3) for d in range(10)])
for L in (1, 2, 3, 4):
    ws = sorted((sigma ** (L + r + abs(c)) for r in range(0, 40) for c in range(-40, 41)), reverse=True)
    cum = []
    s = 0
    for m in range(1, 21):
        s += ws[m - 1]
        cum.append(round(s, 3))
    print(f"  L={L}: cumulative weight of m heaviest, m=1..20: {cum}")
print("  half-plane total for L=5:", sum(sigma ** (5 + r + abs(c)) for r in range(0, 200) for c in range(-200, 201)))
print("  row sums for L=5:", [round(sum(sigma ** (5 + r + abs(c)) for c in range(-200, 201)), 3) for r in range(5)])
# decimal sums on the printed boards
def sig3(d):
    return [1.000, 0.618, 0.382, 0.236, 0.146, 0.090, 0.056, 0.034, 0.021, 0.013, 0.008, 0.005, 0.003][d]


L_army = [(3, 1), (3, 2), (3, 3), (2, 3)]
star = (5, 3)
print("  Problem 17 L weight (3-place):", round(sum(sig3(abs(r - 5) + abs(c - 3)) for (r, c) in L_army), 3))
print("  Problem 17 three heaviest below:", round(sum(sorted((sig3(abs(r - 5) + abs(c - 3)) for r in range(1, 4) for c in range(1, 6)), reverse=True)[:3]), 3))
T = [(4, 2), (4, 3), (4, 4), (4, 5), (4, 6), (3, 4), (2, 4), (1, 4)]
Bk = [(4, 2), (4, 3), (4, 4), (4, 5), (4, 6), (3, 2), (3, 3), (3, 4)]
print("  Problem 18 T weight:", round(sum(sig3(abs(r - 7) + abs(c - 4)) for (r, c) in T), 3),
      " block:", round(sum(sig3(abs(r - 7) + abs(c - 4)) for (r, c) in Bk), 3))
print("  Problem 18 seven heaviest:", round(sum(sorted((sig3(abs(r - 7) + abs(c - 4)) for r in range(1, 5) for c in range(1, 8)), reverse=True)[:7]), 3),
      " eight:", round(sum(sorted((sig3(abs(r - 7) + abs(c - 4)) for r in range(1, 5) for c in range(1, 8)), reverse=True)[:8]), 3))
print("  twenty-army with 3-place decimals (star 144 scale):", round(sum(sig3(abs(r - 8) + abs(c - 5)) for (r, c) in
      [coord(a) for a in "a4 b4 c4 d4 e4 f4 g4 h4 i4 d3 e3 f3 g3 d2 e2 f2 g2 h2 e1 f1".split()]), 3))

# ---------------------------------------------------------------- Fibonacci strips
print()
print("Fibonacci strips:")
for labels, line_after in (([1, 1, 2, 3, 5, 8], 4), ([1, 1, 2, 3, 5, 8, 13], 5), ([1, 1, 2, 3, 5, 8, 13, 21], 6),
                           ([1, 1, 2, 3, 5, 8, 13, 21, 34], 7), ([1, 1, 2, 3, 5, 8, 13, 21, 34, 55], 8)):
    n = len(labels)
    lines = make_lines(strip_cells(n))
    start = frozenset((0, i) for i in range(1, line_after + 1))
    total = sum(labels[i - 1] for (_, i) in start)
    # explore all plays, track totals and farthest cell
    seen = set()
    stack = [start]
    maxtot = total
    far = line_after
    star_reached = False
    while stack:
        p = stack.pop()
        if p in seen:
            continue
        seen.add(p)
        t = sum(labels[i - 1] for (_, i) in p)
        maxtot = max(maxtot, t)
        far = max(far, max(i for (_, i) in p))
        if (0, n) in p:
            star_reached = True
        for m in moves(p, lines):
            stack.append(apply(p, m))
    # all armies (subsets) - can any reach the star?
    any_star = any(can_reach_cell([(0, i) for i in army], lines, (0, n))
                   for k in range(1, line_after + 1) for army in combinations(range(1, line_after + 1), k))
    # forced play?
    p = start
    choices = []
    while moves(p, lines):
        ms = moves(p, lines)
        choices.append(len(ms))
        p = apply(p, ms[0])
    print(f"  labels {labels} line after {line_after}: army total {total}, star {labels[-1]}, max total {maxtot}, farthest {far}, star reached (full army) {star_reached}, any army reaches star {any_star}, choices per step {choices}, jumps {len(choices)}")

# ---------------------------------------------------------------- colour tests on rectangles (both diagonal colourings)
print()
print("Diagonal colouring tests (r+c mod 3 and r-c mod 3) for each hole; 'impossible' if either colouring gives all-same parity")
for rows, cols in ((3, 3), (3, 4), (3, 5), (4, 4)):
    cells = rect(rows, cols)
    out = []
    for hole in cells:
        verdicts = []
        for f in (lambda r, c: (r + c) % 3, lambda r, c: (r - c) % 3):
            counts = [0, 0, 0]
            for (r, c) in cells:
                if (r, c) != hole:
                    counts[f(r, c)] += 1
            par = [x % 2 for x in counts]
            verdicts.append("imp" if len(set(par)) == 1 else "ok")
        out.append(f"{letter(rows, cols, hole)}:{'/'.join(verdicts)}")
    print(f"  {rows}x{cols}: {' '.join(out)}")

# 2-3 Problem 10/11 and 4-5 Problem 4 counts
print()
print("Colour counts (R=1,4,7,10; B=2,5,8; G=3,6,9) for the listed strips:")
for n, h in ((4, 1), (4, 2), (5, 1), (5, 2), (5, 3), (6, 1), (6, 2), (6, 3), (7, 1), (7, 2), (7, 4), (7, 7), (8, 1), (8, 2), (8, 3), (8, 4), (8, 5), (8, 6), (8, 8), (10, 1), (9, 5)):
    ct, counts = colour_test(n, h)
    print(f"  n={n} hole={h}: counts={counts} -> {ct}")

# 2-3 Problem 8 count trajectory
print()
print("Six-strip hole 2, counts after each jump of the game 4>3>2, 1>2>3, 6>5>4, 3>4>5:")
pos = set(i for i in range(1, 7) if i != 2)
def counts_of(pos):
    c = [0, 0, 0]
    for i in pos:
        c[(i - 1) % 3] += 1
    return c
print("  start", counts_of(pos), len(pos))
for j in ("4>3>2", "1>2>3", "6>5>4", "3>4>5"):
    x, y, z = map(int, j.split('>'))
    pos = (pos - {x, y}) | {z}
    print(" ", j, counts_of(pos), len(pos))
