#!/usr/bin/env python3
"""Independent recomputation of every numerical claim in the Week 1 packet."""
import itertools, sys
from functools import lru_cache
from collections import Counter, defaultdict

# ---------------------------------------------------------------- generic peg solitaire on a cell set
def make_board(cells):
    """cells: iterable of (r,c). Returns (cells list, index map, list of jumps (x,y,z) as indices)."""
    cells = list(cells)
    idx = {c: i for i, c in enumerate(cells)}
    jumps = []
    for (r, c) in cells:
        for dr, dc in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            y = (r + dr, c + dc); z = (r + 2 * dr, c + 2 * dc)
            if y in idx and z in idx:
                jumps.append((idx[(r, c)], idx[y], idx[z]))
    return cells, idx, jumps

def moves(pos, jumps):
    for (x, y, z) in jumps:
        if (pos >> x) & 1 and (pos >> y) & 1 and not (pos >> z) & 1:
            yield (x, y, z), pos & ~(1 << x) & ~(1 << y) | (1 << z)

def analyse(cells, jumps, start):
    """Exhaustive: fewest pegs left, set of final single cells, number of winning sequences,
       number of complete games (all leaves) with distribution of leftover counts."""
    seen = {}
    # reachable positions and min pegs
    stack = [start]; reach = {start}
    while stack:
        p = stack.pop()
        for _, q in moves(p, jumps):
            if q not in reach:
                reach.add(q); stack.append(q)
    fewest = min(bin(p).count('1') for p in reach)
    finals = {p for p in reach if bin(p).count('1') == 1}
    final_cells = sorted(cells[p.bit_length() - 1] for p in finals)
    # count winning sequences (paths from start to a single peg)
    @lru_cache(maxsize=None)
    def wins(p):
        if bin(p).count('1') == 1:
            return 1
        return sum(wins(q) for _, q in moves(p, jumps))
    nwin = wins(start)
    # count complete games (leaves), by leftover count
    @lru_cache(maxsize=None)
    def leaves(p):
        ms = list(moves(p, jumps))
        if not ms:
            return Counter({bin(p).count('1'): 1})
        tot = Counter()
        for _, q in ms:
            tot.update(leaves(q))
        return tot
    lv = leaves(start)
    return fewest, final_cells, nwin, dict(lv), len(reach)

def full_except(idx, holes):
    p = (1 << len(idx)) - 1
    for h in holes:
        p &= ~(1 << idx[h])
    return p

def colour_test(n, hole):
    counts = [0, 0, 0]
    for k in range(1, n + 1):
        if k != hole:
            counts[(k - 1) % 3] += 1
    par = [x % 2 for x in counts]
    if par == [0, 0, 0] or par == [1, 1, 1]:
        return counts, 'impossible'
    odd_one = [i for i in range(3) if par.count(par[i]) == 1][0]
    return counts, 'says ' + 'RBG'[odd_one]

print('=' * 70); print('STRIPS n=3..10, every hole')
strip_results = {}
for n in range(3, 11):
    cells, idx, jumps = make_board([(0, k) for k in range(1, n + 1)])
    for h in range(1, n + 1):
        start = full_except(idx, [(0, h)])
        fewest, fc, nwin, lv, nreach = analyse(cells, jumps, start)
        ct = colour_test(n, h)
        strip_results[(n, h)] = (fewest, [c for _, c in fc], nwin, lv)
        print(f'n={n} hole={h}: fewest={fewest} ends={[c for _, c in fc]} winning_seqs={nwin} leaves={lv} colour={ct}')

print('=' * 70); print('BLOCK of n pegs in the middle of a long strip (strip length 40)')
for n in range(1, 13):
    L = 40
    cells, idx, jumps = make_board([(0, k) for k in range(1, L + 1)])
    start = 0
    s0 = (L - n) // 2 + 1
    for k in range(s0, s0 + n):
        start |= 1 << idx[(0, k)]
    fewest, fc, nwin, lv, nreach = analyse(cells, jumps, start)
    print(f'block n={n}: fewest={fewest} leaves={lv}')

print('=' * 70); print('BLOCKS on the 10-strip as printed (2-3 Problem 20)')
cells, idx, jumps = make_board([(0, k) for k in range(1, 11)])
for name, ks in [('3 (4-6)', [4, 5, 6]), ('4 (4-7)', [4, 5, 6, 7]), ('5 (3-7)', [3, 4, 5, 6, 7]), ('6 (3-8)', [3, 4, 5, 6, 7, 8])]:
    start = sum(1 << idx[(0, k)] for k in ks)
    fewest, fc, nwin, lv, nreach = analyse(cells, jumps, start)
    print(f'block {name}: fewest={fewest} leaves={lv}')
# games for block of three
def all_games(cells, jumps, start):
    out = []
    def rec(p, path):
        ms = list(moves(p, jumps))
        if not ms:
            out.append((path, sorted(cells[i][1] for i in range(len(cells)) if (p >> i) & 1)))
            return
        for (x, y, z), q in ms:
            rec(q, path + [f'{cells[x][1]}>{cells[y][1]}>{cells[z][1]}'])
    rec(start, [])
    return out
print('block of three games:', all_games(cells, jumps, sum(1 << idx[(0, k)] for k in [4, 5, 6])))
print('five-strip all games:')
cells5, idx5, jumps5 = make_board([(0, k) for k in range(1, 6)])
for h in (1, 2, 3):
    print('  hole', h, all_games(cells5, jumps5, full_except(idx5, [(0, h)])))
print('six-strip hole 2 all games:')
cells6, idx6, jumps6 = make_board([(0, k) for k in range(1, 7)])
print('  ', all_games(cells6, jumps6, full_except(idx6, [(0, 2)])))
print('six-strip hole 1, 3 games:')
for h in (1, 3):
    print('  hole', h, all_games(cells6, jumps6, full_except(idx6, [(0, h)])))
print('seven-strip hole 2 games:')
cells7, idx7, jumps7 = make_board([(0, k) for k in range(1, 8)])
print('  ', all_games(cells7, jumps7, full_except(idx7, [(0, 2)])))
print('four-strip games:')
cells4, idx4, jumps4 = make_board([(0, k) for k in range(1, 5)])
for h in (1, 2, 3, 4):
    print('  hole', h, all_games(cells4, jumps4, full_except(idx4, [(0, h)])))

# ---------------------------------------------------------------- eight-strip specific games
def replay(cells, idx, jumps, start, seq, namer):
    p = start
    for s in seq:
        a, b, c = s
        x, y, z = idx[a], idx[b], idx[c]
        assert (p >> x) & 1 and (p >> y) & 1 and not (p >> z) & 1, f'illegal jump {namer(a)}>{namer(b)}>{namer(c)} at position {[namer(cells[i]) for i in range(len(cells)) if (p>>i)&1]}'
        p = p & ~(1 << x) & ~(1 << y) | (1 << z)
    return [namer(cells[i]) for i in range(len(cells)) if (p >> i) & 1]

def sj(s):  # strip jump string 'a>b>c' -> tuple of cells
    a, b, c = s.split('>')
    return ((0, int(a)), (0, int(b)), (0, int(c)))
cells8, idx8, jumps8 = make_board([(0, k) for k in range(1, 9)])
print('=' * 70); print('EIGHT-STRIP games quoted in the guide')
for hole, seq in [(2, '4>3>2 1>2>3 6>5>4 3>4>5 8>7>6 5>6>7'), (2, '4>3>2 1>2>3 6>5>4 3>4>5 8>7>6 6>5>4'),
                  (4, '6>5>4 3>4>5 1>2>3 8>7>6 6>5>4 3>4>5'), (4, '6>5>4 3>4>5 1>2>3 8>7>6 6>5>4 4>3>2'),
                  (4, '6>5>4 8>7>6 3>4>5 6>5>4 1>2>3 4>3>2')]:
    print(f'  hole {hole}: {seq} -> ends {replay(cells8, idx8, jumps8, full_except(idx8, [(0, hole)]), [sj(s) for s in seq.split()], lambda c: c[1])}')
print('six-strip: hole 2 4>3>2 1>2>3 6>5>4 3>4>5 ->', replay(cells6, idx6, jumps6, full_except(idx6, [(0, 2)]), [sj(s) for s in '4>3>2 1>2>3 6>5>4 3>4>5'.split()], lambda c: c[1]))
print('six-strip: hole 5 reversed 3>4>5 6>5>4 1>2>3 4>3>2 ->', replay(cells6, idx6, jumps6, full_except(idx6, [(0, 5)]), [sj(s) for s in '3>4>5 6>5>4 1>2>3 4>3>2'.split()], lambda c: c[1]))
print('seven-strip hole 2 line 4>3>2 1>2>3 6>5>4 3>4>5 ->', replay(cells7, idx7, jumps7, full_except(idx7, [(0, 2)]), [sj(s) for s in '4>3>2 1>2>3 6>5>4 3>4>5'.split()], lambda c: c[1]))
print('six-strip hole 1 line 3>2>1 5>4>3 ->', replay(cells6, idx6, jumps6, full_except(idx6, [(0, 1)]), [sj(s) for s in '3>2>1 5>4>3'.split()], lambda c: c[1]))
print('six-strip hole 3 line 1>2>3 4>3>2 6>5>4 ->', replay(cells6, idx6, jumps6, full_except(idx6, [(0, 3)]), [sj(s) for s in '1>2>3 4>3>2 6>5>4'.split()], lambda c: c[1]))

# colour counts after each jump on six-strip hole 2
print('=' * 70); print('COLOUR COUNTS six-strip hole 2 jump by jump')
def counts_of(p, cells):
    cnt = [0, 0, 0]
    for i in range(len(cells)):
        if (p >> i) & 1:
            cnt[(cells[i][1] - 1) % 3] += 1
    return cnt
p = full_except(idx6, [(0, 2)])
print('  start', counts_of(p, cells6), 'total', bin(p).count('1'))
for s in ['4>3>2', '1>2>3', '6>5>4', '3>4>5']:
    a, b, c = sj(s)
    p = p & ~(1 << idx6[a]) & ~(1 << idx6[b]) | (1 << idx6[c])
    print(' ', s, counts_of(p, cells6), 'total', bin(p).count('1'))

# ---------------------------------------------------------------- rectangular boards
def letters(rows, cols):
    return {(r, c): chr(ord('A') + (r - 1) * cols + (c - 1)) for r in range(1, rows + 1) for c in range(1, cols + 1)}

def rect_report(rows, cols, holes_to_test=None, count_wins=True):
    cells, idx, jumps = make_board([(r, c) for r in range(1, rows + 1) for c in range(1, cols + 1)])
    L = letters(rows, cols)
    out = {}
    for cell in cells:
        if holes_to_test and L[cell] not in holes_to_test:
            continue
        start = full_except(idx, [cell])
        fewest, fc, nwin, lv, nreach = analyse(cells, jumps, start)
        out[L[cell]] = (fewest, [L[c] for c in fc], nwin, lv)
        print(f'  {rows}x{cols} hole {L[cell]} {cell}: fewest={fewest} ends={[L[c] for c in fc]} winning_seqs={nwin} leaves={lv if len(lv)<8 else "..."} positions={nreach}')
    return out

print('=' * 70); print('2x3'); rect_report(2, 3)
print('2x4'); rect_report(2, 4)
print('3x3'); r33 = rect_report(3, 3)
print('3x4'); r34 = rect_report(3, 4)
print('3x5'); r35 = rect_report(3, 5)
print('4x4'); r44 = rect_report(4, 4)

# specific sequences on rectangles
def lj(s, rows, cols):
    L = letters(rows, cols); inv = {v: k for k, v in L.items()}
    a, b, c = s.split('>')
    return (inv[a], inv[b], inv[c])
print('=' * 70); print('RECTANGLE sequences quoted in the guide')
cells33, idx33, jumps33 = make_board([(r, c) for r in range(1, 4) for c in range(1, 4)])
L33 = letters(3, 3)
print('3x3 corner line C>B>A H>E>B A>B>C G>D>A ->', replay(cells33, idx33, jumps33, full_except(idx33, [(1, 1)]), [lj(s, 3, 3) for s in 'C>B>A H>E>B A>B>C G>D>A'.split()], lambda c: L33[c]))
cells34, idx34, jumps34 = make_board([(r, c) for r in range(1, 4) for c in range(1, 5)])
L34 = letters(3, 4)
seqA = 'C>B>A J>F>B A>B>C D>C>B H>G>F E>F>G L>K>J I>J>K K>G>C B>C>D'
print('3x4 hole A ->', replay(cells34, idx34, jumps34, full_except(idx34, [(1, 1)]), [lj(s, 3, 4) for s in seqA.split()], lambda c: L34[c]))
seqA2 = seqA.rsplit(' ', 1)[0] + ' C>B>A'
print('3x4 hole A (variant) ->', replay(cells34, idx34, jumps34, full_except(idx34, [(1, 1)]), [lj(s, 3, 4) for s in seqA2.split()], lambda c: L34[c]))
seqB = 'D>C>B A>B>C I>E>A J>F>B B>C>D H>G>F L>K>J J>F>B A>B>C D>C>B'
print('3x4 hole B ->', replay(cells34, idx34, jumps34, full_except(idx34, [(1, 2)]), [lj(s, 3, 4) for s in seqB.split()], lambda c: L34[c]))
seqArev = ' '.join(reversed(seqA.split()))
print('3x4 hole D reversed ->', replay(cells34, idx34, jumps34, full_except(idx34, [(1, 4)]), [lj(s, 3, 4) for s in seqArev.split()], lambda c: L34[c]))
cells35, idx35, jumps35 = make_board([(r, c) for r in range(1, 4) for c in range(1, 6)])
L35 = letters(3, 5)
seqC = 'A>B>C D>C>B K>F>A A>B>C L>G>B B>C>D E>D>C I>H>G N>M>L L>G>B B>C>D O>J>E E>D>C'
print('3x5 hole C ->', replay(cells35, idx35, jumps35, full_except(idx35, [(1, 3)]), [lj(s, 3, 5) for s in seqC.split()], lambda c: L35[c]))
cells44, idx44, jumps44 = make_board([(r, c) for r in range(1, 5) for c in range(1, 5)])
L44 = letters(4, 4)
seq44 = 'D>C>B A>B>C I>E>A G>F>E A>E>I L>H>D D>C>B M>I>E N>J>F B>F>J K>J>I E>I>M P>O>N M>N>O'
print('4x4 hole B ->', replay(cells44, idx44, jumps44, full_except(idx44, [(1, 2)]), [lj(s, 4, 4) for s in seq44.split()], lambda c: L44[c]))

# 4x4 diagonal colouring counts
print('4x4 pattern1 (r+c)%3 classes:', {L44[(r, c)]: (r + c) % 3 for r in range(1, 5) for c in range(1, 5)})
print('4x4 pattern2 (r-c)%3 classes:', {L44[(r, c)]: (r - c + 6) % 3 for r in range(1, 5) for c in range(1, 5)})
def diag_counts(rows, cols, hole, sign):
    cnt = [0, 0, 0]
    for r in range(1, rows + 1):
        for c in range(1, cols + 1):
            if (r, c) != hole:
                cnt[(r + sign * c + 9) % 3] += 1
    return cnt
print('4x4 hole A pattern1', diag_counts(4, 4, (1, 1), 1), 'hole F pattern2', diag_counts(4, 4, (2, 2), -1), 'hole F pattern1', diag_counts(4, 4, (2, 2), 1))
print('4x4: which holes are certified impossible by either colouring:')
for r in range(1, 5):
    for c in range(1, 5):
        c1 = diag_counts(4, 4, (r, c), 1); c2 = diag_counts(4, 4, (r, c), -1)
        imp = lambda cnt: len(set(x % 2 for x in cnt)) == 1
        print(f'   {L44[(r,c)]}: p1={c1} {"IMP" if imp(c1) else "silent"}  p2={c2} {"IMP" if imp(c2) else "silent"}   truth fewest={r44[L44[(r,c)]][0]}')
print('3x4 and 3x5 and 3x3: colouring tests per hole')
for rows, cols, res in [(3, 3, r33), (3, 4, r34), (3, 5, r35)]:
    Lx = letters(rows, cols)
    for r in range(1, rows + 1):
        for c in range(1, cols + 1):
            c1 = diag_counts(rows, cols, (r, c), 1); c2 = diag_counts(rows, cols, (r, c), -1)
            imp = lambda cnt: len(set(x % 2 for x in cnt)) == 1
            print(f'   {rows}x{cols} {Lx[(r,c)]}: p1={c1} {"IMP" if imp(c1) else "silent"} p2={c2} {"IMP" if imp(c2) else "silent"} fewest={res[Lx[(r,c)]][0]}')

# ---------------------------------------------------------------- plus and cross
print('=' * 70); print('PLUS (5 cells) and CROSS (9 cells)')
for arm in (1, 2):
    cs = [(r, c) for r in range(-arm, arm + 1) for c in range(-arm, arm + 1) if abs(r) + abs(c) <= arm and (r == 0 or c == 0)]
    cells, idx, jumps = make_board(cs)
    for hole in cs:
        start = full_except(idx, [hole])
        fewest, fc, nwin, lv, nreach = analyse(cells, jumps, start)
        print(f'  arm={arm} hole={hole}: fewest={fewest} ends={fc} wins={nwin} leaves={lv}')

# ---------------------------------------------------------------- rings
print('=' * 70); print('RINGS')
def ring_board(n):
    cells = list(range(n)); idx = {c: c for c in cells}
    jumps = []
    for x in range(n):
        for d in (1, -1):
            y = (x + d) % n; z = (x + 2 * d) % n
            if len({x, y, z}) == 3:
                jumps.append((x, y, z))
    return cells, idx, jumps
for n in range(3, 13):
    cells, idx, jumps = ring_board(n)
    start = ((1 << n) - 1) & ~1
    fewest, fc, nwin, lv, nreach = analyse(cells, jumps, start)
    print(f'  ring n={n}: fewest={fewest} winning_seqs={nwin} leaves={lv if len(lv)<6 else "..."}')

# ---------------------------------------------------------------- soldiers
print('=' * 70); print('SOLDIERS')
def soldier_board(cols, below, above):
    # rows 1..below below the line, rows below+1.. above; star column = middle
    cs = [(r, c) for r in range(1, below + above + 1) for c in range(1, cols + 1)]
    return make_board(cs)

def reach_target(cells, idx, jumps, start, target):
    t = 1 << idx[target]
    stack = [start]; seen = {start}
    while stack:
        p = stack.pop()
        if p & t:
            return True
        for _, q in moves(p, jumps):
            if q not in seen:
                seen.add(q); stack.append(q)
    return False

def min_armies(cols, below, above, star_row_above, max_size):
    cells, idx, jumps = soldier_board(cols, below, above)
    mid = (cols + 1) // 2
    target = (below + star_row_above, mid)
    below_cells = [(r, c) for (r, c) in cells if r <= below]
    for size in range(1, max_size + 1):
        found = []
        for army in itertools.combinations(below_cells, size):
            start = sum(1 << idx[c] for c in army)
            if reach_target(cells, idx, jumps, start, target):
                found.append(army)
        if found:
            return size, found
    return None, []

for (cols, below, above, label) in [(5, 2, 1, 'K-1 P9'), (5, 2, 2, 'K-1 P10'), (7, 4, 3, '2-3 P14'), (9, 4, 4, '4-5 P10')]:
    for star in range(1, above + 1):
        size, armies = min_armies(cols, below, above, star, 8 if star <= 3 else 0)
        print(f'  board {label} ({cols} wide, {below} below): star {star}: min army = {size}, count = {len(armies)}')
        for a in armies:
            print('      ', sorted(a))
# K-1 Problem 12 board: 5 wide, 2 below, 3 above
size, armies = min_armies(5, 2, 3, 3, 8)
print(f'  board K-1 P12 (5 wide, 2 below): star 3: min army = {size}, count = {len(armies)}')
for a in armies:
    print('      ', sorted(a))

# 4-5 star-3 quoted jump lists
def cj(s):
    a, b, c = s.split('>')
    return tuple((int(x[1]), ord(x[0]) - ord('a') + 1) for x in (a, b, c))
cellsS, idxS, jumpsS = soldier_board(9, 4, 4)
def cname(c):
    return chr(ord('a') + c[1] - 1) + str(c[0])
for name, army, seq in [
    ('star1', 'e4 e3', 'e3>e4>e5'),
    ('star2 L', 'c4 d4 e4 e3', 'e3>e4>e5 c4>d4>e4 e4>e5>e6'),
    ('star3 T', 'c4 d4 e4 f4 g4 e3 e2 e1', 'e3>e4>e5 c4>d4>e4 e4>e5>e6 g4>f4>e4 e1>e2>e3 e3>e4>e5 e5>e6>e7'),
    ('star3 block', 'c4 d4 e4 f4 g4 c3 d3 e3', 'd3>d4>d5 e3>e4>e5 g4>f4>e4 c3>c4>c5 e4>e5>e6 c5>d5>e5 e5>e6>e7'),
    ('twenty', 'a4 b4 c4 d4 e4 f4 g4 h4 i4 d3 e3 f3 g3 d2 e2 f2 g2 h2 e1 f1',
     'e3>e4>e5 e1>e2>e3 c4>d4>e4 a4>b4>c4 d2>d3>d4 e4>e5>e6 f3>f4>f5 f1>f2>f3 c4>d4>e4 e3>e4>e5 h2>g2>f2 f2>f3>f4 f4>f5>f6 g3>g4>g5 i4>h4>g4 g4>g5>g6 e5>e6>e7 g6>f6>e6 e6>e7>e8')]:
    start = sum(1 << idxS[(int(a[1]), ord(a[0]) - ord('a') + 1)] for a in army.split())
    seql = [cj(s) for s in seq.split()]
    # print position after jump 16 for the twenty
    if name == 'twenty':
        p = start
        for k, (a, b, c) in enumerate(seql, 1):
            x, y, z = idxS[a], idxS[b], idxS[c]
            assert (p >> x) & 1 and (p >> y) & 1 and not (p >> z) & 1, f'illegal jump {k}'
            p = p & ~(1 << x) & ~(1 << y) | (1 << z)
            if k == 16:
                print('   twenty after jump 16:', sorted(cname(cellsS[i]) for i in range(len(cellsS)) if (p >> i) & 1))
    print(f'  {name}: ends {replay(cellsS, idxS, jumpsS, start, seql, cname)}')

# 19-soldier impossibility on the infinite board, weight-restricted search: 16 cells d<=7 plus 3 of the 9 cells at d=8
print('=' * 70); print('NINETEEN SOLDIERS (weight-exact armies, all jumps, big board)')
# big board: 15 wide, 9 rows below, 4 above; target at row (9+4), col 8
COLS, BELOW, ABOVE = 17, 9, 4
cellsB, idxB, jumpsB = soldier_board(COLS, BELOW, ABOVE)
midB = (COLS + 1) // 2
targetB = (BELOW + 4, midB)
def dist(c):
    return abs(c[0] - targetB[0]) + abs(c[1] - targetB[1])
below_cells = [c for c in cellsB if c[0] <= BELOW]
d_le7 = [c for c in below_cells if dist(c) <= 7]
d_8 = [c for c in below_cells if dist(c) == 8]
print('  cells with d<=7 below the line:', len(d_le7), ' cells with d=8:', len(d_8))
ok = 0; tried = 0
for extra in itertools.combinations(d_8, 3):
    army = d_le7 + list(extra)
    start = sum(1 << idxB[c] for c in army)
    tried += 1
    if reach_target(cellsB, idxB, jumpsB, start, targetB):
        ok += 1; print('   !!! 19-army works:', sorted(army))
print(f'  tried {tried} armies, {ok} reach row 4')

# ---------------------------------------------------------------- 1-D army
print('=' * 70); print('ONE-DIMENSIONAL ARMY on cells 1..6, strip to 10 (2-3 P17, K-1 P13)')
cells10, idx10, jumps10 = make_board([(0, k) for k in range(1, 11)])
best = 0; best_armies = []
smallest_past = None
for size in range(1, 7):
    for army in itertools.combinations(range(1, 7), size):
        start = sum(1 << idx10[(0, k)] for k in army)
        # max cell reached
        stack = [start]; seen = {start}; mx = max(army)
        while stack:
            p = stack.pop()
            for _, q in moves(p, jumps10):
                if q not in seen:
                    seen.add(q); stack.append(q)
                    mx = max(mx, max(k for k in range(1, 11) if (q >> idx10[(0, k)]) & 1))
        if mx > best:
            best = mx; best_armies = [army]
        elif mx == best:
            best_armies.append(army)
        if mx >= 7 and smallest_past is None:
            smallest_past = (size, army)
print('  farthest cell any army reaches:', best, ' smallest army past the line:', smallest_past)
# all games for army 3,4,5,6 on 10-strip
print('  games for army {3,4,5,6}:', all_games(cells10, jumps10, sum(1 << idx10[(0, k)] for k in [3, 4, 5, 6])))
print('  games for army {1..6}:', all_games(cells10, jumps10, sum(1 << idx10[(0, k)] for k in range(1, 7))))
# longer strips and larger armies: k cells left of line, line after k, can any army reach k+2 ?
for k in range(1, 11):
    n = k + 4
    cells, idx, jumps = make_board([(0, j) for j in range(1, n + 1)])
    mx = 0
    for size in range(1, k + 1):
        for army in itertools.combinations(range(1, k + 1), size):
            start = sum(1 << idx[(0, j)] for j in army)
            stack = [start]; seen = {start}
            while stack:
                p = stack.pop()
                for _, q in moves(p, jumps):
                    if q not in seen:
                        seen.add(q); stack.append(q)
                        mx = max(mx, max(j for j in range(1, n + 1) if (q >> idx[(0, j)]) & 1))
    print(f'  k={k}: farthest cell reached = {mx} (line after {k})')

# ---------------------------------------------------------------- Fibonacci strips
print('=' * 70); print('FIBONACCI STRIPS')
def fib_play(labels, army_cells, star_cell):
    n = len(labels)
    cells, idx, jumps = make_board([(0, k) for k in range(1, n + 1)])
    start = sum(1 << idx[(0, k)] for k in army_cells)
    tot = lambda p: sum(labels[k - 1] for k in range(1, n + 1) if (p >> idx[(0, k)]) & 1)
    games = all_games(cells, jumps, start)
    # max total over all reachable positions and whether star reached
    stack = [start]; seen = {start}; mx = tot(start); star = False
    while stack:
        p = stack.pop()
        if (p >> idx[(0, star_cell)]) & 1: star = True
        for _, q in moves(p, jumps):
            if q not in seen:
                seen.add(q); stack.append(q); mx = max(mx, tot(q))
    return tot(start), games, mx, star
for labels, army, star in [([1, 1, 2, 3, 5, 8], [1, 2, 3, 4], 6), ([1, 1, 2, 3, 5, 8, 13], [1, 2, 3, 4, 5], 7),
                           ([1, 1, 2, 3, 5, 8, 13, 21], [1, 2, 3, 4, 5, 6], 8),
                           ([1, 1, 2, 3, 5, 8, 13, 21, 34], list(range(1, 8)), 9), ([1, 1, 2, 3, 5, 8, 13, 21, 34, 55], list(range(1, 9)), 10)]:
    t0, games, mx, star = fib_play(labels, army, star)
    print(f'  labels={labels} army={army}: start total={t0}, star={labels[star-1]}, games={games}, max total={mx}, star reached={star}')
# any army on the 6 squares of the 8-cell fib strip reaching the star (cell 8)?
cells, idx, jumps = make_board([(0, k) for k in range(1, 9)])
anyreach = False
for size in range(1, 7):
    for army in itertools.combinations(range(1, 7), size):
        start = sum(1 << idx[(0, k)] for k in army)
        if reach_target(cells, idx, jumps, start, (0, 8)):
            anyreach = True
print('  any army on 1..6 reaches cell 8 of the 8-strip:', anyreach)

# ---------------------------------------------------------------- weights
print('=' * 70); print('WEIGHTS')
import math
sig = (math.sqrt(5) - 1) / 2
def sigw(d): return [1.000, 0.618, 0.382, 0.236, 0.146, 0.090, 0.056, 0.034, 0.021, 0.013, 0.008, 0.005, 0.003][d]
print('  sigma^d exact:', [round(sig ** d, 4) for d in range(13)])
print('  3-place neighbour sums:', [(sigw(d + 1) + sigw(d + 2), sigw(d)) for d in range(0, 10)])
# heaviest m cells below the line for target row L (infinite board)
def heaviest(L, m, exact=True):
    ds = []
    for r in range(0, 60):
        for c in range(-60, 61):
            ds.append(L + r + abs(c))
    ds.sort()
    if exact:
        return sum(sig ** d for d in ds[:m])
    return sum(sigw(d) for d in ds[:m])
for L, ms in [(1, [1, 2]), (2, [1, 2, 3, 4]), (3, [1, 2, 3, 4, 7, 8]), (4, [16, 18, 19, 20])]:
    print(f'  target row {L}:', [(m, round(heaviest(L, m), 4), round(heaviest(L, m, False), 3)) for m in ms])
# L, T, block, with 3-place decimals
def board_weights(cols, below, above, mode):
    rows = below + above; mid = (cols + 1) // 2
    W = {}
    for r in range(1, rows + 1):
        for c in range(1, cols + 1):
            d = abs(r - rows) + abs(c - mid)
            W[(r, c)] = sigw(d) if mode == 0 else [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144][mode - d]
    return W
W17 = board_weights(5, 3, 2, 0)
Lcells = [(3, 3), (3, 2), (3, 1), (2, 3)]
print('  P17 L weight (3-place):', round(sum(W17[c] for c in Lcells), 3))
print('  P17 three heaviest below line:', round(sum(sorted([W17[c] for c in W17 if c[0] <= 3], reverse=True)[:3]), 3))
W18 = board_weights(7, 4, 3, 0)
Tcells = [(4, 2), (4, 3), (4, 4), (4, 5), (4, 6), (3, 4), (2, 4), (1, 4)]
Bcells = [(4, 2), (4, 3), (4, 4), (4, 5), (4, 6), (3, 2), (3, 3), (3, 4)]
print('  P18 T weight:', round(sum(W18[c] for c in Tcells), 3), ' block weight:', round(sum(W18[c] for c in Bcells), 3))
print('  P18 seven heaviest below line:', round(sum(sorted([W18[c] for c in W18 if c[0] <= 4], reverse=True)[:7]), 3))
print('  P18 eight heaviest below line:', round(sum(sorted([W18[c] for c in W18 if c[0] <= 4], reverse=True)[:8]), 3))
# T play with 3-place decimals: total after each jump
W19 = board_weights(9, 4, 4, 12)
twenty = [(4, c) for c in range(1, 10)] + [(3, 4), (3, 5), (3, 6), (3, 7), (2, 4), (2, 5), (2, 6), (2, 7), (2, 8), (1, 5), (1, 6)]
print('  P19 twenty-army Fibonacci weight:', sum(W19[c] for c in twenty), ' by rows:', [sum(W19[c] for c in twenty if c[0] == r) for r in (4, 3, 2, 1)])
below19 = sorted([W19[c] for c in W19 if c[0] <= 4], reverse=True)
print('  P19 sixteen heaviest:', sum(below19[:16]), ' nineteen heaviest:', sum(below19[:19]), ' twenty:', sum(below19[:20]))
print('  P19 weights row 4..1:', [[W19[(r, c)] for c in range(1, 10)] for r in (8, 7, 6, 5, 4, 3, 2, 1)])
W19d = board_weights(9, 4, 4, 0)
print('  twenty-army in 3-place decimals:', round(sum(W19d[c] for c in twenty), 3))
# does the 20-army printed on the 4-5 board reach with the exact 19 jumps? done above. Every minimal army weighs exactly 1?
print('  exact sigma weights: L', round(sum(sig ** (abs(r - 5) + abs(c - 3)) for (r, c) in Lcells), 6),
      ' T', round(sum(sig ** (abs(r - 7) + abs(c - 4)) for (r, c) in Tcells), 6),
      ' twenty', round(sum(sig ** (abs(r - 8) + abs(c - 5)) for (r, c) in twenty), 6))
print('  fibonacci sum identity F1..Fk = F(k+2)-1:', [(k, sum([1, 1, 2, 3, 5, 8, 13, 21, 34, 55][:k]), [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144][k + 1] - 1) for k in range(1, 9)])
