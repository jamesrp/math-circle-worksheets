import itertools
from collections import Counter
def make_board(cells):
    cells = list(cells); idx = {c: i for i, c in enumerate(cells)}; jumps = []
    for (r, c) in cells:
        for dr, dc in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            y = (r + dr, c + dc); z = (r + 2 * dr, c + 2 * dc)
            if y in idx and z in idx: jumps.append((idx[(r, c)], idx[y], idx[z]))
    return cells, idx, jumps
def moves(pos, jumps):
    for (x, y, z) in jumps:
        if (pos >> x) & 1 and (pos >> y) & 1 and not (pos >> z) & 1:
            yield (x, y, z), pos & ~(1 << x) & ~(1 << y) | (1 << z)
def games(cells, jumps, start, namer):
    out = []
    def rec(p, path):
        ms = list(moves(p, jumps))
        if not ms:
            out.append((path, [namer(cells[i]) for i in range(len(cells)) if (p >> i) & 1])); return
        for (x, y, z), q in ms:
            rec(q, path + [f'{namer(cells[x])}>{namer(cells[y])}>{namer(cells[z])}'])
    rec(start, []); return out
# 8-strip hole 2 winning games grouped by first three jumps
cells, idx, jumps = make_board([(0, k) for k in range(1, 9)])
start = ((1 << 8) - 1) & ~(1 << idx[(0, 2)])
gs = games(cells, jumps, start, lambda c: str(c[1]))
wins = [g for g in gs if len(g[1]) == 1]
print('8-strip hole 2: complete games', len(gs), 'winning', len(wins))
grp = Counter(tuple(g[0][:3]) for g in wins)
for k, v in sorted(grp.items()): print('  first three', k, '->', v, 'winning games')
for g in wins: print('   ', ' '.join(g[0]), 'ends', g[1])
# non-winning games from hole 2 on eight
for g in gs:
    if len(g[1]) > 1: print('   stuck:', ' '.join(g[0]), 'left', g[1])
# 8-strip hole 1 (4 left) and hole 3 (3 left) sample lines
for h in (1, 3):
    start = ((1 << 8) - 1) & ~(1 << idx[(0, h)])
    gs = games(cells, jumps, start, lambda c: str(c[1]))
    best = min(gs, key=lambda g: len(g[1]))
    print(f'8-strip hole {h}: best line', ' '.join(best[0]), 'left', best[1], ' (all games:', len(gs), ')')
# 7-strip hole 1 (3 left)
cells7, idx7, jumps7 = make_board([(0, k) for k in range(1, 8)])
for h in (1, 3, 4):
    start = ((1 << 7) - 1) & ~(1 << idx7[(0, h)])
    gs = games(cells7, jumps7, start, lambda c: str(c[1]))
    best = min(gs, key=lambda g: len(g[1]))
    print(f'7-strip hole {h}: best line', ' '.join(best[0]), 'left', best[1], ' (games:', len(gs), ')')
# rings 6 and 8: one winning sequence
def ring_board(n):
    cells = list(range(n)); idx = {c: c for c in cells}; jumps = []
    for x in range(n):
        for d in (1, -1):
            y = (x + d) % n; z = (x + 2 * d) % n
            if len({x, y, z}) == 3: jumps.append((x, y, z))
    return cells, idx, jumps
for n in (5, 6, 7, 8):
    cells, idx, jumps = ring_board(n)
    start = ((1 << n) - 1) & ~1
    def rec(p, path):
        ms = list(moves(p, jumps))
        if not ms: return (path, [i for i in range(n) if (p >> i) & 1])
        best = None
        for (x, y, z), q in ms:
            r = rec(q, path + [f'{x+1}>{y+1}>{z+1}'])
            if best is None or len(r[1]) < len(best[1]): best = r
        return best
    print(f'ring {n} (cells 1..{n} clockwise, hole on 1): best', rec(start, []))
# cross: hole at end of arm and centre: best lines and number of complete games
cs = [(r, c) for r in range(-2, 3) for c in range(-2, 3) if abs(r) + abs(c) <= 2 and (r == 0 or c == 0)]
cells, idx, jumps = make_board(cs)
name = {(0,0):'centre',(0,1):'right1',(0,2):'right2',(0,-1):'left1',(0,-2):'left2',(1,0):'up1',(2,0):'up2',(-1,0):'down1',(-2,0):'down2'}
for hole in [(0, 2), (0, 0)]:
    start = ((1 << 9) - 1) & ~(1 << idx[hole])
    gs = games(cells, jumps, start, lambda c: name[c])
    best = min(gs, key=lambda g: len(g[1]))
    print(f'cross hole {name[hole]}: games {len(gs)}, leftover counts {Counter(len(g[1]) for g in gs)}, best line', best)
# 3x5 holes A and B best lines
def letters(rows, cols): return {(r, c): chr(ord('A') + (r - 1) * cols + (c - 1)) for r in range(1, rows + 1) for c in range(1, cols + 1)}
cells, idx, jumps = make_board([(r, c) for r in range(1, 4) for c in range(1, 6)])
L = letters(3, 5)
for hole in [(1, 1), (1, 2)]:
    start = ((1 << 15) - 1) & ~(1 << idx[hole])
    # DFS for a 2-left line
    found = None
    def rec(p, path):
        global found
        if found: return
        ms = list(moves(p, jumps))
        if not ms:
            if bin(p).count('1') == 2: found = (path, [L[cells[i]] for i in range(15) if (p >> i) & 1])
            return
        for (x, y, z), q in ms: rec(q, path + [f'{L[cells[x]]}>{L[cells[y]]}>{L[cells[z]]}'])
    rec(start, [])
    print(f'3x5 hole {L[hole]}: a 2-left line', found)
# 3x3 corner: all 14 games
cells, idx, jumps = make_board([(r, c) for r in range(1, 4) for c in range(1, 4)])
L = letters(3, 3)
gs = games(cells, jumps, ((1 << 9) - 1) & ~1, lambda c: L[c])
print('3x3 corner A games:', len(gs)); [print('   ', ' '.join(g[0]), 'left', g[1]) for g in gs]
# 4x4 hole F: best 2-left line
cells, idx, jumps = make_board([(r, c) for r in range(1, 5) for c in range(1, 5)])
L = letters(4, 4)
found = None
def rec2(p, path):
    global found
    if found: return
    ms = list(moves(p, jumps))
    if not ms:
        if bin(p).count('1') == 2: found = (path, [L[cells[i]] for i in range(16) if (p >> i) & 1])
        return
    for (x, y, z), q in ms: rec2(q, path + [f'{L[cells[x]]}>{L[cells[y]]}>{L[cells[z]]}'])
for hole in [(1, 1), (2, 2)]:
    found = None; rec2(((1 << 16) - 1) & ~(1 << idx[hole]), [])
    print(f'4x4 hole {L[hole]}: a 2-left line', found)
