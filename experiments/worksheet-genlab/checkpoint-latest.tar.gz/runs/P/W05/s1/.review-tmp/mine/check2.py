#!/usr/bin/env python3
"""Independent recomputation of every numerical claim in the Week 1 packet."""
import itertools, sys
from functools import lru_cache
from collections import Counter, defaultdict

# ---------------------------------------------------------------- generic peg solitaire on a cell set
def make_board(cells):
    """cells: iterable of (r,c). Returns (cells list, index map, list of jumps (x,y,z) as indices)."""
    cells = list(cells)
    idx = {c: i for i, c in enumerate(cells)}
    jumps = []
    for (r, c) in cells:
        for dr, dc in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            y = (r + dr, c + dc); z = (r + 2 * dr, c + 2 * dc)
            if y in idx and z in idx:
                jumps.append((idx[(r, c)], idx[y], idx[z]))
    return cells, idx, jumps

def moves(pos, jumps):
    for (x, y, z) in jumps:
        if (pos >> x) & 1 and (pos >> y) & 1 and not (pos >> z) & 1:
            yield (x, y, z), pos & ~(1 << x) & ~(1 << y) | (1 << z)

def analyse(cells, jumps, start):
    """Exhaustive: fewest pegs left, set of final single cells, number of winning sequences,
       number of complete games (all leaves) with distribution of leftover counts."""
    seen = {}
    # reachable positions and min pegs
    stack = [start]; reach = {start}
    while stack:
        p = stack.pop()
        for _, q in moves(p, jumps):
            if q not in reach:
                reach.add(q); stack.append(q)
    fewest = min(bin(p).count('1') for p in reach)
    finals = {p for p in reach if bin(p).count('1') == 1}
    final_cells = sorted(cells[p.bit_length() - 1] for p in finals)
    # count winning sequences (paths from start to a single peg)
    @lru_cache(maxsize=None)
    def wins(p):
        if bin(p).count('1') == 1:
            return 1
        return sum(wins(q) for _, q in moves(p, jumps))
    nwin = wins(start)
    # count complete games (leaves), by leftover count
    @lru_cache(maxsize=None)
    def leaves(p):
        ms = list(moves(p, jumps))
        if not ms:
            return Counter({bin(p).count('1'): 1})
        tot = Counter()
        for _, q in ms:
            tot.update(leaves(q))
        return tot
    lv = leaves(start)
    return fewest, final_cells, nwin, dict(lv), len(reach)

def full_except(idx, holes):
    p = (1 << len(idx)) - 1
    for h in holes:
        p &= ~(1 << idx[h])
    return p

def colour_test(n, hole):
    counts = [0, 0, 0]
    for k in range(1, n + 1):
        if k != hole:
            counts[(k - 1) % 3] += 1
    par = [x % 2 for x in counts]
    if par == [0, 0, 0] or par == [1, 1, 1]:
        return counts, 'impossible'
    odd_one = [i for i in range(3) if par.count(par[i]) == 1][0]
    return counts, 'says ' + 'RBG'[odd_one]


def replay(cells, idx, jumps, start, seq, namer):
    p = start
    for s in seq:
        a, b, c = s
        x, y, z = idx[a], idx[b], idx[c]
        assert (p >> x) & 1 and (p >> y) & 1 and not (p >> z) & 1, f'illegal jump {namer(a)}>{namer(b)}>{namer(c)} at position {[namer(cells[i]) for i in range(len(cells)) if (p>>i)&1]}'
        p = p & ~(1 << x) & ~(1 << y) | (1 << z)
    return [namer(cells[i]) for i in range(len(cells)) if (p >> i) & 1]

def all_games(cells, jumps, start):
    out = []
    def rec(p, path):
        ms = list(moves(p, jumps))
        if not ms:
            out.append((path, sorted(cells[i][1] for i in range(len(cells)) if (p >> i) & 1)))
            return
        for (x, y, z), q in ms:
            rec(q, path + [f'{cells[x][1]}>{cells[y][1]}>{cells[z][1]}'])
    rec(start, [])
    return out

print('=' * 70); print('SOLDIERS')
def soldier_board(cols, below, above):
    # rows 1..below below the line, rows below+1.. above; star column = middle
    cs = [(r, c) for r in range(1, below + above + 1) for c in range(1, cols + 1)]
    return make_board(cs)

def reach_target(cells, idx, jumps, start, target):
    t = 1 << idx[target]
    stack = [start]; seen = {start}
    while stack:
        p = stack.pop()
        if p & t:
            return True
        for _, q in moves(p, jumps):
            if q not in seen:
                seen.add(q); stack.append(q)
    return False


import math
SIG = (math.sqrt(5) - 1) / 2
def min_armies(cols, below, above, star_row_above, max_size):
    """All armies of minimum size reaching the star, using the golden-weight bound to prune subsets."""
    cells, idx, jumps = soldier_board(cols, below, above)
    mid = (cols + 1) // 2
    target = (below + star_row_above, mid)
    below_cells = [(r, c) for (r, c) in cells if r <= below]
    w = {c: SIG ** (abs(c[0] - target[0]) + abs(c[1] - target[1])) for c in below_cells}
    order = sorted(below_cells, key=lambda c: -w[c])
    for size in range(1, max_size + 1):
        found = []
        # enumerate subsets of given size with total weight >= 1 - 1e-9 (necessary condition)
        def rec(start_i, chosen, tot):
            if len(chosen) == size:
                if tot >= 1 - 1e-9:
                    s = sum(1 << idx[c] for c in chosen)
                    if reach_target(cells, idx, jumps, s, target):
                        found.append(tuple(chosen))
                return
            need = size - len(chosen)
            for i in range(start_i, len(order)):
                # upper bound: add the next 'need' heaviest available
                ub = tot + sum(w[order[j]] for j in range(i, min(i + need, len(order))))
                if ub < 1 - 1e-9:
                    break
                chosen.append(order[i]); rec(i + 1, chosen, tot + w[order[i]]); chosen.pop()
        rec(0, [], 0.0)
        if found:
            return size, found
    return None, []

for (cols, below, above, label) in [(5, 2, 1, 'K-1 P9'), (5, 2, 2, 'K-1 P10'), (7, 4, 3, '2-3 P14'), (9, 4, 4, '4-5 P10')]:
    for star in range(1, above + 1):
        size, armies = min_armies(cols, below, above, star, 8 if star <= 3 else 0)
        print(f'  board {label} ({cols} wide, {below} below): star {star}: min army = {size}, count = {len(armies)}')
        for a in armies:
            print('      ', sorted(a))
# K-1 Problem 12 board: 5 wide, 2 below, 3 above
size, armies = min_armies(5, 2, 3, 3, 8)
print(f'  board K-1 P12 (5 wide, 2 below): star 3: min army = {size}, count = {len(armies)}')
for a in armies:
    print('      ', sorted(a))

# 4-5 star-3 quoted jump lists
def cj(s):
    a, b, c = s.split('>')
    return tuple((int(x[1]), ord(x[0]) - ord('a') + 1) for x in (a, b, c))
cellsS, idxS, jumpsS = soldier_board(9, 4, 4)
def cname(c):
    return chr(ord('a') + c[1] - 1) + str(c[0])
for name, army, seq in [
    ('star1', 'e4 e3', 'e3>e4>e5'),
    ('star2 L', 'c4 d4 e4 e3', 'e3>e4>e5 c4>d4>e4 e4>e5>e6'),
    ('star3 T', 'c4 d4 e4 f4 g4 e3 e2 e1', 'e3>e4>e5 c4>d4>e4 e4>e5>e6 g4>f4>e4 e1>e2>e3 e3>e4>e5 e5>e6>e7'),
    ('star3 block', 'c4 d4 e4 f4 g4 c3 d3 e3', 'd3>d4>d5 e3>e4>e5 g4>f4>e4 c3>c4>c5 e4>e5>e6 c5>d5>e5 e5>e6>e7'),
    ('twenty', 'a4 b4 c4 d4 e4 f4 g4 h4 i4 d3 e3 f3 g3 d2 e2 f2 g2 h2 e1 f1',
     'e3>e4>e5 e1>e2>e3 c4>d4>e4 a4>b4>c4 d2>d3>d4 e4>e5>e6 f3>f4>f5 f1>f2>f3 c4>d4>e4 e3>e4>e5 h2>g2>f2 f2>f3>f4 f4>f5>f6 g3>g4>g5 i4>h4>g4 g4>g5>g6 e5>e6>e7 g6>f6>e6 e6>e7>e8')]:
    start = sum(1 << idxS[(int(a[1]), ord(a[0]) - ord('a') + 1)] for a in army.split())
    seql = [cj(s) for s in seq.split()]
    # print position after jump 16 for the twenty
    if name == 'twenty':
        p = start
        for k, (a, b, c) in enumerate(seql, 1):
            x, y, z = idxS[a], idxS[b], idxS[c]
            assert (p >> x) & 1 and (p >> y) & 1 and not (p >> z) & 1, f'illegal jump {k}'
            p = p & ~(1 << x) & ~(1 << y) | (1 << z)
            if k == 16:
                print('   twenty after jump 16:', sorted(cname(cellsS[i]) for i in range(len(cellsS)) if (p >> i) & 1))
    print(f'  {name}: ends {replay(cellsS, idxS, jumpsS, start, seql, cname)}')

# 19-soldier impossibility on the infinite board, weight-restricted search: 16 cells d<=7 plus 3 of the 9 cells at d=8
print('=' * 70); print('NINETEEN SOLDIERS (weight-exact armies, all jumps, big board)')
# big board: 15 wide, 9 rows below, 4 above; target at row (9+4), col 8
COLS, BELOW, ABOVE = 17, 9, 4
cellsB, idxB, jumpsB = soldier_board(COLS, BELOW, ABOVE)
midB = (COLS + 1) // 2
targetB = (BELOW + 4, midB)
def dist(c):
    return abs(c[0] - targetB[0]) + abs(c[1] - targetB[1])
below_cells = [c for c in cellsB if c[0] <= BELOW]
d_le7 = [c for c in below_cells if dist(c) <= 7]
d_8 = [c for c in below_cells if dist(c) == 8]
print('  cells with d<=7 below the line:', len(d_le7), ' cells with d=8:', len(d_8))
ok = 0; tried = 0
for extra in itertools.combinations(d_8, 3):
    army = d_le7 + list(extra)
    start = sum(1 << idxB[c] for c in army)
    tried += 1
    if reach_target(cellsB, idxB, jumpsB, start, targetB):
        ok += 1; print('   !!! 19-army works:', sorted(army))
print(f'  tried {tried} armies, {ok} reach row 4')

# ---------------------------------------------------------------- 1-D army
print('=' * 70); print('ONE-DIMENSIONAL ARMY on cells 1..6, strip to 10 (2-3 P17, K-1 P13)')
cells10, idx10, jumps10 = make_board([(0, k) for k in range(1, 11)])
best = 0; best_armies = []
smallest_past = None
for size in range(1, 7):
    for army in itertools.combinations(range(1, 7), size):
        start = sum(1 << idx10[(0, k)] for k in army)
        # max cell reached
        stack = [start]; seen = {start}; mx = max(army)
        while stack:
            p = stack.pop()
            for _, q in moves(p, jumps10):
                if q not in seen:
                    seen.add(q); stack.append(q)
                    mx = max(mx, max(k for k in range(1, 11) if (q >> idx10[(0, k)]) & 1))
        if mx > best:
            best = mx; best_armies = [army]
        elif mx == best:
            best_armies.append(army)
        if mx >= 7 and smallest_past is None:
            smallest_past = (size, army)
print('  farthest cell any army reaches:', best, ' smallest army past the line:', smallest_past)
# all games for army 3,4,5,6 on 10-strip
print('  games for army {3,4,5,6}:', all_games(cells10, jumps10, sum(1 << idx10[(0, k)] for k in [3, 4, 5, 6])))
print('  games for army {1..6}:', all_games(cells10, jumps10, sum(1 << idx10[(0, k)] for k in range(1, 7))))
# longer strips and larger armies: k cells left of line, line after k, can any army reach k+2 ?
for k in range(1, 11):
    n = k + 4
    cells, idx, jumps = make_board([(0, j) for j in range(1, n + 1)])
    mx = 0
    for size in range(1, k + 1):
        for army in itertools.combinations(range(1, k + 1), size):
            start = sum(1 << idx[(0, j)] for j in army)
            stack = [start]; seen = {start}
            while stack:
                p = stack.pop()
                for _, q in moves(p, jumps):
                    if q not in seen:
                        seen.add(q); stack.append(q)
                        mx = max(mx, max(j for j in range(1, n + 1) if (q >> idx[(0, j)]) & 1))
    print(f'  k={k}: farthest cell reached = {mx} (line after {k})')

# ---------------------------------------------------------------- Fibonacci strips
print('=' * 70); print('FIBONACCI STRIPS')
def fib_play(labels, army_cells, star_cell):
    n = len(labels)
    cells, idx, jumps = make_board([(0, k) for k in range(1, n + 1)])
    start = sum(1 << idx[(0, k)] for k in army_cells)
    tot = lambda p: sum(labels[k - 1] for k in range(1, n + 1) if (p >> idx[(0, k)]) & 1)
    games = all_games(cells, jumps, start)
    # max total over all reachable positions and whether star reached
    stack = [start]; seen = {start}; mx = tot(start); star = False
    while stack:
        p = stack.pop()
        if (p >> idx[(0, star_cell)]) & 1: star = True
        for _, q in moves(p, jumps):
            if q not in seen:
                seen.add(q); stack.append(q); mx = max(mx, tot(q))
    return tot(start), games, mx, star
for labels, army, star in [([1, 1, 2, 3, 5, 8], [1, 2, 3, 4], 6), ([1, 1, 2, 3, 5, 8, 13], [1, 2, 3, 4, 5], 7),
                           ([1, 1, 2, 3, 5, 8, 13, 21], [1, 2, 3, 4, 5, 6], 8),
                           ([1, 1, 2, 3, 5, 8, 13, 21, 34], list(range(1, 8)), 9), ([1, 1, 2, 3, 5, 8, 13, 21, 34, 55], list(range(1, 9)), 10)]:
    t0, games, mx, star = fib_play(labels, army, star)
    print(f'  labels={labels} army={army}: start total={t0}, star={labels[star-1]}, games={games}, max total={mx}, star reached={star}')
# any army on the 6 squares of the 8-cell fib strip reaching the star (cell 8)?
cells, idx, jumps = make_board([(0, k) for k in range(1, 9)])
anyreach = False
for size in range(1, 7):
    for army in itertools.combinations(range(1, 7), size):
        start = sum(1 << idx[(0, k)] for k in army)
        if reach_target(cells, idx, jumps, start, (0, 8)):
            anyreach = True
print('  any army on 1..6 reaches cell 8 of the 8-strip:', anyreach)

# ---------------------------------------------------------------- weights
print('=' * 70); print('WEIGHTS')
import math
sig = (math.sqrt(5) - 1) / 2
def sigw(d): return [1.000, 0.618, 0.382, 0.236, 0.146, 0.090, 0.056, 0.034, 0.021, 0.013, 0.008, 0.005, 0.003][d]
print('  sigma^d exact:', [round(sig ** d, 4) for d in range(13)])
print('  3-place neighbour sums:', [(sigw(d + 1) + sigw(d + 2), sigw(d)) for d in range(0, 10)])
# heaviest m cells below the line for target row L (infinite board)
def heaviest(L, m, exact=True):
    ds = []
    for r in range(0, 60):
        for c in range(-60, 61):
            ds.append(L + r + abs(c))
    ds.sort()
    if exact:
        return sum(sig ** d for d in ds[:m])
    return sum(sigw(d) for d in ds[:m])
for L, ms in [(1, [1, 2]), (2, [1, 2, 3, 4]), (3, [1, 2, 3, 4, 7, 8]), (4, [16, 18, 19, 20])]:
    print(f'  target row {L}:', [(m, round(heaviest(L, m), 4), round(heaviest(L, m, False), 3)) for m in ms])
# L, T, block, with 3-place decimals
def board_weights(cols, below, above, mode):
    rows = below + above; mid = (cols + 1) // 2
    W = {}
    for r in range(1, rows + 1):
        for c in range(1, cols + 1):
            d = abs(r - rows) + abs(c - mid)
            W[(r, c)] = sigw(d) if mode == 0 else [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144][mode - d]
    return W
W17 = board_weights(5, 3, 2, 0)
Lcells = [(3, 3), (3, 2), (3, 1), (2, 3)]
print('  P17 L weight (3-place):', round(sum(W17[c] for c in Lcells), 3))
print('  P17 three heaviest below line:', round(sum(sorted([W17[c] for c in W17 if c[0] <= 3], reverse=True)[:3]), 3))
W18 = board_weights(7, 4, 3, 0)
Tcells = [(4, 2), (4, 3), (4, 4), (4, 5), (4, 6), (3, 4), (2, 4), (1, 4)]
Bcells = [(4, 2), (4, 3), (4, 4), (4, 5), (4, 6), (3, 2), (3, 3), (3, 4)]
print('  P18 T weight:', round(sum(W18[c] for c in Tcells), 3), ' block weight:', round(sum(W18[c] for c in Bcells), 3))
print('  P18 seven heaviest below line:', round(sum(sorted([W18[c] for c in W18 if c[0] <= 4], reverse=True)[:7]), 3))
print('  P18 eight heaviest below line:', round(sum(sorted([W18[c] for c in W18 if c[0] <= 4], reverse=True)[:8]), 3))
# T play with 3-place decimals: total after each jump
W19 = board_weights(9, 4, 4, 12)
twenty = [(4, c) for c in range(1, 10)] + [(3, 4), (3, 5), (3, 6), (3, 7), (2, 4), (2, 5), (2, 6), (2, 7), (2, 8), (1, 5), (1, 6)]
print('  P19 twenty-army Fibonacci weight:', sum(W19[c] for c in twenty), ' by rows:', [sum(W19[c] for c in twenty if c[0] == r) for r in (4, 3, 2, 1)])
below19 = sorted([W19[c] for c in W19 if c[0] <= 4], reverse=True)
print('  P19 sixteen heaviest:', sum(below19[:16]), ' nineteen heaviest:', sum(below19[:19]), ' twenty:', sum(below19[:20]))
print('  P19 weights row 4..1:', [[W19[(r, c)] for c in range(1, 10)] for r in (8, 7, 6, 5, 4, 3, 2, 1)])
W19d = board_weights(9, 4, 4, 0)
print('  twenty-army in 3-place decimals:', round(sum(W19d[c] for c in twenty), 3))
# does the 20-army printed on the 4-5 board reach with the exact 19 jumps? done above. Every minimal army weighs exactly 1?
print('  exact sigma weights: L', round(sum(sig ** (abs(r - 5) + abs(c - 3)) for (r, c) in Lcells), 6),
      ' T', round(sum(sig ** (abs(r - 7) + abs(c - 4)) for (r, c) in Tcells), 6),
      ' twenty', round(sum(sig ** (abs(r - 8) + abs(c - 5)) for (r, c) in twenty), 6))
print('  fibonacci sum identity F1..Fk = F(k+2)-1:', [(k, sum([1, 1, 2, 3, 5, 8, 13, 21, 34, 55][:k]), [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144][k + 1] - 1) for k in range(1, 9)])
