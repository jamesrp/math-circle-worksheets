# Changes made by the rewriter stage (Week 1, Jumping pegs)

The previous version of the four sources (plus `week-boards.tex`, which is `\input` by all of them and was not changed) is in `before-rewrite/`. All four files compile with `pdflatex -interaction=nonstopmode` with no errors and no overfull/underfull warnings; every rendered page was inspected. Page counts: K–1 11 pages (was 9), grades 2–3 9 pages, grades 4–5 9 pages, guide 14 pages (was 11).

Before editing, every claim in the review and every answer I added was recomputed by exhaustive search (all 1-D strips and subsets, all 1365 four-peg and 125,970 eight-peg placements, the 20-peg solution on board T, the value sums 372/377, two-wide columns of depth 2–7 on a nine-wide board, the block table including 5×4 → row 3). The review's numbers were all confirmed.

## Review items adopted (numbering as in `review.md`)

**Mathematics**
1. Shifted L shapes. Guide K–1 Problem 10 (old 11), grades 2–3 Problem 12, grades 4–5 Problem 8 now say that the L with its stack under A, B, D or E reaches row 2 beside the star (B3 C3 D3 D2 → D5 and the other three cases listed), and tell the adult to have the child slide the shape under the star.
2. Board T: the guide now says the nineteen most valuable home squares of board T are worth only 372 (fifteen squares within seven steps worth 340, six at eight steps worth 8 each), and that the 16/9/84-set statement and the perfect-solution search apply to the unbounded board (section 7 Problem 13 and section 9).
3. Two-wide columns: the three finish-early notes now distinguish a board exactly two squares wide (each column is a strip) from a wide grid where pieces spread sideways (row 1 by search for depths 2–7, and by proof for every depth). Section 9 has a new paragraph "Two-wide armies" with the proof; see the note under "Deviations" about the form of the proof.
4. Wording: strip O / strip C "four lines of play; three cross to square 1, one never crosses"; "a jump to the left lands on a value no bigger than the smaller of the two removed values"; K–1 three-piece argument now covers a sideways entry into row 1 (needs four pieces); the free-strip answers now say "farthest square 1 if the army crosses at all, never 2", with the rule that the square touching the river must be full from the start, the counts (K–1: 5 of 15 placements cross; six-square strips: 21 of 63), and the examples 1 2 3 4, 1 2 3 4 5 (never) and 3 4 6 (crosses).

**Enough work, instances**
5. K–1 timing changed to 1–2 (0:08–0:13), 3 (0:13–0:21), 4–5 (0:21–0:30), 6–8 (0:30–0:38), 9–11 (0:38–0:50); old Problem 4 folded into Problem 3 (item 8): every strip F–K now has a "first try" and a "fewest" box, three strips per page (pages 2–3), so the recording shows F, G, I, J fixed and H, K order-dependent side by side; the hour ends on the T of eight (board W).
6. Grades 2–3 Problem 3 cut to four strips (kept 2-3-5, 2-3-5-6, 1-2-4-6, 2–6, relabelled E, F, G, H; the mod-3 certificate is now shown on F, colour counts 0, 2, 2); Problem 12 cut to four shapes (block, row, T, L = shapes 1–4; Problem 14 now asks for shapes 1 and 4). Timing: 1–2 (0:08–0:12), 3–4 (0:12–0:19), 5–6 (0:19–0:25), 7–9 (0:25–0:31), 10–12 (0:31–0:38), 13–14 (0:38–0:44), 15 (0:44–0:50); Problem 16 for a group that finishes.
7. Grades 4–5: board T (twenty pegs) is now Problem 13, the closing problem at 0:40–0:50, printed before board S; the second eight-peg army (board S) is Problem 14, the finisher, with the flag hint. See "Deviations" for the numbering (the free-choice strips became a Problem of their own, so everything after Problem 2 moved up by one).
9. A never-crossing river strip at every level: K–1 strip N (pieces on 1, 2, 3; the only jump is 2 over 3 to 4, nothing crosses), grades 2–3 strip P and grades 4–5 strip D (pegs on 1, 2, 3, 4 of six; forced 3 over 4 to 5, 1 over 2 to 3, stuck). Grades 2–5 record "farthest square reached (0, 1 or 2)" with 0 explained in the problem text; answers, the reason, and the follow-up "3 4 6 crosses, 2 3 6 does not" are in the guide.
11. Three free-choice strips at every level: K–1 strips P, Q, R; grades 2–3 strips R1, R2, R3 (own Problem 6); grades 4–5 strips F1, F2, F3 (own Problem 3). Text: "a different set on each strip".

**Concreteness and order**
10. Grades 2–3 Problem 4 is now act-then-record: play five pennies on strip I, retry on strip J, draw the dots once a pattern works; strips K and L for the stuck pattern. Hint added in the guide (start from strip G and add a peg on 8 or 3).
12. Grades 2–3 Problem 16 and grades 4–5 Problem 14 have four small 5×7 recording boards (Try 1–4, "highest row") next to the empty board, and the text "Record each set you try on one of the small boards ... When a set works, draw a dot in each of its eight squares on board X and list its seven jumps."
13. Board T page has a line "Last jump: from ___ over ___ to ___" (the first line of the jump list), and Problem 13 tells the child to fill it before starting.
14. K–1 boxes are 0.5 in square (`\KBox`), placed above each strip at the right with the words "first try" and "fewest".

**Next action, rules, ambiguities**
15. Gray fill removed from the value strips (grades 2–3 strip S, grades 4–5 strip G); the guide notes that each table row says where the pennies go.
16. Strip T / strip H: "Write 1 and 1 in the corners of the first two home squares, then continue to the right: each value is the sum of the two values before it, up to the star."
17. Grades 2–3 page 2 starts with "Problem 3, continued: for strips G and H ..."; K–1 page 3 likewise ("Problem 3, continued: strips I, J and K").
18. "(on page 5)" added to grades 2–3 Problems 11 and 12 for board U; "(on page 3)" added to grades 4–5 Problem 8 for board O; grades 4–5 Problem 7 now has its recording boards on the same page as board O.

**Level fit**
19. Grades 4–5 Problem 8 is an unpictured search (find a working four-peg shape, a second one, two failing ones, say why one fails) on six blank small boards; Problem 7 (three pegs) is two tries. Problem 10 now compares a shape that worked with the block C2 D2 C3 D3 (both worth 21) and has the child test the block.
20. The one-jump coordinate problems (grades 2–3 Problem 10, grades 4–5 Problem 6) are shortened as suggested.

**Page slop**
21. The three answer-stating sentences are now questions: "Can a peg ever land on square 2 of strip S ...? Use the last column of your table to tell the adult how you know", "Can a peg reach square 2 of strip T? Say how you know", "Can a peg ever land on square 2 of strip G? Tell the adult how you know, and whether the same reason works on strip H".

**Facilitator guide**
22. Hints added: grades 2–3 Problems 4, 9, 11, 16; grades 4–5 Problems 5, 7, 8, 14; K–1 Problems 5, 9, 10. (Grades 4–5 Problem 8 also lists the failing shapes with the row they reach.)
23. Materials: all K–1 cells are 1 in, so K–1 uses pennies or counters up to 1 in (1.25-inch checkers cannot sit in neighbouring squares; they are kept for the launch demonstration); 30 pieces in the K–1 cup (8 per child on the last board); penny counts recomputed (about 160); cell sizes stated correctly (K–1 1 in everywhere, grades 2–5 0.8 in, board T 0.75 in); page counts updated.
24. Timings for all three tables changed (items 5–7); grades 2–3 Problem 15 has a slot.
25. Share: grades 2–3 also show board W if they reached it; K–1 now shows strip O (forced play) and board U (the L) under the new labels.

**Production**
26. All K–1 pictures use `x=\CellSize,y=\CellSize` with `\CellSize` = 1.0 in (boards T, U, V are 5 in square, board W is 5 in by 7 in).
27. The guide's Problem 13 explains that board T is deliberately wider on the left of the star.
28. The `\renewcommand{\arraystretch}` pairs are inside a group; no underfull or overfull boxes remain in any file.

Also done without being asked, as consequences of the above: labels were made sequential after the insertions (K–1 strips L–R and boards S–W; grades 2–3 strips E–H, I–L, M–Q, R1–R3; grades 4–5 strips A–E, F1–F3, G, H), the K–1 pages say "penny" instead of "checker", and the guide's cross-references, share list and "Facts checked by computer" paragraph were updated to the new numbers and labels.

## Deviations from the review, with reasons

- **Item 3, the proof.** The review's option (b) multiplies the Manhattan-distance weights σ^d of the second column by ε and claims the result is still a pagoda function if g(c) ≤ g(a)+g(b). It is not: a horizontal jump from column 2 over the ε column into column 0 (toward the target above column 0) replaces σ^{d+2} + εσ^{d+1} by σ^d, which is an increase. Section 9 instead uses a product weight u(c)·v(r) with v(r) = σ^{2−r} by row only and u = 1 except ε on one column of the army; vertical jumps satisfy the pagoda inequality through v, horizontal jumps through u, the army of depth h is worth (1+ε)(1−σ^h) < 1 for ε < σ^h/(1−σ^h), and swapping the ε column covers every row-2 square. The finish-early notes were changed as in option (a), pointing to this proof.
- **Item 9, the K–1 record.** The K–1 pages use "circle YES or NO" (did a penny get across?) under each river strip plus the X on the farthest square, instead of "0, 1 or 2": the K–1 squares across are numbered 1 and 2 on the strip itself, a square 0 does not exist on the picture, and YES/NO is the convention the K–1 children already used in Problem 2. Grades 2–5 use "0, 1 or 2" as proposed.
- **Items 9 and 11, labels.** Instead of "M2", "O1 O2 O3", "K, K2, L, L2", "Q1 Q2 Q3", "E1 E2 E3", the strips were relabelled in sequence (see above), with numbered suffixes only for the three identical free-choice strips (R1–R3, F1–F3). The guide uses the new labels throughout; the mapping from the review's labels is: K–1 strips L M N O → L M (N new) O, free strip O → P Q R, boards P Q R S T → S T U V W; grades 2–3 strips E G H J → E F G H, K L → I J K L, M N O P → M N O (P new) Q, Q → R1–R3; grades 4–5 strips B C D E → B C (D new) E, E → F1–F3, F G → G H.
- **Item 7, numbering at grades 4–5.** The free-choice strips are a separate Problem 3 (as at grades 2–3), so the old Problems 3–13 are now 4–14: values strip = 4, totals and strip H = 5, board O one jump = 6, three pegs = 7, four-peg search = 8, board P table = 9, totals = 10, board Q = 11, board R = 12, board T = 13, board S = 14. The swap of board T and board S is as the review asked.
- **Item 12, placement of the small boards.** A row of four 7-row small boards above the big board, plus the jump list, does not fit on a Letter page with 0.8-inch cells (pennies need the full-size board), so the four small boards sit in a 2×2 block to the right of the board; the text is as proposed.
- **Item 13.** The "Last jump" line is the first line of the two-column jump list rather than a separate line above it, because a separate line pushed jumps 17–19 onto a new page.
- **Item 23(b).** The review suggested "both checkers sets, or 30 counters" for K–1; since all K–1 cells are 1 in (item 26), 1.25-inch checkers do not fit anywhere on the K–1 pages, so the guide asks for 30 pennies or 1-inch counters and keeps the checkers for the launch demonstration.
- **Verification note.** Everything in the guide's "Facts checked by computer" paragraph was recomputed: the 5×4 block by exhaustive search (6.4 million states, highest row 3) and the 5×5 block by an explicit 21-jump sequence reaching row 4 (the upper bound, no army reaches row 5, is Conway's theorem).
