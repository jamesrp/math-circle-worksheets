#!/usr/bin/env python3
"""Conway's Soldiers on the square grid, verified by exhaustive search with the
golden-ratio weight bound.

Coordinates (x, y).  The line runs between y = 0 and y = 1; the army sits in
y <= 0.  Target cell (0, r).  Weight of a cell = s^d with s = (sqrt5 - 1)/2 and
d = |x| + |r - y| (taxicab distance to the target).  Since s^2 + s = 1, a jump
straight towards the target keeps the total weight, every other jump lowers it,
and a position containing the target peg has weight >= 1.  So an army whose
total weight is < 1 can never reach the target.

Weights are kept EXACTLY as pairs (a, b) meaning a + b*s, using
    s^n = (-1)^n (F_{n-1} - F_n s),   F_{-1} = 1, F_0 = 0, F_1 = 1, ...

What this script establishes (see verify_soldiers.out):
  1. max total weight of m pegs below the line, for each target row r:
     rows 1,2,3 need at least 2,4,8 pegs (1,3,7 pegs have weight < 1);
     19 pegs can have weight exactly 1 for row 4, and 18 pegs cannot.
  2. every minimal army for rows 1,2,3 (all armies of that size with weight
     >= 1, each searched exhaustively), with one winning move sequence.
  Row 4 (a 20-peg army exists, 19 cannot) is handled by the faster bitboard
  scripts verify_soldiers_row4.py and verify_soldiers_row4_all.py.
Run:  python3 verify_soldiers.py > verify_soldiers.out
"""
import sys
from functools import lru_cache
import itertools

sys.setrecursionlimit(10000)
S = (5 ** 0.5 - 1) / 2


# sanity: build F table directly
F = {-1: 1, 0: 0}
for n in range(1, 80):
    F[n] = F[n - 1] + F[n - 2]


def spow(n):
    """s^n as exact pair (a, b) = a + b*s."""
    sign = 1 if n % 2 == 0 else -1
    return (sign * F[n - 1], -sign * F[n])


def add(p, q):
    return (p[0] + q[0], p[1] + q[1])


def sub(p, q):
    return (p[0] - q[0], p[1] - q[1])


def val(p):
    return p[0] + p[1] * S


def ge_one(p):
    """Is a + b*s >= 1 ?  Exact: equality only at (1, 0)."""
    if p == (1, 0):
        return True
    return val(p) > 1.0


def cell_weight(c, r):
    x, y = c
    return spow(abs(x) + abs(r - y))


def region_cells(r, xmax, ymin):
    return [(x, y) for x in range(-xmax, xmax + 1) for y in range(ymin, r + 1)]


def jumps(pos, cells):
    for (x, y) in pos:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            b = (x + dx, y + dy)
            c = (x + 2 * dx, y + 2 * dy)
            if b in pos and c not in pos and c in cells:
                yield (x, y), b, c


def search(army, r, cells, weights, limit_nodes=5_000_000):
    """DFS with weight pruning.  Returns a move list reaching (0, r) or None."""
    target = (0, r)
    start = frozenset(army)
    w0 = (0, 0)
    for c in start:
        w0 = add(w0, weights[c])
    if not ge_one(w0):
        return None
    seen = set()
    nodes = [0]
    path = []

    def dfs(pos, w):
        if target in pos:
            return True
        if pos in seen:
            return False
        seen.add(pos)
        nodes[0] += 1
        if nodes[0] > limit_nodes:
            raise RuntimeError("node limit")
        mv = []
        for a, b, c in jumps(pos, cells):
            nw = sub(add(w, weights[c]), add(weights[a], weights[b]))
            if ge_one(nw):
                # prefer jumps toward the target
                d_gain = (abs(a[0]) + abs(r - a[1])) - (abs(c[0]) + abs(r - c[1]))
                mv.append((-d_gain, a, b, c, nw))
        mv.sort()
        for _, a, b, c, nw in mv:
            path.append((a, b, c))
            if dfs((pos - {a, b}) | {c}, nw):
                return True
            path.pop()
        return False

    return list(path) if dfs(start, w0) else None


def show(army, r, moves=None, xr=None):
    xs = [c[0] for c in army] + [0]
    ys = [c[1] for c in army] + [r]
    x0, x1 = min(xs) - 1, max(xs) + 1
    if xr:
        x0, x1 = xr
    lines = []
    for y in range(r, min(ys) - 1, -1):
        row = ""
        for x in range(x0, x1 + 1):
            if (x, y) == (0, r):
                row += "T" if (x, y) not in army else "X"
            elif (x, y) in army:
                row += "X"
            else:
                row += "."
        lines.append(f"y={y:3d}  {row}")
        if y == 1:
            lines.append("       " + "-" * (x1 - x0 + 1) + "  (line)")
    return "\n".join(lines)


def replay(army, moves, r):
    pos = set(army)
    for a, b, c in moves:
        assert a in pos and b in pos and c not in pos, (a, b, c, pos)
        pos -= {a, b}
        pos.add(c)
    assert (0, r) in pos
    return pos


def max_weight_subsets(r, m, cells, weights):
    """Enumerate all m-subsets of cells with total weight >= 1 (pruned)."""
    order = sorted(cells, key=lambda c: -val(weights[c]))
    wl = [weights[c] for c in order]
    n = len(order)
    # suffix best: sum of the k largest among positions >= i is just the first k of the suffix
    out = []

    def rec(i, k, w, chosen):
        if k == 0:
            if ge_one(w):
                out.append(tuple(chosen))
            return
        if i >= n:
            return
        # upper bound: take the next k cells
        bound = w
        for j in range(i, min(n, i + k)):
            bound = add(bound, wl[j])
        if not ge_one(bound):
            return
        chosen.append(order[i])
        rec(i + 1, k - 1, add(w, wl[i]), chosen)
        chosen.pop()
        rec(i + 1, k, w, chosen)

    rec(0, m, (0, 0), [])
    return out


def canonical(army):
    """Canonical form under left-right reflection."""
    a = tuple(sorted(army))
    b = tuple(sorted((-x, y) for x, y in army))
    return min(a, b)


def main():
    print("s = (sqrt5-1)/2 =", S, "; check s^2 + s =", S * S + S)
    for n in range(0, 10):
        a, b = spow(n)
        assert abs(a + b * S - S ** n) < 1e-12
    print("exact powers of s verified for n = 0..9")
    print()

    # 1. Max weight of m pegs below the line ---------------------------------
    print("=" * 72)
    print("1. MAXIMUM TOTAL WEIGHT OF m PEGS BELOW THE LINE (target row r)")
    print("=" * 72)
    for r in (1, 2, 3, 4, 5):
        cells = region_cells(r, 14, -14)
        below = [c for c in cells if c[1] <= 0]
        ws = sorted((val(cell_weight(c, r)) for c in below), reverse=True)
        line = []
        for m in (1, 2, 3, 4, 7, 8, 18, 19, 20):
            tot = (0, 0)
            for c in sorted(below, key=lambda c: -val(cell_weight(c, r)))[:m]:
                tot = add(tot, cell_weight(c, r))
            line.append(f"m={m}: {val(tot):.4f} [{tot[0]}+{tot[1]}s]")
        print(f"row {r}: " + "; ".join(line))
    print("Total weight of the whole infinite half-plane for row 5 is exactly 1 (row 4: 1/s = 1.618...).")
    print("Hence: row 1 needs >= 2 pegs, row 2 >= 4, row 3 >= 8, row 4 >= 19 (19 only with weight exactly 1).")
    print()

    # 2. All minimal armies for rows 1, 2, 3 -------------------------------------
    print("=" * 72)
    print("2. ALL MINIMAL ARMIES FOR ROWS 1, 2, 3 (exhaustive over armies of weight >= 1)")
    print("=" * 72)
    for r, m in ((1, 2), (2, 4), (3, 8)):
        cells = set(region_cells(r, 12, -12))
        weights = {c: cell_weight(c, r) for c in cells}
        below = [c for c in cells if c[1] <= 0]
        cands = max_weight_subsets(r, m, below, weights)
        wins = {}
        for army in cands:
            mv = search(army, r, cells, weights)
            if mv is not None:
                wins[canonical(army)] = (army, mv)
        print(f"row {r}, {m} pegs: {len(cands)} armies have weight >= 1; {len(wins)} of them (up to mirror image) reach the target:")
        for key, (army, mv) in sorted(wins.items()):
            print(show(army, r, xr=(-4, 4)))
            print("   moves (from, over, to):", mv)
            replay(army, mv, r)
            print()
        # also confirm smaller armies fail: every (m-1)-subset has weight < 1
        fewer = max_weight_subsets(r, m - 1, below, weights)
        print(f"   armies of {m-1} pegs with weight >= 1: {len(fewer)}  (so {m-1} pegs can never reach row {r})")
        print()

    print("Row 4: see verify_soldiers_row4.py and verify_soldiers_row4_all.py (bitboard search).")


def sum_w(a, weights):
    t = (0, 0)
    for c in a:
        t = add(t, weights[c])
    return t


if __name__ == "__main__":
    main()
