#!/usr/bin/env python3
"""Last checks for specific claims in bank.md.
  1. every army placed on squares 1..6 of a 10-strip (line after 6) reaches at most square 7;
  2. colour counts (squares 1,4,7,... = red; 2,5,8 = blue; 3,6,9 = green) for the strips in the
     'predict before playing' problem, and which colour the lone survivor would need;
  3. two-player 'last jump wins' on the 3x3 corner-hole board: a full winning strategy for the starter;
  4. the 3x3 board with two holes.
Run:  python3 verify_misc.py > verify_misc.out
"""
import itertools
import sys
from collections import deque
from functools import lru_cache

sys.path.insert(0, ".")
from verify_boards import lines_of, moves, analyse, show_strip, show_grid, grid_cells

print("1. ALL ARMIES ON SQUARES 1..6 OF A 10-STRIP")
cells = [(i, 0) for i in range(1, 11)]
lines = lines_of(cells)
worst = 0
count = 0
for k in range(1, 7):
    for combo in itertools.combinations(range(1, 7), k):
        start = frozenset((i, 0) for i in combo)
        seen = {start}
        q = deque([start])
        far = 0
        while q:
            p = q.popleft()
            far = max(far, max(c[0] for c in p))
            for _, r in moves(p, lines):
                if r not in seen:
                    seen.add(r)
                    q.append(r)
        worst = max(worst, far)
        count += 1
print(f"   {count} armies tried; farthest square ever reached by any of them: {worst} (line is after square 6)")
print()

print("2. COLOUR COUNTS FOR THE PREDICTION STRIPS")
names = {0: "red", 1: "blue", 2: "green"}   # square i has colour (i-1) mod 3
for n, hole in ((7, 4), (8, 3), (8, 1), (9, 5), (8, 2), (8, 4), (6, 2), (10, 2)):
    pegs = [i for i in range(1, n + 1) if i != hole]
    counts = [sum(1 for i in pegs if (i - 1) % 3 == c) for c in range(3)]
    par = [c % 2 for c in counts]
    verdict = "no single counter possible"
    for c in range(3):
        others = [par[j] for j in range(3) if j != c]
        if others[0] == others[1] and par[c] != others[0]:
            sq = [i for i in range(1, n + 1) if (i - 1) % 3 == c]
            verdict = f"survivor must be on {names[c]}: squares {sq}"
    r = analyse(cells[:n], [(i, 0) for i in pegs])
    print(f"   n={n} hole={hole} {show_strip(n, set((i,0) for i in pegs))}: red {counts[0]}, blue {counts[1]}, green {counts[2]} -> {verdict}; "
          f"truth: min left {r['minleft']}, single-counter squares {[c[0] for c in r['singles']]}")
print()

print("3. TWO-PLAYER GAME ON THE 3x3 CORNER-HOLE BOARD (last jump wins)")
g = grid_cells(3, 3)
L = lines_of(g)
start = frozenset(c for c in g if c != (0, 0))


@lru_cache(maxsize=None)
def win(p):
    return any(not win(r) for _, r in moves(p, L))


def strategy(p, depth=0, who="starter"):
    """Print the starter's winning replies to every opponent move."""
    ind = "      " * depth
    if not any(True for _ in moves(p, L)):
        print(f"{ind}no jumps left; last jump was made by {'the opponent' if who == 'starter' else 'the starter'}")
        return
    if who == "starter":
        for mv, r in moves(p, L):
            if not win(r):
                print(f"{ind}starter jumps {mv[0]} over {mv[1]} to {mv[2]}")
                strategy(r, depth + 1, "opponent")
                return
    else:
        for mv, r in moves(p, L):
            print(f"{ind}if opponent jumps {mv[0]} over {mv[1]} to {mv[2]}:")
            strategy(r, depth + 1, "starter")


print(f"   starter {'wins' if win(start) else 'loses'} from the corner-hole start (coordinates (column, row) from 0 at bottom-left)")
strategy(start)
print()

print("4. 3x3 WITH TWO HOLES")
for holes in ([(0, 0), (2, 2)], [(0, 0), (0, 2)], [(0, 0), (1, 1)]):
    r = analyse(g, [c for c in g if c not in holes])
    print(f"   holes {holes}: positions {r['states']}, fewest left {r['minleft']}")
