# Copyedits, Week 1 (jumping pegs)

Originals are in `before-copyedit/`. No problem, diagram, answer or move sequence was added, removed, reordered or changed; every edit is wording, punctuation or term consistency. All four files recompile without errors or overfull boxes, with the same page counts (14, 11, 14, 16).

## Student pages

The three student files were checked against the page rules (no titles, teasers, section labels, Name/Date lines, praise, exclamation marks, clip-art, adult-directed instructions or explanations): nothing to delete. `week-grades-2-3.tex` and `week-grades-4-5.tex` are unchanged.

1. `week-k-1.tex`, Problem 15: "the corner square is empty" -> "one corner square is empty" (board J has four corners; only one is empty).

## Facilitator guide (`week-facilitator.tex`)

2. Section 1, arrival bullet: "slantwise jumps" -> "diagonal jumps", matching "never diagonally" in the rule statement.
3. Section 1, table-work bullet: "(about 43 minutes)" -> "(43 minutes)"; the interval is exact.
4. Section 2, checkers: "the second set stays in the bag" -> "a second set stays in the bag" (no second set had been introduced).
5. Section 3, launch script: "never slantwise" -> "never diagonally" (same term throughout).
6. Section 4.1, Problem 4: "there are only these five positions in the whole game" -> "on strip H there are only these five positions ..." (the count is strip H's).
7. Section 4.1, Problem 10, jump (1): "the checker below the middle one jumps up over it" -> "the lowest checker jumps up over the one above it" (unambiguous naming of the same jump).
8. Section 5.1, Problem 6, strip K: added "farthest square 4" so K is reported like L and M (the jump already named lands on 4).
9. Section 5.1, Problem 7: "Every price is the sum of the two prices to its left" -> "From square 3 on, every price is the sum of the two prices before it" (squares 1 and 2 have no two predecessors).
10. Section 5.1, Problem 8, the three jumps of the L: "the row $-1$ penny ... the row 0 penny ... the far end penny in row 0 ... the row 1 penny" -> "the penny in row $-1$ ... the penny in row 0 ... the penny at the far end of row 0 ... the penny in row 1" (consistent phrasing, no unhyphenated compound modifiers).
11. Section 5.4, reserve R3: "col" -> "column" in all eleven places, and each jump written "row r, column c jumps ..." as in Problem 9's list.
12. Section 6, board-naming paragraph: now says boards L, M and Q carry the printed letters and numbers and that board P (the same grid as Q, unlettered) is named the same way here; previously it claimed all four are lettered on the pages.
13. Section 6.1, Problem 3: "they cannot check all 63 by hand" -> "the children cannot check all 63 by hand".
14. Section 6.1, Problem 5: "the row 1 penny ... the row 0 penny" -> "the penny in row 1 ... the penny in row 0".
15. Section 6.1, Problem 6: "Mirror images ... are the same army" -> "count as the same army".
16. Section 6.1, Problem 7, general fact: "(a jump straight towards the star is neutral, every other jump loses)" -> "(a jump straight towards the star onto a square worth 2 or more is neutral; every other jump loses)" (on board M a jump towards the star inside the all-1 region, e.g. A4 over B4 to C4, loses 1; the claim "no jump ever raises the total" is unchanged).
17. Section 6.1, Problem 7, board N: squares were named D3, C3, E3, D2 although the guide states that N is unlettered; now "the square just under the line in the star's column costs 3, its three neighbours below the line (left, right and below it) cost 2 each, and every other square costs 1: the best three total 3 + 2 + 2 = 7" (same squares, same prices, same conclusion).
18. Section 6.1, Problem 8: "20-armies" -> "20-penny armies".
19. Section 6.4, reserve R3: period added after the ellipsis that ends the list of prices (`\dots\ The 9-wide` -> `\dots. The 9-wide`).
20. Section 6.4, reserve R5: "A second 20-army" -> "A second 20-penny army"; "exactly four 20-armies" -> "exactly four 20-penny armies".
21. Section 8, Fibonacci bullet: period added after "$1, 1, 2, 3, 5, 8, \dots$"; "squares $1..k$" -> "squares 1 to $k$"; "and also its converse:" -> "sharp in both directions:" (the sentence states reachability of one past the line and impossibility of two, not a converse).
22. Section 8, Conway bullet: "a 19-army" -> "a 19-peg army".
23. Section 8: run-in heading "Pagoda functions." set in bold like the other run-in headings of the section.
24. Section 8, colouring paragraph: "the two squares where the survivor really ends" -> "the two squares on which the survivor can end".
25. Section 8, verification note: "no 19-army works; four 20-armies work" -> "no 19-peg army works; four 20-peg armies work".

Checked and left as is: British spelling (colour, centre, grey, neighbour) is consistent in all four files; "K--1", "grades 2--3", "grades 4--5" and "Section~n" references are uniform; strip notation `X`/`.` is defined once and used consistently; digits are used for recorded answers (positions, pennies, jumps) and words for prose counts, which is the guide's consistent convention.
