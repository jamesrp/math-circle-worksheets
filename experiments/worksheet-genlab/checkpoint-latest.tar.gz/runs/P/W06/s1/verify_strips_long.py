#!/usr/bin/env python3
"""Strips of 11 to 16 squares with one hole: fewest pegs left for each hole
(holes past the middle are mirror images).  Extends the table of verify_boards.py.
Run:  python3 verify_strips_long.py > verify_strips_long.out
"""
import sys
sys.path.insert(0, '.')
from verify_boards import analyse

for n in range(3, 17):
    res = []
    for h in range(1, (n + 1) // 2 + 1):
        cells = [(i, 0) for i in range(1, n + 1)]
        start = [(i, 0) for i in range(1, n + 1) if i != h]
        r = analyse(cells, start)
        res.append((h, r['minleft']))
    good = [h for h, m in res if m == 1]
    print(f"n={n:2d}: fewest left by hole {res}; holes that reach one peg: {good}")
