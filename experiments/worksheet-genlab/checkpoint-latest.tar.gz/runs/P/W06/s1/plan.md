# Week 1 plan: jumping pegs (peg solitaire, strip armies, Conway's Soldiers)

Stage: curator. This file is the complete content for the four LaTeX files. Part A holds the student pages (final printed text of every problem, the diagrams and recording spaces to draw, minutes). Part B holds the facilitator guide. Every number, position and move sequence below was re-verified by `verify_curator.py` (output in `verify_curator.out`), independently of the bank's scripts.

Bank cross-reference (for traceability only; do not print): K–1 uses B01, B02, B03, B04, B07, B30, B31, B41, B32, B17, B18; grades 2–3 use B02, B03, B04, B05, B06, B08, B11, B25, B26, B32, B33 (with B27/B28 as the adult's argument); grades 4–5 use B05, B06, B12-style map of `XX.XXX`, B25, B26, B28, B29, B32, B33, B36, B34, B35. Reserves in the guide draw on B08, B09, B10, B40, B43, B38, B19, B20, B12, B37, B39.

Suggested `\ActivityTopic`: `Jumping pegs`. Level strings for the headers: `Grades K--1`, `Grades 2--3`, `Grades 4--5`.

---

## Conventions for all diagrams (formatter)

- **Squares and pieces.** K–1 plays with checkers (1.25 in across) on 1.25-in squares. Grades 2–3 and 4–5 play with pennies (0.75 in across) on 1-in squares; strips of 8 or 9 squares and all army boards for grades 4–5 are drawn at the smaller scale stated with each problem (0.85 in or 0.75 in) so that they fit the 7.2-in usable width. Nothing playable is ever smaller than 0.75 in per square.
- **Start position.** A light-grey filled circle (diameter about 0.7 of the square) centred in a square means "a counter starts here". Empty squares are plain. This one convention is used on every strip and board, at every level.
- **Thick line.** A 2.5-pt black line drawn along the grid line between the two squares (strips) or the two rows (boards) it separates, extended about 0.15 in beyond the strip or board on both sides.
- **Star.** A five-pointed star outline centred in a square (the target).
- **Recording pieces.** "Small strip" / "small board" = an empty copy of the strip or board at the smaller scale given (it keeps the thick line and the star, no circles). "Number box" = a 0.55-in square box. "Tally box" = a 2-in by 0.55-in box. "Mark box" = a 0.5-in square box. Labels are single letters or digits placed at the left of a strip or above a board (`A`, `B`, ..., `1`, `2`, ...) and the one-word tags `jumps` beside a tally box, `left` beside a number box where the text says "write how many"; no other words on the pages.
- **Square numbers.** For grades 2–3 and 4–5, print small digits 1, 2, 3, ... under the squares of every strip. K–1 strips have no digits.
- **Board coordinates (grades 4–5 boards L, M, Q only).** Column letters A to I under the columns, row numbers from 1 upward at the left of the rows, so that a jump can be written "C2 over C3 to C4".
- **Army boards.** Rows are counted from the thick line: the row just above the line is row 1, the next row 2, and so on; the row just below the line is row 0, then −1, −2, −3. Columns are counted from the star's column (0), positive to the right. These names are for this plan and the guide only; the pages show only the boards (and the coordinates just described on L, M, Q).
- **Page fitting.** Usable area is 7.2 in wide, about 9.4 in tall under the header in portrait; 9.7 in by 7.2 in in landscape. Where a problem's pieces exceed a page, the plan says how to split it; a continuation page carries the running header and the remaining pieces of the same problem (strips, boards, recording spaces), never a repeated problem text and never a heading. K–1 Problem 5 needs a landscape page (strips of 6 and 7 at 1.25 in are 7.5 in and 8.75 in wide); if landscape is impossible, print those two strips at 1.0 in per square.
- **Type.** K–1 in 14pt (`extarticle`); other pages 12pt.

---

# Part A. Student pages

## A1. K–1 table (three children; the adult reads aloud and scribes). Total 67 minutes.

### Problem 1 (3 min)
**Text.** Problem 1: A checker may jump over the checker next to it, to the left or to the right, into the empty square right behind it. The checker that was jumped over comes off the strip. Put a checker on each circle of strip A. Make a jump if you can. Do the same on strip B and on strip C. Put a mark in the box beside each strip where a jump was possible. On each strip where you jumped, point to the square where the checker landed.

**Diagram.** Three strips of 3 squares at 1.25 in, labelled A, B, C at the left, stacked with 0.6 in between them. Circles: A on squares 1 and 2; B on squares 1 and 3; C on squares 2 and 3. A mark box 0.4 in to the right of each strip.

### Problem 2 (3 min)
**Text.** Problem 2: Put a checker on each circle of strip D. The last square is empty. Jump until no jump is left. Make one tally mark in the long box for each jump. On the small strip, draw a dot in each square that still has a checker. Write how many checkers are left in the number box.

**Diagram.** Strip D: 4 squares at 1.25 in, circles on squares 1, 2, 3. Below it: a tally box (tag `jumps`), then a small strip of 4 at 0.5 in with a number box (tag `left`) at its right. Problems 2 and 3 fit on one page together.

### Problem 3 (3 min)
**Text.** Problem 3: Put a checker on each circle of strip E. This time the second square is empty. Jump until no jump is left. Make a tally mark for each jump, draw dots on the small strip for the checkers that are left, and write how many. Then look at the small strips of Problems 2 and 3 together. Point to the strip that let you jump more times.

**Diagram.** Strip E: 4 squares at 1.25 in, circles on squares 1, 3, 4. Tally box, small strip of 4 at 0.5 in, number box, as in Problem 2.

### Problem 4 (8 min)
**Text.** Problem 4: Strips F, G and H have five squares each, with the empty square in a different place on each. On each strip, put a checker on each circle and jump until no jump is left. Try to leave as few checkers as you can. Draw dots on the small strip under it for the checkers that are left and write how many. On strip H, play twice, starting with a different jump each time, and draw both endings. Put a mark in the box beside the one strip where you could choose between two jumps.

**Diagram.** Three strips of 5 at 1.25 in, labelled F, G, H, each with a mark box at its right. Circles: F on 1, 2, 3, 4 (square 5 empty); G on 1, 2, 3, 5 (square 4 empty); H on 1, 2, 4, 5 (square 3 empty). Under F and under G: one small strip of 5 at 0.5 in with a number box. Under H: two small strips of 5 at 0.5 in, each with a number box. Keep the gaps between pieces at 0.3 in so that everything fits one page (3 × 1.25 + 4 × 0.5 + gaps ≈ 7.7 in plus the text); if it still overflows, strip H and its two small strips go on a continuation page with the running header only.

### Problem 5 (4 min) — landscape page
**Text.** Problem 5: Strips J and K have the empty square at the end, like strips D and F. Put a checker on each circle of strip J and jump until no jump is left. Draw dots on the small strip for the checkers that are left and write how many. Do the same on strip K.

**Diagram (landscape).** Strip J: 6 squares at 1.25 in (7.5 in wide), circles on 1–5. Strip K: 7 squares at 1.25 in (8.75 in wide), circles on 1–6. Under each: a small strip of the same length at 0.5 in with a number box. Total height about 2 × 1.25 + 2 × 0.5 + gaps ≈ 4.5 in plus text: fits one landscape page.

### Problem 6 (5 min)
**Text.** Problem 6: The four small strips at the top are strips D, F, J and K again, from the shortest to the longest. Draw your four endings on them. Point to where the checkers are left each time and show the adult what is the same on all four. The last small strip has eight squares. Before you play, draw dots where you think the checkers will be left on a strip of eight with the empty square at the end. Then put seven checkers on the strip of eight the adult gives you, with the last square empty, play, and check your drawing.

**Diagram.** Five small strips at 0.5 in, of 4, 5, 6, 7 and 8 squares, one under the other with their left ends aligned, 0.3 in apart, each with a number box at its right. The strip of 8 is separated from the other four by a 0.5-in gap. (The physical strip of eight is cut by the adult from a printed 1.25-in grid; see the guide.)

### Problem 7 (2 min)
**Text.** Problem 7: Board A has a thick line across it and a star just above the line. Put a checker on each of the two circles below the line. A checker may also jump up or down, over the checker next to it into the empty square right behind it. Jump so that a checker lands on the star. Then take both checkers off, put one checker on the circle just under the line, and try to get it onto the star. Tell the adult whether one checker can reach the star.

**Diagram.** Board A: 3 columns by 3 rows at 1.25 in (3.75 in square). Thick line between the top row and the middle row. Star in the top middle square (column 0, row 1). Circles in the middle column's two lower squares (rows 0 and −1).

### Problem 8 (5 min)
**Text.** Problem 8: Board B has two stars above the line. Put checkers below the line so that after your jumps a checker sits on each star. Use as few checkers as you can. When it works, draw a dot on the small board in each square where a checker started, and write how many checkers you used in the number box.

**Diagram.** Board B: 5 columns by 3 rows at 1.25 in (6.25 in by 3.75 in). Thick line under the top row. Stars in the top row in the 2nd and 4th columns (columns −1 and +1). No circles. Below: a small board (same layout at 0.5 in, 2.5 in by 1.5 in, with line and stars) and a number box beside it.

### Problem 9 (5 min)
**Text.** Problem 9: Board C has three stars above the line. Put checkers below the line so that after your jumps a checker sits on each star. Use as few checkers as you can. Draw a dot on the small board in each square where a checker started, and write how many checkers you used. Look at your numbers for one star, two stars and three stars. Tell the adult how many checkers four stars would need, and show with the checkers why.

**Diagram.** Board C: 5 columns by 3 rows at 1.25 in. Thick line under the top row. Stars in the top row in the 1st, 3rd and 5th columns (columns −2, 0, +2). Small board at 0.5 in and a number box below.

### Problem 10 (5 min)
**Text.** Problem 10: On board D the star is two rows above the line. Put a checker on each of the four circles. Make jumps so that a checker lands on the star. Draw the first jump as an arrow on small board 1, the second on small board 2 and the third on small board 3.

**Diagram.** Board D: 5 columns by 4 rows at 1.25 in (6.25 in by 5 in); rows are −1, 0, 1, 2 from the bottom; thick line between rows 0 and 1; star at column 0, row 2 (top row, middle column). Circles at (0,0), (+1,0), (+2,0), (0,−1): the middle square of row 0, the two squares to its right, and the square below the middle one. Below: three small boards at 0.4 in (2 in by 1.6 in each) side by side, labelled 1, 2, 3.

### Problem 11 (4 min)
**Text.** Problem 11: Board E has four circles in a column under the star. Put a checker on each circle. Try to get a checker onto the star. Colour the highest square that any checker reached. Boards D and E both use four checkers. Point to the board where a checker reached the star.

**Diagram.** Board E: 3 columns by 6 rows at 1.25 in (3.75 in by 7.5 in); rows −3 to 2; thick line between rows 0 and 1; star at column 0, row 2; circles in the middle column at rows 0, −1, −2, −3. Place the board at the left with the problem text above it; the child colours a square on the board itself, so there is no recording piece.

### Problem 12 (5 min)
**Text.** Problem 12: On board F the star is two rows above the line. Take three checkers. Put them anywhere below the line and try to get one onto the star. Draw each army of three you tried on a small board. Cross out each army that did not reach the star.

**Diagram.** Board F: 5 columns by 4 rows at 1.25 in, rows −1 to 2, thick line between rows 0 and 1, star at column 0, row 2, no circles. Below: four small boards at 0.3 in (1.5 in by 1.2 in) in one row, 0.3 in apart.

### Problem 13 (5 min)
**Text.** Problem 13: On board G the star is two rows above the line. Take four checkers. Find two different ways to place them below the line so that a checker reaches the star. Draw both armies on the small boards, with a dot for each checker.

**Diagram.** Board G: identical to board F. Below: two small boards at 0.5 in (2.5 in by 2 in) side by side.

### Problem 14 (4 min)
**Text.** Problem 14: Board H has nine squares. Put a checker on each circle. The middle square is empty. Look for a jump. If there is none, tell the adult why not. Then take the checker off one corner and put it in the middle square. Now find every jump you could make first, and point to each one.

**Diagram.** Board H: 3 by 3 at 1.25 in, circles on all squares except the middle one.

### Problem 15 (6 min)
**Text.** Problem 15: On board J the corner square is empty. Put a checker on each circle. Jump until no jump is left. Make a tally mark for each jump, and draw dots on small board 1 for the checkers that are left. Play again, starting with the other first jump, and record on small board 2. Play a third time, choosing differently later on, and record on small board 3. Write the fewest checkers you managed to leave in the number box.

**Diagram.** Board J: 3 by 3 at 1.25 in, circles on all squares except the bottom-left corner. Below: three small boards at 0.5 in (1.5 in square) in a row, labelled 1, 2, 3, each with a tally box under it; one number box at the right.

K–1 minutes: 3 + 3 + 3 + 8 + 4 + 5 + 2 + 5 + 5 + 5 + 4 + 5 + 5 + 4 + 6 = 67.

---

## A2. Grades 2–3 table (four third graders). Total 63 minutes.

### Problem 1 (4 min)
**Text.** Problem 1: A penny may jump over the penny next to it, to the left or to the right, into the empty square right behind it. The penny that was jumped over comes off the strip. Put a penny on each circle of strip A. The last square is empty. Jump until no jump is left. Make one tally mark for each jump. Draw the pennies that are left as dots on the small strip and write how many in the number box. Then do the same on strip B, where the second square is empty.

**Diagram.** Strip A: 4 squares at 1 in, circles on 1, 2, 3; below it a tally box, a small strip of 4 at 0.5 in and a number box. Strip B: 4 squares at 1 in, circles on 1, 3, 4; the same recording pieces. Digits 1–4 under the squares.

### Problem 2 (5 min)
**Text.** Problem 2: Strips C, D and E have five squares each, with the empty square in a different place on each. On each strip, put a penny on each circle and jump until no jump is left, trying to leave as few pennies as you can. Draw each ending on a small strip and write the number of pennies left. On strip E, play twice, starting with a different jump each time, and draw both endings. Then look at all your endings from Problems 1 and 2 side by side, and circle the letter of each strip that let you get down to one penny.

**Diagram.** Strips C (circles 1–4, square 5 empty), D (circles 1, 2, 3, 5), E (circles 1, 2, 4, 5), 5 squares at 1 in each. Under C and D one small strip of 5 at 0.5 in with a number box; under E two. Problems 1 and 2 may share a page if they fit; otherwise one page each.

### Problem 3 (8 min)
**Text.** Problem 3: Strips F, G and H have six squares each. On each strip, put a penny on each circle and play until no jump is left, trying to leave as few pennies as you can. Play each strip at least three times, making different choices where you can. Draw every different ending you find on the small strips under it and write its number of pennies. On strip F, circle the square where the last penny sat in each ending. On strip G, write beside each ending the number of the square its first jump started from. Write the fewest pennies you could leave on each strip in the number box at the right.

**Diagram.** Strips F (circles 1, 3, 4, 5, 6; square 2 empty), G (circles 1, 2, 4, 5, 6; square 3 empty), H (circles 1–5; square 6 empty), 6 squares at 1 in each, a number box at the right of each strip. Under each strip: three small strips of 6 at 0.5 in, each with a number box; beside each small strip of G, a short blank line (1 in) for the square number. Two pages: the text with strips F and G and their small strips on the first, strip H and its small strips on a continuation page.

### Problem 4 (6 min)
**Text.** Problem 4: Strip J has eight squares and the fourth square is empty. Put a penny on each circle and play three times, making different choices each time. Each time, make a tally mark for every jump, and when no jump is left, count the pennies. Fill in one row of the table for each play: the number of jumps, the number of pennies left, and the two numbers added together. Draw each ending on a small strip.

**Diagram.** Strip J: 8 squares at 0.85 in (6.8 in wide), circles on 1, 2, 3, 5, 6, 7, 8, digits under the squares. A table with three rows and three columns headed `jumps`, `pennies left`, `jumps + pennies left`, cells 1.6 in by 0.5 in. Three small strips of 8 at 0.4 in with a tally box beside each.

### Problem 5 (8 min)
**Text.** Problem 5: Make a map of every position you can reach on strip E, the strip of five with the middle square empty. The top box shows the start. In the boxes below, draw every position that one jump can reach from the start, with an arrow from the start to each one. Then, from each new position, draw every position that one more jump can reach, with an arrow. Keep going until every position is either already on the map or has no jump left. Circle the positions that have no jump left and write the number of pennies in each. Count the positions on your map and write the number in the number box.

**Diagram.** A full page. Top centre: a box holding a strip of 5 at 0.5 in with dots on squares 1, 2, 4, 5. Below it three rows of empty boxes, each box a blank strip of 5 at 0.5 in inside a thin rounded frame: row 1 with 2 boxes, row 2 with 3 boxes, row 3 with 3 boxes (8 boxes), at least 1 in of white space between rows for arrows. A number box at the bottom right.

### Problem 6 (5 min)
**Text.** Problem 6: Strips K, L and M have a thick line across them. The pennies start on the left of the line, on the circles. Jump so that a penny gets as far to the right as it can. Play each strip twice. On the small strip under each, put a cross on the farthest square that any penny reached, and write in the number box how many squares past the line it is.

**Diagram.** Three strips of 7 at 0.95 in (6.65 in wide), digits under the squares. K: thick line after square 3, circles on 1–3. L: line after 4, circles on 1–4. M: line after 5, circles on 1–5. Under each a small strip of 7 at 0.5 in with the line drawn, and a number box.

### Problem 7 (7 min)
**Text.** Problem 7: Strip N has nine squares, a thick line after square 6, and a star on square 8. Put pennies on any of the squares 1 to 6, as many or as few as you like, and try to get a penny onto the star. For each army you try, draw its pennies as dots on one of the small strips and put a cross on the farthest square a penny reached. Try at least six different armies, some with gaps between the pennies.

**Diagram.** Strip N: 9 squares at 0.75 in (6.75 in), digits 1–9 under the squares, thick line after square 6, star on square 8, no circles. Six small strips of 9 at 0.4 in (3.6 in wide) with the line and the star drawn, in two columns of three. Problems 6 and 7 may share a page if the pieces fit; otherwise separate pages.

### Problem 8 (8 min)
**Text.** Problem 8: On board P the star is two rows above the line. Pennies may also jump up or down, over the penny next to them into the empty square right behind it. Take exactly three pennies. Put them anywhere below the line and try to land one on the star. Draw each army of three you tried on a small board. Then take exactly four pennies and find a way to place them below the line so that a penny lands on the star. Draw every army of four that works on a small board, with its jumps drawn as arrows numbered 1, 2, 3.

**Diagram.** Board P: 5 columns by 4 rows at 1 in (5 in by 4 in), rows −1 to 2, thick line between rows 0 and 1, star at column 0, row 2, no circles. Below: six small boards at 0.3 in (1.5 in by 1.2 in) in two rows of three.

### Problem 9 (12 min)
**Text.** Problem 9: On board Q the star is three rows above the line. Put a penny on each of the eight circles. Find seven jumps that land a penny on the star. Record them in order: draw the first jump as an arrow on small board 1, the second on small board 2, and so on to small board 7.

**Diagram.** Board Q: 7 columns by 5 rows at 0.95 in (6.65 in by 4.75 in), rows −1 to 3, thick line between rows 0 and 1, star at column 0, row 3. Circles at row 0, columns −2, −1, 0, 1, 2 and at row −1, columns 0, 1, 2 (eight circles). On the following page: seven small boards at 0.3 in (2.1 in by 1.5 in) labelled 1 to 7, three per row.

Grades 2–3 minutes: 4 + 5 + 8 + 6 + 8 + 5 + 7 + 8 + 12 = 63.

---

## A3. Grades 4–5 table (two fourth graders, one fifth grader). Total 77 minutes.

### Problem 1 (7 min)
**Text.** Problem 1: A penny may jump over the penny next to it, to the left or to the right, into the empty square right behind it. The penny that was jumped over comes off the strip. Strips A, B and C have six squares each, with the empty square in a different place on each. On each strip, put a penny on each circle and play until no jump is left, trying to leave as few pennies as you can. Play each strip at least three times, making different choices where you can. Draw every different ending you find on the small strips under it and write its number of pennies. On strip A, circle the square where the last penny sat in each ending. On strip B, write beside each ending the number of the square its first jump started from. Write the fewest pennies you could leave on each strip in the number box at the right.

**Diagram.** Strips A (circles 1, 3, 4, 5, 6), B (circles 1, 2, 4, 5, 6), C (circles 1–5), 6 squares at 1 in, digits under the squares, a number box at the right of each. Under each strip three small strips of 6 at 0.5 in with number boxes; beside each small strip of B a 1-in blank line. Two pages: the text with strips A and B and their small strips on the first, strip C and its small strips on a continuation page.

### Problem 2 (7 min)
**Text.** Problem 2: Make a map of every position you can reach on strip B. The top box shows the start. In the boxes below, draw every position that one jump can reach from the start, with an arrow from the start to each one. From each new position, draw every position that one more jump can reach, with an arrow. Stop when every position is either already on the map or has no jump left. Circle the positions with no jump left and write the number of pennies in each. Count the positions on the map and write the number in the number box.

**Diagram.** As grades 2–3 Problem 5 but with strips of 6 at 0.4 in: the start box shows dots on squares 1, 2, 4, 5, 6; 8 empty boxes in rows of 2, 3, 3; number box.

### Problem 3 (8 min)
**Text.** Problem 3: Strips D, E and F have a thick line across them. The pennies start on the left of the line, on the circles. Jump so that a penny gets as far to the right as it can. Play each strip twice. On the small strip under each, put a cross on the farthest square any penny reached, and write how many squares past the line it is. Strip G has nine squares, a line after square 6, and a star on square 8. Put pennies on any of the squares 1 to 6, as many or as few as you like, and try to get a penny onto the star. Draw each army you try as dots on a small strip and put a cross on the farthest square a penny reached. Try at least six different armies, some with gaps.

**Diagram.** D, E, F: strips of 7 at 0.9 in with the line after 3, 4, 5 and circles on 1–3, 1–4, 1–5; small strips of 7 at 0.45 in with number boxes. Strip G: 9 squares at 0.75 in, digits, line after 6, star on 8, no circles; six small strips of 9 at 0.35 in in two columns of three. Two pages if needed (D–F on the first, G and its small strips on the second).

### Problem 4 (12 min)
**Text.** Problem 4: Strip H is strip G with a price printed under every square: 1, 1, 2, 3, 5, 8 on squares 1 to 6, then 13, 21, 34 past the line. Put a penny on each of the squares 1 to 6. Add up the prices of the squares your pennies are on and write the total in the first row of table 1. Make a jump, add up the prices of the squares that have pennies now, and write the new total in the next row. Continue until no jump is left, writing the total after every jump. Play strip H a second time with different jumps and fill in table 2. Then do the same on strip J, where the pennies start on squares 1, 2, 4, 5 and 6, and fill in table 3. Write under the tables what a jump to the right does to the total and what a jump to the left does to it. Write the price of the star square beside the largest total in your tables. Last, fill in the small table: an army filling squares 1 to 3 is worth 1 + 1 + 2 = 4, and the square two past it, square 5, costs 5. Do the rows for armies filling squares 1 to 4, 1 to 5, 1 to 6 and 1 to 7, and write the difference in the last column.

**Diagram.** Strip H: 9 squares at 0.75 in, line after 6, star on 8, circles on 1–6. On strips H and J only, the small square digits 1–9 go above the strip, and under each square its price is printed in bold, larger type (1, 1, 2, 3, 5, 8, 13, 21, 34), so that a penny never covers a price. Tables 1 and 2 side by side under strip H: each two columns headed `after jump` and `total`, six rows (`0`, `1`, `2`, `3`, `4`, `5`), cells 1.1 in by 0.45 in. Strip J: as H but circles on 1, 2, 4, 5, 6; table 3 beneath it. Two ruled lines (`\AnswerLines{2}`) under the tables. The small table: rows `1 to 3`, `1 to 4`, `1 to 5`, `1 to 6`, `1 to 7`; columns `army's worth`, `price of the square two past`, `difference`; the first row filled in with 4, 5, 1. This problem takes two pages (H with tables 1–2 and the ruled lines; J with table 3 and the small table).

### Problem 5 (6 min)
**Text.** Problem 5: On board K the star is two rows above the line. Pennies may also jump up or down, over the penny next to them into the empty square right behind it. Take exactly three pennies, put them anywhere below the line, and try to land one on the star. Draw each army of three you tried on a small board. Then take exactly four pennies and find a placement that works. Draw every army of four that works on a small board, with its jumps drawn as arrows numbered 1, 2, 3.

**Diagram.** Board K: 5 columns by 4 rows at 0.75 in (3.75 in by 3 in), rows −1 to 2, line between rows 0 and 1, star at column 0, row 2, no circles. Six small boards at 0.3 in in two rows of three.

### Problem 6 (12 min)
**Text.** Problem 6: On board L the star is three rows above the line. Land a penny on the star using exactly eight pennies, placed anywhere below the line. Draw the army you used on small board 1, and list its seven jumps in order in the blanks, naming each square by its column letter and row number, for example C2 over C3 to C4. Then find a second army of eight that works and is not a mirror image of the first. Draw it on small board 2 and list its jumps.

**Diagram.** Board L: 9 columns (letters A–I under the columns) by 7 rows (numbers 1–7 at the left) at 0.75 in (6.75 in by 5.25 in). The thick line lies between rows 4 and 5 (rows 1–4 are below the line, rows 5–7 above); the star is at E7. No circles. Board L and the text fill the first page. On a continuation page: two small boards at 0.3 in (2.7 in by 2.1 in) labelled 1 and 2 side by side, and under each a list of seven numbered blanks of the form `___ over ___ to ___`.

### Problem 7 (10 min)
**Text.** Problem 7: Board M is board L with a price printed in every square. Put a penny on each of the eight circles. Add up the prices of the eight squares and write the total in the first row of the table. Make the seven jumps that land a penny on the star, and after each jump write the total price of the squares that have pennies. Then put the pennies back on the circles, make one jump that moves a penny away from the star, and write the new total in the last row. Next, find the seven most expensive squares below the line on board M, add up their prices, and write the sum beside the star's price. On board N the star is two rows above the line. Find the three most expensive squares below its line, add up their prices, and write the sum beside that star's price.

**Diagram.** Board M: the same board as L (9 columns A–I by 7 rows at 0.75 in, letters and numbers, line between rows 4 and 5, star at E7) with a price printed in bold in the top-left corner of every square: the star costs 13; a square whose distance from the star (squares across plus squares up or down) is 1, 2, 3, 4 costs 8, 5, 3, 2; every square at distance 5 or more costs 1. Circles on C4, D4, E4, F4, G4, E3, F3, G3. Because a penny covers its square, print beside the table a reference copy of board M at 0.35 in (3.15 in by 2.45 in) with the prices large and centred and no circles. The table has two columns `after jump` and `total` and nine rows labelled `0`, `1`, ..., `7`, `away`; under it the line `13` followed by a 1.5-in blank (the star's price beside the sum). Board M and its text fill the first page; the table, the reference copy and the `13` line go on the second page with board N. Board N: 7 columns (A–G) by 5 rows (1–5) at 0.75 in (5.25 in by 3.75 in), line between rows 3 and 4, star at D5 costing 8; prices printed large and centred: distance 1 costs 5, distance 2 costs 3, distance 3 costs 2, distance 4 or more costs 1; no circles; under it the line `8` followed by a 1.5-in blank.

### Problem 8 (15 min)
**Text.** Problem 8: Fill in the table with the fewest pennies that can land a penny one row, two rows and three rows above the line, using what you found in Problems 5 and 6 and at the start of the session. Write your guess for four rows and for five rows. On board P the star is four rows above the line. Try to land a penny on the star with 16 pennies placed anywhere below the line. Write in the number box the highest row above the line that any penny reached. Then use board Q. Put a penny on each of the 20 circles and find the 19 jumps that land a penny on the star. List them in order in the blanks by square names.

**Diagram.** A horizontal table: one row of five cells (1.2 in by 0.5 in) under the headings `1 row`, `2 rows`, `3 rows`, `4 rows`, `5 rows`. Board P: 9 columns (A–I) by 8 rows (1–8) at 0.75 in (6.75 in by 6 in), line between rows 4 and 5, star at E8, no circles; the number box sits at the right end of the table's row. Text, table and board P fill the first page (about 9.3 in with 0.15-in gaps); if it overflows, board P moves to a continuation page by itself. Next page: board Q, identical to P but with 20 circles: row 4 at A, B, C, D, E, F, G, H, I (all nine), row 3 at C, D, E, F, row 2 at B, C, D, E, F, row 1 at D, E. Under it, 19 numbered blanks `___ over ___ to ___` in three columns of seven, seven and five, 0.3 in apart vertically.

Grades 4–5 minutes: 7 + 7 + 8 + 12 + 6 + 12 + 10 + 15 = 77.

---

# Part B. Facilitator guide content

The guide is one document for the three adults. Sections in this order.

## B1. The session at a glance

- 0:00–0:04 Arrival and free handling. Each table has its first page and its cup of counters. Children may put counters anywhere and jump; correct only slantwise jumps, slides, and jumps over an empty square.
- 0:04–0:07 Whole-group launch at the big board (script in B3), then children go to their tables.
- 0:07–0:50 Table work (about 43 minutes). Orders and timings in B4–B6.
- 0:50–0:58 Share (B7).
- 0:58–1:00 Counters back in the cups, pages home with the children.

Adults: organizer (math PhD) at grades 4–5; second mathematician at grades 2–3; parent at K–1. The K–1 table needs reading aloud and scribing above all, and every argument the table needs is written out in B4 so that nothing has to be worked out during the hour. Any other assignment works; each table's section is self-contained. The two mathematicians should each drop by the K–1 table for a minute during Problems 9 and 12 (the two arguments) if their own table is in the middle of a long problem.

The one rule for the whole hour: a counter may jump over the counter right next to it (left, right, up or down, never diagonally) into the empty square immediately beyond; the counter jumped over is removed. No sliding, no jumping over an empty square, no jumping over two counters.

## B2. Materials and preparation

Materials (counts):
- Pennies: 100. Cup of 40 for grades 2–3 (four children; the row-3 army needs 8 each), cup of 60 for grades 4–5 (three children; the row-4 army needs 20 each).
- Checkers: 24, one full set, for K–1 (8 per child, four of each colour, so that a checker of the other colour is at hand for the reserve "which checker is the last one"); the second set stays in the bag as spares.
- Student pages: K–1 packet × 3, grades 2–3 packet × 4, grades 4–5 packet × 3 (one per child; the strips and boards are played on directly). Facilitator guide × 3.
- Pencils: 12. Crayons: 3 (K–1 Problem 11 colours a square). Two erasers.
- Three strips of eight 1.25-in squares cut from a printed 1.25-in grid, for K–1 Problem 6 (one per child).
- Launch and share board: one printed 1-in grid at least 9 squares wide and 8 squares tall (portrait Letter works). Draw a thick line with a marker between the 4th and 5th rows from the bottom (four rows below the line, four above). Use a small sticky note as the star; it is moved to row 1 for the launch and to rows 2, 3, 4 during the share. Two spare pennies for the launch.
- Four spare printed 1-in grids and a marker, for reserve boards (outline a 3-by-4 or 3-by-3 board when needed). Ten sheets of scrap paper.

Preparation (15 minutes the day before): print and staple the packets; cut the three strips of eight; prepare the launch board; sort the cups; each adult reads their table's section (B4, B5 or B6) once through and plays the first three problems with real counters.

## B3. Whole-group launch (2 minutes)

Everyone stands around the launch board (star on row 1, two pennies in the star's column in rows 0 and −1, nothing else).

Script. "This is the line. These two counters start below it. Here is the only rule we use all hour: a counter may jump over the counter right next to it, left, right, up or down, never slantwise, into the empty square right behind it, and the counter it jumped over comes off. [Invite a K–1 child to make the jump: the lower penny over the upper one onto the star.] One counter is over the line. [Remove the jumped counter, leave the one on the star, then put a single penny back below the line alone.] Can one counter alone ever go anywhere? [Let them answer: no, nothing to jump over.] So it took two counters to get one over the line. At your tables you will work out how far an army can get, how few counters you can leave on a strip, and the question that matters most: how you can be sure when something cannot be done. Go."

Do not state any answers beyond "two counters get one row over". Do not mention the golden ratio; it is for the share and the mathematicians.

## B4. K–1 table (parent; three children)

Order and timing (table work runs from 0:07 to 0:50, 43 minutes; the pages hold 67 minutes): Problems 1–4 by 0:24, Problems 5–6 by 0:33, Problems 7–10 by 0:50 (the army; these are what the table shows at the share). Problems 11–15 are for a fast table or a child who races ahead, and the reserves in B4.4 come after those. Whatever happens, start Problem 7 by 0:33: if the table is still on Problem 4 at 0:30, finish recording it and skip Problems 5–6 (they can be done at the end). The child places the checkers and jumps; the adult reads each problem aloud, scribes the dots, tallies and numbers when asked, and asks the "how do you know" questions listed below only after the recording is done.

### B4.1 Answers and arguments

Problem 1. Strip A (checkers on 1 and 2): one jump, 1 over 2 into 3, landing on square 3; one checker left. Strip B (checkers on 1 and 3): no jump. The middle square is empty, a checker may only jump over a checker, and neither checker has a neighbour. Strip C: one jump, 3 over 2 into 1, landing on square 1. Marks beside A and C.

Problem 2. Strip D (`XXX.`): the only possible jump is 2 over 3 into 4. Then `X..X`, no jump left. One jump, two checkers left (squares 1 and 4). There is never a choice.

Problem 3. Strip E (`X.XX`): the only first jump is 4 over 3 into 2 (`XX..`), then the only jump is 1 over 2 into 3 (`..X.`). Two jumps, one checker left, on square 3. Strip E allowed more jumps. Same three checkers, same strip, the empty square moved by one, and the ending changed from two left to one left.

Problem 4. Every play on a strip of five leaves two checkers. Strip F (`XXXX.`): forced, 3 over 4 into 5, then 1 over 2 into 3, stuck at `..X.X`. Strip G (`XXX.X`): forced, 2 over 3 into 4, then 5 over 4 into 3, stuck at `X.X..`. Strip H (`XX.XX`): two possible first jumps. After 1 over 2 into 3 (`..XXX`) the only jump is 4 over 3 into 2, stuck at `.X..X`. After 5 over 4 into 3 (`XXX..`) the only jump is 2 over 3 into 4, stuck at `X..X.`. The mark goes beside H. Why no strip of five can get down to one: there are only these five positions in the whole game (the start, two positions after the first jump, two stuck endings) and both endings have two checkers. A child can show this by playing H both ways and pointing out that F and G never offered a choice.

Problem 5. Strip J (`XXXXX.`): forced, 4 over 5 into 6, then 2 over 3 into 4, stuck at `X..X.X`, three left. Strip K (`XXXXXX.`): forced, 5 over 6 into 7, 3 over 4 into 5, 1 over 2 into 3, stuck at `..X.X.X`, three left.

Problem 6. Endings with the empty square at the end: 4 squares `X..X` (2 left), 5 squares `..X.X` (2), 6 squares `X..X.X` (3), 7 squares `..X.X.X` (3), 8 squares `X..X.X.X` (4). What is the same: the checkers left sit on every second square counted from the right end, and there is never a choice. The strip of eight: 6 over 7 into 8, 4 over 5 into 6, 2 over 3 into 4, stuck at `X..X.X.X`, four left. Reason a child can give: the only checker that can move is the one two squares from the empty square; it jumps into the hole and leaves a new hole two squares further left; then the same thing happens again, until the hole reaches the left end. Ask: "Where would they be on a strip of nine?" (`..X.X.X.X`, four left.)

Problem 7. Two checkers: the lower one jumps over the upper one onto the star. One checker alone never jumps: there is nothing to jump over.

Problem 8. Four checkers: a pair stacked under each star (rows 0 and −1 in each star's column); each pair does the jump of Problem 7. Fewer than four is impossible (see Problem 9).

Problem 9. Six checkers, a pair under each star. Four stars would need eight. The argument, in the children's terms: every checker that ends on a star got there by jumping, because checkers only move by jumping; every jump throws one checker off; so for every star there is one checker on it and at least one checker thrown away for it, at least two per star. Have a child show it with checkers: put a pair under one star, jump, and point to the thrown-away checker; "this one was used up for that star". Sequence for the table: 1 star 2, 2 stars 4, 3 stars 6, 4 stars 8.

Problem 10. The L reaches the star in three jumps: (1) the checker below the middle one jumps up over it, landing just above the line in the star's column; (2) the rightmost checker in the row below the line jumps left over its neighbour into the star's column; (3) that checker jumps up over the one above the line onto the star. On the small boards: arrow up, arrow left, arrow up.

Problem 11. The column of four reaches only the row just above the line, and on board E the play is forced: the second checker from the top jumps up over the top one to row 1 (the only jump available); then the bottom checker jumps up over the one above it into row −1 (again the only jump); then nothing can jump (the two remaining checkers are two squares apart with an empty square between them). Colour the square just above the line. Board D reached the star, board E did not: the same four checkers, a different shape.

Problem 12. Three checkers never reach a star two rows up (checked by complete search over every placement). Argument for the adult, to be given in pieces: with three checkers you can make at most two jumps, because each jump throws one checker off and the checker on the star must remain. To land on the star, the last jump comes from the square just below the line over a checker in the row just above the line (a sideways jump inside row 2 would need two checkers already up in row 2, which is even more work). So just before the last jump we need one checker in row 1 and one checker in row 0 under it. The checker in row 1 got there by jumping up over the checker that was in row 0, and that jump threw that row-0 checker away. So someone else must refill row 0 before the last jump: that is a third jump, and three jumps need four checkers. The L does exactly this: up, then refill from the side, then up.

Problem 13. The two ways: the L of Problem 10 (three checkers in row 0 starting at the star's column and going right, plus one checker under the first) and its mirror image (going left). Complete search shows these are the only two placements of four checkers that work. If a child offers a shape with the checkers elsewhere, let them test it; it will fail.

Problem 14. Middle empty: no jump at all. A jump needs an empty square two steps away in a straight line with a checker in between; the only empty square is the middle, and every checker is either next to it (the side squares) or diagonal from it (the corners), never two steps away in a straight line. Corner empty (bottom-left): exactly two first jumps, the top-left checker down over the left-middle one, or the bottom-right checker left over the bottom-middle one.

Problem 15. The fewest is four; every play ends with four or five checkers (16 positions in the whole game). A play that leaves four: top-left down over left-middle into the corner; right-middle left over the centre into left-middle; corner up over left-middle into top-left; bottom-right left over bottom-middle into the corner; stuck with the top row full and one checker in the bottom-left corner. The ending with five is an L (the whole left column and the whole bottom row), reached for instance by top-left down into the corner, top-right left over top-middle into top-left, right-middle left over the centre into left-middle. The three endings with four are: top row plus the bottom-left corner; right column plus the bottom-left corner; and the four checkers top-left, top-right, centre, bottom-right. One checker is impossible here; a child can say "we tried every first jump and every way after it" (there are only 16 positions).

### B4.2 Hints, in order
- Problem 1: "Which checker has a checker right next to it? Where is the empty square behind that one?" Then demonstrate one jump on strip A and let the child do B and C.
- Problems 2–4: "Find every checker that could jump right now. How many are there?" (On D, E, F, G the answer is always one; on H it is two.) If a child slides or jumps over a gap, reset and restate the rule.
- Problem 6: "Look at the right-hand end of each small strip. Where is the first checker? The next one?" For the prediction: "Do it in your head: which checker jumps first on the strip of eight?"
- Problem 8: if a child puts three or four checkers under one star: "That star is done. What did the other star need?" If they try a row of checkers along the line: "Which way must the checker jump to cross the line? What must be under it?"
- Problem 9: "Show me the checker that got thrown away for this star. And for that one."
- Problem 10: "Which jump crosses the line first? Now which checker can jump into the middle column?"
- Problem 12: after two or three failed armies, "How many jumps can three checkers ever make?" then "What has to be under the star just before the last jump?"
- Problem 14: "Point to the empty square. Is any checker two steps away from it in a straight line?"
- Problem 15: "Try starting with the other first jump. Which checker could you save at the end?"

### B4.3 If the table stalls
Reading and placing take most of the time at this table. Keep the rhythm: the child moves, the adult scribes. If a child cannot find any jump on a strip, do the first jump with the child's hand and let them find the next. Never leave a problem unrecorded; the dots on the small strips are what the share uses. If Problems 12–13 stall, stop after five minutes, show the L and its mirror, and go on to Problem 14, which is a fresh start.

### B4.4 If the table finishes early (reserves, no printing needed)
- R1. The count that never changes. On strip J put checkers on squares 1, 2, 4, 5, 6 (`XX.XXX`). Play twice with different first jumps. The two endings are `X..X.X` (2 jumps, 3 left) and `.X.X..` (3 jumps, 2 left); jumps plus checkers left is 5 both times, because each jump throws off exactly one checker.
- R2. Which checker is the last one. On strip J set `X.XXXX` (checkers on 1, 3, 4, 5, 6) with a checker of the other colour on square 1. Every play ends with one checker (7 positions in the game). The checker from square 1 can be the survivor (it ends on square 5: 4 over 3 into 2, 1 over 2 into 3, 6 over 5 into 4, 3 over 4 into 5) and the checker from square 6 can be the survivor (it ends on square 2: same start, then 4 over 3 into 2 as the last jump). A checker that starts on 3, 4 or 5 never survives.
- R3. Count the first jumps. On strip H (`XX.XX`): 2 first jumps. On `X.XXXX`: 1. On board J: 2. Ask the child to point to each.
- R4. Last jump wins, on board J (corner empty). Two players take turns making one jump; whoever makes the last possible jump wins. The starter wins by jumping the top-left checker down into the corner; whichever of the two available replies the opponent makes (right-middle into left-middle, or top-right into top-left), the starter makes the other one and no jump is left.

## B5. Grades 2–3 table (second mathematician; four children)

Order and timing (table work runs from 0:07 to 0:50, 43 minutes; the pages hold 63 minutes): Problems 1–2 by 0:16, Problem 3 by 0:24, Problem 5 by 0:32, Problems 6–7 by 0:42, Problem 8 by 0:50; Problem 9 is for the pair that gets there and for the share (the adult places the army at the share in any case). Problem 4 is done only if the table is ahead of these times; otherwise it is the first thing to do after Problem 8 or at the end. Whatever happens, start Problem 6 by 0:36 so that the army problems are reached. Let the children work in two pairs on Problems 3, 7, 8 and 9; each child still records on their own page.

### B5.1 Answers and arguments

Problem 1. Strip A (`XXX.`): the only jump is 2 over 3 into 4; stuck at `X..X`; 1 jump, 2 left. Strip B (`X.XX`): 4 over 3 into 2, then 1 over 2 into 3; stuck at `..X.`; 2 jumps, 1 left. Same three pennies; moving the hole by one square changes the ending.

Problem 2. Strip C (`XXXX.`): forced, 3 over 4 into 5, 1 over 2 into 3, stuck `..X.X`, 2 left. Strip D (`XXX.X`): forced, 2 over 3 into 4, 5 over 4 into 3, stuck `X.X..`, 2 left. Strip E (`XX.XX`): first jump 1 over 2 into 3, then 4 over 3 into 2, stuck `.X..X`; or first jump 5 over 4 into 3, then 2 over 3 into 4, stuck `X..X.`; 2 left either way. Only strip B is circled. On a strip of five no hole position allows one penny (the other hole positions are mirror images of C and D).

Problem 3. Strip F (`X.XXXX`, hole at 2): the first jump is forced (4 over 3 into 2, giving `XX..XX`), then there are choices, but every play ends with exactly one penny (the game has 7 positions; the two endings are `.X....` and `....X.`). The last penny sits on square 2 or square 5, never anywhere else. Example: 4 over 3 into 2, 1 over 2 into 3, 6 over 5 into 4, then 3 over 4 into 5 (ends on 5) or 4 over 3 into 2 (ends on 2). Strip G (`XX.XXX`, hole at 3): two first jumps. Starting 1 over 2 into 3, the rest is forced: 4 over 3 into 2, 6 over 5 into 4, stuck `.X.X..`, 2 left. Starting 5 over 4 into 3, the rest is forced: 2 over 3 into 4, stuck `X..X.X`, 3 left. So the fewest is 2, and the first jump decides it. Strip H (`XXXXX.`, hole at 6): forced, 4 over 5 into 6, 2 over 3 into 4, stuck `X..X.X`, 3 left. Compare: hole at 2 always 1; hole at 3, 2 or 3; hole at 6 always 3.

Problem 4. Strip J (`XXX.XXXX`): the endings are `.X......` and `....X...` (1 penny, 6 jumps), `..X...X.` (2 pennies, 5 jumps) and `X.X.X..X` (4 pennies, 3 jumps). The last column is 7 every time. Reason: every jump throws off exactly one penny, so the number of jumps equals the number of pennies removed, and removed plus left is the starting seven. Sample plays: to 1 penny: 6 over 5 into 4, 3 over 4 into 5, 1 over 2 into 3, 8 over 7 into 6, 6 over 5 into 4, then 3 over 4 into 5 (ends on 5) or 4 over 3 into 2 (ends on 2). To 2 pennies: 6 over 5 into 4, 8 over 7 into 6, 3 over 4 into 5, 1 over 2 into 3, 5 over 6 into 7. To 4 pennies: 2 over 3 into 4, then the forced 5 over 4 into 3 and 7 over 6 into 5, and no jump is left. Ending with exactly 3 is impossible (there are 16 positions in the game and no stuck position has 3).

Problem 5. The map of `XX.XX` has 5 positions and 4 arrows: `XX.XX` → `..XXX` and `XXX..`; `..XXX` → `.X..X` (stuck); `XXX..` → `X..X.` (stuck). Both stuck positions have 2 pennies. Because the map contains every position that can ever be reached, it is a proof that one penny is impossible on this strip: there is no way to play that is not on the map. Ask: "Could there be a play we missed?" The answer is no, because at every position we drew every possible jump.

Problem 6. Always exactly one square past the line, and the play is forced. K (block of 3): 2 over 3 into 4, then nothing. L (block of 4): 3 over 4 into 5, 1 over 2 into 3, then nothing; farthest square 5. M (block of 5): 4 over 5 into 6, 2 over 3 into 4; farthest square 6. Number boxes: 1, 1, 1.

Problem 7. No army on squares 1 to 6 ever gets a penny onto square 8; the farthest any penny ever reaches is square 7 (all 63 armies checked by computer). Gaps do not help. The argument for the table, with prices (this is the grades 4–5 Problem 4; the adult leads it here with pencil and paper): write 1, 1, 2, 3, 5, 8 under squares 1 to 6 and 13, 21 under squares 7 and 8. Every price is the sum of the two prices to its left. A jump to the right removes pennies from two neighbouring squares and puts one on the next square, whose price is exactly the sum of the two: the total price of the pennies on the strip does not change. A jump to the left lands on a square that costs less than the two it used together: the total goes down. So the total never goes up. The whole army on squares 1 to 6 is worth 1 + 1 + 2 + 3 + 5 + 8 = 20, and any smaller army is worth less. A penny sitting on square 8 is worth 21 by itself. So no penny ever gets there. Third graders can follow this if the adult does the adding with them on one of their small strips. A shorter picture, less rigorous but good for the table: to land on 8 you need pennies on 6 and 7; the penny on 7 came from 5 over 6, which emptied 6; to refill 6 you need 4 and 5 full again; refilling 5 needs 3 and 4; and so on, each refill needing a refill two squares further left, until the chain asks for a square left of square 1, which does not exist.

Problem 8. Three pennies never reach the star two rows up (complete search over every placement). Argument: with three pennies at most two jumps are possible, since each jump removes one penny and one must remain. The last jump onto the star comes from row 0 over a penny in row 1 (a sideways jump within row 2 would need two pennies already in row 2, costing even more). So just before it, one penny is in row 1 and one in row 0 under it. The penny in row 1 arrived by jumping over the penny in row 0, which removed it; so row 0 must be refilled by another jump: three jumps at least, hence four pennies at least. With four pennies exactly one shape works, up to mirror image: the L, three pennies in row 0 starting from the star's column and running to the right (or to the left), and one penny in row −1 under the first. Jumps: (1) the row −1 penny jumps up over the row 0 penny into row 1; (2) the far end penny in row 0 jumps sideways over its neighbour into the star's column; (3) that penny jumps up over the row 1 penny onto the star. Any other four-penny placement fails (search); children may test whatever they propose.

Problem 9. The army: row 0 at columns −2, −1, 0, 1, 2 and row −1 at columns 0, 1, 2. The seven jumps: (1) row −1, column 0 jumps up over row 0 into row 1; (2) row 0, column −2 jumps right over column −1 into column 0; (3) row 0, column 0 jumps up over row 1 into row 2; (4) row −1, column 1 jumps up over row 0 into row 1; (5) row −1, column 2 jumps up over row 0 into row 1; (6) row 1, column 2 jumps left over column 1 into column 0; (7) row 1, column 0 jumps up over row 2 onto the star. The structure: the first three jumps are the L of Problem 8 getting a penny to row 2; jumps 4–6 bring a second penny to row 1 under it using two stacked pairs; jump 7 finishes. Seven pennies can never reach row 3 (the grades 4–5 table proves it with prices; for this table say "the price argument shows it, ask the 4–5 table at the share").

### B5.2 Hints, in order
- Problems 1–2: "Which pennies can jump at all? Count them." "Is there a choice anywhere?"
- Problem 3: "On strip G, try the other first jump and play to the end. Which first jump was better?" "On strip F, what happens on the first jump no matter what?"
- Problem 4: "Before adding, guess the third column. Now check it." "What does one jump do to the number of pennies?"
- Problem 5: "From the start there are two jumps. Draw both results, then work on each one." "Are the two endings the same or mirror images?"
- Problem 6: "Which penny is the only one that can move?"
- Problem 7: "Try a big army, a tiny army, an army with a gap. Which square did the best one reach?" Then lead the price argument (B5.1, Problem 7) at the table with paper.
- Problem 8: "How many jumps can three pennies make?" "What must be under the star just before the last jump, and how did it get there?"
- Problem 9: "First get a penny two rows up: that is Problem 8. Then you need a penny just above the line in the star's column while the one two rows up is still there. Where can that penny come from?"

### B5.3 If the table stalls
The mechanics are quick for third graders; stalls come from "fewest" searches. Set a limit: three plays per strip, then record and move on; the map (Problem 5) is where certainty comes from. If Problem 7 becomes random poking after four armies, stop and do the price argument at the table. If Problem 9 stalls after six minutes, give jumps 1–3 (the L) and let them find 4–7.

### B5.4 If the table finishes early (reserves, no printing needed)
- R1. Strip J again: find plays that end with 1, with 2 and with 4 pennies, then try to end with exactly 3. Three is impossible (the four stuck positions of the game have 1, 1, 2, 4 pennies).
- R2. Last jump wins on strip G (`XX.XXX`): two players alternate single jumps; whoever makes the last possible jump wins. The starter wins with 1 over 2 into 3: the rest is forced (4 over 3 into 2, then 6 over 5 into 4), three jumps, the starter makes the last. The other first jump, 5 over 4 into 3, loses: the reply 2 over 3 into 4 ends the game after two jumps.
- R3. A second army of eight for row 3 that is not a mirror image of Problem 9's: row 0 at columns −2 to 2, and column 0 at rows −1, −2, −3. Jumps: (1) row −1 col 0 up over row 0 into row 1; (2) row 0 col −2 right over col −1 into col 0; (3) row −3 col 0 up over row −2 into row −1; (4) row 0 col 0 up over row 1 into row 2; (5) row 0 col 2 left over col 1 into col 0; (6) row −1 col 0 up over row 0 into row 1; (7) row 1 col 0 up over row 2 onto the star. These two are the only eight-penny armies for row 3 (up to mirror image; complete search).
- R4. Four holes, four different games. Outline a 3-wide, 4-tall board on a spare grid, 11 pennies. Hole in a corner: one penny is possible, and the lone survivor can only end on that corner or the other corner of the same short side (121 positions). Hole in the middle of a short side: only one jump exists in the whole game, then stuck with 10. Hole in the second square up a long side: one penny is possible and it can only end on the starting hole (154 positions). Hole on an inside square: two jumps, stuck with 9. A solution for the corner hole, naming squares (column, row) from the bottom-left corner (1,1): (1,3) over (1,2) into (1,1); (3,2) over (2,2) into (1,2); (1,1) over (1,2) into (1,3); (1,4) over (1,3) into (1,2); (2,4) over (2,3) into (2,2); (2,1) over (2,2) into (2,3); (3,4) over (3,3) into (3,2); (3,1) over (3,2) into (3,3); (3,3) over (2,3) into (1,3); (1,3) over (1,2) into (1,1).
- R5. Row 3 with seven pennies: let them try; it is impossible (the 4–5 table's price map: the seven most expensive squares below the line are worth 3 + 2 + 2 + 2 + 1 + 1 + 1 = 12, and the star costs 13).

## B6. Grades 4–5 table (organizer; three children)

Order and timing (table work runs from 0:07 to 0:50, 43 minutes; the pages hold 77 minutes): Problem 1 by 0:14, Problem 3 by 0:22, Problem 4 by 0:33, Problem 5 by 0:39, Problem 6 by 0:50 (the second army of Problem 6 can be left for the share); Problems 7–8 are for the fast pair and for the share (the organizer plays the 19 jumps at the share in any case). Problem 2 (the map) is done in its printed place only if the table is ahead of these times; otherwise the "how do you know" for strip B is asked orally (hint: list every play) and the map is done at the end. If the table is still slow, shorten Problem 1 to strips A and B and cut Problem 3 to strip G only, so that Problem 4 (the prices) and Problems 5–6 (rows 2 and 3) are reached. The three children can work as a trio on Problems 2, 6 and 8.

### B6.1 Answers and arguments

Problem 1. Strip A (`X.XXXX`): the first jump is forced (4 over 3 into 2); afterwards every play ends with exactly one penny, on square 2 or on square 5 (7 positions, endings `.X....` and `....X.`). Example: 4 over 3 into 2, 1 over 2 into 3, 6 over 5 into 4, then 3 over 4 into 5 or 4 over 3 into 2. Strip B (`XX.XXX`): starting with 1 over 2 into 3 forces 4 over 3 into 2 and 6 over 5 into 4, ending `.X.X..` with 2; starting with 5 over 4 into 3 forces 2 over 3 into 4, ending `X..X.X` with 3. Fewest 2, decided by the first jump. Strip C (`XXXXX.`): forced, 4 over 5 into 6, 2 over 3 into 4, `X..X.X`, 3 left. Number boxes: 1, 2, 3.

Problem 2. The map of `XX.XXX`: 6 positions, 5 arrows. `XX.XXX` → `..XXXX` and `XXX..X`; `..XXXX` → `.X..XX`; `.X..XX` → `.X.X..` (stuck, 2); `XXX..X` → `X..X.X` (stuck, 3). No position is reached twice. The map proves that 2 is the fewest on strip B and that only the first jump matters. (If a child asks about strip A: its map has 7 positions and 7 arrows, and two different routes meet at `..XX..`; see reserve R1.)

Problem 3. Strips D, E, F: always exactly one square past the line, forced play. D: 2 over 3 into 4. E: 3 over 4 into 5, 1 over 2 into 3. F: 4 over 5 into 6, 2 over 3 into 4. Number boxes 1, 1, 1. Strip G: no army on squares 1 to 6 ever reaches square 8; square 7 is the farthest (all 63 armies checked by computer; they cannot check all 63 by hand in the time, which is the point of Problem 4).

Problem 4. Full army on squares 1 to 6: total 20 before any jump. A jump to the right lands on a square whose price is exactly the sum of the two prices it used (1 + 1 = 2, 1 + 2 = 3, 2 + 3 = 5, 3 + 5 = 8, 5 + 8 = 13, 8 + 13 = 21), so the total stays the same. A jump to the left lands on a square that costs less than the two it used together (for 3 over 2 into 1 the change is 1 − 2 − 1 = −2; for a jump from square k over k − 1 into k − 2 it is always negative), so the total goes down. Hence the total never goes up, and the largest total in any table is 20 (every play from the full army has at most 5 jumps; the tables have room for that). The star, square 8, costs 21, and a penny sitting on it would alone be worth 21: so no penny ever lands on square 8, whatever the play, and this covers every army at once, since any army on squares 1 to 6 is worth at most 20. Strip J (squares 1, 2, 4, 5, 6): total 18, same conclusion; possible jumps from the start are 1 over 2 into 3 (total stays 18), 5 over 4 into 3 (total drops to 1 + 1 + 2 + 8 = 12) and 5 over 6 into 7 (stays 18). Small table: 1 to 3: 4 and 5; 1 to 4: 7 and 8; 1 to 5: 12 and 13; 1 to 6: 20 and 21; 1 to 7: 33 and 34; difference always 1. Why the next row will also give 1 without adding: adding one more penny adds the next price to the army; the old army was worth one less than its old target; old target plus the new penny's price is the new target, because each price is the sum of the two before it; so the new army is again worth one less than its new target. (Fibonacci identity: 1 + 1 + 2 + ... + F(n) = F(n + 2) − 1.)

Problem 5. Three pennies never reach row 2 (complete search over every placement). Argument: at most two jumps with three pennies; the last jump onto the star comes from row 0 over row 1; the row 1 penny got there by a jump that removed the row 0 penny beneath it; refilling row 0 is a third jump; so four pennies at least. With four, the only shape up to mirror image is the L: row 0 at columns 0, 1, 2 (or 0, −1, −2) and row −1 at column 0. Jumps: (0,−1) up over (0,0) into (0,1); (2,0) left over (1,0) into (0,0); (0,0) up over (0,1) onto (0,2). The row-2 price board of Problem 7 gives the clean proof: the three most expensive squares below the line are worth 3 + 2 + 2 = 7 and the star costs 8.

Problem 6. Exactly two armies of eight work, up to mirror image (complete search). In board L coordinates (letters A–I, rows 1–7, line between rows 4 and 5, star E7):
Army (a): C4, D4, E4, F4, G4, E3, F3, G3. Jumps: 1. E3 over E4 to E5; 2. C4 over D4 to E4; 3. E4 over E5 to E6; 4. F3 over F4 to F5; 5. G3 over G4 to G5; 6. G5 over F5 to E5; 7. E5 over E6 to E7.
Army (b): C4, D4, E4, F4, G4, E3, E2, E1. Jumps: 1. E3 over E4 to E5; 2. C4 over D4 to E4; 3. E1 over E2 to E3; 4. E4 over E5 to E6; 5. G4 over F4 to E4; 6. E3 over E4 to E5; 7. E5 over E6 to E7.
Structure of (a): jumps 1–3 are the L reaching row 2; jumps 4–6 use two stacked pairs to bring a penny to E5 while E6 is still occupied; jump 7 finishes. Structure of (b): the L again, then a column refills E4 and E5 from below. Mirror images (columns C and D swapped with G and F) are the same army.

Problem 7. Board M prices: the star E7 costs 13; distance 1 costs 8, distance 2 costs 5, distance 3 costs 3, distance 4 costs 2, distance 5 or more costs 1. Army (a) is worth 1 + 2 + 3 + 2 + 1 + 2 + 1 + 1 = 13 (C4 1, D4 2, E4 3, F4 2, G4 1, E3 2, F3 1, G3 1). After each of the seven jumps the total is still 13: every jump in this solution lands on a square worth exactly the two it used (jump 1: 2 + 3 = 5 at E5; jump 2: 1 + 2 = 3 at E4; jump 3: 3 + 5 = 8 at E6; jump 4: 1 + 2 = 3 at F5; jump 5: 1 + 1 = 2 at G5; jump 6: 2 + 3 = 5 at E5; jump 7: 5 + 8 = 13 at E7). A jump away from the star lowers the total: for example E4 over E3 down to E2 removes 3 + 2 and adds 1, total 9; F4 over G4 right to H4 removes 2 + 1 and adds 1, total 11. General fact: no jump ever raises the total (a jump straight towards the star is neutral, every other jump loses), checked by computer for every jump on a large board. The seven most expensive squares below the line: E4 (3), D4, F4, E3 (2 each), and three squares worth 1 (for instance C4, G4, F3): 3 + 2 + 2 + 2 + 1 + 1 + 1 = 12, less than 13. So no army of seven pennies, placed anywhere, can ever put a penny on the star: its total starts at 12 or less, never rises, and a penny on the star is worth 13 by itself. The best eight are worth exactly 13, so an eight-penny army must be worth exactly 13, must never make a wasteful jump, and must end with nothing else on the board, which is what armies (a) and (b) do. Board N: the star costs 8; the three most expensive squares below the line are D3 (3), C3, E3 and D2 (2 each): the best three total 7, less than 8, so three pennies can never reach row 2; the L is worth 3 + 2 + 1 + 2 = 8 exactly.

Problem 8. Table: 1 row: 2; 2 rows: 4; 3 rows: 8; 4 rows: 20; 5 rows: never, for any number of pennies. Most children guess 16 for row 4; the pattern breaks. With 16 pennies, or any number up to 18, it is impossible: with Conway's exact weights (B8) the 18 heaviest squares below the line weigh 0.9787 in total, less than the star's weight 1. Nineteen is also impossible: the only 19-penny armies heavy enough weigh exactly 1, there are 84 of them, and a computer search shows none reaches row 4. Twenty works, and only four different 20-armies work up to mirror image (search). Board Q's army: row 4 at A–I, row 3 at C, D, E, F, row 2 at B, C, D, E, F, row 1 at D, E. The 19 jumps: 1. C3 over C4 to C5; 2. D3 over D4 to D5; 3. D1 over D2 to D3; 4. B2 over C2 to D2; 5. D2 over D3 to D4; 6. E3 over E4 to E5; 7. E1 over E2 to E3; 8. A4 over B4 to C4; 9. C4 over D4 to E4; 10. E4 over E5 to E6; 11. G4 over F4 to E4; 12. F2 over F3 to F4; 13. E3 over E4 to E5; 14. I4 over H4 to G4; 15. G4 over F4 to E4; 16. E5 over E6 to E7; 17. C5 over D5 to E5; 18. E4 over E5 to E6; 19. E6 over E7 to E8. Structure: jumps 1–2 park two helpers at C5 and D5 (row 1); jumps 3–5 rebuild D4; jumps 6–10 push a penny to E6 (row 2) using the column E1–E4 and the left half of row 4; jumps 11–15 refill E4 and push again to E5; jump 16 reaches E7 (row 3); jump 17 brings the helpers to E5; jumps 18–19 climb to the star. This army weighs exactly 1, so every one of its 19 jumps is straight towards the star and nothing is left over.

### B6.2 Hints, in order
- Problem 1: "On strip A, what is the only first jump? After it, where can the last penny possibly end up? Try to make it end somewhere else." "On strip B, play both first jumps to the end."
- Problem 2: "Two arrows leave the start. Follow each branch to the end. Did any position appear twice?"
- Problem 3: "Which penny is the only one that can move?" On strip G: "Try the full army, then leave square 3 empty, then use only squares 4, 5, 6."
- Problem 4: "Before adding, guess whether the total went up, down, or stayed." "Which square's price equals the two before it? All of them?" "If the total can never go up, and it starts at 20, what is the most a single penny on the strip could ever be worth?"
- Problem 5: "How many jumps can three pennies make? How many jumps did the L need?"
- Problem 6: "You know how to reach row 2 with four. What must sit at E5 when a penny is at E6, and where can it come from?" Then "two stacked pairs make a sideways jump into column E possible". For the second army: "Instead of two pairs, could a column under E4 do the refilling?"
- Problem 7: "Which jumps kept the total? Which lowered it? Is there any jump that raised it?" "Add up the seven best squares below the line before you compare."
- Problem 8: after five minutes with 16, say that 16 cannot work, and neither can 17, 18 or 19 (reasons in B6.1), then hand them board Q. Hint for the 19 jumps: "First park two pennies at C5 and D5; they are needed at the very end." Second hint: "Get a penny to E6 the way the L does, using the column E1 to E4 and the left half of row 4."

### B6.3 If the table stalls
Fourth and fifth graders stall on "find the army" problems (6 and 8), not on strips. Give Problem 6 eight minutes; then show army (a)'s first three jumps and let them finish; then give army (b) as the second. Problem 8's 16-penny attempt is meant to fail: stop it after five minutes and go to board Q with the first hint. If the whole table is behind at 0:34, skip Problem 4's second table and the small table and go straight to Problems 5 and 6, so that the row-2 and row-3 armies exist for the share.

### B6.4 If the table finishes early (reserves, no printing needed)
- R1. The map of strip A (`X.XXXX`) on scrap paper: 7 positions, 7 arrows: `X.XXXX` → `XX..XX`; `XX..XX` → `..X.XX` and `XX.X..`; both of these → `..XX..`; `..XX..` → `....X.` and `.X....` (stuck, 1 penny each). Two routes meet, so the map is not a tree; the endings are exactly squares 2 and 5.
- R2. Finish on the hole. Outline a 3-wide, 4-tall board on a spare grid, 11 pennies, hole in the bottom-left corner; finish with one penny on that corner. Solution, squares named (column, row) from (1,1) at the bottom-left: (1,3) over (1,2) into (1,1); (3,2) over (2,2) into (1,2); (1,1) over (1,2) into (1,3); (1,4) over (1,3) into (1,2); (2,4) over (2,3) into (2,2); (2,1) over (2,2) into (2,3); (3,4) over (3,3) into (3,2); (3,1) over (3,2) into (3,3); (3,3) over (2,3) into (1,3); (1,3) over (1,2) into (1,1). Replacing the last jump by (1,2) over (1,3) into (1,4) finishes on the other corner; these two corners are the only possible final squares (121 positions).
- R3. Row 5 on paper. Prices by distance from a star five rows up: 89, 55, 34, 21, 13, 8, 5, 3, 2, 1, 1, ... The 9-wide, 4-deep block of 36 squares under the star is worth 72, less than 89. The 25 squares at distance 5 to 9 are worth 61 and every further square is worth 1, so at least 53 pennies are needed before their prices could even add up to 89: no army of 52 or fewer can reach row 5. (The exact weights in B8 show that no finite army can.)
- R4. Last jump wins (two players alternate single jumps; the last jump wins). On `XX.XX` every play has exactly 2 jumps, so the second player always wins; on `X.XXXX` every play has exactly 4 jumps, second player again; on `XXX.XXX` every play has exactly 3 jumps, so the starter always wins whatever anyone does: the count "jumps = pennies removed" decides these games. On `XX.XXX` the starter wins only with 1 over 2 into 3.
- R5. A second 20-army for row 4, on a spare grid marked like board Q (9 columns A–I, 8 rows, line between rows 4 and 5, star at E8): row 4 at A, B, C, D, E, F, G; row 3 at C, D, E, F, G; row 2 at B, C, D, E, F, G; row 1 at D, E. Its 19 jumps (verified by replay): 1. C3 over C4 to C5; 2. D3 over D4 to D5; 3. D1 over D2 to D3; 4. B2 over C2 to D2; 5. D2 over D3 to D4; 6. E3 over E4 to E5; 7. E1 over E2 to E3; 8. G2 over F2 to E2; 9. E2 over E3 to E4; 10. F3 over F4 to F5; 11. G3 over G4 to G5; 12. A4 over B4 to C4; 13. C4 over C5 to C6; 14. D4 over D5 to D6; 15. E4 over E5 to E6; 16. G5 over F5 to E5; 17. E5 over E6 to E7; 18. C6 over D6 to E6; 19. E6 over E7 to E8. Structure: helpers parked at C5 and D5, the centre column rebuilt, a penny pushed to E7, then the helpers climb to C6 and D6 and jump across to E6 for the final climb. The search finds exactly four 20-armies up to mirror image (this one, board Q's, and two others not printed); all four weigh exactly 1, so none of their solutions ever makes a jump that is not straight towards the star.

## B7. The share (8 minutes, at the launch board)

1. K–1 (2 min). One child builds the L on the launch board with the star two rows up and makes the three jumps. Another child answers "how many checkers for one star, two stars, three stars?" (2, 4, 6) and says why each star needs two: the one that lands and the one thrown away for it.
2. Grades 2–3 (2 min). One child places the eight-penny army (star three rows up) and makes the seven jumps. Another states the strip result: on a strip, an army never gets more than one square past the line, however big it is, and says the price reason in one sentence ("the total price never goes up, and the square two past the line costs more than the whole army").
3. Grades 4–5 (3 min). One child shows the small table of Problem 4 (4 and 5, 7 and 8, ..., 33 and 34: the army is always worth one less than its target). Another gives the table of fewest: 2, 4, 8 and then 20, not 16. The organizer states Conway's theorem: no army of any size ever reaches row 5, and says that the proof gives each square a weight so that the star alone weighs as much as the whole infinite army; then, time permitting, plays the 19 jumps of board Q on the launch board (star four rows up).
4. Close (1 min). "One rule, three questions all hour: can it be done, how few, and how do you know for sure. The strongest answers today were the map, which lists everything, and the prices, which never go up."

## B8. Mathematics behind the session (for the two mathematicians)

The object. A position is a finite set of occupied cells of a strip or of the square grid; a move replaces cells a, b, c in a line (a, b occupied, c empty) by c alone. Every problem on the pages is one of five questions about this dynamical system: existence (can a target position be reached), impossibility, optimality (fewest pegs left; fewest pegs used), completeness (which end positions or end squares occur), and counting (number of positions, number of first moves). Impossibility is where the mathematics is: the children meet three kinds of certificate.

1. Exhaustion: the map of positions (grades 2–3 Problem 5, grades 4–5 Problem 2). Complete for strips of 5 or 6 (5 or 6 positions) and for the 3×3 board (16). Beyond about 30 positions it is a computer's job: the 4×4 board with a corner hole has 1687 positions, the 5×5 board with a centre hole 1,183,924.

2. Invariants and monovariants (potential functions). A function on positions that never increases under a move bounds what can be reached. The session uses four:
   - Jumps + pegs left = starting pegs (grades 2–3 Problem 4): an invariant, because every jump removes exactly one peg. It settles two-player "last jump wins" games whenever every play has the same length (reserve R4 for grades 4–5).
   - Fibonacci prices on the strip (grades 4–5 Problem 4): price F(i) on square i with F = 1, 1, 2, 3, 5, 8, ... Since F(i+2) = F(i+1) + F(i), a rightward jump is neutral and a leftward one loses. An army on squares 1..k is worth F(k+2) − 1, one less than the target two past the line: the identity F(1) + ... + F(k) = F(k+2) − 1. This is the one-dimensional shadow of Conway's argument, and also its converse: one past the line is always reached (forced play), two never.
   - Integer price maps on the grid (grades 4–5 Problem 7): price F(K − d) at Manhattan distance d from the star, with 1 beyond. A jump straight towards the star is neutral (three consecutive Fibonacci numbers), a jump across the star's column or row loses the price of the middle cell, a jump away loses. Because along any line of three cells the distance pattern is d, d+1, d+2 (or reversed) or d+1, d, d+1, no jump raises the total (checked by machine on a large board). Consequences: row 2 needs weight 8 and the best three cells are worth 7; row 3 needs 13 and the best seven are worth 12; row 4 needs 34 (K = 9) and the best eighteen are worth 33, so the integer map proves only that 18 pegs are too few for row 4.
   - Conway's weights (Winning Ways, chapter 23; Aigner's "Moving into the desert with Fibonacci"): weight σ^d at distance d from the target, with σ = (√5 − 1)/2, so σ² + σ = 1 and a jump towards the target is exactly neutral (σ^{d+2} + σ^{d+1} = σ^d), every other jump strictly loses. For a target in row 5 the whole half-plane below the line weighs exactly 1: a row at vertical distance k weighs σ^k + 2σ^{k+1}/(1 − σ) = σ^k + 2σ^{k−1}, and summing over k ≥ 5 gives σ³ + 2σ² = (2σ − 1) + (2 − 2σ) = 1. A finite army therefore weighs strictly less than 1, the weight never increases, and a peg on the target alone weighs 1: row 5 is unreachable by any finite army. For a target in row 4 the half-plane weighs 1/σ ≈ 1.618, so the argument gives only a lower bound: the 18 heaviest cells weigh (in exact form −12 + 21σ) ≈ 0.979 < 1, so 19 pegs are necessary; the 19 heaviest weigh exactly 1, which forces a 19-army to be one of the 84 maximal ones and to waste nothing; our search shows all 84 fail. Twenty suffice: four armies up to mirror image, and the printed one weighs exactly 1, so its solution uses only jumps straight towards the star. Minimality of 20 was proved by Bell, Hirschberg and Guerrero-García ("The minimum size required of a solitaire army", INTEGERS 7, 2007), in agreement with our search. Rows 1, 2, 3 cost 2, 4, 8 (unique army for row 2, exactly two for row 3, by search); the doubling is a coincidence that the fourth case breaks.
   
   Pagoda functions. Berlekamp, Conway and Guy call any function p on the cells with p(a) + p(b) ≥ p(c) for every move (a over b into c) a pagoda function; the sum of p over the position is then a monovariant, and a target position of larger pagoda value than the start is unreachable. Conway's weights, the Fibonacci prices and the integer price maps are pagoda functions; so is the counting invariant with p ≡ 1 turned into "pegs removed = jumps". The children's "prices never go up" is exactly this idea. Pagoda functions were introduced to prove impossibility results on the 33-hole English board (see also Beasley, "The Ins and Outs of Peg Solitaire").

3. Colouring invariants (not on this week's pages; the natural next session). Colour square i of a strip by i mod 3, or cell (c, r) of the grid by (c + r) mod 3 or by (c − r) mod 3. Every jump uses three consecutive cells of three different colours, so all three colour counts change by 1 at once and their parities move together. For `X.XXXXXX` (8, hole at 2) this proves the last peg can only sit on squares 1, 4, 7 (the truth is 4 or 7: necessary, not sufficient); for the 3×4 board with a corner hole the two diagonal colourings together allow exactly the two squares where the survivor really ends; for the 5×5 board with a centre hole all counts are 8, 8, 8, and one peg is impossible: a one-minute proof for a game with over a million positions.

Where it leads.
- Undergraduate: monovariants and invariants are the first chapter of any olympiad combinatorics course (Engel, "Problem-Solving Strategies", chapter on the invariance principle) and of the combinatorics units that teach Conway's Soldiers (Aigner's article; Winning Ways). The Fibonacci identity in Problem 4 and the exact arithmetic in Z[σ] (write every weight as a + bσ with integers a, b) are good exercises.
- Peg solitaire on graphs (Beeler and Hoilman, "Peg solitaire on graphs", Discrete Mathematics 311, 2011): which graphs, from which starting hole, can be reduced to one peg. For paths our search up to 16 squares shows: n = 3 yes (hole at an end); every even n ≥ 4 yes, with the hole at the 2nd square from an end (and for n ≥ 6 also the 5th); every odd n ≥ 5 no, from every hole. Beeler and Hoilman settle paths in general (and other families such as complete and complete bipartite graphs), and the subject has a growing literature on which graphs are solvable.
- Computation: deciding whether a general peg-solitaire position can be reduced to one peg is NP-complete (Uehara and Iwata, "Generalized Hi-Q is NP-complete", 1990), so certificates like pagoda functions, which are checked by one addition per move, are the tool that scales.
- Research directions the children's questions touch: minimal armies for other targets and other boards (hexagonal and triangular grids, higher dimensions), and the fact that with infinitely many moves allowed, row 5 becomes reachable (Tatham and Taylor, "Reaching row five in solitaire army"), which shows exactly what finiteness does in Conway's proof.

## B9. Verification note (for the guide's last paragraph)

Every position count, ending, minimal army and move sequence in this guide was checked by exhaustive search (`verify_curator.py` and the bank's `verify_*.py`, kept in the working directory); the row-4 results (no 19-army works; four 20-armies work) come from a bitboard search of every army heavy enough to reach the target, and the weights were computed exactly in Z[σ].
