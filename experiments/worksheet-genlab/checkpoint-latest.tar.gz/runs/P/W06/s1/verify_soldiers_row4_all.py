#!/usr/bin/env python3
"""Row 4 of Conway's Soldiers: search EVERY 20-peg army of weight >= 1 (cells
within taxicab distance 10 of the target; farther pegs cannot take part, see
the notes in verify_soldiers_row4.py), up to mirror symmetry, and print every
army that reaches (0, 4) together with a move sequence.
Run:  python3 verify_soldiers_row4_all.py > verify_soldiers_row4_all.out
"""
import itertools
import sys
import time
from multiprocessing import Pool

sys.path.insert(0, ".")
import verify_soldiers_row4 as V

R = V.R
BELOW = [c for c in V.CELLS if c[1] <= 0 and abs(c[0]) + abs(R - c[1]) <= 10]


def enumerate_armies(m):
    order = sorted(BELOW, key=lambda c: -V.val(V.W[c]))
    wl = [V.W[c] for c in order]
    n = len(order)
    out = []

    def rec(i, k, w, chosen):
        if k == 0:
            if V.ge_one(w):
                out.append(tuple(chosen))
            return
        if i >= n:
            return
        bound = w
        for j in range(i, min(n, i + k)):
            bound = V.add(bound, wl[j])
        if not V.ge_one(bound):
            return
        chosen.append(order[i])
        rec(i + 1, k - 1, V.add(w, wl[i]), chosen)
        chosen.pop()
        rec(i + 1, k, w, chosen)

    rec(0, m, (0, 0), [])
    return out


def canonical(army):
    a = tuple(sorted(army))
    b = tuple(sorted((-x, y) for x, y in army))
    return min(a, b)


def work(army):
    mv, nodes = V.search(list(army), node_limit=2_000_000)
    return army, mv, nodes


if __name__ == "__main__":
    t0 = time.time()
    armies = enumerate_armies(20)
    print(f"20-peg armies of weight >= 1 within distance 10: {len(armies)}")
    canon = sorted(set(canonical(a) for a in armies))
    print(f"up to mirror symmetry: {len(canon)}")
    sys.stdout.flush()
    wins = []
    done = 0
    limits = 0
    with Pool(2) as pool:
        for army, mv, nodes in pool.imap_unordered(work, canon, chunksize=16):
            done += 1
            if mv == "limit":
                limits += 1
                print("node limit for", army)
            elif mv is not None:
                wins.append((army, mv))
                print(f"WIN #{len(wins)} after {done} armies, {time.time()-t0:.0f}s: {sorted(army)}")
                print(V.show(set(army), xr=(-6, 6), ymin=-6))
                print("moves (from, over, to):")
                for i, m_ in enumerate(mv, 1):
                    print(f"  {i:2d}. {m_[0]} over {m_[1]} to {m_[2]}")
                V.replay(set(army), mv)
                sys.stdout.flush()
            if done % 2000 == 0:
                print(f"... {done}/{len(canon)} armies checked, {len(wins)} wins, {time.time()-t0:.0f}s")
                sys.stdout.flush()
    print(f"FINISHED: {len(wins)} winning 20-peg armies up to mirror symmetry; {limits} inconclusive; {time.time()-t0:.0f}s")
