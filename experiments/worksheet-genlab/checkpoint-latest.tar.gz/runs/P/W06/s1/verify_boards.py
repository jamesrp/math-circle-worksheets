#!/usr/bin/env python3
"""Exhaustive analysis of small peg-solitaire boards (strips and small grids).

A board is a set of cells; a jump is (a, b, c) with a, b occupied, c empty,
a-b-c three consecutive cells in a row or column.  The jumper at a lands on c
and the peg at b is removed.

For each start we compute, by breadth-first search over all reachable positions:
  * the number of reachable positions,
  * the minimum number of pegs left when stuck,
  * every reachable stuck (terminal) position, in particular where a lone
    surviving peg can stand,
  * whether the play is forced (at most one legal move in every position),
  * the 3-colouring prediction for where a lone survivor may stand.
Run:  python3 verify_boards.py  > verify_boards.out
"""
from collections import deque
import itertools


def lines_of(cells):
    """All ordered triples (a, b, c) of consecutive collinear cells in `cells`."""
    S = set(cells)
    out = []
    for (x, y) in cells:
        for dx, dy in ((1, 0), (0, 1), (-1, 0), (0, -1)):
            b = (x + dx, y + dy)
            c = (x + 2 * dx, y + 2 * dy)
            if b in S and c in S:
                out.append(((x, y), b, c))
    return out


def moves(pos, lines):
    for a, b, c in lines:
        if a in pos and b in pos and c not in pos:
            yield (a, b, c), (pos - {a, b}) | {c}


def analyse(cells, start):
    lines = lines_of(cells)
    start = frozenset(start)
    seen = {start}
    q = deque([start])
    terminals = set()
    forced = True
    while q:
        p = q.popleft()
        nxt = list(moves(p, lines))
        if len(nxt) > 1:
            forced = False
        if not nxt:
            terminals.add(p)
        for _, r in nxt:
            if r not in seen:
                seen.add(r)
                q.append(r)
    minleft = min(len(t) for t in terminals)
    singles = sorted(next(iter(t)) for t in terminals if len(t) == 1)
    return dict(states=len(seen), minleft=minleft, terminals=terminals,
                singles=singles, forced=forced)


def colour_prediction(cells, start, key):
    """3-colouring invariant: with colour c(cell) in {0,1,2} such that every jump
    triple carries all three colours, the parities of the three colour-counts all
    flip at every jump.  A lone survivor on colour k has counts (1 on k, 0, 0),
    so the start must have count-parities equal on the two other colours and
    different on k.  Returns the set of cells a lone survivor could occupy."""
    counts = [0, 0, 0]
    for c in start:
        counts[key(c) % 3] += 1
    par = [x % 2 for x in counts]
    allowed = set()
    for k in range(3):
        others = [par[j] for j in range(3) if j != k]
        if others[0] == others[1] and par[k] != others[0]:
            allowed = {c for c in cells if key(c) % 3 == k}
    return allowed


def show_strip(n, pos):
    return "".join("X" if (i, 0) in pos else "." for i in range(1, n + 1))


def strip_report():
    print("=" * 70)
    print("ONE-DIMENSIONAL STRIPS: n cells, n-1 pegs, one hole")
    print("=" * 70)
    for n in range(3, 11):
        cells = [(i, 0) for i in range(1, n + 1)]
        for h in range(1, n // 2 + 1 + (n % 2)):
            if h > (n + 1) // 2:
                continue
            start = [(i, 0) for i in range(1, n + 1) if i != h]
            r = analyse(cells, start)
            pred = colour_prediction(cells, start, key=lambda c: c[0])
            single_cells = [c[0] for c in r["singles"]]
            pred_cells = sorted(c[0] for c in pred)
            print(f"n={n:2d} hole={h}: {show_strip(n, set(start))}  states={r['states']:4d} "
                  f"minleft={r['minleft']}  lone-survivor cells={single_cells}  "
                  f"3-colour allows={pred_cells}  forced={r['forced']}")
        print()


def strip_custom(n, pegs, label):
    cells = [(i, 0) for i in range(1, n + 1)]
    start = [(i, 0) for i in pegs]
    r = analyse(cells, start)
    pred = colour_prediction(cells, start, key=lambda c: c[0])
    terms = sorted(show_strip(n, t) for t in r["terminals"])
    print(f"{label}: start {show_strip(n, set(start))} (n={n})  states={r['states']} "
          f"minleft={r['minleft']} lone-survivor cells={[c[0] for c in r['singles']]} "
          f"3-colour allows={sorted(c[0] for c in pred)} forced={r['forced']}")
    print("   stuck positions:", terms)
    return r


def farthest_reach_1d(k, n=30):
    """Pegs on cells 1..k of a strip of n cells (n large).  Farthest cell any peg reaches."""
    cells = [(i, 0) for i in range(1, n + 1)]
    lines = lines_of(cells)
    start = frozenset((i, 0) for i in range(1, k + 1))
    seen = {start}
    q = deque([start])
    best = k
    while q:
        p = q.popleft()
        best = max(best, max(c[0] for c in p))
        for _, r in moves(p, lines):
            if r not in seen:
                seen.add(r)
                q.append(r)
    return best, len(seen)


def farthest_reach_any_subset(k, span, n=40):
    """Best over ALL k-peg armies inside cells 1..span (line after cell span): farthest cell reached."""
    cells = [(i, 0) for i in range(1, n + 1)]
    lines = lines_of(cells)
    best = 0
    for combo in itertools.combinations(range(1, span + 1), k):
        start = frozenset((i, 0) for i in combo)
        seen = {start}
        q = deque([start])
        while q:
            p = q.popleft()
            best = max(best, max(c[0] for c in p) - span)
            for _, r in moves(p, lines):
                if r not in seen:
                    seen.add(r)
                    q.append(r)
    return best


def grid_cells(w, h):
    return [(x, y) for x in range(w) for y in range(h)]


def show_grid(cells, pos, w, h):
    rows = []
    for y in range(h - 1, -1, -1):
        rows.append("".join(("X" if (x, y) in pos else ".") if (x, y) in cells else " " for x in range(w)))
    return "\n".join(rows)


def grid_report(w, h, holes_list, label):
    cells = grid_cells(w, h)
    print("=" * 70)
    print(f"{label}: {w}x{h} grid")
    print("=" * 70)
    for holes in holes_list:
        start = [c for c in cells if c not in holes]
        r = analyse(cells, start)
        predA = colour_prediction(cells, start, key=lambda c: c[0] + c[1])
        predB = colour_prediction(cells, start, key=lambda c: c[0] - c[1])
        both = sorted(predA & predB)
        print(f"holes={holes}: states={r['states']} minleft={r['minleft']} "
              f"lone-survivor cells={r['singles']}  two-diagonal-colourings allow={both}")
        print(show_grid(cells, set(start), w, h))
        print()


def shape_report(cells, starts, label, w, h):
    print("=" * 70)
    print(label)
    print("=" * 70)
    for start in starts:
        r = analyse(cells, start)
        predA = colour_prediction(cells, start, key=lambda c: c[0] + c[1])
        predB = colour_prediction(cells, start, key=lambda c: c[0] - c[1])
        both = sorted(predA & predB)
        print(f"start pegs={len(start)}: states={r['states']} minleft={r['minleft']} "
              f"lone-survivor cells={r['singles']} two-diagonal-colourings allow={both} forced={r['forced']}")
        print(show_grid(cells, set(start), w, h))
        print()


if __name__ == "__main__":
    strip_report()

    print("=" * 70)
    print("STRIPS WITH OTHER STARTS")
    print("=" * 70)
    strip_custom(3, [1, 2], "3-strip, two pegs left end")
    strip_custom(3, [1, 3], "3-strip, pegs at both ends")
    strip_custom(4, [1, 2, 3], "4-strip, hole at end")
    strip_custom(4, [1, 3, 4], "4-strip, hole at cell 2")
    strip_custom(5, [1, 2, 3, 4], "5-strip, hole at end")
    strip_custom(5, [1, 2, 4, 5], "5-strip, hole in middle")
    strip_custom(5, [1, 3, 4, 5], "5-strip, hole at cell 2")
    strip_custom(6, [1, 2, 3, 4, 5], "6-strip, hole at end")
    strip_custom(6, [1, 2, 3, 5, 6], "6-strip, hole at 4")
    strip_custom(6, [1, 2, 4, 5, 6], "6-strip, hole at 3")
    strip_custom(6, [2, 3, 4, 5, 6], "6-strip, hole at 1")
    strip_custom(6, [1, 2, 4, 5], "6-strip XX.XX.")
    strip_custom(6, [1, 2, 3, 5], "6-strip XXX.X.")
    strip_custom(7, [1, 2, 3, 5, 6, 7], "7-strip, hole in middle")
    strip_custom(7, [1, 2, 3, 4, 5, 6], "7-strip, hole at end")
    strip_custom(7, [1, 2, 3, 4, 6, 7], "7-strip, hole at 5")
    strip_custom(7, [1, 2, 3, 4, 5, 7], "7-strip, hole at 6")
    strip_custom(7, [2, 3, 4, 5, 6, 7], "7-strip, hole at 1")
    strip_custom(7, [1, 2, 3, 5, 6], "7-strip XXX.XX.")
    strip_custom(7, [2, 3, 5, 6], "7-strip .XX.XX.")
    strip_custom(8, [1, 2, 3, 4, 6, 7, 8], "8-strip, hole at 5")
    strip_custom(8, [1, 2, 3, 4, 5, 6, 7], "8-strip, hole at end")
    strip_custom(8, [1, 2, 3, 5, 6, 7], "8-strip XXX.XXX.")
    strip_custom(8, [2, 3, 4, 6, 7, 8], "8-strip .XXX.XXX")
    strip_custom(9, [1, 2, 3, 4, 6, 7, 8, 9], "9-strip, hole in middle")
    strip_custom(9, [2, 3, 4, 5, 6, 7, 8, 9], "9-strip, hole at 1")
    strip_custom(9, [1, 2, 3, 4, 5, 6, 7, 8], "9-strip, hole at 9")
    strip_custom(10, [1, 2, 3, 4, 5, 6, 7, 8, 9], "10-strip, hole at end")
    strip_custom(10, [1, 2, 3, 4, 5, 7, 8, 9, 10], "10-strip, hole at 6")

    print()
    print("=" * 70)
    print("ONE-DIMENSIONAL SOLDIERS: block of k pegs on cells 1..k, how far past cell k?")
    print("=" * 70)
    for k in range(2, 11):
        best, states = farthest_reach_1d(k)
        print(f"k={k:2d} pegs in a block: farthest cell reached = {best} (= {best - k} past the block); reachable positions={states}")
    print()
    print("Best over ALL armies of k pegs placed anywhere in cells 1..span (line right after cell span):")
    for k, span in ((2, 4), (3, 5), (4, 6), (5, 7), (6, 8), (7, 9)):
        print(f"  k={k}, span={span}: farthest past the line = {farthest_reach_any_subset(k, span)}")
    print()

    # 2-D small boards -------------------------------------------------------
    grid_report(3, 3, [[(1, 1)], [(0, 0)], [(1, 0)]], "3x3 grid, one hole")
    grid_report(3, 3, [[(0, 0), (2, 2)], [(0, 0), (0, 2)], [(0, 0), (1, 1)], [(1, 0), (1, 2)], [(0, 1), (1, 0)]], "3x3 grid, two holes")
    grid_report(4, 4, [[(0, 0)], [(1, 0)], [(1, 1)]], "4x4 grid, one hole")
    grid_report(3, 4, [[(0, 0)], [(1, 0)], [(0, 1)], [(1, 1)]], "3 wide x 4 tall, one hole")
    grid_report(2, 4, [[(0, 0)], [(0, 1)]], "2x4 grid, one hole")
    grid_report(2, 5, [[(0, 0)], [(0, 1)], [(0, 2)]], "2x5 grid, one hole")
    grid_report(3, 5, [[(1, 2)], [(0, 0)], [(1, 0)], [(0, 2)]], "3x5 grid, one hole")
    grid_report(5, 5, [[(2, 2)], [(0, 0)]], "5x5 grid, one hole")

    # plus / cross shapes
    plus5 = [(1, 0), (0, 1), (1, 1), (2, 1), (1, 2)]
    shape_report(plus5, [[c for c in plus5 if c != (1, 1)], [c for c in plus5 if c != (1, 0)]],
                 "PLUS of 5 cells (centre hole / arm hole)", 3, 3)
    plus9 = [(2, 0), (2, 1), (0, 2), (1, 2), (2, 2), (3, 2), (4, 2), (2, 3), (2, 4)]
    shape_report(plus9, [[c for c in plus9 if c != (2, 2)], [c for c in plus9 if c != (2, 0)], [c for c in plus9 if c != (2, 1)]],
                 "PLUS with arms of length 2 (9 cells): centre hole / arm-end hole / arm-middle hole", 5, 5)
    # 3x3 with a 1-cell bump on each side (the "small English" shape, 13 cells)
    cross13 = [(x, y) for x in range(1, 4) for y in range(1, 4)] + [(2, 0), (2, 4), (0, 2), (4, 2)]
    shape_report(cross13, [[c for c in cross13 if c != (2, 2)], [c for c in cross13 if c != (2, 0)], [c for c in cross13 if c != (1, 1)]],
                 "CROSS of 13 cells (3x3 plus four arm cells): centre hole / arm hole / corner hole", 5, 5)
