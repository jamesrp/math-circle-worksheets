# Week 1 problem bank: jumping-peg games (peg solitaire, strips, Conway's Soldiers)

Stage: bank. 45 candidate problems, B01–B45, for the curator to select and sequence. Nothing here is a worksheet.

## Conventions used throughout

- **The jump.** A counter may jump over a counter in the next square (left, right, up or down, never diagonally) into the empty square immediately beyond it. The counter jumped over is removed. Nothing else is ever allowed: no sliding, no jumping over an empty square, no jumping over two counters.
- **Strips.** Squares are numbered 1, 2, 3, ... from the left. A position is written with X for a counter and . for an empty square, e.g. `XX.XX`. "Hole at 3" means square 3 empty, all other squares full. By mirror symmetry, hole at square k on a strip of n behaves exactly like hole at square n+1−k; the bank lists only holes up to the middle.
- **Grids.** A board that is 3 wide and 4 tall is "3×4". Squares are named (column, row), columns counted from the left starting at 1, rows from the bottom starting at 1. So (1,1) is the bottom-left corner of any board.
- **Army boards (Conway's Soldiers).** A thick horizontal line runs across a grid. Counters start only below the line. Rows above the line are row 1, 2, 3, 4 counted upward from the line; the row just below the line is row 0, then −1, −2, .... Columns are counted from the star column, which is column 0; columns to the right are +1, +2, ..., to the left −1, −2, .... "Row 2" as a goal means: land any counter on any square of row 2 (in practice on the star).
- **Pieces.** K–1 uses checkers (about 1.25 in across) or large counters on 1.25-inch squares; grades 2–3 and 4–5 use pennies on 1-inch squares. The template's usable width is 7.2 in portrait and 9.7 in landscape, so a K–1 strip of 6 or 7 squares needs a landscape page; no K–1 strip in this bank is longer than 7 squares. For grades 2–5, strips of 8 to 10 squares and the army grids of B34, B35 and B37 are printed at 0.8 or 0.9 in per square (pennies are 0.75 in across) so that they fit a page; the problem text says so where it matters. Every problem states the board so that the formatter can draw it at the right size. "Blank strip"/"blank grid" means an empty copy of the board printed for recording.
- **Colourings.** On strips: square i gets colour (i−1) mod 3, i.e. squares 1, 4, 7, 10 are red, 2, 5, 8 blue, 3, 6, 9 green. On grids: the "diagonal colouring" gives square (c, r) the colour (c + r) mod 3; the "other diagonal colouring" gives it (c − r) mod 3.

## Verification files (all in this directory; every number below comes from them)

- `verify_boards.py` → `verify_boards.out`: exhaustive search (all reachable positions) for strips of 3–10 with one hole and other starts, 1-D armies, 3×3, 3×4, 4×4, 3×5, 5×5, plus shapes; 3-colouring predictions.
- `verify_extra.py` → `verify_extra.out`: stuck-position distributions; one-colouring vs two-colouring predictions; complete maps of positions for `XX.XX`, `X.XXXX`, `XX.XXX`, `XXX.XXX`; the Fibonacci price list on a strip checked as a monovariant; two-player (last jump wins) values; first-move counts.
- `verify_paths.py` → `verify_paths.out`: explicit move sequences for every "can be done" claim on strips and small grids; which starting counter can survive.
- `verify_soldiers.py` → `verify_soldiers.out`: exact golden-ratio weights (integer pairs a + b·σ); maximum weight of m counters; every minimal army for rows 1, 2, 3 with move sequences; 7 counters cannot reach row 3, 3 cannot reach row 2.
- `verify_soldiers_row4.py`, `verify_soldiers_row4_all.py` → `.out`: bitboard search proving 19 counters cannot reach row 4 (the 84 armies of weight exactly 1 all fail; every other 19-army has weight < 1) and finding all 20-counter armies that can (4 up to mirror image), with move sequences.
- `verify_prices2d.py` → `verify_prices2d.out`: the integer (Fibonacci) price map on the grid never increases under any jump; best totals of m squares for rows 2, 3, 4, 5.
- `verify_misc.py` → `verify_misc.out`: all 63 armies on squares 1–6 of a 10-strip; colour counts for the prediction strips; the two-player strategy on the 3×3 board; 3×3 with two holes.
- `verify_strips_long.py` → `verify_strips_long.out`: the one-hole strip table extended to 16 squares.

Literature for the facilitator guide's mathematics section: Berlekamp, Conway, Guy, *Winning Ways*, ch. 23 (Conway's Soldiers, 2/4/8/20, row 5 impossible via the golden ratio); M. Aigner, "Moving into the desert with Fibonacci", *Math. Magazine* 70 (1997) (Fibonacci/golden-ratio potential functions); G. Bell, D. Hirschberg, P. Guerrero-García, "The minimum size required of a solitaire army", *INTEGERS* 7 (2007) G07 (20 is minimal for row 4; our search agrees); R. Beeler, D. Hoilman, "Peg solitaire on graphs", *Discrete Math.* 311 (2011) (which starts on a path of n squares can be cleared to one peg; our table for n ≤ 16 agrees: even n from the 2nd or 5th square from either end, odd n never except n = 3); pagoda functions: *Winning Ways* ch. 23 and J. Beasley, *The Ins and Outs of Peg Solitaire*.

---

## Part A. The jump on a strip (K–1 core; 2–3 warm-up)

### B01 — Which strips allow a jump? (three strips of 3)
- **Levels:** K–1.
- **Materials and setup:** Three strips of 3 squares (1.25-inch squares), two checkers each. Strip A: checkers on squares 1 and 2. Strip B: checkers on squares 1 and 3. Strip C: checkers on squares 2 and 3.
- **Child's action (as printed):** A checker may jump over the checker next to it into the empty square right behind it. The checker that was jumped over is taken off the strip. Put the checkers on strip A as in the picture. Make a jump if you can. Do the same on strips B and C. Put a mark under each strip where a jump was possible. On strip A, point to the square where the checker landed and count the checkers left.
- **Expected result (verified):** A: one jump, 1 over 2 into 3, one checker left on square 3. B: no jump (the middle square is empty; a checker cannot jump over an empty square, and there is no square beyond square 3). C: one jump, 3 over 2 into 1. Verified by exhaustive search (`verify_boards.out`: 3-strip starts).
- **Mathematical question / distinction:** Existence of a move; the rule "jump over a neighbour into an empty square" as the object of study. B is the first impossibility: no legal move at all.
- **Minutes:** 3.
- **Before / after:** Needs nothing. Opens B02, B03, B17.

### B02 — Strip of 4, hole at the end (`XXX.`)
- **Levels:** K–1, 2–3.
- **Materials and setup:** Strip of 4 (1.25-inch squares for K–1), three checkers on squares 1, 2, 3; square 4 empty. Below it: a tally box and a blank strip.
- **Child's action (as printed):** Put checkers on squares 1, 2 and 3. Jump until no jump is left. Make one tally mark for each jump. When you are stuck, draw a dot in each square that still has a checker on the blank strip, and write how many checkers are left.
- **Expected result (verified):** Exactly one jump is ever possible: 2 over 3 into 4. Stuck position `X..X`, two checkers left. There is never a choice (2 positions in total).
- **Mathematical question / distinction:** Dynamics of a forced start; the answer "2 left" is unavoidable. Contrast with B03: same strip, same three checkers, hole moved by one square, and the outcome changes.
- **Minutes:** 3.
- **Before / after:** Needs B01. Opens B03, B07.

### B03 — Strip of 4, hole at square 2 (`X.XX`)
- **Levels:** K–1, 2–3.
- **Materials and setup:** Strip of 4, three checkers on squares 1, 3, 4; square 2 empty. Tally box and blank strip below.
- **Child's action (as printed):** Put checkers on squares 1, 3 and 4. Jump until no jump is left. Tally each jump. Draw the checkers that are left on the blank strip and write how many. Compare with the strip of Problem [B02]: which strip let you jump more times?
- **Expected result (verified):** Forced play: 4 over 3 into 2, then 1 over 2 into 3. One checker left, on square 3; two jumps. (Mirror image: hole at 3 ends with one checker on square 2.)
- **Mathematical question / distinction:** Existence of a complete clearance (down to one), and the fact that the hole position decides it. First instance of "the same pieces, a different start, a different answer".
- **Minutes:** 3.
- **Before / after:** Needs B02. Opens B04, B05, B13.

### B04 — Strip of 5, every hole (`XXXX.`, `XXX.X`, `XX.XX`)
- **Levels:** K–1 (adult scribes), 2–3.
- **Materials and setup:** Three strips of 5 with four checkers each: hole at square 5, hole at square 4, hole at square 3. (Holes at 1 and 2 are mirror images of 5 and 4.) A blank strip and a number box under each.
- **Child's action (as printed):** On each strip, jump until you are stuck. Try to leave as few checkers as you can. Draw the checkers that are left on the blank strip and write the number. Play the third strip twice, starting with a different jump each time.
- **Expected result (verified):** Every hole leaves at least 2. Hole at 5: forced, 3 over 4 into 5, then 1 over 2 into 3, stuck `..X.X`. Hole at 4: forced, 2 over 3 into 4, then 5 over 4 into 3, stuck `X.X..`. Hole at 3: two possible first jumps (1 over 2 into 3, or 5 over 4 into 3); after either, one more jump, stuck `.X..X` or `X..X.`; 5 positions in all. No strip of 5 can be brought down to one checker.
- **Mathematical question / distinction:** Impossibility across all starts, established by complete enumeration (the children can actually exhaust it: at most two choices in the whole game). Contrast with size 4 (B03), where one hole works.
- **Minutes:** K–1: 8. 2–3: 5.
- **Before / after:** Needs B03. Opens B05, B11, B13.

### B05 — Strip of 6, hole at square 2 (`X.XXXX`): down to one
- **Levels:** 2–3, 4–5; K–1 with the adult as a stretch.
- **Materials and setup:** Strip of 6, five pennies on squares 1, 3, 4, 5, 6. Four blank strips for recording tries.
- **Child's action (as printed):** Jump until you are stuck. Try to finish with only one penny. Draw each finished position on a blank strip and write how many pennies are left. Do at least three tries with different choices. On every try that ends with one penny, circle the square it ended on.
- **Expected result (verified):** Every play ends with exactly one penny (7 positions, both stuck positions have one penny). The first jump is forced (4 over 3 into 2); then there are choices, but all roads lead to `..XX..` and a last jump. The survivor ends on square 2 or square 5, never anywhere else. Example: 4 over 3 into 2, 1 over 2 into 3, 6 over 5 into 4, 3 over 4 into 5 (ends on 5); replace the last jump by 4 over 3 into 2 to end on 2.
- **Mathematical question / distinction:** Existence of a clearance (and here you cannot even fail), plus a completeness question: which squares can the last penny sit on? The answer {2, 5} is the seed for the colouring (B14–B15). Contrast with size 5 (B04): one square longer and "never" becomes "always".
- **Minutes:** 5–6.
- **Before / after:** Needs B03 or B04. Opens B06, B09, B12, B14, B44.

### B06 — Strip of 6, hole at the end and hole at square 3 (`XXXXX.`, `XX.XXX`)
- **Levels:** 2–3, 4–5.
- **Materials and setup:** Two strips of 6, five pennies each: hole at 6; hole at 3. Blank strips for every stuck position found.
- **Child's action (as printed):** On each strip, find the fewest pennies you can leave. Draw every different stuck position you reach and write its number of pennies. On the second strip, write down which first jump you made before each result.
- **Expected result (verified):** Hole at 6: forced, 4 over 5 into 6, then 2 over 3 into 4, stuck `X..X.X`, 3 left. Hole at 3: two first jumps. 1 over 2 into 3 leads (forced afterwards) to 4 over 3 into 2, 6 over 5 into 4, stuck `.X.X..`, 2 left. 5 over 4 into 3 leads to 2 over 3 into 4, stuck `X..X.X`, 3 left. So the fewest is 2, and it is decided by the first jump.
- **Mathematical question / distinction:** Optimality and the role of a choice: on the same strip of 6, hole 2 always gives 1 (B05), hole 3 gives 2 or 3 depending on the first move, hole 6 always gives 3.
- **Minutes:** 6.
- **Before / after:** Needs B05. Opens B12, B13, B38.

### B07 — Hole at the end, strips of 4 to 8: what always happens
- **Levels:** K–1 (strips 4, 5, 6), 2–3 (strips 4 to 8).
- **Materials and setup:** Strips of 4, 5, 6, 7, 8, each full except the last square (3, 4, 5, 6, 7 checkers). A blank strip and number box under each; the five blank strips lined up one under the other.
- **Child's action (as printed):** On each strip, jump until you are stuck. Draw the stuck position on the blank strip under it and write how many checkers are left. When all five are done, look at the five drawings together and describe what you see to your table.
- **Expected result (verified):** Play is forced on every strip (there is never a second jump available). Stuck positions: `X..X`, `..X.X`, `X..X.X`, `..X.X.X`, `X..X.X.X`; checkers left 2, 2, 3, 3, 4 (half the length, rounded down). The survivors sit on every second square from the right end. Reason a child can give: the only checker that can move is the one two squares from the hole; it jumps into the hole and makes a new hole two squares further left, and the same thing happens again on any longer strip.
- **Mathematical question / distinction:** "What always happens" (forced dynamics), a pattern across sizes, and an explanation of the form "the same reason works again on a bigger case". Contrast with hole-at-2 strips (B05, B44), where play branches.
- **Minutes:** K–1: 8. 2–3: 7.
- **Before / after:** Needs B02. Opens B13, B27.

### B08 — Jumps plus counters: the count that never changes
- **Levels:** K–1 (strip of 6, hole at 3), 2–3 (strip of 8, hole at 4).
- **Materials and setup:** K–1: strip of 6 with checkers on 1, 2, 4, 5, 6 (`XX.XXX`). 2–3: strip of 8 with pennies on all squares but 4 (`XXX.XXXX`). A three-column table: jumps made / counters left / jumps + counters left, with three rows.
- **Child's action (as printed):** Play three times, making different choices where you can. Each time: tally every jump, and when you are stuck, count the counters left. Fill in one row of the table for each play. Fill in the last column by adding.
- **Expected result (verified):** K–1: the two possible endings are `X..X.X` (2 jumps, 3 left) and `.X.X..` (3 jumps, 2 left); the last column is 5 both times. 2–3: endings with 1, 2 or 4 pennies left (6, 5 or 3 jumps); the last column is 7 every time. The sum is the starting number of counters because every jump removes exactly one counter.
- **Mathematical question / distinction:** An invariant (counting): the number of jumps in any play equals the number of counters removed. The outcomes vary, the sum does not. Explanation a child can give: "each jump takes one counter off".
- **Minutes:** K–1: 6. 2–3: 6.
- **Before / after:** Needs B02. Opens B39 (the invariant decides a two-player game), B43.

### B09 — Which checker is the last one?
- **Levels:** K–1, 2–3.
- **Materials and setup:** Strip of 6 with the hole at 2; five checkers, one of them a different colour (or with a sticker). Three blank strips.
- **Child's action (as printed):** Put the marked checker on square 1 and the others on 3, 4, 5, 6. Play until one checker is left. Is it the marked one? Circle the square it ended on. Play again from the same start and try to get the other answer. Now do the same with the marked checker starting on square 6, and then on square 3.
- **Expected result (verified by tracking each checker's identity through all plays):** The survivor is always one of the two end checkers: the checker from square 1 can survive (it ends on square 5) and the checker from square 6 can survive (it ends on square 2). A checker starting on 3, 4 or 5 never survives. Which end checker survives depends on the last jump chosen.
- **Mathematical question / distinction:** Dynamics: the survivor travels the whole strip and ends near the far end; the two possible endings of B05 come from the two end checkers.
- **Minutes:** 5.
- **Before / after:** Needs B05. Opens B14.

### B10 — Count the first jumps
- **Levels:** K–1.
- **Materials and setup:** Four boards with checkers already drawn: strip `XX.XX`; strip `X.XXXX`; strip `XXX.XXX`; a 3×3 grid with a corner empty and 8 checkers. A number box under each.
- **Child's action (as printed):** On each board, find every different jump you could make as the very first jump. Draw an arrow for each one on the picture. Write how many there are.
- **Expected result (verified):** 2 (1 over 2 into 3; 5 over 4 into 3), 1 (4 over 3 into 2), 2 (2 over 3 into 4; 6 over 5 into 4), 2 (into the empty corner along the row or along the column).
- **Mathematical question / distinction:** Counting moves; reinforces that jumps go both ways and never over an empty square. Prepares the "map of positions" (B11).
- **Minutes:** 4.
- **Before / after:** Needs B01. Opens B11, B17.

## Part B. Maps of all positions (completeness)

### B11 — The whole map for `XX.XX`
- **Levels:** 2–3, 4–5.
- **Materials and setup:** Strip of 5, hole at 3, four pennies. A page with a top box holding the start and eight empty strip-boxes below it with room for arrows.
- **Child's action (as printed):** Draw the start in the top box. Draw every position you can reach with one jump in boxes below it, with an arrow from the position it came from. Keep going from each new position until every position is stuck or already drawn. Circle the stuck positions. Count the positions on your map.
- **Expected result (verified):** 5 positions, 4 arrows: `XX.XX` → `..XXX` and `XXX..`; `..XXX` → `.X..X` (stuck); `XXX..` → `X..X.` (stuck). Both stuck positions have 2 pennies. The map shows every possible play, so it proves that 1 penny is impossible on this strip.
- **Mathematical question / distinction:** Completeness: a map of the state space as a proof of impossibility. The map is a tree here; in B12 paths merge.
- **Minutes:** 8.
- **Before / after:** Needs B04. Opens B12, B39.

### B12 — Maps for `X.XXXX` and `XXX.XXX`
- **Levels:** 4–5.
- **Materials and setup:** Two strips (6 with hole at 2; 7 with hole at 4), pennies, two map pages with ten boxes each.
- **Child's action (as printed):** Make the complete map of positions for each strip, as in Problem [B11]. Circle every stuck position and write its number of pennies. Mark any position that can be reached in two different ways.
- **Expected result (verified):** `X.XXXX`: 7 positions, 7 arrows; `XX..XX` has two exits which meet again at `..XX..`; the two stuck positions `....X.` and `.X....` both have 1 penny. `XXX.XXX`: 7 positions, 6 arrows; two mirror-image branches; stuck positions `X.X.X..` and `..X.X.X`, both with 3 pennies, so 3 is the fewest and 1 or 2 is impossible.
- **Mathematical question / distinction:** Completeness again, now with merging (the state graph is not a tree) and with a symmetric map; gives the exact set of endings of B05.
- **Minutes:** 10.
- **Before / after:** Needs B11. Opens B13, B14.

## Part C. Sizes and starts side by side (compare, then explain)

### B13 — Which strips can be cleared to one? Sizes 3 to 8
- **Levels:** 4–5 (2–3 for sizes 3 to 6).
- **Materials and setup:** Strips of 3, 4, 5, 6, 7, 8; pennies. A table with rows "size 3 ... size 8" and columns "hole at 1, 2, 3, 4" (holes past the middle are mirror images and are greyed out). Each child takes some sizes.
- **Child's action (as printed):** For every size and every hole position, play and write in the table the fewest pennies you managed to leave. Colour the cells where you got down to one penny. Then write which sizes have at least one coloured cell.
- **Expected result (verified, fewest left):** size 3: hole 1 → 1, hole 2 → 2 (no jump). Size 4: 2, 1. Size 5: 2, 2, 2. Size 6: 3, 1, 2. Size 7: 3, 2, 2, 3. Size 8: 4, 1, 3, 1. One penny is possible only for sizes 3, 4, 6, 8, and never with the hole at the end (size 3 excepted). Every odd size from 5 up fails for every hole. (Exhaustive search confirms this up to size 16, `verify_strips_long.out`; from size 6 on, the even sizes succeed exactly from the 2nd and the 5th square counted from either end. The general statement for paths of every length is a theorem of Beeler and Hoilman 2011.)
- **Mathematical question / distinction:** A pattern across sizes with a break in it (odd sizes fail, even sizes succeed from the right holes); the hole-at-the-end column follows B07. The children's evidence is complete for sizes up to 7 (maps with at most 10 positions).
- **Minutes:** 15 (shared across the table).
- **Before / after:** Needs B05, B06. Opens B14, B16, B44, B45.

### B14 — Where does the last penny end? Collecting the data
- **Levels:** 4–5.
- **Materials and setup:** Strips `X.XXXX` (6), `X.XXXXXX` (8), `XXX.XXXX` (8), `X.XXXXXXXX` (10), pennies; under each strip a blank strip for colouring squares.
- **Child's action (as printed):** Play each strip several times, finishing with one penny whenever you can. Each time, colour on the blank strip the square the last penny ended on. When you have played each strip at least four times, write under it the list of squares that ever got coloured, and the distance between them.
- **Expected result (verified):** {2, 5}; {4, 7}; {2, 5}; {6, 9}. The possible final squares on each strip are exactly three apart. Example plays: 8-strip hole 2: 4 over 3 into 2, 1 over 2 into 3, 6 over 5 into 4, 3 over 4 into 5, 8 over 7 into 6, then 5 over 6 into 7 (ends on 7) or 6 over 5 into 4 (ends on 4). 10-strip hole 2: continue the same pattern; last jump 7 over 8 into 9 (ends on 9) or 8 over 7 into 6 (ends on 6).
- **Mathematical question / distinction:** Completeness of endings (an invariant is lurking: "three apart"). This is the question the colouring of B15 answers; it is met here before the colouring is introduced.
- **Minutes:** 8.
- **Before / after:** Needs B05. Opens B15.

### B15 — Three colours on the strip
- **Levels:** 4–5.
- **Materials and setup:** Strip of 8 printed with squares coloured red, blue, green, red, blue, green, red, blue (squares 1–8); pennies on all squares but 2. A table with columns red / blue / green and rows "start, after jump 1, after jump 2, after jump 3".
- **Child's action (as printed):** Count the pennies on red squares, on blue squares, on green squares, and write the three numbers in the first row. Make a jump and count again. Make two more jumps, counting after each. Under the table, write what happens to each colour's number at every jump. Then fill in the counts for a position with a single penny on a red square, on a blue square, on a green square.
- **Expected result (verified):** Start: red 3, blue 2, green 2. Every jump uses one square of each colour: two colours lose a penny and one colour gains a penny, so all three numbers change by exactly 1 at every jump, and each switches between odd and even together. Therefore "which colour count is the odd one out" never changes. Red is the odd one out at the start (odd, while blue and green are even). A single penny on red gives counts 1, 0, 0 (red odd, others even: allowed); on blue or green the odd one out would be blue or green (not allowed). So the last penny must sit on a red square: 1, 4 or 7. Observed in B14: 4 or 7 only. The colouring rules squares out; it does not promise the remaining ones.
- **Mathematical question / distinction:** An invariant (parity of colour counts) proving impossibility of endings on blue and green. Distinction: necessary but not sufficient (square 1 is red yet never reached, by the complete search).
- **Minutes:** 12.
- **Before / after:** Needs B14. Opens B16, B22.

### B16 — Predict before playing
- **Levels:** 4–5.
- **Materials and setup:** Four strips printed with the three colours and their starting pennies drawn: `XXX.XXX` (7), `XX.XXXXX` (8), `.XXXXXXX` (8), `XXXX.XXXX` (9). Under each: three count boxes, a line "one penny possible? on which colour?", and a blank strip.
- **Child's action (as printed):** For each strip, write the three colour counts without moving anything. Decide from the counts alone whether a single penny could be left, and on which colour it would have to sit. Then play the strip and draw the fewest-penny position you reached.
- **Expected result (verified):** `XXX.XXX`: counts 2, 2, 2 (all even): impossible; play confirms, fewest 3. `XX.XXXXX`: 3, 3, 1 (all odd): impossible; fewest 3. `.XXXXXXX`: 2, 3, 2: blue is the odd one out, so a lone penny would have to sit on 2, 5 or 8, but the play is forced and ends with 4 pennies (`X.X.X..X`). `XXXX.XXXX`: 3, 2, 3: blue is the odd one out, so a lone penny would have to sit on 2, 5 or 8, but the complete search (25 positions) shows the fewest is 2. Two of the four are settled by colours alone; the other two need actual play.
- **Mathematical question / distinction:** A certificate of impossibility versus a mere necessary condition; the children learn which kind of question the colouring can decide.
- **Minutes:** 10.
- **Before / after:** Needs B15. Opens B21, B23.

## Part D. Small boards in two dimensions

### B17 — 3×3 board, middle empty: is there a jump?
- **Levels:** K–1.
- **Materials and setup:** 3×3 grid with 1.25-inch squares, 8 checkers. A second copy of the grid with a blank grid beside it and a tally box.
- **Child's action (as printed):** Put a checker on every square except the middle one. Find a jump. If there is none, tell the adult why. Now take the checker off one corner and put it in the middle. Find all the jumps you can make, one after another, until you are stuck. Tally the jumps and draw the stuck position on the blank grid.
- **Expected result (verified):** With the middle empty there is no jump at all: the only empty square is the middle, and no checker is two squares away from it in a straight line. After moving a corner checker to the middle (corner empty, 8 checkers): two possible first jumps, into the corner along its row or its column; every play ends with 4 or 5 checkers (16 positions; 4 jumps at most).
- **Mathematical question / distinction:** Existence of a move in 2-D; the trivial impossibility (no landing square). Contrast: the same 8 checkers with the hole moved to a corner give a real game.
- **Minutes:** 5.
- **Before / after:** Needs B01. Opens B18, B10.

### B18 — 3×3 board, corner empty: the fewest left
- **Levels:** K–1, 2–3.
- **Materials and setup:** 3×3 grid, 8 counters, corner (1,1) empty. Three blank grids.
- **Child's action (as printed):** Play until you are stuck. Draw the stuck position on a blank grid and write how many counters are left. Play again with the other first jump, and again with different later choices. What is the fewest you can leave?
- **Expected result (verified):** Fewest is 4; one stuck position has 5 (an L: the whole left column and the whole bottom row). A 4-jump play: (1,3) over (1,2) into (1,1); (3,2) over (2,2) into (1,2); (1,1) over (1,2) into (1,3); (3,1) over (2,1) into (1,1); stuck with the top row full and one counter at (1,1). The stuck positions with 4 counters, for the hole at (1,1), are exactly: top row plus (1,1); right column plus (1,1); and (1,3), (3,3), (2,2), (3,1). Listed in `verify_extra.out`.
- **Mathematical question / distinction:** Optimality on a board small enough to exhaust (16 positions). Contrast with 3×4 boards (B19), where a corner hole allows a full clearance.
- **Minutes:** K–1: 6. 2–3: 5.
- **Before / after:** Needs B17. Opens B19, B40, B42.

### B19 — 3×4 board: four holes, four different games
- **Levels:** 2–3, 4–5 (K–1: boards B and D only, with the adult).
- **Materials and setup:** Four 3×4 boards (3 wide, 4 tall), 11 counters each. Board A: hole at the corner (1,1). Board B: hole at (2,1), the middle of the bottom side. Board C: hole at (1,2), second square up the left side. Board D: hole at (2,2), an inside square. A blank grid and number box beside each; two extra blank grids for boards A and C.
- **Child's action (as printed):** On each board, play until you are stuck, trying to leave as few counters as you can. Draw each stuck position in the grid beside the board and write the number. Play boards A and C several times and record every different number you get.
- **Expected result (verified):** A: one counter is possible (121 positions; stuck positions with 1, 2, 3, 4, 6, 7 or 8 counters); a lone survivor can end only on (1,1) or (1,4). B: only one jump exists in the whole game, (2,3) over (2,2) into (2,1); then stuck with 10. C: one counter is possible (154 positions); a lone survivor can end only on (1,2), the starting hole. D: two jumps, (2,4) over (2,3) into (2,2) then (2,1) over (2,2) into (2,3); stuck with 9. Solutions for A and C are in B20 and `verify_paths.out`.
- **Mathematical question / distinction:** Existence versus impossibility decided by the hole; long open games (A, C) beside games that die after one or two forced moves (B, D); where the survivor can end (completeness), which the 2-D colouring (B22) explains.
- **Minutes:** 2–3: 15. 4–5: 12.
- **Before / after:** Needs B18. Opens B20, B21, B22.

### B20 — 3×4 corner-hole board: finish on the hole
- **Levels:** 2–3, 4–5.
- **Materials and setup:** 3×4 board, hole at (1,1), 11 counters; a page of ten small 3×4 grids for recording the jumps as arrows, one per grid.
- **Child's action (as printed):** Finish with one counter sitting on the square that was empty at the start. Record your jumps in order: draw an arrow for the first jump on the first small grid, the second on the second, and so on. Then find a way to finish on the other corner of the same side instead.
- **Expected result (verified):** Ten jumps: (1,3) over (1,2) into (1,1); (3,2) over (2,2) into (1,2); (1,1) over (1,2) into (1,3); (1,4) over (1,3) into (1,2); (2,4) over (2,3) into (2,2); (2,1) over (2,2) into (2,3); (3,4) over (3,3) into (3,2); (3,1) over (3,2) into (3,3); (3,3) over (2,3) into (1,3); (1,3) over (1,2) into (1,1). Replacing the last jump by (1,2) over (1,3) into (1,4) finishes on (1,4). No other single-counter ending exists.
- **Mathematical question / distinction:** Existence with a prescribed final square; recording a complete solution so that another child can replay it.
- **Minutes:** 8.
- **Before / after:** Needs B19. Opens B22, B24.

### B21 — 4×4 board: hole next to a corner, hole in a corner
- **Levels:** 4–5 (reserve for a strong pair).
- **Materials and setup:** Two 4×4 boards, 15 counters each. Board E: hole at (2,1). Board F: hole at (1,1). Blank grids and number boxes.
- **Child's action (as printed):** On board E, finish with one counter; record the jumps as arrows on the small grids. On board F, find the fewest counters you can leave. Write both numbers.
- **Expected result (verified):** E: one counter is possible (1871 positions); a lone survivor can end only on (3,1) or (3,4). Fourteen jumps: (2,3) over (2,2) into (2,1); (4,2) over (3,2) into (2,2); (1,2) over (2,2) into (3,2); (1,4) over (1,3) into (1,2); (1,1) over (1,2) into (1,3); (3,1) over (2,1) into (1,1); (3,4) over (2,4) into (1,4); (1,4) over (1,3) into (1,2); (1,1) over (1,2) into (1,3); (4,4) over (4,3) into (4,2); (4,1) over (4,2) into (4,3); (4,3) over (3,3) into (2,3); (1,3) over (2,3) into (3,3); (3,2) over (3,3) into (3,4). F: the fewest is 2 (1687 positions, no ending with 1); the diagonal colouring settles it without play (B22).
- **Mathematical question / distinction:** Impossibility on a board too large to exhaust by hand, certified by colouring; existence on its neighbour.
- **Minutes:** 15.
- **Before / after:** Needs B19, B15. Opens B22, B23.

### B22 — Diagonal colouring on the 3×4 board
- **Levels:** 4–5.
- **Materials and setup:** Two 3×4 boards printed with the diagonal colouring (square (c, r) gets colour (c + r) mod 3, so each diagonal stripe has one colour), starts A (hole (1,1)) and C (hole (1,2)) drawn on them; count boxes; then the same two boards with the other diagonal colouring ((c − r) mod 3).
- **Child's action (as printed):** For board A, count the counters on each colour. Say which colour the last counter must be on, and list all squares of that colour. Compare with the squares you actually finished on in Problem [B19]. Do the same for board C. Then repeat with the second colouring, and list the squares allowed by both colourings at once.
- **Expected result (verified):** Board A: first colouring allows (1,1), (1,4), (2,3), (3,2); second colouring allows (1,1), (1,4), (2,2), (3,3); both together: exactly (1,1) and (1,4), which is exactly where the survivor was seen to end. Board C: both together allow only (1,2), again exactly the truth. For the 4×4 corner-hole board (B21 F) each colouring alone already allows nothing, so one counter is impossible. (Why the colouring works: every jump, in a row or in a column, uses three consecutive squares of three different colours, exactly as on the strip.)
- **Mathematical question / distinction:** Two independent invariants combine; here the certificate is sharp (allowed set = reachable set), unlike some strips in B16.
- **Minutes:** 12.
- **Before / after:** Needs B15, B19. Opens B23, B24.

### B23 — 5×5 board, middle empty: no need to play
- **Levels:** 4–5 (reserve; also for the mathematicians' share).
- **Materials and setup:** 5×5 board printed with the diagonal colouring, 24 pennies, hole at (3,3).
- **Child's action (as printed):** Count the pennies on each colour. Decide whether one penny can ever be left on this board. Then play once and write how few you reached.
- **Expected result (verified):** With the centre empty the three colour counts are 8, 8, 8, all even. A single penny would give counts 1, 0, 0 (one odd, two even), and the odd/even pattern of the three counts relative to each other never changes (B15), so a single penny is impossible on the 5×5 board from the centre hole. Exhaustive search (1.18 million positions) confirms: the fewest is 2. (Corner hole: the first colouring gives counts 7, 9, 8 and would allow the third colour, but the other diagonal colouring gives 8, 8, 8 and rules everything out; fewest 2 there too.)
- **Mathematical question / distinction:** A one-minute proof for a board with over a million positions; the impossibility is certified, not observed.
- **Minutes:** 8.
- **Before / after:** Needs B22. Opens nothing (endpoint for the share).

### B24 — 3×5 board, hole in the middle of a long side
- **Levels:** 4–5 (reserve).
- **Materials and setup:** 3×5 board (3 wide, 5 tall), 14 counters, hole at (1,3). Small grids for recording.
- **Child's action (as printed):** Finish with one counter on the square that was empty at the start. Record the jumps as arrows.
- **Expected result (verified):** Possible, 13 jumps: (1,1) over (1,2) into (1,3); (1,4) over (1,3) into (1,2); (3,1) over (2,1) into (1,1); (1,1) over (1,2) into (1,3); (3,2) over (2,2) into (1,2); (1,2) over (1,3) into (1,4); (1,5) over (1,4) into (1,3); (2,4) over (2,3) into (2,2); (3,4) over (3,3) into (3,2); (3,2) over (2,2) into (1,2); (1,2) over (1,3) into (1,4); (3,5) over (2,5) into (1,5); (1,5) over (1,4) into (1,3). The survivor can end only on (1,3) (1137 positions). With a corner hole the fewest is 2; with the centre hole (2,3) the game dies after two jumps (12 left, 5 positions in all).
- **Mathematical question / distinction:** Existence on a longer board; the same "finish on the hole" phenomenon as B19 C.
- **Minutes:** 12.
- **Before / after:** Needs B20. Opens nothing.

## Part E. The army on a strip (Conway's Soldiers in one dimension)

### B25 — How far past the line? Blocks of 3, 4, 5
- **Levels:** K–1, 2–3.
- **Materials and setup:** Three strips of 7 with a thick line drawn after square 3, after square 4, after square 5; checkers on squares 1–3, 1–4, 1–5 respectively. Blank strips.
- **Child's action (as printed):** The checkers start on the left of the line. Jump so that a checker gets as far to the right as it can. Colour the farthest square any checker reached. Try each strip twice. Write how many squares past the line you got.
- **Expected result (verified for blocks of 2 to 10):** Always exactly one square past the line (squares 4, 5, 6). Play is forced: for the block of 4, 3 over 4 into 5, then 1 over 2 into 3, and nothing else. Two squares past the line is never reached, however long the block.
- **Mathematical question / distinction:** Optimality and impossibility ("one past, never two") independent of the army's size. Contrast with the 2-D army (B30–B34), which gets four rows past the line.
- **Minutes:** K–1: 6. 2–3: 5.
- **Before / after:** Needs B02. Opens B26, B27, B28.

### B26 — Any army you like: still one square
- **Levels:** 2–3, 4–5.
- **Materials and setup:** Strip of 9 (0.9 in per square, landscape) with the line after square 6; pennies; a recording table with columns "squares I used" and "farthest square reached".
- **Child's action (as printed):** Put pennies on any squares from 1 to 6, as many or as few as you like, and try to get a penny to square 8. Record each army you tried and the farthest square a penny reached. Try at least six different armies, some with gaps.
- **Expected result (verified for all 63 armies on squares 1–6, on a strip long enough for any advance):** No army ever gets a penny past square 7 (one past the line). Gaps do not help.
- **Mathematical question / distinction:** Impossibility for every start (a universal statement the children cannot check by exhaustion for larger strips), which calls for an argument: B27 (descent) or B28 (prices).
- **Minutes:** 8.
- **Before / after:** Needs B25. Opens B27, B28.

### B27 — Why never two squares past: the chain of holes
- **Levels:** 4–5 (2–3 with the adult leading).
- **Materials and setup:** Strip of 9 with the line after square 6 and square 8 marked with a star; five blank strips for drawing positions; fill-in blanks as below.
- **Child's action (as printed):** To land on square 8, a penny must jump from square __ over square __. Draw that position on strip 1. The penny on square 7 got there by a jump from square __ over square __. Draw the position right after that jump on strip 2, and cross out the squares that became empty. To put a penny back on square 6, you need pennies on squares __ and __. The penny on 5 got there by a jump from __ over __, which emptied square __. To fill square 4 again you need pennies on __ and __. Continue the chain on strips 3 to 5. Where does the chain stop?
- **Expected result:** 6 over 7; 5 over 6, emptying 5 and 6; pennies on 4 and 5; 3 over 4, emptying 3 and 4; pennies on 2 and 3; 1 over 2, emptying 1 and 2; pennies on 0 and 1, and there is no square 0. Each refill needs a refill two squares further left, and the army stops at square 1, so the chain cannot be completed: square 8 is never reached. (Proof sketch for the guide: take the first jump onto square 8; the pennies on 6 and 7 just before it; the last jump onto 7 came from 5 over 6 and emptied 6; the first refill of 6 after that came from 4 over 5 and needed 5 refilled after it was emptied; and so on, giving an endless chain of distinct earlier jumps, which is impossible in a finite play.)
- **Mathematical question / distinction:** Impossibility by descent; structural, unlike the arithmetic certificate of B28. The child's product is the filled chain.
- **Minutes:** 10.
- **Before / after:** Needs B26. Opens B28.

### B28 — Price tags on the strip
- **Levels:** 4–5.
- **Materials and setup:** Strip of 9 with the line after square 7 and prices printed under the squares: 1, 1, 2, 3, 5, 8, 13, then 21 and 34 past the line; seven pennies on squares 1–7. A second copy with pennies on squares 1, 2, 3, 5, 6, 7 only. A table: "after jump number / total price of my pennies".
- **Child's action (as printed):** Add up the prices of the squares your pennies are on. Write it as the total before any jump. Make a jump and add up again. Continue until stuck, writing the total after every jump. Do the same on the second strip. Then answer: what is the price of square 9, and could your total ever reach it?
- **Expected result (verified: no jump on the strip ever raises the total; max total over all reachable positions equals the starting total):** First strip: 33 before any jump; a jump to the right lands on a square worth exactly the two squares it used (8 + 13 = 21), so the total stays 33; a jump to the left lowers it. Square 9 costs 34 > 33, and a penny sitting there would alone be worth 34, so no penny ever lands on square 9. Second strip: total 30, same conclusion. Each price is the sum of the two prices to its left (the Fibonacci rule), which is exactly what makes a rightward jump price-neutral.
- **Mathematical question / distinction:** A monovariant (potential-function) proof of impossibility executed with whole-number arithmetic; works for every army at once, unlike exhaustion (B26); it is the 1-D shadow of the golden-ratio argument.
- **Minutes:** 12.
- **Before / after:** Needs B26 (and ideally B27). Opens B29, B36.

### B29 — Always one less
- **Levels:** 4–5 (reserve).
- **Materials and setup:** Table with rows for armies of 3, 4, 5, 6, 7 pennies filling squares 1 to 3, 4, 5, 6, 7 (line right after the army, target two squares past the line), columns "army's worth" and "price of the target square". Price list 1, 1, 2, 3, 5, 8, 13, 21, 34.
- **Child's action (as printed):** Fill in the table. What do you notice about the two columns? Explain why the next row (8 pennies) will follow the same rule without adding it up.
- **Expected result (verified):** 4 and 5; 7 and 8; 12 and 13; 20 and 21; 33 and 34. The army is always worth one less than its target. Reason: adding one more penny adds the next price; the old worth was one less than the old target; old target plus the new penny's price is the new target by the Fibonacci rule; so the new worth is again one less than the new target.
- **Mathematical question / distinction:** The identity F(1)+...+F(n) = F(n+2) − 1 discovered as the reason the price argument never fails; an explanation of the form "the same reason works again".
- **Minutes:** 6.
- **Before / after:** Needs B28. Opens B36.

## Part F. The army on the grid (Conway's Soldiers)

### B30 — Over the line (row 1)
- **Levels:** K–1; also the whole-group launch action for everyone.
- **Materials and setup:** Grid (1.25-inch squares for K–1) with a thick line; a star on the square just above the line in the middle column; two checkers.
- **Child's action (as printed):** Put two checkers in the star's column, one on the square just below the line and one below that. Jump so that a checker lands on the star. Now try with only one checker. How many checkers do you need to get one over the line?
- **Expected result (verified; also the unique minimal army):** One jump, the lower checker over the upper into the star. One checker alone can never jump. Two are needed and two are enough.
- **Mathematical question / distinction:** The first row costs 2; the base case of the sequence 2, 4, 8, 20, never.
- **Minutes:** 2.
- **Before / after:** Needs nothing. Opens B31, B32, B41.

### B31 — Two stars, three stars
- **Levels:** K–1.
- **Materials and setup:** Grid with the line; two stars in row 1, in columns −1 and +1 (two columns apart); a second grid with three stars in row 1 in columns −2, 0, +2. Blank grids below the line for drawing armies.
- **Child's action (as printed):** Put checkers below the line so that after your jumps a checker sits on each star. Use as few checkers as you can. Draw where you put them. Then do the same for the three stars.
- **Expected result:** 4 checkers for two stars, 6 for three: a pair stacked under each star. Fewer is impossible: every checker that ends above the line made at least one jump, every jump removes a checker, so each star costs at least two checkers. (Counting argument; no search needed.)
- **Mathematical question / distinction:** Optimality with a reason a young child can give ("each one needs a partner to jump over"). Contrast with B32, where one star two rows up costs 4 by itself.
- **Minutes:** 5.
- **Before / after:** Needs B30. Opens B32.

### B32 — Row 2: the fewest checkers
- **Levels:** K–1 (with the adult), 2–3, 4–5.
- **Materials and setup:** Grid with the line and a star in row 2 above column 0; counters. Two blank grids for armies of 3, three for armies of 4.
- **Child's action (as printed):** Try to land a counter on the star, two rows above the line. First use exactly 3 counters, placed anywhere below the line. Draw every army of 3 you tried. Then use exactly 4. Draw every army of 4 that works, with its jumps numbered.
- **Expected result (verified: every army of weight at least 1 searched exhaustively):** No army of 3 works. Reason for the table: with 3 counters there are at most 2 jumps; the jump onto the star must come from row 0 over row 1 (a sideways jump inside row 2 would need two counters already in row 2), so just before it one counter is in row 1 and one in row 0; the row-1 counter got there by a jump from row −1 over row 0, which removed the row-0 counter; refilling row 0 would need a third jump. With 4 counters there is, up to mirror image, exactly one army that works, an L: (0,0), (1,0), (2,0) and (0,−1). Jumps: (0,−1) over (0,0) into (0,1); (2,0) over (1,0) into (0,0); (0,0) over (0,1) into (0,2). A column of 4 under the star reaches only row 1 (the strip result of B25).
- **Mathematical question / distinction:** Optimality (4) and completeness (the L is the only shape). Row 2 costs twice row 1.
- **Minutes:** K–1: 8. 2–3: 8. 4–5: 6.
- **Before / after:** Needs B30. Opens B33, B34, B36, B41.

### B33 — Row 3 with 8 counters
- **Levels:** 2–3 (army shape given as a picture), 4–5 (find the army).
- **Materials and setup:** Grid with the line and a star in row 3 above column 0; 8 counters; blank grids; a page of small grids for numbering jumps. For 2–3 the army (a) below is printed as shaded squares.
- **Child's action (as printed):** 4–5: Land a counter on the star three rows above the line using exactly 8 counters. Draw the army you used and number the seven jumps on the small grids. Then find a second army of 8 that is not a mirror image of the first. 2–3: Put counters on the eight shaded squares. Find the seven jumps that land a counter on the star. Number them on the small grids.
- **Expected result (verified: exactly two armies up to mirror image):** Army (a): row 0 at columns −2, −1, 0, 1, 2; row −1 at columns 0, 1, 2. Jumps: (0,−1) over (0,0) into (0,1); (−2,0) over (−1,0) into (0,0); (0,0) over (0,1) into (0,2); (1,−1) over (1,0) into (1,1); (2,−1) over (2,0) into (2,1); (2,1) over (1,1) into (0,1); (0,1) over (0,2) into (0,3). Army (b): row 0 at columns −2 to 2; column 0 at rows −1, −2, −3. Jumps: (0,−1) over (0,0) into (0,1); (−2,0) over (−1,0) into (0,0); (0,−3) over (0,−2) into (0,−1); (0,0) over (0,1) into (0,2); (2,0) over (1,0) into (0,0); (0,−1) over (0,0) into (0,1); (0,1) over (0,2) into (0,3). Seven counters can never reach row 3 (weights; for the table, the price map of B36).
- **Mathematical question / distinction:** Existence and completeness at the next size; the doubling 2, 4, 8 continues once more.
- **Minutes:** 2–3: 12. 4–5: 15.
- **Before / after:** Needs B32. Opens B34, B36.

### B34 — The table of rows, and row 4
- **Levels:** 4–5.
- **Materials and setup:** Table "row reached / fewest counters" with rows 1 to 5; a grid 9 wide and 8 tall (rows −3 to 4) at 0.8 in per square, with the line and a star in row 4 above the middle column; 20 pennies.
- **Child's action (as printed):** Fill in the fewest counters for rows 1, 2 and 3 from your earlier problems. Write your guess for row 4. Then try to reach row 4 with 16 counters. If you run out of ideas, try with 20.
- **Expected result (verified by exhaustive search over all 20-counter armies of sufficient weight; 19 cannot):** 2, 4, 8, then 20, not 16. The doubling pattern breaks. Row 5 can never be reached by any finite army (Conway; golden-ratio weights; guide's mathematics section). Children will not finish this in the session; the guide holds the 20-army of B35 for the share.
- **Mathematical question / distinction:** A pattern that breaks at the fourth case; optimality at a size beyond hand search; the famous impossibility at row 5.
- **Minutes:** 10 (open-ended).
- **Before / after:** Needs B33. Opens B35, B37.

### B35 — The 20-counter army (reserve; adult demonstration for the share)
- **Levels:** 4–5 reserve; the two mathematicians.
- **Materials and setup:** Grid 9 wide and 8 tall (rows −3 to 4) at 0.8 in per square, with the line and the star at (0,4); the army printed as shaded squares: row 0 at columns −4 to 4 (9 counters); row −1 at columns −2, −1, 0, 1 (4); row −2 at columns −3, −2, −1, 0, 1 (5); row −3 at columns −1, 0 (2). Twenty counters.
- **Child's action (as printed):** Put a counter on each shaded square. Find the 19 jumps that land a counter on the star.
- **Expected result (verified by replay):** 1. (−2,−1) over (−2,0) into (−2,1). 2. (−1,−1) over (−1,0) into (−1,1). 3. (−1,−3) over (−1,−2) into (−1,−1). 4. (−3,−2) over (−2,−2) into (−1,−2). 5. (−1,−2) over (−1,−1) into (−1,0). 6. (0,−1) over (0,0) into (0,1). 7. (0,−3) over (0,−2) into (0,−1). 8. (−4,0) over (−3,0) into (−2,0). 9. (−2,0) over (−1,0) into (0,0). 10. (0,0) over (0,1) into (0,2). 11. (2,0) over (1,0) into (0,0). 12. (1,−2) over (1,−1) into (1,0). 13. (0,−1) over (0,0) into (0,1). 14. (4,0) over (3,0) into (2,0). 15. (2,0) over (1,0) into (0,0). 16. (0,1) over (0,2) into (0,3). 17. (−2,1) over (−1,1) into (0,1). 18. (0,0) over (0,1) into (0,2). 19. (0,2) over (0,3) into (0,4). Our exhaustive search finds exactly 4 armies of 20 (up to mirror image) that can do it; the other three are in `verify_soldiers_row4_all.out`. No army of 19 can: the 84 armies of 19 whose weight is exactly 1 all fail, and every other 19-army has weight below 1.
- **Mathematical question / distinction:** Existence at the hardest reachable size; the guide's answer to B34.
- **Minutes:** 15 or more.
- **Before / after:** Needs B34. Opens the mathematics section (golden ratio).

### B36 — Price map on the grid
- **Levels:** 4–5.
- **Materials and setup:** Grid with the line and a star in row 3; prices printed on the squares by distance from the star (distance = squares across plus squares up or down): star 13; distance 1: 8; distance 2: 5; distance 3: 3; distance 4: 2; distance 5 and beyond: 1. Counters. The same for a star in row 2 with prices 8, 5, 3, 2, 1, 1, ....
- **Child's action (as printed):** Make three jumps of your choice and, for each, compare the price of the landing square with the two prices of the squares you used. Which jumps keep the total the same? Which lower it? Then find the 7 most expensive squares below the line and add them up. Compare with the star's price. What does this say about armies of 7? Do the same with 3 squares on the row-2 board.
- **Expected result (verified on a 25×25 grid: no jump raises the total; best totals computed):** A jump straight towards the star lands on a square worth exactly the sum of the two it used (3 + 2 = 5, 5 + 3 = 8); a sideways or backward jump lowers the total. Row 3: the best 7 squares are worth 3 + 2 + 2 + 2 + 1 + 1 + 1 = 12 < 13, so no army of 7 counters can ever reach row 3 (the best 8 are worth exactly 13, consistent with B33). Row 2: best 3 squares 3 + 2 + 2 = 7 < 8, so 3 counters cannot reach row 2 (B32).
- **Mathematical question / distinction:** The potential-function certificate in two dimensions, with whole numbers; it proves optimality for rows 2 and 3 in one addition each. (For row 4 the integer prices show only that 18 counters are too few; 19 needs the search of B35.)
- **Minutes:** 12.
- **Before / after:** Needs B28, B33. Opens B37.

### B37 — Row 5 on this board (reserve)
- **Levels:** 4–5 reserve; mathematicians.
- **Materials and setup:** Grid 9 wide and 9 tall (rows −3 to 5) at 0.75 in per square, with the line and a star in row 5; prices by distance printed in the squares: 89, 55, 34, 21, 13, 8, 5, 3, 2, 1, 1, ...; the 9-wide, 4-deep block of 36 squares directly below the line outlined. No counters needed; this is an adding problem.
- **Child's action (as printed):** Add up the prices of the 36 squares in the outlined block. Compare with the star's price. Then work out how many squares below the line you would need before their prices could add up to 89.
- **Expected result (verified):** The block is worth 72 < 89. The 25 squares at distance 5 to 9 are worth 61 and every further square is worth 1, so at least 53 squares are needed to reach 89: no army of 52 or fewer counters can ever reach row 5. (With the golden-ratio prices in the guide's mathematics section, the whole infinite half-plane below the line is worth exactly the price of the row-5 square, so no finite army at all can reach row 5.)
- **Mathematical question / distinction:** Impossibility for every army up to a size the children can name; the bridge to Conway's theorem.
- **Minutes:** 8.
- **Before / after:** Needs B36. Opens the mathematics section.

## Part G. Two-player variants (reserves; the same jump, last jump wins)

### B38 — Last jump wins on `XX.XXX`
- **Levels:** 2–3, 4–5 (reserve).
- **Materials and setup:** Strip of 6, hole at 3, five pennies; a score table "who started / who won" with five rows.
- **Child's action (as printed):** Two players take turns making one jump each. The player who makes the last possible jump wins. Play five games, taking turns to start, and fill in the table. Then find a first jump that wins for the starter no matter what.
- **Expected result (verified):** The starter wins with 1 over 2 into 3: the rest is forced (4 over 3 into 2 for the second player, then 6 over 5 into 4 for the starter, stuck), three jumps, starter makes the last. The other first jump, 5 over 4 into 3, loses: the second player replies 2 over 3 into 4 and the game is over after two jumps.
- **Mathematical question / distinction:** A game version of B06: the same choice that decided "2 or 3 left" decides the winner.
- **Minutes:** 8.
- **Before / after:** Needs B06. Opens B39, B40.

### B39 — Games the count decides (`XX.XX`, `X.XXXX`, `XXX.XXX`)
- **Levels:** 4–5 (reserve).
- **Materials and setup:** The three strips, pennies.
- **Child's action (as printed):** Two players take turns making one jump each; the player who makes the last possible jump wins. Play each strip this way a few times. For each strip, write who wins and why the outcome is the same every game.
- **Expected result (verified):** `XX.XX`: every play has exactly 2 jumps (2 pennies always remain), so the second player always makes the last jump. `X.XXXX`: every play has exactly 4 jumps (one penny always remains), so the second player always wins. `XXX.XXX`: every play has exactly 3 jumps (3 remain), so the starter always wins, whatever anyone does. The count "jumps = pennies removed" (B08) decides the game when the number of survivors is the same in every play.
- **Mathematical question / distinction:** The counting invariant as a game-deciding argument; contrast with B38, where the number of jumps depends on play.
- **Minutes:** 6.
- **Before / after:** Needs B08, B11. Opens nothing.

### B40 — Last jump wins on the 3×3 board with a corner hole
- **Levels:** 2–3, 4–5 (reserve).
- **Materials and setup:** 3×3 board, 8 counters, hole at (1,1).
- **Child's action (as printed):** Two players take turns making one jump each; the player who makes the last possible jump wins. Play four games. Find a way for the starter to win every time.
- **Expected result (verified):** The starter wins. Strategy: jump (1,3) over (1,2) into (1,1). If the opponent jumps (3,2) over (2,2) into (1,2), reply (3,3) over (2,3) into (1,3); if the opponent jumps (3,3) over (2,3) into (1,3), reply (3,2) over (2,2) into (1,2). Either way no jump is left and the starter made the last one. (The mirror-image first jump, (3,1) over (2,1) into (1,1), works the same way.)
- **Mathematical question / distinction:** A complete strategy on a small game tree (16 positions).
- **Minutes:** 8.
- **Before / after:** Needs B18. Opens nothing.

## Part H. Further K–1 doing and further strip reserves

### B41 — Build the L and jump to row 2 (K–1)
- **Levels:** K–1.
- **Materials and setup:** Large grid (1.25-inch squares) with the line and a star two rows above it; the L army printed as four shaded squares: (0,0), (0,−1), (1,0), (2,0). Four checkers. A small copy of the picture for arrows. A second grid with four shaded squares in a column under the star: (0,0), (0,−1), (0,−2), (0,−3).
- **Child's action (as printed):** Put a checker on each shaded square. Make jumps so that a checker lands on the star. Draw the jumps as arrows on the small picture, in order. Then use the second board: put checkers on its four shaded squares and try to reach the star.
- **Expected result (verified):** L: three jumps, up over the line ((0,−1) over (0,0) into (0,1)), left along row 0 ((2,0) over (1,0) into (0,0)), up onto the star ((0,0) over (0,1) into (0,2)). Column of 4: the play is forced and reaches row 1 only ((0,−1) over (0,0) into (0,1), then (0,−3) over (0,−2) into (0,−1), stuck).
- **Mathematical question / distinction:** Existence by construction versus impossibility for a different shape of the same size; a K–1 instance of "the shape matters, not only the number".
- **Minutes:** 6.
- **Before / after:** Needs B30. Opens B32.

### B42 — 3×3 board with two holes
- **Levels:** 2–3 (reserve).
- **Materials and setup:** Two 3×3 boards, 7 counters each: holes at opposite corners (1,1) and (3,3); holes at (1,1) and (1,3), two corners of one side.
- **Child's action (as printed):** On each board, find the fewest counters you can leave. Draw the stuck position with the fewest counters. Did the second hole help compared with Problem [B18]?
- **Expected result (verified):** Opposite corners: fewest 2 (23 positions). Same-side corners: fewest 2 (21 positions). With one corner hole the fewest was 4, so a second hole helps, but one counter is still impossible on the 3×3 board with these starts.
- **Mathematical question / distinction:** Optimality under a changed start; a bigger empty space does not give a full clearance.
- **Minutes:** 6.
- **Before / after:** Needs B18. Opens nothing.

### B43 — `XXX.XXXX`: endings with 1, 2 and 4, never 3
- **Levels:** 2–3.
- **Materials and setup:** Strip of 8, hole at 4, seven pennies; four blank strips.
- **Child's action (as printed):** Play several times. Find a play that ends with 1 penny, a play that ends with 2, and a play that ends with 4. Draw the three stuck positions. Then try to end with exactly 3 and say what happened.
- **Expected result (verified, 16 positions):** Stuck positions: `.X......` and `....X...` (1 penny; e.g. 6 over 5 into 4, 3 over 4 into 5, 1 over 2 into 3, 8 over 7 into 6, 6 over 5 into 4, then 3 over 4 into 5 or 4 over 3 into 2); `..X...X.` (2 pennies; e.g. 6 over 5 into 4, 8 over 7 into 6, 3 over 4 into 5, 1 over 2 into 3, 5 over 6 into 7); `X.X.X..X` (4 pennies: any play that starts with 2 over 3 into 4 is forced from then on, 5 over 4 into 3, 7 over 6 into 5, and stops there after three jumps). Ending with 3 is impossible.
- **Mathematical question / distinction:** Completeness of endings: not every number between the best and the worst occurs.
- **Minutes:** 8.
- **Before / after:** Needs B08. Opens B12.

### B44 — Hole at 2 on strips of 6, 8, 10: the repeating trick
- **Levels:** 4–5.
- **Materials and setup:** Strips `X.XXXX`, `X.XXXXXX`, `X.XXXXXXXX`, pennies; small strips for recording jumps in order.
- **Child's action (as printed):** Clear each strip to one penny and record the jumps in order. Then describe, in words, a way of jumping that would clear a strip of 12 with the hole at 2.
- **Expected result (verified):** 6: 4 over 3 into 2, 1 over 2 into 3, 6 over 5 into 4, 3 over 4 into 5. 8: the same four, then 8 over 7 into 6, 5 over 6 into 7. 10: then 10 over 9 into 8, 7 over 8 into 9. The trick: "jump the penny two to the right of the hole back over into the hole, then jump the penny two to the left of the new hole forward over it; the hole has moved two squares right; repeat." It clears every even length with the hole at 2 (and, by the same moves, the hole at n−1).
- **Mathematical question / distinction:** Existence for all even sizes by an explicit repeating strategy ("the same reason works again on a bigger case"), complementing the table of B13.
- **Minutes:** 10.
- **Before / after:** Needs B05, B13. Opens B45.

### B45 — The trick on odd strips (7 and 9)
- **Levels:** 4–5 (reserve).
- **Materials and setup:** Strips `X.XXXXX` (7) and `X.XXXXXXX` (9), pennies.
- **Child's action (as printed):** Use the trick of Problem [B44] on each strip. Where does it stop, and how many pennies are left? Try other ways and record the fewest you can leave.
- **Expected result (verified):** The trick ends with pennies on squares 5 and 7 (strip of 7) or 7 and 9 (strip of 9): 2 left, and no other play does better (fewest 2 on both, by exhaustive search; 7 positions and 13 positions). The odd square at the end is always one too many.
- **Mathematical question / distinction:** The strategy's failure on odd sizes, matching the table of B13; a counterexample to "the trick clears everything".
- **Minutes:** 6.
- **Before / after:** Needs B44. Opens nothing.

---

## Coverage summary for the curator

- **K–1 without reading (16):** B01, B02, B03, B04, B07, B08, B09, B10, B17, B18, B19 (boards B, D), B25, B30, B31, B32, B41. Reserves for fast K–1 finishers: B09, B10, B31, B41, B05 (with the adult).
- **Grades 2–3 (21):** B02, B03, B04, B05, B06, B07, B08, B09, B11, B18, B19, B20, B25, B26, B27 (adult-led), B32, B33 (army given), B38, B40, B42, B43. Reserves: B42, B43, B38, B40, B20.
- **Grades 4–5 (28):** B05, B06, B11, B12, B13, B14, B15, B16, B19, B20, B21, B22, B23, B24, B26, B27, B28, B29, B32, B33, B34, B35, B36, B37, B38, B39, B44, B45. Reserves: B21, B23, B24, B35, B37, B39, B40, B45.
- **Contrasting instances:** can/cannot by hole (B02/B03, B04/B05, B19 A–D, B21 E/F); sizes 3–4–5–6–7–8 (B13) and 4–5–6–7–8 (B07); armies 2–4–8–20 (B30, B32, B33, B34) and 1-D "always one" (B25, B26); same start, different endings (B05, B06, B43).
- **Building toward an argument:** forced-chain explanation (B07), counting invariant (B08, B39), state maps as proofs (B11, B12), colouring invariants (B15, B16, B22, B23), descent (B27), Fibonacci/golden-ratio potential (B28, B29, B36, B37), strategy for all even sizes (B44, B45).
- **Pure doing:** B01–B06, B17–B20, B24, B25, B30–B33, B35, B41–B43.
- **Whole-group launch candidate:** B30 (the one action everyone uses: the jump over the line), followed at every table by a strip problem (B01/B02 or B05).
