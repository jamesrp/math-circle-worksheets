#!/usr/bin/env python3
"""Curator-stage verification for the Week 1 plan (plan.md).

Re-checks, independently of the bank's scripts, every instance, number and move
sequence that plan.md prints.  Run:  python3 verify_curator.py > verify_curator.out
"""
from itertools import combinations
from fractions import Fraction
import math

# ----------------------------------------------------------------------------
# 1. STRIPS.  A position is a string of X (counter) and . (empty); squares 1..n.
# ----------------------------------------------------------------------------

def strip_moves(p):
    n = len(p)
    out = []
    for i in range(n):
        if p[i] != 'X':
            continue
        for d in (1, -1):
            j, k = i + d, i + 2 * d
            if 0 <= k < n and p[j] == 'X' and p[k] == '.':
                q = list(p)
                q[i] = '.'; q[j] = '.'; q[k] = 'X'
                out.append(((i + 1, j + 1, k + 1), ''.join(q)))
    return out


def strip_explore(start):
    seen = {start}
    stack = [start]
    edges = {}
    while stack:
        p = stack.pop()
        mv = strip_moves(p)
        edges[p] = [q for _, q in mv]
        for _, q in mv:
            if q not in seen:
                seen.add(q)
                stack.append(q)
    stuck = sorted(p for p in seen if not edges[p])
    minleft = min(p.count('X') for p in stuck)
    forced = all(len(set(edges[p])) <= 1 for p in seen)
    lone = sorted(p.index('X') + 1 for p in stuck if p.count('X') == 1)
    arrows = sum(len(set(v)) for v in edges.values())
    return seen, edges, stuck, minleft, forced, lone, arrows


def report_strip(label, start):
    seen, edges, stuck, minleft, forced, lone, arrows = strip_explore(start)
    dist = {}
    for p in stuck:
        dist[p.count('X')] = dist.get(p.count('X'), 0) + 1
    first = [m for m, _ in strip_moves(start)]
    print(f"{label:34s} {start:12s} positions={len(seen):2d} arrows={arrows:2d} "
          f"fewest={minleft} forced={forced} stuck={stuck} by-count={dict(sorted(dist.items()))} "
          f"lone-survivor-squares={lone} first-jumps={first}")


def replay_strip(start, moves):
    p = start
    for (a, b, c) in moves:
        legal = dict(strip_moves(p))
        assert (a, b, c) in legal, f"illegal strip move {a} over {b} to {c} from {p}"
        p = legal[(a, b, c)]
    return p


print("=" * 78)
print("1. STRIPS USED ON THE STUDENT PAGES")
print("=" * 78)
print("K-1 problem 1 (strips of 3):")
report_strip("  A: checkers on 1,2", "XX.")
report_strip("  B: checkers on 1,3", "X.X")
report_strip("  C: checkers on 2,3", ".XX")
print("K-1 problems 2-3 / grades 2-3 problem 1 (strips of 4):")
report_strip("  hole at 4", "XXX.")
report_strip("  hole at 2", "X.XX")
print("K-1 problem 4 / grades 2-3 problem 2 (strips of 5):")
report_strip("  hole at 5", "XXXX.")
report_strip("  hole at 4", "XXX.X")
report_strip("  hole at 3", "XX.XX")
print("K-1 problem 5 (hole at the end, strips of 6, 7, and the adult's strip of 8):")
report_strip("  6, hole at 6", "XXXXX.")
report_strip("  7, hole at 7", "XXXXXX.")
report_strip("  8, hole at 8", "XXXXXXX.")
print("Grades 2-3 problem 3 / grades 4-5 problem 1 (strips of 6):")
report_strip("  A: hole at 2", "X.XXXX")
report_strip("  B: hole at 3", "XX.XXX")
report_strip("  C: hole at 6", "XXXXX.")
print("Grades 2-3 problem 4 (strip of 8, hole at 4):")
report_strip("  hole at 4", "XXX.XXXX")
print("K-1 reserve (strip of 6, hole at 3 = XX.XXX, counted above).")
print()

print("Named plays printed in the guide (replayed):")
plays = {
    "X.XX  -> ..X.": ("X.XX", [(4, 3, 2), (1, 2, 3)]),
    "XXXX. -> ..X.X": ("XXXX.", [(3, 4, 5), (1, 2, 3)]),
    "XXX.X -> X.X..": ("XXX.X", [(2, 3, 4), (5, 4, 3)]),
    "XX.XX -> .X..X": ("XX.XX", [(1, 2, 3), (4, 3, 2)]),
    "XX.XX -> X..X.": ("XX.XX", [(5, 4, 3), (2, 3, 4)]),
    "XXXXX. -> X..X.X": ("XXXXX.", [(4, 5, 6), (2, 3, 4)]),
    "XXXXXX. -> ..X.X.X": ("XXXXXX.", [(5, 6, 7), (3, 4, 5), (1, 2, 3)]),
    "XXXXXXX. -> X..X.X.X": ("XXXXXXX.", [(6, 7, 8), (4, 5, 6), (2, 3, 4)]),
    "X.XXXX ends on 5": ("X.XXXX", [(4, 3, 2), (1, 2, 3), (6, 5, 4), (3, 4, 5)]),
    "X.XXXX ends on 2": ("X.XXXX", [(4, 3, 2), (1, 2, 3), (6, 5, 4), (4, 3, 2)]),
    "XX.XXX first 1 over 2 -> 2 left": ("XX.XXX", [(1, 2, 3), (4, 3, 2), (6, 5, 4)]),
    "XX.XXX first 5 over 4 -> 3 left": ("XX.XXX", [(5, 4, 3), (2, 3, 4)]),
    "XXX.XXXX -> 1 left on 5": ("XXX.XXXX", [(6, 5, 4), (3, 4, 5), (1, 2, 3), (8, 7, 6), (6, 5, 4), (3, 4, 5)]),
    "XXX.XXXX -> 1 left on 2": ("XXX.XXXX", [(6, 5, 4), (3, 4, 5), (1, 2, 3), (8, 7, 6), (6, 5, 4), (4, 3, 2)]),
    "XXX.XXXX -> 2 left": ("XXX.XXXX", [(6, 5, 4), (8, 7, 6), (3, 4, 5), (1, 2, 3), (5, 6, 7)]),
    "XXX.XXXX -> 4 left": ("XXX.XXXX", [(2, 3, 4), (5, 4, 3), (7, 6, 5)]),
}
for name, (start, moves) in plays.items():
    end = replay_strip(start, moves)
    stuck = not strip_moves(end)
    print(f"  {name:36s} {len(moves)} jumps -> {end}  left={end.count('X')} stuck={stuck}")
print()

print("Complete maps (positions and arrows) for the two map problems:")
for start in ("XX.XX", "XX.XXX", "X.XXXX"):
    seen, edges, stuck, minleft, forced, lone, arrows = strip_explore(start)
    print(f"  {start}: {len(seen)} positions, {arrows} arrows")
    order = [start] + sorted(p for p in seen if p != start)
    for p in order:
        nxt = sorted(set(edges[p]))
        print(f"     {p} -> {nxt if nxt else 'STUCK'}")
print()

print("Jumps + counters left on XXX.XXXX (every stuck position):")
seen, edges, stuck, *_ = strip_explore("XXX.XXXX")
for p in stuck:
    left = p.count('X')
    print(f"  {p}: {left} left, {7 - left} jumps, sum = 7")
print()

print("Survivor identity on X.XXXX (which starting checker can be the last one):")
def strip_moves_id(p):
    n = len(p); out = []
    for i in range(n):
        if p[i] is None: continue
        for d in (1, -1):
            j, k = i + d, i + 2 * d
            if 0 <= k < n and p[j] is not None and p[k] is None:
                q = list(p); q[k] = q[i]; q[i] = None; q[j] = None
                out.append(tuple(q))
    return out
start_id = (1, None, 3, 4, 5, 6)
seen = {start_id}; stack = [start_id]; survivors = set()
while stack:
    p = stack.pop(); mv = strip_moves_id(p)
    if not mv and sum(x is not None for x in p) == 1:
        survivors.add(([x for x in p if x is not None][0], [i + 1 for i, x in enumerate(p) if x is not None][0]))
    for q in mv:
        if q not in seen: seen.add(q); stack.append(q)
print(f"  (starting square of survivor, final square): {sorted(survivors)}")
print()

# ----------------------------------------------------------------------------
# 2. THE ARMY ON A STRIP
# ----------------------------------------------------------------------------
print("=" * 78)
print("2. THE ARMY ON A STRIP")
print("=" * 78)
for k in (3, 4, 5):
    start = 'X' * k + '.' * (7 - k)
    seen, edges, stuck, minleft, forced, lone, arrows = strip_explore(start)
    far = max(max(i + 1 for i, c in enumerate(p) if c == 'X') for p in seen)
    print(f"  block of {k} on a strip of 7, line after square {k}: farthest square reached = {far} "
          f"(= {far - k} past the line), forced={forced}, positions={len(seen)}, stuck={stuck}")

best = 0; count = 0
for r in range(1, 7):
    for army in combinations(range(6), r):
        start = ''.join('X' if i in army else '.' for i in range(6)) + '...'
        seen, *_ = strip_explore(start)
        far = max(max(i + 1 for i, c in enumerate(p) if c == 'X') for p in seen)
        best = max(best, far); count += 1
print(f"  all {count} armies on squares 1-6 of a strip of 9 (line after 6): farthest square ever reached = {best} (square 8 never)")

print()
print("Price tags on the strip of 9 (line after 6, star on square 8): prices 1 1 2 3 5 8 | 13 21 34")
prices = [1, 1, 2, 3, 5, 8, 13, 21, 34]
def total(p):
    return sum(prices[i] for i, c in enumerate(p) if c == 'X')
raises = 0; checked = 0
seen_all = set()
for r in range(1, 10):
    for army in combinations(range(9), r):
        start = ''.join('X' if i in army else '.' for i in range(9))
        if start in seen_all: continue
        seen, edges, *_ = strip_explore(start)
        for p in seen:
            seen_all.add(p)
            for m, q in strip_moves(p):
                checked += 1
                if total(q) > total(p): raises += 1
                a, b, c = m
                expected = prices[c - 1] - prices[a - 1] - prices[b - 1]
                if c > a:  # rightward
                    assert expected == 0, (p, m)
                else:
                    assert expected < 0, (p, m)
print(f"  every jump from every position of every army on the 9-strip checked: {checked} jumps, {raises} raise the total;")
print(f"  rightward jumps keep the total (price of landing square = sum of the two used), leftward jumps lower it.")
print(f"  full army 1-6 is worth {total('XXXXXX...')}; gapped army 1,2,4,5,6 is worth {total('XX.XXX...')}; star (square 8) costs {prices[7]}")
print("  Block armies (line right after the block, target two squares past the line):")
fib = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
for k in (3, 4, 5, 6, 7):
    worth = sum(fib[:k]); target = fib[k + 1]
    print(f"     army of {k}: worth {worth}, target square {k + 2} costs {target}, difference {target - worth}")
print()

# ----------------------------------------------------------------------------
# 3. SMALL BOARDS (3x3) AND THE ARMY ON THE GRID
# ----------------------------------------------------------------------------
print("=" * 78)
print("3. SMALL BOARDS: 3x3")
print("=" * 78)

def grid_moves(pos, cells):
    out = []
    for (x, y) in pos:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            over = (x + dx, y + dy); to = (x + 2 * dx, y + 2 * dy)
            if over in pos and to in cells and to not in pos:
                q = set(pos); q.discard((x, y)); q.discard(over); q.add(to)
                out.append((((x, y), over, to), frozenset(q)))
    return out


def grid_explore(start, cells):
    start = frozenset(start)
    seen = {start}; stack = [start]; stuck = []
    while stack:
        p = stack.pop(); mv = grid_moves(p, cells)
        if not mv: stuck.append(p)
        for _, q in mv:
            if q not in seen: seen.add(q); stack.append(q)
    return seen, stuck

cells33 = {(x, y) for x in range(1, 4) for y in range(1, 4)}
mid = cells33 - {(2, 2)}
print(f"  3x3 middle empty: first jumps available = {len(grid_moves(frozenset(mid), cells33))}")
corner = cells33 - {(1, 1)}
seen, stuck = grid_explore(corner, cells33)
dist = {}
for p in stuck: dist[len(p)] = dist.get(len(p), 0) + 1
print(f"  3x3 corner (1,1) empty: first jumps = {[m for m, _ in grid_moves(frozenset(corner), cells33)]}, "
      f"positions={len(seen)}, stuck by count={dict(sorted(dist.items()))}, fewest={min(dist)}")
print("  stuck positions with 4 checkers:")
for p in stuck:
    if len(p) == 4: print("     ", sorted(p))
print("  stuck position with 5 checkers:", [sorted(p) for p in stuck if len(p) == 5])

def replay_grid(start, moves, cells):
    p = frozenset(start)
    for m in moves:
        legal = dict(grid_moves(p, cells))
        assert m in legal, f"illegal grid move {m} from {sorted(p)}"
        p = legal[m]
    return p

p = replay_grid(corner, [((1, 3), (1, 2), (1, 1)), ((3, 2), (2, 2), (1, 2)), ((1, 1), (1, 2), (1, 3)), ((3, 1), (2, 1), (1, 1))], cells33)
print(f"  4-jump play on the corner board ends with {len(p)} checkers at {sorted(p)}, stuck={not grid_moves(p, cells33)}")
print()

print("=" * 78)
print("4. THE ARMY ON THE GRID (columns from the star column 0, rows from the line: row 1 is just above it)")
print("=" * 78)
BIG = {(x, y) for x in range(-12, 13) for y in range(-12, 8)}

def army_reaches(army, target, cells=BIG, limit=2_000_000):
    start = frozenset(army)
    seen = {start}; stack = [start]
    while stack:
        p = stack.pop()
        if target in p: return True
        for _, q in grid_moves(p, cells):
            if q not in seen:
                seen.add(q); stack.append(q)
                if len(seen) > limit: raise RuntimeError("search too large")
    return False

# Row 1: two checkers; one checker alone can never jump.
print(f"  row 1: column of 2 reaches (0,1): {army_reaches([(0, 0), (0, -1)], (0, 1))}; a single checker has "
      f"{len(grid_moves(frozenset([(0, 0)]), BIG))} jumps available")

# K-1 two stars / three stars: constructive check
two = [(-1, 0), (-1, -1), (1, 0), (1, -1)]
p = replay_grid(two, [((-1, -1), (-1, 0), (-1, 1)), ((1, -1), (1, 0), (1, 1))], BIG)
print(f"  two stars at (-1,1),(1,1): 4 checkers in two stacked pairs end at {sorted(p)}")
three = [(-2, 0), (-2, -1), (0, 0), (0, -1), (2, 0), (2, -1)]
p = replay_grid(three, [((-2, -1), (-2, 0), (-2, 1)), ((0, -1), (0, 0), (0, 1)), ((2, -1), (2, 0), (2, 1))], BIG)
print(f"  three stars at (-2,1),(0,1),(2,1): 6 checkers end at {sorted(p)}")
print("  fewer is impossible: each checker above the line at the end made a jump; each jump removes a different checker.")

# Row 2 with 3 and with 4 counters: exhaustive over a region.
region = [(x, y) for x in range(-4, 5) for y in range(-4, 1)]
print(f"  row 2 search region: columns -4..4, rows -4..0 ({len(region)} squares)")
wins3 = [a for a in combinations(region, 3) if army_reaches(a, (0, 2))]
print(f"  armies of 3 that reach row 2 in the region: {len(wins3)}")
wins4 = [a for a in combinations(region, 4) if army_reaches(a, (0, 2))]
print(f"  armies of 4 that reach row 2 in the region: {len(wins4)} -> {[sorted(a) for a in wins4]}")
L = [(0, 0), (1, 0), (2, 0), (0, -1)]
p = replay_grid(L, [((0, -1), (0, 0), (0, 1)), ((2, 0), (1, 0), (0, 0)), ((0, 0), (0, 1), (0, 2))], BIG)
print(f"  the L: 3 jumps end at {sorted(p)}")
col4 = [(0, 0), (0, -1), (0, -2), (0, -3)]
seen, stuck = grid_explore(col4, BIG)
top = max(y for p in seen for (x, y) in p)
print(f"  column of 4 under the star: positions={len(seen)}, highest row reached={top}, stuck={[sorted(p) for p in stuck]}")
sq4 = [(0, 0), (1, 0), (0, -1), (1, -1)]
seen, stuck = grid_explore(sq4, BIG)
print(f"  2x2 block of 4: positions={len(seen)}, highest row reached={max(y for p in seen for (x, y) in p)}")

# Row 3 with 8: the two armies and their jumps.
army_a = [(-2, 0), (-1, 0), (0, 0), (1, 0), (2, 0), (0, -1), (1, -1), (2, -1)]
jumps_a = [((0, -1), (0, 0), (0, 1)), ((-2, 0), (-1, 0), (0, 0)), ((0, 0), (0, 1), (0, 2)), ((1, -1), (1, 0), (1, 1)),
           ((2, -1), (2, 0), (2, 1)), ((2, 1), (1, 1), (0, 1)), ((0, 1), (0, 2), (0, 3))]
p = replay_grid(army_a, jumps_a, BIG)
print(f"  row 3 army (a) {sorted(army_a)}: 7 jumps end at {sorted(p)}")
army_b = [(-2, 0), (-1, 0), (0, 0), (1, 0), (2, 0), (0, -1), (0, -2), (0, -3)]
jumps_b = [((0, -1), (0, 0), (0, 1)), ((-2, 0), (-1, 0), (0, 0)), ((0, -3), (0, -2), (0, -1)), ((0, 0), (0, 1), (0, 2)),
           ((2, 0), (1, 0), (0, 0)), ((0, -1), (0, 0), (0, 1)), ((0, 1), (0, 2), (0, 3))]
p = replay_grid(army_b, jumps_b, BIG)
print(f"  row 3 army (b) {sorted(army_b)}: 7 jumps end at {sorted(p)}")

# Row 4 with 20: the printed army and its 19 jumps.
army20 = [(-4, 0), (-3, 0), (-2, 0), (-1, 0), (0, 0), (1, 0), (2, 0), (3, 0), (4, 0),
          (-2, -1), (-1, -1), (0, -1), (1, -1),
          (-3, -2), (-2, -2), (-1, -2), (0, -2), (1, -2),
          (-1, -3), (0, -3)]
jumps20 = [((-2, -1), (-2, 0), (-2, 1)), ((-1, -1), (-1, 0), (-1, 1)), ((-1, -3), (-1, -2), (-1, -1)),
           ((-3, -2), (-2, -2), (-1, -2)), ((-1, -2), (-1, -1), (-1, 0)), ((0, -1), (0, 0), (0, 1)),
           ((0, -3), (0, -2), (0, -1)), ((-4, 0), (-3, 0), (-2, 0)), ((-2, 0), (-1, 0), (0, 0)),
           ((0, 0), (0, 1), (0, 2)), ((2, 0), (1, 0), (0, 0)), ((1, -2), (1, -1), (1, 0)),
           ((0, -1), (0, 0), (0, 1)), ((4, 0), (3, 0), (2, 0)), ((2, 0), (1, 0), (0, 0)),
           ((0, 1), (0, 2), (0, 3)), ((-2, 1), (-1, 1), (0, 1)), ((0, 0), (0, 1), (0, 2)),
           ((0, 2), (0, 3), (0, 4))]
assert len(army20) == 20 and len(set(army20)) == 20 and len(jumps20) == 19
board9x8 = {(x, y) for x in range(-4, 5) for y in range(-3, 5)}
p = replay_grid(army20, jumps20, board9x8)
print(f"  row 4 army of 20 (rows 0..-3, columns -4..4): 19 jumps on the 9x8 board end at {sorted(p)}")
print()

# ----------------------------------------------------------------------------
# 5. INTEGER PRICE MAPS ON THE GRID
# ----------------------------------------------------------------------------
print("=" * 78)
print("5. INTEGER PRICE MAPS ON THE GRID (price by distance from the star)")
print("=" * 78)
def price_map(star, K):
    # distance d -> F(K-d) for d <= K-2, else 1   (F: 1,1,2,3,5,8,13,21,34,55,89)
    def price(cell):
        d = abs(cell[0] - star[0]) + abs(cell[1] - star[1])
        return fib[K - 1 - d] if K - 1 - d >= 0 else 1
    return price

for (star, K, m) in (((0, 2), 6, 3), ((0, 3), 7, 7), ((0, 4), 9, 18), ((0, 5), 11, 36)):
    price = price_map(star, K)
    cells = {(x, y) for x in range(-14, 15) for y in range(-14, 8)}
    raises = 0; n = 0
    for (x, y) in cells:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            over = (x + dx, y + dy); to = (x + 2 * dx, y + 2 * dy)
            if over in cells and to in cells:
                n += 1
                if price(to) > price((x, y)) + price(over): raises += 1
    below = sorted((price(c) for c in cells if c[1] <= 0), reverse=True)
    ring = [price((star[0], star[1] - d)) for d in range(0, K + 1)]
    print(f"  star {star} (row {star[1]}): prices by distance {ring}...; {n} jumps checked, {raises} raise the total; "
          f"best {m} squares below the line total {sum(below[:m])}, best {m + 1} total {sum(below[:m + 1])}")
price3 = price_map((0, 3), 7)
print("  army (a) on the row-3 price board: squares and prices", [(c, price3(c)) for c in army_a], "total", sum(price3(c) for c in army_a))
pos = set(army_a); totals = [sum(price3(c) for c in pos)]
for (a, b, c) in jumps_a:
    pos -= {a, b}; pos.add(c); totals.append(sum(price3(x) for x in pos))
print("  totals before and after each of the 7 jumps:", totals)
for (a, b, c) in (((0, 0), (0, -1), (0, -2)), ((1, 0), (2, 0), (3, 0))):
    print(f"  a jump away from the star, {a} over {b} to {c}: removes {price3(a)}+{price3(b)}, adds {price3(c)}: change {price3(c) - price3(a) - price3(b)}")
price2 = price_map((0, 2), 6)
print("  the L on the row-2 price board:", [(c, price2(c)) for c in L], "total", sum(price2(c) for c in L), "; star costs", price2((0, 2)))
# Row 5 integer bound: squares needed to reach 89
price5 = price_map((0, 5), 11)
below5 = sorted((price5((x, y)) for x in range(-60, 61) for y in range(-60, 1)), reverse=True)
acc = 0
for i, v in enumerate(below5, 1):
    acc += v
    if acc >= 89:
        print(f"  row-5 board: the {i} most expensive squares below the line are the first to total >= 89 (total {acc});"
              f" so {i - 1} counters can never reach row 5 by the integer prices"); break
block = sum(price5((x, y)) for x in range(-4, 5) for y in range(-3, 1))
print(f"  the 9-wide, 4-deep block of 36 squares under the star is worth {block}")
print()

# ----------------------------------------------------------------------------
# 6. GOLDEN-RATIO WEIGHTS (exact arithmetic in Z[s], s^2 = 1 - s)
# ----------------------------------------------------------------------------
print("=" * 78)
print("6. GOLDEN-RATIO WEIGHTS: s = (sqrt5 - 1)/2, s^2 + s = 1")
print("=" * 78)
class Q5:  # a + b*s with s^2 = 1 - s
    def __init__(self, a, b=0): self.a, self.b = Fraction(a), Fraction(b)
    def __add__(self, o): return Q5(self.a + o.a, self.b + o.b)
    def __mul__(self, o): return Q5(self.a * o.a + self.b * o.b, self.a * o.b + self.b * o.a - self.b * o.b)
    def val(self): return float(self.a) + float(self.b) * (math.sqrt(5) - 1) / 2
    def __repr__(self): return f"{self.a} + {self.b}s = {self.val():.6f}"
s = Q5(0, 1)
pw = [Q5(1)]
for i in range(1, 80): pw.append(pw[-1] * s)
print(f"  s^2 + s = {pw[2] + pw[1]}")
# half-plane total for a target in row r: sum over rows y<=0 and all columns of s^(|x| + r - y)
def halfplane(r):
    # per row at vertical distance k: s^k + 2 s^(k+1)/(1-s) = s^k + 2 s^(k-1)  (since 1-s = s^2)
    # sum over k = r, r+1, ...: sum_k s^k = s^r/(1-s) = s^(r-2);  sum_k 2 s^(k-1) = 2 s^(r-3)
    return pw[r - 2] + Q5(2) * pw[r - 3]
print(f"  total weight of the whole half-plane below the line, target in row 5: {halfplane(5)}")
print(f"  total weight of the whole half-plane below the line, target in row 4: {halfplane(4)}")
def w(cell, star):
    return pw[abs(cell[0] - star[0]) + abs(cell[1] - star[1])]
def maxweight(m, star):
    cells = sorted(((x, y) for x in range(-30, 31) for y in range(-30, 1)), key=lambda c: -w(c, star).val())
    tot = Q5(0)
    for c in cells[:m]: tot = tot + w(c, star)
    return tot
for r, ms in ((2, (3, 4)), (3, (7, 8)), (4, (18, 19, 20))):
    for m in ms:
        print(f"  target row {r}: greatest possible weight of {m} counters = {maxweight(m, (0, r))}")
print(f"  weight of the printed 20-army for row 4: {sum((w(c, (0, 4)) for c in army20), Q5(0))}")
# a jump towards the star: s^(d+2) + s^(d+1) = s^d
print(f"  s^7 + s^6 = {pw[7] + pw[6]}  and  s^5 = {pw[5]}  (a jump straight towards the star keeps the weight)")

# ----------------------------------------------------------------------------
# 7. JUMP LISTS IN THE PRINTED BOARD COORDINATES (grades 4-5 boards L, M: 9 columns A-I = army
#    columns -4..4, 7 rows 1..7 = army rows -3..3; board Q: 9 columns, 8 rows 1..8 = army rows -3..4)
# ----------------------------------------------------------------------------
print()
print("=" * 78)
print("7. JUMP LISTS IN BOARD COORDINATES (column letter A-I, row number from the bottom)")
print("=" * 78)
def name(cell, rows_below=3):
    return f"{chr(ord('E') + cell[0])}{cell[1] + rows_below + 1}"
def show(label, army, jumps, rows_below=3):
    print(f"  {label}: army on", ", ".join(name(c, rows_below) for c in sorted(army, key=lambda c: (-c[1], c[0]))))
    for i, (a, b, c) in enumerate(jumps, 1):
        print(f"     {i:2d}. {name(a, rows_below)} over {name(b, rows_below)} to {name(c, rows_below)}")
show("board L, army (a), star E7", army_a, jumps_a)
show("board L, army (b), star E7", army_b, jumps_b)
show("board Q, army of 20, star E8", army20, jumps20)
print("  board M: a jump away from the star, E4 over E3 to E2: prices", price3((0, 0)), price3((0, -1)), price3((0, -2)))

# ----------------------------------------------------------------------------
# 8. THE OTHER THREE 20-ARMIES (from the bank's search), replayed on the 9x8 board
# ----------------------------------------------------------------------------
print()
print("=" * 78)
print("8. THE OTHER THREE 20-ARMIES FOR ROW 4, replayed")
print("=" * 78)
others = {
 "alt 1": ([(-4,0),(-3,-2),(-3,0),(-2,-2),(-2,-1),(-2,0),(-1,-3),(-1,-2),(-1,-1),(-1,0),(0,-3),(0,-2),(0,-1),(0,0),(1,-2),(1,-1),(1,0),(2,-2),(2,-1),(2,0)],
   [((-2,-1),(-2,0),(-2,1)),((-1,-1),(-1,0),(-1,1)),((-1,-3),(-1,-2),(-1,-1)),((-3,-2),(-2,-2),(-1,-2)),((-1,-2),(-1,-1),(-1,0)),
    ((0,-1),(0,0),(0,1)),((0,-3),(0,-2),(0,-1)),((2,-2),(1,-2),(0,-2)),((0,-2),(0,-1),(0,0)),((1,-1),(1,0),(1,1)),((2,-1),(2,0),(2,1)),
    ((-4,0),(-3,0),(-2,0)),((-2,0),(-2,1),(-2,2)),((-1,0),(-1,1),(-1,2)),((0,0),(0,1),(0,2)),((2,1),(1,1),(0,1)),((0,1),(0,2),(0,3)),
    ((-2,2),(-1,2),(0,2)),((0,2),(0,3),(0,4))]),
 "alt 2": ([(-4,0),(-3,-1),(-3,0),(-2,-3),(-2,-2),(-2,-1),(-2,0),(-1,-2),(-1,-1),(-1,0),(0,-3),(0,-2),(0,-1),(0,0),(1,-2),(1,-1),(1,0),(2,-2),(2,-1),(2,0)],
   [((-2,-1),(-2,0),(-2,1)),((-2,-3),(-2,-2),(-2,-1)),((-1,-1),(-1,0),(-1,1)),((-3,-1),(-2,-1),(-1,-1)),((-1,-2),(-1,-1),(-1,0)),
    ((0,-1),(0,0),(0,1)),((0,-3),(0,-2),(0,-1)),((2,-2),(1,-2),(0,-2)),((0,-2),(0,-1),(0,0)),((1,-1),(1,0),(1,1)),((2,-1),(2,0),(2,1)),
    ((-4,0),(-3,0),(-2,0)),((-2,0),(-2,1),(-2,2)),((-1,0),(-1,1),(-1,2)),((0,0),(0,1),(0,2)),((2,1),(1,1),(0,1)),((0,1),(0,2),(0,3)),
    ((-2,2),(-1,2),(0,2)),((0,2),(0,3),(0,4))]),
 "alt 3": ([(-4,0),(-3,-1),(-3,0),(-2,-3),(-2,-2),(-2,-1),(-2,0),(-1,-2),(-1,-1),(-1,0),(0,-3),(0,-2),(0,-1),(0,0),(1,-2),(1,-1),(1,0),(2,0),(3,0),(4,0)],
   [((-2,-1),(-2,0),(-2,1)),((-2,-3),(-2,-2),(-2,-1)),((-1,-1),(-1,0),(-1,1)),((-3,-1),(-2,-1),(-1,-1)),((-1,-2),(-1,-1),(-1,0)),
    ((0,-1),(0,0),(0,1)),((0,-3),(0,-2),(0,-1)),((-4,0),(-3,0),(-2,0)),((-2,0),(-1,0),(0,0)),((0,0),(0,1),(0,2)),((2,0),(1,0),(0,0)),
    ((1,-2),(1,-1),(1,0)),((0,-1),(0,0),(0,1)),((4,0),(3,0),(2,0)),((2,0),(1,0),(0,0)),((0,1),(0,2),(0,3)),((-2,1),(-1,1),(0,1)),
    ((0,0),(0,1),(0,2)),((0,2),(0,3),(0,4))]),
}
for label, (army, jumps) in others.items():
    assert len(army) == 20 and len(set(army)) == 20 and len(jumps) == 19
    p = replay_grid(army, jumps, board9x8)
    print(f"  {label}: 19 jumps end at {sorted(p)}; weight {sum((w(c, (0, 4)) for c in army), Q5(0))}")
    show(f"  {label} in board Q coordinates, star E8", army, jumps, rows_below=3)

# ----------------------------------------------------------------------------
# 9. TWO MORE REPLAYS USED IN THE GUIDE
# ----------------------------------------------------------------------------
print()
print("=" * 78)
print("9. TWO MORE REPLAYS")
print("=" * 78)
p = replay_grid(corner, [((1, 3), (1, 2), (1, 1)), ((3, 3), (2, 3), (1, 3)), ((3, 2), (2, 2), (1, 2))], cells33)
print(f"  3x3 corner board, 3-jump play to the L: ends with {len(p)} at {sorted(p)}, stuck={not grid_moves(p, cells33)}")
cells34 = {(x, y) for x in range(1, 4) for y in range(1, 5)}
start34 = cells34 - {(1, 1)}
sol34 = [((1, 3), (1, 2), (1, 1)), ((3, 2), (2, 2), (1, 2)), ((1, 1), (1, 2), (1, 3)), ((1, 4), (1, 3), (1, 2)), ((2, 4), (2, 3), (2, 2)),
         ((2, 1), (2, 2), (2, 3)), ((3, 4), (3, 3), (3, 2)), ((3, 1), (3, 2), (3, 3)), ((3, 3), (2, 3), (1, 3)), ((1, 3), (1, 2), (1, 1))]
p = replay_grid(start34, sol34, cells34)
print(f"  3x4 corner-hole board, 10 jumps: ends at {sorted(p)}")
p = replay_grid(start34, sol34[:-1] + [((1, 2), (1, 3), (1, 4))], cells34)
print(f"  3x4 corner-hole board, alternative last jump: ends at {sorted(p)}")
seen, stuck = grid_explore(start34, cells34)
print(f"  3x4 corner-hole board: positions={len(seen)}, lone survivors at {sorted(set(next(iter(q)) for q in stuck if len(q) == 1))}")
for hole, label in (((2, 1), "short-side middle"), ((1, 2), "long-side second square"), ((2, 2), "inside")):
    seen, stuck = grid_explore(cells34 - {hole}, cells34)
    print(f"  3x4 hole at {hole} ({label}): positions={len(seen)}, fewest={min(len(q) for q in stuck)}, "
          f"lone survivors at {sorted(set(next(iter(q)) for q in stuck if len(q) == 1))}")
