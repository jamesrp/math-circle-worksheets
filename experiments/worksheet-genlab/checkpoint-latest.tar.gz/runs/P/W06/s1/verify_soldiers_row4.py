#!/usr/bin/env python3
"""Conway's Soldiers, row 4: find a 20-peg army that reaches (0,4) and show that
no 19-peg army can.  Bitboard version of the search in verify_soldiers.py.

Weight bookkeeping (exact, in Z[s], s = (sqrt5-1)/2, s^2 + s = 1):
  * 20 pegs below the line have total weight at most 1 + s^8 (the 16 cells at
    taxicab distance <= 7 from (0,4) plus any 4 of the 9 cells at distance 8).
  * a position containing the target has weight >= 1, and jumps never raise the
    weight, so every position on a winning line has weight >= 1.
  * Hence a winning 20-peg army loses at most s^8 in total.  Every jump that is
    not straight towards the target loses at least s^8 (a jump across the
    central column at distance 8) or 2 s^9 > s^8 (any jump away from the
    target from distance <= 8).  So pegs stay inside |x| <= 4, -4 <= y <= 4
    for the "top-20" armies, and the board below can be kept small.
  * 19 pegs have weight at most exactly 1: the 16 cells at distance <= 7 plus
    3 of the 9 cells at distance 8 (84 armies).  Those may use only
    weight-preserving jumps and must finish with the single target peg.
Run:  python3 verify_soldiers_row4.py > verify_soldiers_row4.out
"""
import itertools
import sys
import time

S = (5 ** 0.5 - 1) / 2
F = {-1: 1, 0: 0}
for n in range(1, 60):
    F[n] = F[n - 1] + F[n - 2]


def spow(n):
    sign = 1 if n % 2 == 0 else -1
    return (sign * F[n - 1], -sign * F[n])


def add(p, q):
    return (p[0] + q[0], p[1] + q[1])


def sub(p, q):
    return (p[0] - q[0], p[1] - q[1])


def val(p):
    return p[0] + p[1] * S


def ge_one(p):
    return p == (1, 0) or val(p) > 1.0


R = 4
XMAX, YMIN = 6, -6
CELLS = [(x, y) for y in range(YMIN, R + 1) for x in range(-XMAX, XMAX + 1)]
IDX = {c: i for i, c in enumerate(CELLS)}
BIT = {c: 1 << i for i, c in enumerate(CELLS)}
W = {c: spow(abs(c[0]) + abs(R - c[1])) for c in CELLS}
TARGET_BIT = BIT[(0, R)]

# jump triples as bit masks: (a|b, c, a, b, c, delta weight)
JUMPS = []
for (x, y) in CELLS:
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        b = (x + dx, y + dy)
        c = (x + 2 * dx, y + 2 * dy)
        if b in IDX and c in IDX:
            dw = sub(W[c], add(W[(x, y)], W[b]))
            gain = (abs(x) + abs(R - y)) - (abs(c[0]) + abs(R - c[1]))
            JUMPS.append((BIT[(x, y)] | BIT[b], BIT[c], (x, y), b, c, dw, gain))
JUMPS.sort(key=lambda t: -t[6])   # towards-target jumps first


def weight_of(mask):
    w = (0, 0)
    for c in CELLS:
        if mask & BIT[c]:
            w = add(w, W[c])
    return w


def search(army, node_limit):
    start = 0
    for c in army:
        start |= BIT[c]
    w0 = weight_of(start)
    if not ge_one(w0):
        return None, 0
    seen = set()
    path = []
    nodes = 0

    stack = [(start, w0, iter(JUMPS))]
    seen.add(start)
    while stack:
        pos, w, it = stack[-1]
        if pos & TARGET_BIT:
            return list(path), nodes
        advanced = False
        for ab, cbit, a, b, c, dw, gain in it:
            if (pos & ab) == ab and not (pos & cbit):
                nw = add(w, dw)
                if ge_one(nw):
                    npos = (pos & ~ab) | cbit
                    if npos in seen:
                        continue
                    seen.add(npos)
                    nodes += 1
                    if nodes > node_limit:
                        return "limit", nodes
                    path.append((a, b, c))
                    stack.append((npos, nw, iter(JUMPS)))
                    advanced = True
                    break
        if not advanced:
            stack.pop()
            if path:
                path.pop()
    return None, nodes


def show(army, xr=(-5, 5), ymin=-4):
    lines = []
    for y in range(R, ymin - 1, -1):
        row = ""
        for x in range(xr[0], xr[1] + 1):
            if (x, y) == (0, R):
                row += "T"
            elif (x, y) in army:
                row += "X"
            else:
                row += "."
        lines.append(f"y={y:3d}  {row}")
        if y == 1:
            lines.append("       " + "-" * (xr[1] - xr[0] + 1) + "  (line)")
    return "\n".join(lines)


def replay(army, moves):
    pos = set(army)
    for a, b, c in moves:
        assert a in pos and b in pos and c not in pos, (a, b, c, sorted(pos))
        pos -= {a, b}
        pos.add(c)
    assert (0, R) in pos
    return pos


def main():
    below = [c for c in CELLS if c[1] <= 0]
    d7 = [c for c in below if abs(c[0]) + abs(R - c[1]) <= 7]
    d8 = [c for c in below if abs(c[0]) + abs(R - c[1]) == 8]
    assert len(d7) == 16 and len(d8) == 9
    print("cells at distance <= 7 from (0,4):", sorted(d7))
    print("cells at distance 8:", sorted(d8))
    print("weight of the 16 cells:", weight_of(sum(BIT[c] for c in d7)), "=", val(weight_of(sum(BIT[c] for c in d7))))
    print()

    # ---- 20 pegs: try the 126 top-weight armies ---------------------------------
    print("=" * 72)
    print("20 PEGS: top-weight armies (16 cells at distance <= 7 plus 4 of the 9 at distance 8)")
    print("=" * 72)
    t0 = time.time()
    found = None
    for extra in itertools.combinations(sorted(d8), 4):
        army = d7 + list(extra)
        mv, nodes = search(army, node_limit=4_000_000)
        if mv == "limit":
            print("node limit for extra", extra)
            continue
        if mv is not None:
            found = (army, mv)
            print(f"SOLUTION with extra cells {extra}  ({nodes} positions searched, {time.time()-t0:.0f}s)")
            break
        print(f"no solution with extra cells {extra} ({nodes} positions)")
    if found:
        army, mv = found
        print(show(army))
        print("moves (from, over, to):")
        for i, m in enumerate(mv, 1):
            print(f"  {i:2d}. {m[0]} over {m[1]} to {m[2]}")
        fin = replay(army, mv)
        print("final position:", sorted(fin))
        print("weight of final position:", weight_of(sum(BIT[c] for c in fin)))
    print()

    # ---- 19 pegs: the 84 armies of weight exactly 1 -------------------------
    print("=" * 72)
    print("19 PEGS: the 84 armies of weight exactly 1")
    print("=" * 72)
    t0 = time.time()
    fails = 0
    for extra in itertools.combinations(sorted(d8), 3):
        army = d7 + list(extra)
        assert weight_of(sum(BIT[c] for c in army)) == (1, 0)
        mv, nodes = search(army, node_limit=20_000_000)
        if mv == "limit":
            print("NODE LIMIT (inconclusive) for extra", extra)
        elif mv is None:
            fails += 1
        else:
            print("UNEXPECTED 19-peg solution:", extra, mv)
    print(f"{fails} of 84 nineteen-peg armies cannot reach row 4  ({time.time()-t0:.0f}s)")
    print("Any other 19-peg army has weight < 1.  Therefore the minimum army for row 4 is 20.")


if __name__ == "__main__":
    main()
