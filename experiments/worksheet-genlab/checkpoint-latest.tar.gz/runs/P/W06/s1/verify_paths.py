#!/usr/bin/env python3
"""Concrete move sequences for the boards used in the bank, plus which starting
counter can be the lone survivor (counters are tracked by identity).
Run:  python3 verify_paths.py > verify_paths.out
"""
from collections import deque
import sys

sys.path.insert(0, ".")
from verify_boards import lines_of, moves, analyse, show_strip, show_grid, grid_cells


def best_path(cells, start, goal=None):
    """BFS to a stuck position with the fewest pegs (or to a position satisfying goal)."""
    lines = lines_of(cells)
    start = frozenset(start)
    prev = {start: None}
    q = deque([start])
    best = None
    while q:
        p = q.popleft()
        nxt = list(moves(p, lines))
        if goal is not None:
            if goal(p):
                best = p
                break
        elif not nxt:
            if best is None or len(p) < len(best):
                best = p
        for mv, r in nxt:
            if r not in prev:
                prev[r] = (p, mv)
                q.append(r)
    path = []
    p = best
    while prev[p] is not None:
        p, mv = prev[p]
        path.append(mv)
    return best, path[::-1]


def fmt_strip_moves(path):
    return [f"{a[0]} over {b[0]} to {c[0]}" for a, b, c in path]


def fmt_grid_moves(path):
    return [f"{a} over {b} to {c}" for a, b, c in path]


print("=" * 72)
print("STRIP SOLUTIONS (cells numbered 1..n from the left)")
print("=" * 72)
for n, hole in ((4, 2), (6, 2), (6, 5), (8, 2), (8, 4), (10, 2), (10, 5)):
    cells = [(i, 0) for i in range(1, n + 1)]
    start = [(i, 0) for i in range(1, n + 1) if i != hole]
    fin, path = best_path(cells, start)
    print(f"n={n} hole={hole} {show_strip(n, set(start))}: ends {show_strip(n, fin)} ({len(fin)} left) via {fmt_strip_moves(path)}")
    # every lone-survivor ending
    r = analyse(cells, start)
    for s in r["singles"]:
        fin2, path2 = best_path(cells, start, goal=lambda p, s=s: p == frozenset([s]))
        print(f"      survivor at cell {s[0]}: {fmt_strip_moves(path2)}")
print()

print("=" * 72)
print("WHICH STARTING COUNTER SURVIVES (identity tracking)")
print("=" * 72)


def survivors_by_identity(n, pegs):
    cells = [(i, 0) for i in range(1, n + 1)]
    lines = lines_of(cells)
    # state: tuple of (cell, id) pairs
    start = frozenset((i, i) for i in pegs)   # (cell, identity=start cell)
    seen = {start}
    q = deque([start])
    result = set()
    while q:
        p = q.popleft()
        cellmap = {c: i for c, i in p}
        pos = frozenset((c, 0) for c in cellmap)
        nxt = list(moves(pos, lines))
        if not nxt and len(p) == 1:
            (c, i), = p
            result.add((i, c))
        for (a, b, c), _ in nxt:
            ida = cellmap[a[0]]
            np_ = (p - {(a[0], ida), (b[0], cellmap[b[0]])}) | {(c[0], ida)}
            if np_ not in seen:
                seen.add(np_)
                q.append(np_)
    return sorted(result)


for n, hole in ((4, 2), (6, 2), (8, 2), (8, 4)):
    pegs = [i for i in range(1, n + 1) if i != hole]
    res = survivors_by_identity(n, pegs)
    print(f"n={n} hole={hole}: (starting cell of survivor, final cell) = {res}")
print()

print("=" * 72)
print("SMALL BOARD SOLUTIONS")
print("=" * 72)
boards = [
    ("3x3 corner hole -> 4 left", 3, 3, [(0, 0)], None),
    ("3x4 corner hole (0,0) -> 1 left", 3, 4, [(0, 0)], None),
    ("3x4 hole (0,1) long-side middle -> 1 left", 3, 4, [(0, 1)], None),
    ("3x4 hole (1,0) short-side middle", 3, 4, [(1, 0)], None),
    ("3x4 hole (1,1) inside", 3, 4, [(1, 1)], None),
    ("4x4 hole (1,0) -> 1 left", 4, 4, [(1, 0)], None),
    ("4x4 corner hole -> 2 left", 4, 4, [(0, 0)], None),
    ("3x5 hole (0,2) -> 1 left", 3, 5, [(0, 2)], None),
]
for label, w, h, holes, goal in boards:
    cells = grid_cells(w, h)
    start = [c for c in cells if c not in holes]
    fin, path = best_path(cells, start)
    print(f"{label}: {len(path)} jumps, {len(fin)} left")
    print(show_grid(cells, set(start), w, h))
    print("  ->")
    print(show_grid(cells, fin, w, h))
    print("  moves:", fmt_grid_moves(path))
    print()

# 3x4 corner: every ending with 1 peg
cells = grid_cells(3, 4)
start = [c for c in cells if c != (0, 0)]
r = analyse(cells, start)
for s in r["singles"]:
    fin, path = best_path(cells, start, goal=lambda p, s=s: p == frozenset([s]))
    print(f"3x4 corner hole, survivor at {s}: {fmt_grid_moves(path)}")
print()

print("=" * 72)
print("K-1 ROW-1 COUNTING: fewest counters to get k counters above the line in row 1")
print("=" * 72)
print("Each counter above the line arrived by a jump, each jump removes one counter, so n >= 2k; two stacked")
print("counters per column achieve it: k=1:2, k=2:4, k=3:6.")
