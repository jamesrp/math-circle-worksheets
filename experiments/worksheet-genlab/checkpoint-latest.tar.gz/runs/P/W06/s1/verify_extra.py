#!/usr/bin/env python3
"""Extra checks for the problem bank:
  A. distribution of stuck positions (how many pegs left, and which cells) for
     the boards used at the tables;
  B. what ONE diagonal colouring (x+y mod 3) predicts for the lone survivor,
     against the exact answer;
  C. the complete map of positions for small strips (for "draw the map" tasks);
  D. the Fibonacci price list on a strip is a monovariant: no jump raises the
     total price, and a block army is worth exactly one less than the target;
  E. two-player variant (players alternate jumps, last jump wins): who wins
     from small strip starts, for fast-finisher reserves;
  F. first-move counts and forced-play checks for the K-1 strips;
  G. 3x3 corner-hole board: all stuck positions.
Run:  python3 verify_extra.py > verify_extra.out
"""
from collections import Counter, deque
from functools import lru_cache
import sys

sys.path.insert(0, ".")
from verify_boards import lines_of, moves, analyse, colour_prediction, show_strip, show_grid, grid_cells


def strip(n):
    return [(i, 0) for i in range(1, n + 1)]


def pegs(cells_idx):
    return [(i, 0) for i in cells_idx]


def stuck_distribution(cells, start, w=None, h=None, label=""):
    r = analyse(cells, start)
    dist = Counter(len(t) for t in r["terminals"])
    print(f"{label}: start {len(start)} pegs; reachable positions {r['states']}; "
          f"stuck positions by pegs left: {dict(sorted(dist.items()))}; min left {r['minleft']}")
    return r


print("=" * 72)
print("A. STUCK-POSITION DISTRIBUTIONS")
print("=" * 72)
for n, hole in ((4, 1), (4, 2), (5, 1), (5, 3), (6, 1), (6, 2), (6, 3), (7, 4), (8, 2), (8, 4), (8, 3), (8, 1)):
    start = [(i, 0) for i in range(1, n + 1) if i != hole]
    r = stuck_distribution(strip(n), start, label=f"strip n={n} hole={hole} {show_strip(n, set(start))}")
    print("    stuck:", sorted(show_strip(n, t) for t in r["terminals"]))
print()
g33 = grid_cells(3, 3)
r = stuck_distribution(g33, [c for c in g33 if c != (0, 0)], label="3x3 corner hole")
for t in sorted(r["terminals"], key=len):
    print(show_grid(g33, t, 3, 3))
    print()
g34 = grid_cells(3, 4)
for hole in ((0, 0), (1, 0), (0, 1), (1, 1)):
    r = stuck_distribution(g34, [c for c in g34 if c != hole], label=f"3x4 hole {hole}")
g44 = grid_cells(4, 4)
for hole in ((0, 0), (1, 0), (1, 1)):
    r = stuck_distribution(g44, [c for c in g44 if c != hole], label=f"4x4 hole {hole}")
g35 = grid_cells(3, 5)
for hole in ((0, 0), (0, 2), (1, 2)):
    r = stuck_distribution(g35, [c for c in g35 if c != hole], label=f"3x5 hole {hole}")
print()

print("=" * 72)
print("B. ONE DIAGONAL COLOURING (x+y mod 3) VERSUS THE TRUTH")
print("=" * 72)
for (w, h, hole) in ((3, 4, (0, 0)), (3, 4, (0, 1)), (4, 4, (1, 0)), (4, 4, (0, 0)), (4, 4, (1, 1)), (3, 5, (0, 2)), (3, 5, (0, 0)), (5, 5, (2, 2))):
    cells = grid_cells(w, h)
    start = [c for c in cells if c != hole]
    if w * h <= 16 or (w, h) == (3, 5):
        r = analyse(cells, start)
        truth = r["singles"]
    else:
        truth = "not recomputed here (see verify_boards.out: none)"
    one = sorted(colour_prediction(cells, start, key=lambda c: c[0] + c[1]))
    two = sorted(colour_prediction(cells, start, key=lambda c: c[0] - c[1]))
    print(f"{w}x{h} hole {hole}: one colouring allows {one}; other diagonal allows {two}; both: {sorted(set(one) & set(two))}; truth: {truth}")
print()

print("=" * 72)
print("C. COMPLETE MAPS OF POSITIONS FOR SMALL STRIPS")
print("=" * 72)
for n, hole in ((5, 3), (6, 2), (6, 3), (7, 4)):
    cells = strip(n)
    lines = lines_of(cells)
    start = frozenset((i, 0) for i in range(1, n + 1) if i != hole)
    seen = {start: 0}
    order = [start]
    q = deque([start])
    edges = []
    while q:
        p = q.popleft()
        for mv, r_ in moves(p, lines):
            if r_ not in seen:
                seen[r_] = len(order)
                order.append(r_)
                q.append(r_)
            edges.append((show_strip(n, p), show_strip(n, r_)))
    print(f"strip n={n} hole={hole}: {len(order)} positions, {len(edges)} arrows")
    for p in order:
        outs = sorted(set(b for a, b in edges if a == show_strip(n, p)))
        print(f"   {show_strip(n, p)} -> {outs if outs else 'STUCK'}")
    print()

print("=" * 72)
print("D. FIBONACCI PRICE LIST ON A STRIP (monovariant)")
print("=" * 72)
# cells 1..N on a strip; the army is a block on cells 1..m; the line is after cell m;
# target = cell m+2.  Price of cell m+2 = F(m+2), cell m+1 = F(m+1), cell m = F(m), ..., cell 1 = F(1);
# cells beyond the target are never reached before the target is; there are none to the left of cell 1.
F = [0, 1]
for _ in range(30):
    F.append(F[-1] + F[-2])
for m in (3, 4, 5, 6, 7):
    N = m + 2
    price = {i: F[i] for i in range(1, N + 1)}
    cells = strip(N)
    lines = lines_of(cells)
    start = frozenset((i, 0) for i in range(1, m + 1))
    # check local property on every triple
    bad = []
    for a, b, c in lines:
        if price[c[0]] > price[a[0]] + price[b[0]]:
            bad.append((a, b, c))
    tot = lambda p: sum(price[c[0]] for c in p)
    seen = {start}
    q = deque([start])
    increases = 0
    maxtot = tot(start)
    while q:
        p = q.popleft()
        for mv, r_ in moves(p, lines):
            if tot(r_) > tot(p):
                increases += 1
            if r_ not in seen:
                seen.add(r_)
                q.append(r_)
                maxtot = max(maxtot, tot(r_))
    print(f"army of {m} in a block, prices cells 1..{N}: {[price[i] for i in range(1, N+1)]}; army total {tot(start)}; "
          f"target (cell {N}) price {price[N]}; jumps that raise the total: {increases}; violations of local rule: {len(bad)}; "
          f"max total ever: {maxtot}; positions: {len(seen)}")
print("(With a longer strip the cells past the target would need prices too; the argument is only about reaching the target,")
print(" and cells past the target cannot be occupied before the target is.  To the left of the army there are no cells here;")
print(" if there were, give them price 1 each: a block army of m pegs is then worth F(m+2)-1 plus 1 per extra cell it does")
print(" not occupy, so choose the strip so that the army fills every cell to the left of the line.)")
print()

print("=" * 72)
print("E. TWO-PLAYER VARIANT: players alternate jumps, the player who makes the last jump wins")
print("=" * 72)


def game_value(n, start):
    cells = strip(n)
    lines = lines_of(cells)

    @lru_cache(maxsize=None)
    def win(p):
        # True if the player to move wins
        for mv, r_ in moves(p, lines):
            if not win(r_):
                return True
        return False

    def winning_moves(p):
        return [mv for mv, r_ in moves(p, lines) if not win(r_)]

    s = frozenset(start)
    return win(s), winning_moves(s)


for n, hole in ((5, 3), (6, 2), (6, 3), (7, 3), (7, 4), (8, 2), (8, 4), (8, 5), (9, 5)):
    start = [(i, 0) for i in range(1, n + 1) if i != hole]
    w, wm = game_value(n, start)
    print(f"strip n={n} hole={hole} {show_strip(n, set(start))}: first player {'WINS' if w else 'LOSES'}; "
          f"winning first moves: {[(a[0], b[0], c[0]) for a, b, c in wm]}")
for w_, h_, hole in ((3, 3, (0, 0)), (3, 4, (0, 0)), (3, 4, (0, 1))):
    cells = grid_cells(w_, h_)
    lines = lines_of(cells)
    start = frozenset(c for c in cells if c != hole)

    @lru_cache(maxsize=None)
    def win2(p):
        for mv, r_ in moves(p, lines):
            if not win2(r_):
                return True
        return False
    wm = [mv for mv, r_ in moves(start, lines) if not win2(r_)]
    print(f"{w_}x{h_} hole {hole}: first player {'WINS' if win2(start) else 'LOSES'}; winning first moves: {wm}")
print()

print("=" * 72)
print("F. FIRST-MOVE COUNTS AND FORCED PLAY (K-1 strips)")
print("=" * 72)
for n, pegs_ in ((3, [1, 2]), (4, [1, 2, 3]), (4, [1, 3, 4]), (5, [1, 2, 3, 4]), (5, [1, 2, 4, 5]), (6, [1, 2, 3, 4, 5]), (6, [1, 3, 4, 5, 6]), (7, [1, 2, 3, 4, 5, 6]), (6, [1, 2, 3]), (6, [1, 2, 3, 4]), (7, [1, 2, 3, 4, 5]), (8, [1, 2, 3, 4, 5, 6])):
    cells = strip(n)
    lines = lines_of(cells)
    start = frozenset((i, 0) for i in pegs_)
    first = [(a[0], b[0], c[0]) for (a, b, c), _ in moves(start, lines)]
    r = analyse(cells, [(i, 0) for i in pegs_])
    far = max(max(c[0] for c in t) for t in r["terminals"])
    print(f"n={n} {show_strip(n, start)}: first moves {first}; forced={r['forced']}; positions={r['states']}; "
          f"min left={r['minleft']}; farthest cell any peg ever reaches={max(max(c[0] for c in p) for p in [start] + list(r['terminals']))}")
