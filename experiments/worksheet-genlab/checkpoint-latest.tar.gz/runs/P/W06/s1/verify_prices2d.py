#!/usr/bin/env python3
"""Integer 'price list' version of the weight argument, for use at the tables.

Price of a cell at taxicab distance d from the target: F(K-d) for d <= K-1
(so the target costs F(K), the next ring F(K-1), ...) and 1 for every farther
cell.  Claim: no jump ever raises the total price of the counters on the board.
A jump from a over b to c changes the total by p(c) - p(a) - p(b).
We check every jump triple on a large grid, then compute the best total that
m counters below the line can have, for the rows the tables use.
Run:  python3 verify_prices2d.py > verify_prices2d.out
"""
F = [0, 1]
for _ in range(40):
    F.append(F[-1] + F[-2])


def price(d, K):
    return F[K - d] if d <= K - 1 else 1


def check(K, r, half=12):
    target = (0, r)
    cells = [(x, y) for x in range(-half, half + 1) for y in range(-half, half + 1)]
    S = set(cells)
    dist = lambda c: abs(c[0] - target[0]) + abs(c[1] - target[1])
    p = {c: price(dist(c), K) for c in cells}
    worst = -10 ** 9
    bad = 0
    for (x, y) in cells:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            b = (x + dx, y + dy)
            c = (x + 2 * dx, y + 2 * dy)
            if b in S and c in S:
                delta = p[c] - p[(x, y)] - p[b]
                worst = max(worst, delta)
                if delta > 0:
                    bad += 1
    below = sorted((p[c] for c in cells if c[1] <= 0), reverse=True)
    return worst, bad, below, p


for K, r, ms in ((6, 2, (3, 4)), (7, 3, (7, 8)), (8, 3, (7, 8)), (9, 4, (18, 19, 20)), (10, 4, (18, 19, 20)), (11, 5, (36,))):
    worst, bad, below, p = check(K, r)
    line = ", ".join(f"best {m} counters below the line total {sum(below[:m])}" for m in ms)
    print(f"target row {r}, K={K}: target price F({K})={F[K]}; ring prices {[price(d, K) for d in range(0, K + 2)]};")
    print(f"   largest price change of any jump = {worst} (jumps that raise the total: {bad}); {line}")
# the 9-wide, 4-deep block for row 5
K, r = 11, 5
worst, bad, below, p = check(K, r)
block = [(x, y) for x in range(-4, 5) for y in range(-3, 1)]
print(f"row 5, K=11: a 9-wide 4-deep block of 36 counters just below the line is worth {sum(p[c] for c in block)} < {F[K]} = target price")
print()
print("1-D strip check: army on cells 1..m of a strip, target two cells past the army:")
for m in (3, 4, 5, 6, 7, 9):
    prices = [F[i] for i in range(1, m + 3)]
    print(f"   m={m}: prices {prices}; army total {sum(prices[:m])}; target {prices[-1]}")
