# Week 1 (Jumping pegs) — editor's list of edits

Every answer, jump sequence and count in the guide was rechecked by exhaustive search (1-D strips of 4–7 home squares over every subset; all 455 three-peg and 1365 four-peg placements on the row-2 board; all 125 970 eight-peg sets on the row-3 board, and all 75 sets of value ≥ 55 on a seven-wide version; the 19-jump solution on board T; the 84 nineteen-peg sets of weight 377 on the infinite board; rectangular blocks 2×1 … 5×5 on an unbounded board). Everything printed was found correct except the items below. Edits 5–8 fix the one genuinely wrong argument (the two-wide column), edit 3 a wrong statement that a child will run into, edits 9–10 a precision error about board T, and edit 1 an over-broad headline fact. The rest are guidance points on the student pages and a missing hint block.

---

**1. week-facilitator.tex — section 1, headline facts**

Original:
```
The headline facts: on a strip, an army of any size sends a peg exactly one square past the line, never two; on a grid,
```
Replacement:
```
The headline facts: on a strip, two pegs next to the line already send a peg one square past it, and no army, however large, ever sends one two squares past; on a grid,
```
Reason: mathematical precision — "an army of any size sends a peg one square past" is false for one peg or for pegs not touching the line (strip O lets children choose such placements).

**2. week-facilitator.tex — section 5, Problem 10**

Original:
```
Complete reason, which a first grader can follow with the pieces: to land on the star you need, at one moment, a piece in row 1 under the star and a piece on the home square directly below it.
```
Replacement:
```
Complete reason, which a first grader can follow with the pieces: to land on the star you need, at one moment, a piece in row 1 under the star and a piece on the home square directly below it (the only other way onto the star, a sideways jump along row 2, would need two pieces already in row 2, so it needs even more).
```
Reason: facilitator guide must give complete arguments — the argument omitted the sideways-in-row-2 case.

**3. week-facilitator.tex — section 5, Problem 11**

Original:
```
Every other four-piece shape stops in row 1 or lower.
```
Replacement:
```
Every other placement stops in row 1 or lower, with one exception to expect: the L moved sideways to another column (four such placements) reaches row 2 in that column, but not the star.
```
Reason: mathematical error — search shows six of the 1365 placements reach row 2 across; the four shifted L's reach row 2 away from the star, and a child who tries one will record row 2 correctly.

**4. week-facilitator.tex — section 5, Problem 12**

INSERT AFTER:
```
If the children reach only row 2, that is a real result; show the last three jumps and let them redo the whole thing.
```
Inserted text:
```
\Hints{``Which square must be full just under the star before the last jump, and which one under that?'' ``Get one piece across first, as on board R, then fill the empty river square from one end of the row and jump up again into row 2.'' ``The other end of the row fills the middle river square a second time, and the column of three below it sends a piece up twice: into row 1, then onto the star.''}
```
Reason: guide must give hints in the order to give them; the hardest K–1 problem had none.

**5. week-facilitator.tex — section 5, "If the table finishes early" (b)**

Original:
```
(b) A tall column two squares wide: no matter how deep, no piece ever gets past row 1, because with only two columns no sideways jump is possible, so each column is a strip on its own. Let them try a 2-by-4 column.
```
Replacement:
```
(b) A tall column two squares wide: no matter how deep, no piece ever gets past row 1, even though pieces can jump sideways out of the two columns (the proof is a values argument, section 9; on a board that is itself only two squares wide it is simpler: each column is a strip on its own). Let them try a 2-by-4 column.
```
Reason: mathematical error — on an ordinary board a piece can jump sideways out of the two columns (search shows pegs do reach the neighbouring columns), so the stated reason was wrong; the fact is true (proof added in edit 8).

**6. week-facilitator.tex — section 6, "If the table finishes early" (c)**

Original:
```
(c) Blocks: a two-wide column of any depth never passes row 1 (each column is a strip; no sideways jump exists); a three-by-three block
```
Replacement:
```
(c) Blocks: a two-wide column of any depth never passes row 1, even though pegs can jump sideways out of it (proof in section 9); a three-by-three block
```
Reason: same error as edit 5.

**7. week-facilitator.tex — section 7, "If the table finishes early" (b)**

Original:
```
(b) Narrow armies: a two-wide column of any depth never passes row 1 (no sideways jump is possible, so each column is a strip); a three-wide army
```
Replacement:
```
(b) Narrow armies: a two-wide column of any depth never passes row 1, even though pegs can leave the two columns sideways (the values proof is in section 9: weight the columns $1, 0, 1, \sigma, \sigma^2, \dots$ outward from the target's column); a three-wide army
```
Reason: same error as edit 5.

**8. week-facilitator.tex — section 9, "Facts checked by computer"**

Original:
```
two wide (any depth tried, and provably any depth) row 1;
```
Replacement:
```
two wide (depths up to six searched, and provably any depth, see the next paragraph) row 1;
```
and INSERT AFTER:
```
and above any other column less still.
```
Inserted text (new paragraph):
```

\textbf{The two-wide column.} It needs a different pagoda function, because the Manhattan weights make its two columns worth $1+\sigma > 1$ for a target in row 2 above one of them. Put the target at $(0,2)$ and the army in columns $0$ and $1$, rows $y\le0$, and take $w(x,y) = u(x)\,\sigma^{|y-2|}$ with column weights $u(0)=1$, $u(1)=0$, $u(x)=\sigma^{|x|}$ for $x\le-1$ and $u(x)=\sigma^{x-2}$ for $x\ge2$. A product of two nonnegative one-dimensional pagoda functions is a pagoda function on the plane (a jump changes only one factor), and $u$ satisfies $u(a)+u(b)\ge u(c)$ for every three consecutive columns in both directions: away from column 1 the weights are geometric with ratio $\sigma$, and the three triples containing column 1 are $(\sigma,1,0)$, $(1,0,1)$ and $(0,1,\sigma)$. Column 1 is worth nothing and column 0 is worth $\sum_{y\le0}\sigma^{2-y} = 1$, so the infinite two-wide column is worth exactly the target square and any finite one strictly less: no two-wide column of any depth reaches row 2 above column 0, nor, by symmetry, above column 1, however far its pegs spread sideways. For a target in row 2 above any other column the Manhattan weights already give the infinite column at most $\sigma+\sigma^2 = 1$. (The inequality was also checked numerically on a large window.)
```
Reason: the claimed "provably any depth" had no valid proof (the proof offered in sections 5–7 was wrong); this is the proof.

**9. week-facilitator.tex — section 7, Problem 13**

Original:
```
Nineteen pegs can be worth 377 too (the sixteen squares within seven steps of the star plus three of the nine squares at eight steps), but none of those 84 sets works, by exhaustive computer search;
```
Replacement:
```
Nineteen pegs can be worth 377 too on a wider board (the sixteen squares within seven steps of the star plus three of the nine squares at eight steps; board T itself, seven columns wide, holds only fifteen of the sixteen, so on it no nineteen squares reach 377), but none of those 84 sets works, by exhaustive computer search;
```
Reason: mathematical precision — board T has only 15 squares within seven steps of E8; the heaviest 19 squares on it are worth 372.

**10. week-facilitator.tex — section 9, "Two dimensions on the pages"**

Original:
```
are worth exactly 1, i.e.\ 377 on board T.
```
Replacement:
```
are worth exactly 1, i.e.\ 377 in the units of board T (board T itself is one column too narrow to hold all sixteen).
```
Reason: same as edit 9.

**11. week-grades-2-3.tex — Problem 1**

Original:
```
\Problem{1}{Put a penny on each gray square of strip A. A jump: a peg hops over a peg right next to it,
```
Replacement:
```
\Problem{1}{Put a penny on each gray square of strip A. The pennies are the pegs. A jump: a peg hops over a peg right next to it,
```
Reason: guidance "plain sentences with concrete nouns" — the page switched from "penny" to "peg" without saying they are the same thing.

**12. week-grades-4-5.tex — Problem 1**

Original:
```
\Problem{1}{Put a penny on each gray square of strip A. The thick line is the river. A jump: a peg hops
```
Replacement:
```
\Problem{1}{Put a penny on each gray square of strip A. The pennies are the pegs. The thick line is the river. A jump: a peg hops
```
Reason: same as edit 11.

**13. week-grades-2-3.tex — Problem 14**

Original:
```
Tell the adult at your table what these totals say about Problem 11, and what shape 1 shows.}
```
Replacement:
```
Tell the adult at your table what these totals say about Problem 11, and what shape 1 shows about whether a total of 21 is enough.}
```
Reason: guidance "a child should never have to guess the task" — "what shape 1 shows" named no question.

**14. week-grades-4-5.tex — Problem 9**

Original:
```
Tell the adult at your table what these totals show about Problem 6, and what shape I shows about totals.}
```
Replacement:
```
Tell the adult at your table what these totals show about Problem 6, and what shape I shows about whether a total of 21 is enough.}
```
Reason: same as edit 13.
