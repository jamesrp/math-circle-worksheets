# Review of the Week 1 "Jumping pegs" packet

Scope: all four sources plus `week-boards.tex`, every rendered page (9 + 9 + 9 + 11), and an independent exhaustive check of the guide's answers (strip outcomes, the ten five-peg patterns, river strips, all 1365 four-peg placements on the 5x5 board, all 125970 eight-peg sets on the 5x7 board, every printed jump sequence, the 20-peg army and its value 377, and the block-reach table). Everything mathematical that the student pages rely on is correct; the files compile cleanly (no errors, no overfull boxes); diagrams are well drawn and cells are the right size for checkers and pennies. The problems below are about quantity, pacing, differentiation, collaboration, and a few guide statements, in that order of importance.

## 1. Each table has roughly twice as much as fits in forty minutes, and the guide's timings hide it

This is the one thing that will go wrong on the day.

- K-1 (`week-k-1.tex`): twelve problems on nine pages for two kindergartners and a first grader, everything read aloud. The guide (`week-facilitator.tex` line 80) gives Problems 10-12 eight minutes: three recorded three-checker trials, three recorded four-checker shapes, and the T of eight, which needs seven planned jumps that a kindergartner cannot plan. Problem 3 alone (six strips, count and write) will take ten minutes at this age.
- Grades 2-3 (`week-grades-2-3.tex`): sixteen problems; the guide (line 141) expects fourteen by 0:50. Problems 7-9 get eight minutes: a five-row table with ten sums, two "tell the adult why" questions, seven values to fill in and two more sums. Third graders need fifteen minutes for that block alone. Problems 10-12 get ten minutes: four recorded placements and six shapes with jump lists.
- Grades 4-5 (`week-grades-4-5.tex`): thirteen problems, twelve by 0:50; Problems 3-4 (twelve sums, two explanations) get nine minutes.

What to change:

- K-1: cut to seven core problems. Keep 1, 2, 3 (with strips F, H, K only; move strip J, "no jump possible", into Problem 2 where it belongs), 5 (strips L and N; drop M, which repeats L's lesson), 6, 7, 8, 9. Make Problems 10 and 11 one optional page ("Extra") with one small board each, not three. Drop Problem 12 from the K-1 packet, or keep Board T as a single page the organizer plays with the whole table during the 0:40 visit, with the adult doing the jumps the children call out. Retime: 1-2 (0:08-0:16), 3 (0:16-0:26), 5-6 (0:26-0:34), 7-9 (0:34-0:48).
- Grades 2-3: core is Problems 1-3 (strips E, F, H, J only), 5-8 (the river army and the one-dimensional values argument, which is this table's proof), 10, 12 (the shape hunt), and 15 (the T of eight) as the finale. Move 4, 9, 11, 13, 14 and 16 to "Extra" pages at the back. The two-dimensional value board (13-14) belongs to the 4-5 table only; see item 2. Retime: 1-3 (0:08-0:20), 5-8 (0:20-0:34), 10 and 12 (0:34-0:44), 15 (0:44-0:50).
- Grades 4-5: core is 1-5, 7, 8-11; make 6 and 12 "Extra"; 13 stays as the finish-early puzzle. Retime 3-4 to fifteen minutes (0:13-0:28) and compress 5-7 to 0:28-0:36.
- On every student page, prefix the optional problems with "Extra:" in the problem label so the table adult can skip them without explaining, and say in section 1 of the guide that a table that does only the core problems has done the session.

## 2. The two older tables get the same packet, and the younger one gets more of it

Problems 10-16 of grades 2-3 are, board for board, shape for shape and table row for table row, Problems 5-12 of grades 4-5 (Board U = O, V = P, W = Q, X = S; Shapes 1-6 = I-N; identical value tables). The third graders are then expected to finish all of it except Board T, so they get sixteen problems against the fifth grader's thirteen. The organizer asked for three levels.

What to change:

- Grades 2-3 keeps the one-dimensional argument (Strip S, Strip T) as its proof and the two-dimensional work as play: the crossing (10), the three-peg trials (11) and the shape hunt (12), with the answer "only the L and its mirror" discovered by the table, and the T of eight as the finale. Remove the 2-D value board and its table (13-14); the adult can show the values on the guide's board if a child asks why three never works.
- Grades 4-5 drops the clear-the-strip material entirely (it already does) and gets the 2-D values as its own: the value board, the "find a jump that raises the total" challenge (item 3), the 18-versus-21 and 52-versus-55 counts, the flags, and Board T.
- Give the two older packets different shape sets in the shape hunt, or at least different order and names, so the tables have something different to show at the share.

## 3. The values arrive from nowhere, and "the total never goes up" is checked on examples only

On grades 2-3 page 4 and grades 4-5 page 2 the children are handed 1, 1, 2, 3, 5, 8, 13, 21 with no reason, fill in five or six rows of a table, and are then asked (2-3 Problem 8, 4-5 Problem 4) why a peg can never land on square 2 "whatever jumps you make". The step that makes that a proof, that every jump toward the star keeps the total because each value is the sum of the two before it and every jump away lowers it, appears only in the guide (lines 178 and 235). The same gap is larger in two dimensions: 2-3 Problem 13 / 4-5 Problem 8 check four jumps on a 25-square board and Problem 14 / 9 then uses "the total never rises" for every jump on the board. The request named the monovariant argument as the point of the session, so the student pages should carry it.

What to change:

- Insert, after the values table on both older packets, a problem with two parts: "(a) Find a jump anywhere on the strip that makes the total go up. Try jumps to the right and jumps to the left. (b) When a peg jumps to the right it leaves two squares and lands on the next one. Why is the total exactly the same after every jump to the right?" Then Problem 8 / 4 can ask for the full argument.
- Grades 4-5: replace the copy exercise on Strip G ("continue the pattern", line 80) with a discovery: "Strip G has no values. Write 1 and 1 on its two leftmost squares, then choose the other values yourself so that a jump toward the star never changes the total. Then check that every jump away from the star lowers it." This forces the recurrence and is the moment the fifth grader understands why Fibonacci numbers appear. The guide answer: the values are forced, square by square.
- Grades 4-5, Board P: before Problem 9 add "The star is worth 21, its neighbours 13, the squares two steps away 8. Say the rule that gives every square its value. Find a jump on board P that makes the total go up." The guide already has the rule (line 246); the children should produce it, because Problems 9 and 11 use it.
- Grades 4-5 Problem 4 should also ask "why is the army always exactly one short?" with the 12/13, 20/21, 33/34 pattern; the guide (line 237) asks it, the page does not.

## 4. There is no structure for the children to work with each other

The request says the children work with each other and with the mathematicians; the packet is individual worksheets and the only interaction written in is "tell the adult". Section 4 of the guide has nothing on grouping.

What to change (write these into the student instructions and into section 4):

- Pairs on one board: one plays, one records, swap after each strip or shape. Say so in Problems 3, 5 (grades 2-3), 2, 7 (grades 4-5) and 3, 5 (K-1, where the first grader records for a kindergartner).
- Design-for-your-neighbour: 2-3 Problem 4 ("draw a five-peg pattern on strip K, pass it to your neighbour, who must clear it or show it cannot be cleared"), 2-3 Problem 6 / 4-5 Problem 2 Strip E / K-1 Problem 6 ("choose the starting squares for the person next to you").
- The shape hunt (2-3 Problem 12, 4-5 Problem 7, K-1 Problem 11) as a table job: each child takes two shapes, results are pooled on one shared sheet (add a "table results" row of six yes/no boxes to the page), and a shape reported as working must be replayed by someone else before it is ticked.
- The T of eight and Board T as one-board, whole-table puzzles with the adult as scribe on the jump lines; the four third graders should not each need eight pennies and a private solution.
- At the share, a child, not the adult, explains the other table's result back ("what did the 2-3 table find?").

## 5. K-1 recording and reading load

- Problems 10 and 11 ask five-year-olds to transcribe a placement onto a 0.4-inch mini grid with dots and an X, three times each. Replace with one large board and have the adult record ("The adult draws your checkers on the small board"), or drop as in item 1.
- Problem 12's text is on page 8 and its board on page 9; a read-aloud adult has to hold two pages. If Board T stays, set its cells to 1 in (`x=1.08in,y=1.08in` at line 160 becomes `\CellSize`) so the text and the board share page 9.
- Problems 5 and 6 record "the farthest square reached" four times when the answer is always square 1; after strip L, children see this as repetition. Keep L and N (the forced line) and the free strip O.
- K-1 boards have no coordinates, but the guide's answers for Problems 9 and 12 use C2, E3 and so on, with an apology (line 114). Print small letters under the columns on Boards Q, R, S and T (the `\ColLetters` macro exists) so the adult can follow the guide; the children can ignore them.
- Strip J in Problem 3 ("jump until no jump is possible" when none is) belongs in Problem 2.

## 6. Guide: statements to correct or qualify

- Lines 294 and 320: "Nineteen pegs can be worth 377 too (the sixteen squares within seven steps of the star plus three of the nine squares at eight steps)" is false on Board T as printed (seven columns, four home rows): only fifteen squares lie within seven steps of E8 and six at eight steps, and the nineteen heaviest home squares are worth 372 < 377. So on Board T the values alone rule out nineteen pegs; the 84-set search is a statement about the unbounded half-plane. Reword both places: "On an unbounded board the nineteen heaviest squares (sixteen within seven steps, three of nine at eight) are worth exactly 377 and none of those 84 sets works; on Board T itself the heaviest nineteen are worth only 372, so there the values already settle it."
- Line 52: "the organizer stopping at the K-1 table twice" leaves the 4-5 table without its anchored adult, which the organizer's plan rules out. Either say the visits are brief and the 4-5 table is given a problem to work alone, or drop the visits (the K-1 section is already self-contained).
- Line 68: the launch tells every child to "put a piece on each gray square of strip A" and jump, but the 4-5 Strip A has the river and asks for the crossing jump specifically. Add "any jump is fine for now" to the launch script, or make the 4-5 Strip A plain like the others.
- Lines 120, 188, 243: the counts "exactly two of 1365 placements" and "three of the eight-peg sets" are correct for the 5-wide boards printed (verified), but say "on this 5-wide board" since the unbounded answers differ (the row-2 count is a property of this board).
- Line 104: the Problem 6 explanation ("refilling home square 4 is itself a jump, which uses up two more pieces behind it") is a heuristic, not the case analysis it is presented as; label it "a way to say it to a child" and point the parent to the forced lines of Problem 5 for the complete check.
- Line 137 (c), line 210 (c), line 299 (c) and line 326: the block-reach facts are stated without saying the board width. I checked them and they hold on a wide board and on the children's 5-wide board alike (3x3 reaches row 2 above a side column only; 3x4 reaches row 3 above a side column; 5x2 and 5x3 reach row 3 above the middle column; 5x4 is worth 369 < 377 with the star in row 4, so it cannot reach row 4; 5x5 does reach row 4 even on a 5-wide board). Add "on the 5-wide board or any wider one" so a table using a blank grid knows the facts apply, and give the 5x2 case to the K-1 list too (ten pieces, row 3, a nicer early-finish target than the 3x4).

## 7. Layout and typography

- Printed values (`valtext` in `week-boards.tex` line 8) are `\footnotesize` in 65 percent gray. Children are adding these numbers; set them `\small` and in `ink`. The corner position is right, since a penny covers the cell centre.
- Grades 4-5: Problem 12's text sits under Board R on page 7 while Board S is on page 8, and Problem 13's text is at the foot of page 8 with Board T on page 9. Put each problem with its board: Board S at `\CellSize` 0.72 in fits on page 8 with its text and the seven jump lines.
- Grades 2-3 page 2 opens with strips G-J under no heading; repeat "Problem 3, continued" above strip G.
- The K-1 problem text runs to five sentences in several places (Problems 5, 6, 10, 11); since the adult reads, break each into an action line and a recording line so the adult can read one line, wait, then read the next (the guide asks for exactly this at line 80).
- Guide: the K-1 parent's section is two and a half dense pages. Add a half-page answer box at the start of section 5 (strip: outcomes; board: highest row; the three jumps on Board R) so the parent can run the table from one place and read the rest beforehand.

## 8. Smaller points

- Section 2: the penny count (130) does not include the 2-3 table's finish-early Board T (twenty per child); say "give the 4-5 cup to the 2-3 table if they get there".
- Section 8: the organizer's one-minute story of "never row five" is told with nothing to look at; a printed wide grid with the twenty-peg army and the star four rows up, held up at the end, would make the share land.
- Section 9 references (Winning Ways vol. 4 ch. 23; Aigner, Math. Magazine 70, 1997; Honsberger, Mathematical Gems II; Bell, Hirschberg and Guerrero-Garcia, INTEGERS 7, 2007; Beeler and Hoilman, Discrete Math. 311, 2011; Uehara and Iwata, 1990) match my recollection; the writer notes they were not checked online, and the guide should say so in one clause or the organizer should check them.
- `\ActivityId` values W1-K-v1, W1-M-v1, W1-U-v1, W1-F-v1 and the footers are consistent; keep them when renumbering problems.
