# Changes to the Week 1 "Jumping pegs" packet (rewriter stage)

The previous version is preserved in `before-rewrite/`. All four files recompile with
`pdflatex -interaction=nonstopmode` with no errors and no overfull boxes; every page was rendered
and checked. Page counts: K-1 8 (was 9), grades 2-3 9 (was 9), grades 4-5 10 (was 9), guide 14 (was 11).
`\ActivityId` values and footers are unchanged. Every answer printed in the guide, including the new
problems, was re-verified by exhaustive search (strips over all subsets, all 1365 four-peg placements,
all eight-peg sets of sufficient value, every printed jump sequence, the twenty-peg army and its
value 377, the 372 figure for nineteen pegs on the printed board, the block-reach table including the
new 5x2 case and the 5x5 block, and "no jump raises the total" over every jump on the strip and on
boards P and R).

## Review item 1 (quantity and pacing) - done

- K-1 cut from twelve problems to eight core problems plus three Extra. Strips G, I, J of the old
  Problem 3 dropped (J's "no jump possible" became strip C of Problem 2, now 1-3-5); the old
  Problem 4 ("try a different order") is folded into Problem 3 as a second box per strip; the old
  strip M dropped; Problems 10-11 (three checkers, four checkers in a new shape) are one Extra page
  with one small board each, recorded by the adult; Board T (now P) is an Extra played by the whole
  table with the adult making the jumps, text and board on one page at 1-inch cells.
  Retimed: 1-2 (0:08-0:16), 3 (0:16-0:26), 4-5 (0:26-0:34), 6-8 (0:34-0:48).
- Grades 2-3: core is now 1-3 (strips E, F, H, J of the old packet, relabelled E-H), the river
  (4-5), the strip values with the two new problems (6-9), the crossing and the shape hunt (10-11)
  and the T of eight (12). Old Problems 4, 9, 11, 16 are Extra 13-16; the 2-D value board and its
  table (old 13-14) are removed from this packet. Values table cut from five rows to four.
  Retimed: 1-3 (0:08-0:20), 4-5 (0:20-0:27), 6-9 (0:27-0:37), 10-11 (0:37-0:45), 12 (0:45-0:50).
- Grades 4-5: old 6 (three pegs) and 12 (another eight-peg set) are Extra 14-15, Board T (now U)
  is Extra 16; three new problems inserted (see item 3). Retimed: 1-2 (0:08-0:13), 3-5
  (0:13-0:24), 6-7 (0:24-0:30), 8 (0:30-0:37), 9-11 (0:37-0:43), 12-13 (0:43-0:50).
- Optional problems are labelled "Problem N (Extra)" on the pages; section 1 of the guide says a
  table that does only the core problems has done the session, and each table section says what to
  skip at 0:40 so that the hour ends on the table's finale.

## Review item 2 (differentiation) - done

- Grades 2-3 keeps the one-dimensional values argument as its proof and the two-dimensional work as
  play; the 2-D value board and table are gone from that packet (the guide points the adult to the
  4-5 board P if a child asks why three pegs fail).
- Grades 4-5 owns the 2-D values: board P with the four jumps, the new rule-and-no-raise problem
  (10), 18 versus 21 (11), board R 52 versus 55 (13), the flags (Extra 15) and the twenty-peg board.
- Different shape sets: grades 2-3 hunt block, row of four, T, two stacks, L and mirror L (shapes
  1-6; two of six work and are mirror images); grades 4-5 hunt block, Z, column-plus-side,
  mirror L, S and tall L (shapes I-N; one works, four of the six are worth 21). Both sets checked.

## Review item 3 (the values argument on the page) - done

- Both older packets get, after the values table, a "find a jump that makes the total go up"
  problem with a three-row recording table and a yes/no, followed by the sum "__ + __ = __" and
  "why is the total exactly the same after every jump to the right" (2-3 Problems 7-8; 4-5
  Problem 4). The full impossibility argument is then asked (2-3 Problem 9, 4-5 Problem 5).
- Grades 4-5 Problem 6 replaces "continue the pattern" with the discovery: write 1 and 1, choose
  the other values so that a jump toward the star never changes the total, check jumps away lower
  it; then the 12/13, 20/21, 33/34, 54/55 pattern and "why is the army always exactly one short"
  are on the page. The guide gives the forced values and the "both grow by the same amount" argument.
- Grades 4-5 Problem 10 asks for the rule behind board P's values and for a raising jump (there is
  none; the guide lists the three kinds of jump and why each keeps or lowers the total).

## Review item 4 (children working with each other) - done

- Pairs on one board written into K-1 Problems 3-4, grades 2-3 Problems 3-4, grades 4-5 Problem 2.
- Design-for-your-neighbour: K-1 Problem 5 (strip K), 2-3 Problem 5 (strip M) and Extra 13
  (five-peg patterns passed to the neighbour), 4-5 Problem 2 strip E.
- Shape hunts as table jobs with a "table results" row of six yes/no boxes and the replay rule
  (2-3 Problem 11, 4-5 Problem 8); K-1 Extra 10 compares the three children's small boards.
- The T of eight (K-1 Extra 11, 2-3 Problem 12, 4-5 Problem 12) and the twenty pegs (4-5 Extra 16)
  are one-board, whole-table puzzles; at K-1 the adult makes the jumps the children call.
- Section 4 of the guide has a "Working together" subsection; section 8 has a child from another
  table say each result back.

## Review item 5 (K-1 load) - done

Adult records on the small boards; Board P text and board share a page; strips L, N, O kept (now
I, J, K), M dropped; column letters printed under every K-1 board; strip J moved to Problem 2;
every K-1 problem is written as short action and recording lines.

## Review item 6 (guide statements) - done

- The nineteen-peg statement is reworded in section 7 (Extra 16) and section 9: on the printed
  board the heaviest nineteen are worth 372 (fifteen squares within seven steps, six at eight), on
  an unbounded board the nineteen heaviest are worth exactly 377 and none of the 84 sets works.
- The organizer's K-1 visits are dropped; every adult stays at their table.
- The launch script says "any jump is fine for now" and mentions the 4-5 river.
- The 1365 and eight-peg counts say "on this 5-wide board" in the table sections. I also checked
  them on wider boards (9 wide for row 2, 7 wide for row 3): the answers are the same, and section 9
  now says so, rather than claiming the unbounded answers differ.
- The Problem 6 (now 5) explanation is labelled "a way to say it to a child" with the forced line of
  strip J and the values argument named as the complete checks.
- Block facts say "on the 5-wide board or any wider one"; the 5x2 case (ten pieces, row 3 above the
  middle column) is in the K-1 early-finish list; 5x4 is explained by its value 369 < 377.

## Review item 7 (layout) - done

Values are `\small` in `ink`; 4-5 Problem 15's text sits with its board and Problem 16's text sits
with Board U (0.72-inch cells, jump lines in three columns); "Problem 3, continued" heads page 2 of
grades 2-3; K-1 text is split into action and recording lines; section 5 opens with an answer box.

## Review item 8 - done

Penny count redone (150, a cup of 50 per table, which also covers a 2-3 table borrowing board U);
a share page (section 10) with the twenty-peg army, the row-4 star and a dashed row-5 star;
the references are marked as cited from memory.

## Rejected or modified

- Item 1 suggested keeping K-1 Problem 4 out entirely; I kept its content as a second box inside
  Problem 3 (one strip, two orders) because the comparison "same strip, different number" is the
  point of the strip work, and it costs no extra reading.
- Item 2 asked for the three-peg trials (old 2-3 Problem 11) in the 2-3 core while item 1 made them
  Extra; I followed item 1 (Extra 15) for time, and the shape hunt carries the "which shapes" question.
- Item 6 said the unbounded row-2 and row-3 counts differ from the 5-wide ones; my search on wider
  boards found the same two L shapes and the same three eight-peg sets, so the guide says the counts
  were checked on the 5-wide and on wider boards instead of hedging.
- The twenty-peg board is renamed U (grades 4-5 Extras are S, T, U) so that the letters run in page
  order; the guide uses the new letters throughout.
