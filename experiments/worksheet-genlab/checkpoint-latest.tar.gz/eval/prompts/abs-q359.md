You are evaluating one activity packet for a one-hour elementary math-circle session. You do not know who or what produced it. Your standard is the organizer's: a parent with a math PhD who runs the circle, has piloted packets with these children, and wants packets that need as little human editing as possible before being handed to the tables.

The packet is in `/home/claude/genlab/eval/packets/q359`: `week-k-1.tex`, `week-grades-2-3.tex`, `week-grades-4-5.tex`, `week-facilitator.tex`, their PDFs, and rendered pages in `render/` (`<file>-<n>.png`, one per page, plus `<file>.txt` extracted text). Look at every rendered page with your image viewer — all of them, in order — and read the sources when you need to quote or check something. Use the extracted text to search.

The organizer's request was:

Make an activity packet for a one-hour math circle session for grades K–5, where the kids work with each other and with professional mathematicians guiding them. The organizer's high-level activity outline is given below.

The group: ten children (two kindergartners and a first grader / four third graders / two fourth graders and a fifth grader) and three adults (the organizer, a math PhD; a second mathematician; one parent who is not a mathematician). One adult is anchored to each of three tables: K–1, grades 2–3 (the third graders sit here), grades 4–5. Session shape: a few minutes of free handling of the materials, a short whole-group launch, table work for most of the hour, a brief share at the end. The children have done math circle before; the older ones have seen simple games and puzzles, but nothing from this theme.

Deliverables — LaTeX sources that compile with `pdflatex -interaction=nonstopmode` (TikZ is available) to US Letter PDFs, written into the working directory named at the end of this message:

- `week-k-1.tex` — student pages for the K–1 table (no independent reading required; the adult reads aloud)
- `week-grades-2-3.tex` — student pages for the grades 2–3 table
- `week-grades-4-5.tex` — student pages for the grades 4–5 table
- `week-facilitator.tex` — one facilitator guide for the three adults: materials and preparation, the whole-group launch, what each table does in what order, complete answers and arguments for every problem, hints, and what to do when a table stalls or finishes early

Call it Week 1. Compile all four files until they build without errors, and look at the rendered pages (`pdftoppm -r 60 -png file.pdf out`) to check that diagrams and spacing came out as intended. Do not leave stray files other than the four `.tex` sources and their PDFs (plus any `.tex` files you `\input`).

The organizer's high-level outline for this session:

Theme: Bulgarian solitaire.

Counters sit in piles. A move takes one counter from every pile and puts all of those counters together as a new pile (piles that hit zero disappear). Brandt (1982) proved that if the number of counters is a triangular number 1 + 2 + ... + k, then no matter how you start you always end at the staircase (k, k−1, ..., 1), which is a fixed point; for other numbers of counters the game falls into a cycle instead. Later work bounds how many moves the staircase takes (at most k² − k, Igusa; Etienne), describes the cycles that occur for non-triangular numbers, identifies "Garden of Eden" states that no state leads to, and connects everything to partitions and Young diagrams. I like it because it is a deterministic dynamical system children can run by hand with counters, the triangular numbers keep coming back, and "does every start end in the same place?" is a real theorem with a real proof.

Materials on hand: lots of counters (also playing cards), paper for recording.

A verified fact sheet for this theme, prepared independently and checked by computer, is at `/home/claude/genlab/notes/facts-B-bulgarian.md`; read it and use it to check the mathematics. Where a packet makes a claim the sheet does not cover, recompute it yourself (a short program is fine).

What the organizer wants from a packet, in order of importance:

1. Mathematics. The problems are concrete instances of the real questions in the theme (existence, impossibility, invariants, optimality, completeness, reconfiguration, counting, dynamics), with a ladder from doing toward an argument that a mathematician at the table can push toward. Every answer and claim, on student pages and in the guide, is correct.
2. Concrete work, and enough of it. Nearly every problem has a physical or drawn action with the materials and a board, grid or blank to record in; sequences run act → record → compare → explain; a representation (table, code, coloring, map) is introduced only after the question it answers; each idea gets several purposeful, contrasting instances rather than one example and a question; each table has at least forty minutes of real work, and the last problems for the fast table are still real problems.
3. The next action is always clear. Each problem says what to build, place, move, count, draw, compare or record and where; rules are stated inside the problem text; nothing must be inferred from a title or label; text can be read aloud; no hidden tricks.
4. Level fit. K–1 needs no reading but is real mathematics, not decoration, and would keep three young children and an adult busy for the hour with big clear diagrams; 2–3 and 4–5 are demanding but reachable; explanations are asked for in forms a child can produce (point, list all cases, table, strategy, counterexample, "the same reason again"), never as a general rule with a variable.
5. Student pages carry nothing but the running header, the footer, `Problem N:` problems in plain direct sentences, and the diagrams and recording space children need. No page titles, teaser questions, section headings, labels ("Warm-up", "Challenge", "Go further", "Bonus", "Rules", "Fun fact", "Think about"), rule boxes, Name/Date lines, encouragement, exclamation marks, emoji, adult-facing remarks, explanations of the answer, or cute register.
6. The facilitator guide has materials with counts, a short whole-group launch built on the one concrete action everyone will use, per-table order with rough timings, complete answers and complete arguments for every problem, hints in order, what to do when a table stalls or finishes, and a short mathematical background for the mathematicians.
7. Production: compiles, diagrams legible and correctly scaled to the physical pieces where they are meant to be covered, layout clean.

Do not reward length for its own sake: extra pages count only if they are distinct real work, and a short packet is fine only if the tables would not run out. Do not reward sophistication of vocabulary. Judge from what a child at that table would actually do with the page.

Procedure: view every page; then go through the checks below; for every defect you report, quote the offending text (or name the page and problem) so that an editor could find it; for each table estimate the minutes of real work problem by problem and sum them.

Write your evaluation as JSON to `/home/claude/genlab/eval/results/abs-q359.json` with exactly this structure:

{
  "packet": "/home/claude/genlab/eval/packets/q359",
  "pages": {"k1": n, "g23": n, "g45": n, "facilitator": n},
  "problems": {"k1": n, "g23": n, "g45": n},
  "minutes_of_real_work": {"k1": n, "g23": n, "g45": n},
  "checks": {
    "C01_student_page_titles_or_headings": {"yes": bool, "evidence": "..."},
    "C02_name_date_lines": {"yes": bool, "evidence": "..."},
    "C03_encouragement_or_exclamations": {"yes": bool, "evidence": "..."},
    "C04_labels_boxes_funfacts": {"yes": bool, "evidence": "..."},
    "C05_explanation_before_two_cases": {"yes": bool, "evidence": "..."},
    "C06_table_under_40_minutes": {"yes": bool, "evidence": "..."},
    "C07_math_error_student_pages": {"yes": bool, "evidence": "..."},
    "C08_math_error_guide": {"yes": bool, "evidence": "..."},
    "C09_unclear_next_action": {"yes": bool, "evidence": "..."},
    "C10_k1_requires_reading_or_trivial": {"yes": bool, "evidence": "..."},
    "C11_answer_leakage_on_student_page": {"yes": bool, "evidence": "..."},
    "C12_guide_missing_components": {"yes": bool, "evidence": "..."},
    "C13_diagram_or_layout_defects": {"yes": bool, "evidence": "..."},
    "C14_adult_facing_text_on_student_pages": {"yes": bool, "evidence": "..."},
    "C15_general_rule_with_variable_demanded": {"yes": bool, "evidence": "..."},
    "C16_representation_before_its_question": {"yes": bool, "evidence": "..."}
  },
  "dimensions": {
    "D1_math_substance_and_correctness": {"score": 1-5, "reason": "..."},
    "D2_concreteness_and_order": {"score": 1-5, "reason": "..."},
    "D3_amount_and_contrast_of_work": {"score": 1-5, "reason": "..."},
    "D4_next_action_clarity": {"score": 1-5, "reason": "..."},
    "D5_level_fit": {"score": 1-5, "reason": "..."},
    "D6_page_slop_and_register": {"score": 1-5, "reason": "..."},
    "D7_facilitator_guide": {"score": 1-5, "reason": "..."},
    "D8_production": {"score": 1-5, "reason": "..."}
  },
  "editing_need": {"score": 1-10, "reason": "..."},
  "top_fixes": ["...", "...", "..."],
  "best_thing": "..."
}

Dimension anchors: 5 = the organizer would not change anything on this dimension; 4 = one or two small edits; 3 = real but bounded problems, an hour of editing on this dimension; 2 = serious problems on most pages or in most problems; 1 = unusable on this dimension. `editing_need` anchors: 10 = print as is; 8 = under fifteen minutes of edits; 6 = about an hour; 4 = half a day of rewriting; 2 = keep the idea, rewrite everything; 1 = start over.

Be exact and severe where the packet is wrong, and say so plainly when it is good; do not soften either. End your final message with the editing_need score and the three top fixes, nothing else.
