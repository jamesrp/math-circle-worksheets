#!/usr/bin/env python3
"""Export the final PDFs of every COMPLETED run (all pipeline stages have DONE markers) to <out>/<outline>/<wf>-s<seed>/."""
import sys, json, pathlib, shutil
ROOT = pathlib.Path('/home/claude/genlab/runs')
out = pathlib.Path(sys.argv[1])
shutil.rmtree(out, ignore_errors=True)
n = 0
for pj in ROOT.glob('*/*/s*/pipeline.json'):
    d = pj.parent
    if any(x in d.name for x in ('partial', 'aborted', 'contaminated', 'orphan')):
        continue
    meta = json.loads(pj.read_text())
    done = all(pathlib.Path(st['done_marker']).exists() for g in meta['groups'] for st in g)
    if not done:
        continue
    pdfs = [d / f'week-{k}.pdf' for k in ('k-1', 'grades-2-3', 'grades-4-5', 'facilitator')]
    if not all(p.exists() for p in pdfs):
        continue
    dst = out / meta['outline'] / f"{meta['workflow']}-s{meta['seed']}"
    dst.mkdir(parents=True, exist_ok=True)
    for p in pdfs:
        shutil.copy(p, dst / p.name)
    n += 1
print('exported', n, 'completed packets to', out)
