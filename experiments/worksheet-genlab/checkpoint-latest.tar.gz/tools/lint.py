#!/usr/bin/env python3
"""Deterministic slop/structure lint for a packet directory (run tools/render.sh first).
Usage: lint.py <packet_dir>  -> writes <packet_dir>/render/lint.json and prints a one-line summary.
Counts are heuristics for reporting alongside judge scores; they are not folded into judge prompts."""
import json, re, sys, pathlib, glob

STUDENT = ['week-k-1', 'week-grades-2-3', 'week-grades-4-5']
FAC = 'week-facilitator'
LABELS = r"warm-?up|challenge|go further|bonus|fun fact|think about|remember:|hint:|name:|date:|rules:|reflection|extension|great job|well done|you did it|let'?s\b|let us|nice work|good luck|have fun|congratulations|you're a|you are a"
HYPE = r"\b(explore|exploring|discover|discovering|journey|magic|magical|amazing|awesome|exciting|excited|adventure|cool|wow|superhero|quest|mission|mystery|detective|wonder|wonderful|fantastic|incredible)\b"
ADULT = r"\b(facilitator|teacher|adult|parent|instructor)\b"
HEADCMD = r"\\(section|subsection|subsubsection|paragraph|PageTitle|Task|Subhead|chapter|part)\*?\{"

def strip_comments(tex):
    return re.sub(r'(?<!\\)%.*', '', tex)

def student_metrics(d, name):
    tex_p = d / f'{name}.tex'
    txt_p = d / 'render' / f'{name}.txt'
    m = {'exists': tex_p.exists()}
    if not tex_p.exists():
        return m
    tex = strip_comments(tex_p.read_text(errors='ignore'))
    txt = txt_p.read_text(errors='ignore') if txt_p.exists() else ''
    body = tex.split(r'\begin{document}', 1)[-1]
    m['pages'] = len(glob.glob(str(d / 'render' / f'{name}-*.png')))
    words = re.findall(r"[A-Za-z][A-Za-z'’-]+", txt)
    m['words'] = len(words)
    m['problems'] = len(re.findall(r'\\Problem\{|\\Task\{|\\textbf\{Problem|^\s*Problem\s+\d+[:.]', body, re.M))
    if m['problems'] == 0:
        m['problems'] = len(re.findall(r'Problem\s+\d+[:.]', txt))
    m['exclamations'] = txt.count('!')
    m['heading_cmds'] = len(re.findall(HEADCMD, body))
    # standalone bold/large labels on their own line (not Problem N)
    m['standalone_labels'] = len([l for l in body.splitlines() if re.match(r'^\s*(\\textbf\{[^}]*\}|\{\\(large|Large|LARGE|huge|Huge)\\bfseries[^}]*\})\s*(\\\\|\\par)?\s*$', l) and 'Problem' not in l and 'Board' not in l and len(l) < 80])
    m['forbidden_labels'] = len(re.findall(LABELS, txt, re.I))
    m['forbidden_label_hits'] = sorted(set(x.lower() for x in re.findall(LABELS, txt, re.I)))[:12]
    m['hype_words'] = len(re.findall(HYPE, txt, re.I))
    m['adult_facing'] = len(re.findall(ADULT, txt, re.I))
    m['name_date'] = len(re.findall(r'\bName\b.{0,40}\bDate\b|\\NameLine|Name:\s*_|Date:\s*_', txt + body))
    m['emoji'] = len([c for c in txt if ord(c) >= 0x2600 and ord(c) not in (0x2013, 0x2014, 0x2026, 0x25a1, 0x25b3, 0x25cb, 0x2192, 0x2190, 0x2194, 0x2212, 0x00d7)])
    m['em_dashes_per_1k'] = round(1000 * (txt.count('—') + txt.count('–') * 0) / max(1, m['words']), 2)
    m['tikzpictures'] = len(re.findall(r'\\begin\{tikzpicture\}', body))
    m['recording_space'] = len(re.findall(r'\\AnswerLines|\\hrulefill|\\rule\{[^}]*\}\{\.?[0-9]*pt\}|\\Space\{|\\WriteBox|\\vspace\{[1-9][^}]*in\}|rectangle', body))
    m['uses_template'] = 1 if 'genlab-common' in tex or r'\WorksheetHeader' in tex else 0
    m['worksheet_headers'] = len(re.findall(r'\\WorksheetHeader', body))
    m['questions'] = txt.count('?')
    return m

def fac_metrics(d):
    tex_p = d / f'{FAC}.tex'; txt_p = d / 'render' / f'{FAC}.txt'
    m = {'exists': tex_p.exists()}
    if not tex_p.exists():
        return m
    txt = txt_p.read_text(errors='ignore') if txt_p.exists() else ''
    m['pages'] = len(glob.glob(str(d / 'render' / f'{FAC}-*.png')))
    m['words'] = len(re.findall(r"[A-Za-z][A-Za-z'’-]+", txt))
    for k, pat in {'materials': r'\bmaterials?\b', 'launch': r'\blaunch\b|whole-group|whole group', 'hints': r'\bhints?\b', 'solutions': r'\bsolutions?\b|\banswers?\b',
                   'stall_finish': r'\bstall|finish(es|ed)? early|fast finisher|runs out|if a table', 'timing': r'\bminutes?\b', 'background': r'\bundergraduate|research|theorem\b'}.items():
        m['has_' + k] = 1 if re.search(pat, txt, re.I) else 0
    return m

def main():
    d = pathlib.Path(sys.argv[1])
    out = {'packet': str(d), 'student': {}, 'facilitator': fac_metrics(d)}
    tot = {'pages': 0, 'problems': 0, 'words': 0, 'slop_items': 0, 'tikz': 0}
    for s in STUDENT:
        m = student_metrics(d, s)
        out['student'][s] = m
        if m.get('exists'):
            tot['pages'] += m['pages']; tot['problems'] += m['problems']; tot['words'] += m['words']; tot['tikz'] += m['tikzpictures']
            tot['slop_items'] += m['exclamations'] + m['heading_cmds'] + m['standalone_labels'] + m['forbidden_labels'] + m['hype_words'] + m['adult_facing'] + m['name_date'] + m['emoji']
    tot['slop_per_page'] = round(tot['slop_items'] / max(1, tot['pages']), 2)
    out['totals'] = tot
    (d / 'render').mkdir(exist_ok=True)
    (d / 'render' / 'lint.json').write_text(json.dumps(out, indent=2))
    print(f"{d.name}: student pages={tot['pages']} problems={tot['problems']} words={tot['words']} tikz={tot['tikz']} slop_items={tot['slop_items']} ({tot['slop_per_page']}/page) fac_pages={out['facilitator'].get('pages')}")

if __name__ == '__main__':
    main()
