#!/usr/bin/env bash
# Copy a finished writer(guided) base packet into a run directory (or a subdirectory of it) so the
# run's later stages start from the shared base. Marks the writer stage as done.
# Usage: branch_from_base.sh <base_run_dir> <target_dir> [<stage_name, default writer>]
set -euo pipefail
BASE="$(cd "$1" && pwd)"; TGT="$(mkdir -p "$2" && cd "$2" && pwd)"; NAME="${3:-writer}"
mkdir -p "$TGT"
cd "$BASE"
for f in week-*.tex week-*.pdf; do [ -f "$f" ] && cp "$f" "$TGT/"; done
for t in *.tex; do case "$t" in week-*.tex|genlab-common.tex) ;; *) cp "$t" "$TGT/";; esac; done
{ echo "Branched from shared base $BASE (identical writer(guided) stage)."; echo; cat "$BASE/DONE-writer.md"; } > "$TGT/DONE-$NAME.md"
mkdir -p "$TGT/snapshots"
echo "branched $BASE -> $TGT"
