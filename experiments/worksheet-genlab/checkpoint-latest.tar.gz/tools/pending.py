#!/usr/bin/env python3
"""List pending stages as chains (per run directory, in pipeline order) for the stage-runner workflow.
Usage: pending.py [W04 W03 ...]   (default: all runs). Prints JSON {"chains": [...]} for the Workflow args,
one chain per run directory = its remaining stages in order (dependent stages must run sequentially)."""
import sys, json, pathlib
ROOT = pathlib.Path('/home/claude/genlab/runs')
want = set(sys.argv[1:])
chains = []
for pj in sorted(ROOT.glob('*/*/s*/pipeline.json')):
    d = pj.parent
    if any(x in d.name for x in ('partial', 'aborted', 'contaminated', 'orphan')):
        continue
    m = json.loads(pj.read_text())
    if want and m['workflow'] not in want:
        continue
    chain = []
    for g in m['groups']:
        for st in g:
            if not pathlib.Path(st['done_marker']).exists():
                chain.append({'label': f"{m['workflow']}-{st['name']}-{m['outline']}-s{m['seed']}", 'prompt': st['prompt']})
    if chain:
        chains.append(chain)
print(json.dumps({'chains': chains}))
print(f"# {sum(len(c) for c in chains)} pending stages in {len(chains)} chains", file=sys.stderr)
