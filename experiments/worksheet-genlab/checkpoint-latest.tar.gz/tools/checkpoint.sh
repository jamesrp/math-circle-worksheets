#!/usr/bin/env bash
# Checkpoint the experiment workspace so a fresh session can resume.
# Produces, under /mnt/user-data/outputs/worksheet-genlab/:
#   checkpoint-latest.tar.gz   (everything except ref/ and regenerable renders)
#   STATE.md, notes/, spec/, eval/results (plain copies for browsing)
# Then the orchestrator commits these to ~/math-circle/experiments/worksheet-genlab/ on the user's machine.
set -euo pipefail
SRC=/home/claude/genlab
OUT=/mnt/user-data/outputs/worksheet-genlab
mkdir -p "$OUT"
cd "$SRC"
# PDFs and PNG renders are excluded (regenerable from the .tex sources with tools/render.sh); this keeps the
# tarball under the 20 MB per-file commit limit. Final PDFs are committed separately under packets/.
tar --exclude='./ref' --exclude='*.png' --exclude='*.pdf' --exclude='*.aux' --exclude='*.log' --exclude='*.out' \
    --exclude='*.fls' --exclude='*.fdb_latexmk' --exclude='*.synctex.gz' --exclude='__pycache__' \
    -czf "$OUT/checkpoint-latest.tar.gz" .
python3 /home/claude/genlab/tools/export_final_pdfs.py "$OUT/packets"
rm -rf "$OUT/notes" "$OUT/spec" "$OUT/eval-results"
cp -r notes "$OUT/notes"
cp -r spec "$OUT/spec"
mkdir -p "$OUT/eval-results"
[ -d eval/results ] && cp -r eval/results/. "$OUT/eval-results/" || true
cp STATE.md "$OUT/STATE.md"
ls -la "$OUT"
du -sh "$OUT/checkpoint-latest.tar.gz"
