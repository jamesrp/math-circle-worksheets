#!/usr/bin/env bash
# Snapshot the current packet (tex + pdf + inputs) of a run directory under snapshots/<label>/
# Usage: snapshot.sh <run_dir> <label>
set -euo pipefail
D="$1"; L="$2"
mkdir -p "$D/snapshots/$L"
cd "$D"
for f in week-k-1 week-grades-2-3 week-grades-4-5 week-facilitator; do
  [ -f "$f.tex" ] && cp "$f.tex" "snapshots/$L/"
  [ -f "$f.pdf" ] && cp "$f.pdf" "snapshots/$L/"
done
# any other .tex the documents \input (excluding stage prompts, which are .md)
for t in *.tex; do
  case "$t" in week-*.tex) ;; *) cp "$t" "snapshots/$L/" ;; esac
done
ls "snapshots/$L"
