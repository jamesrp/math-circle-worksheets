#!/usr/bin/env python3
"""Copy a packet into a blind evaluation directory: tex sources (comments stripped), PDFs, rendered pages.
Usage: collect.py <src_packet_dir> <dest_dir>
Only files needed by judges are copied; nothing about provenance (pipeline.json, reviews, stage prompts, snapshots) is copied."""
import sys, re, shutil, pathlib, subprocess

def strip_comments(tex):
    """Blank out comment TEXT but keep every '%' so TeX's whitespace handling (end-of-line suppression) is unchanged
    and the compiled output is byte-for-byte the same layout."""
    out = []
    for line in tex.splitlines():
        m = re.search(r'(?<!\\)%', line)
        if m:
            line = line[:m.start() + 1]
        out.append(line)
    return '\n'.join(out) + '\n'

def main():
    src, dst = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
    dst.mkdir(parents=True, exist_ok=True)
    for p in src.glob('*.tex'):
        (dst / p.name).write_text(strip_comments(p.read_text(errors='ignore')))
    # PDFs are NOT copied: render.sh recompiles the (comment-stripped) sources in the blind directory, so the judged
    # PDF is guaranteed to match the judged sources (one agent reported pdflatex once picking up a stray file from
    # the shared scratchpad). genlab-common.tex is copied with the sources when the packet uses it.
    subprocess.run(['bash', '/home/claude/genlab/tools/render.sh', str(dst)], check=False, capture_output=True)
    # remove compile byproducts so nothing but sources, pdfs, render remain
    for p in dst.glob('*'):
        if p.suffix in ('.aux', '.log', '.out', '.toc'):
            p.unlink()
    print('collected', dst)

if __name__ == '__main__':
    main()
