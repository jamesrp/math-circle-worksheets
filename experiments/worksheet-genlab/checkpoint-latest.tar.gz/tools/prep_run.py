#!/usr/bin/env python3
"""Prepare a run directory for (workflow, outline, seed): render stage prompts, copy template, write pipeline.json.

Usage: prep_run.py W04 T 1
Creates runs/<outline>/<wf>/s<seed>/ with stage-XX-<name>.md prompt files.
"""
import json, os, re, sys, shutil, pathlib

ROOT = pathlib.Path('/home/claude/genlab')
SPEC = ROOT / 'spec'
PROMPTS = SPEC / 'prompts'

def read(p):
    return pathlib.Path(p).read_text()

def block(name):
    txt = read(PROMPTS / '_blocks.md')
    m = re.search(r'## ' + name + r'\n\n(.*?)(?=\n## |\Z)', txt, re.S)
    return m.group(1).strip()

TABLE_SPECS = {
    'k-1': ("K–1: two kindergartners (5 years old; count to about 20 by ones, compare more/fewer, cannot read, can copy a shape, "
            "lose focus after about eight minutes on one task and need a change of activity or a new piece to hold) and a first grader "
            "(6; reads short words slowly, adds within 10 on fingers, likes to explain), with the parent who is not a mathematician "
            "(reads the pages aloud, follows the guide literally, cannot supply a missing rule or answer, will ask the organizer if stuck)."),
    'grades-2-3': ("Grades 2–3: four third graders (8–9; read fluently, add and subtract within 100, know some multiplication, can list cases "
            "with prompting, work in two pairs, argue about rules, one is fast and gets restless, one is careful and slow), with the second "
            "mathematician (knows the guide, enjoys asking \"how do you know\", can supply the argument if asked)."),
    'grades-4-5': ("Grades 4–5: two fourth graders and a fifth grader (9–11; fluent readers; multiplication and division; can follow a two-step "
            "rule and check each other; will try to generalize early and can be wrong; one has seen parity arguments before), with the organizer "
            "(math PhD, knows the guide and the mathematics; wants to push toward the argument without giving it away)."),
}

def render(template, **kw):
    txt = read(PROMPTS / template)
    common = dict(TASK_BRIEF=read(SPEC / 'task-brief.md').strip(),
                  GUIDANCE=read(SPEC / 'antislop-v1.md').strip(),
                  TEMPLATE_INSTRUCTIONS=block('TEMPLATE_INSTRUCTIONS'),
                  STAGE_PROTOCOL=block('STAGE_PROTOCOL'),
                  EXTRA_INPUTS='', REVIEW_SENTENCE='A review of it is in `' + kw.get('WORKDIR','') + '/review.md`.')
    common.update(kw)
    for k, v in common.items():
        txt = txt.replace('{{' + k + '}}', v)
    txt = re.sub(r'<!--.*?-->\n?', '', txt, flags=re.S)
    left = re.findall(r'\{\{[A-Z_]+\}\}', txt)
    assert not left, f'unfilled placeholders in {template}: {left}'
    return txt

def pipeline(wf, workdir):
    W = str(workdir)
    stages = []  # list of stage groups; each group is a list of (name, template, kwargs, subdir)
    guided = ('writer', 'writer-guided.md', {}, None)
    naive = ('writer', 'writer-naive.md', {}, None)
    rev_t = ('reviewer', 'reviewer-targeted.md', {}, None)
    rev_g = ('reviewer', 'reviewer-generic.md', {}, None)
    rew = ('rewriter', 'rewriter.md', {}, None)
    if wf == 'W01':
        stages = [[naive]]
    elif wf == 'W02':
        stages = [[guided]]
    elif wf == 'W03':
        stages = [[guided], [rev_g], [rew]]
    elif wf == 'W04':
        stages = [[guided], [rev_t], [rew]]
    elif wf == 'W05':
        extra = ("\nA research mathematician prepared a dossier for this session: `" + W + "/dossier.md`. Read it first and build the packet "
                 "on its instances, verified data, and arguments; you may add or drop instances if you have a good reason.\n")
        stages = [[('mathematician', 'mathematician-dossier.md', {}, None)],
                  [('writer', 'writer-guided.md', {'EXTRA_INPUTS': extra}, None)],
                  [rev_t], [rew]]
    elif wf == 'W06':
        stages = [[('bank', 'bank-generator.md', {}, None)], [('curator', 'curator.md', {}, None)],
                  [('formatter', 'formatter.md', {}, None)], [('copyeditor', 'copyeditor.md', {}, None)]]
    elif wf == 'W07':
        # trimmed design (2026-10-02): one simulator agent covers all three tables
        extra = ("A minute-by-minute simulation of how the packet would go at each of the three tables is in `" + W +
                 "/sim-all.md`; treat its consequential problems and suggested changes as the review.")
        stages = [[guided],
                  [('sim-all', 'table-simulator-all.md', {'TABLE_K': TABLE_SPECS['k-1'], 'TABLE_M': TABLE_SPECS['grades-2-3'], 'TABLE_U': TABLE_SPECS['grades-4-5']}, None)],
                  [('rewriter', 'rewriter.md', {'REVIEW_SENTENCE': extra}, None)]]
    elif wf == 'W08':
        # trimmed design: cand1 = W02 s1 base, cand2 = W02 s2 (noise-floor writer), cand3 = fresh writer
        cands = [('writer-cand%d' % i, 'writer-guided.md', {}, 'cand%d' % i) for i in (1, 2, 3)]
        stages = [cands, [('selector', 'selector.md', {}, None)]]
    elif wf == 'W09':
        # trimmed design: round 1 is W04 (branched from its output); one further round here, a third only if warranted
        stages = [[guided]]
        for r in (1, 2):
            stages.append([('reviewer-r%d' % r, 'reviewer-targeted.md', {}, None)])
            stages.append([('rewriter-r%d' % r, 'rewriter.md', {}, None)])
    elif wf == 'W10':
        stages = [[guided], [('editor', 'editor-editlist.md', {}, None)]]
    else:
        raise SystemExit('unknown workflow ' + wf)
    return stages

def main():
    wf, outline, seed = sys.argv[1], sys.argv[2], int(sys.argv[3])
    outline_file = {'T': 'T-tilings.md', 'P': 'P-pegs.md', 'B': 'B-bulgarian.md'}[outline]
    workdir = ROOT / 'runs' / outline / wf / f's{seed}'
    workdir.mkdir(parents=True, exist_ok=True)
    (workdir / 'snapshots').mkdir(exist_ok=True)
    if wf != 'W01':  # the naive workflow gets no template file (vertical-slice fix: its presence was used as a hint)
        shutil.copy(SPEC / 'genlab-common.tex', workdir / 'genlab-common.tex')
    outline_txt = read(SPEC / 'outlines' / outline_file).strip()
    groups = pipeline(wf, workdir)
    plan = []
    n = 0
    for gi, group in enumerate(groups):
        g = []
        for (name, template, kw, subdir) in group:
            n += 1
            wd = workdir / subdir if subdir else workdir
            if subdir:
                wd.mkdir(exist_ok=True)
                shutil.copy(SPEC / 'genlab-common.tex', wd / 'genlab-common.tex')
            txt = render(template, OUTLINE=outline_txt, WORKDIR=str(wd), **kw)
            fname = f'stage-{n:02d}-{name}.md'
            (workdir / fname).write_text(txt)
            g.append({'stage': n, 'name': name, 'prompt': str(workdir / fname), 'workdir': str(wd), 'done_marker': str(wd / f'DONE-{name}.md')})
        plan.append(g)
    meta = {'workflow': wf, 'outline': outline, 'seed': seed, 'workdir': str(workdir), 'groups': plan,
            'versions': {'task_brief': 'tb-v1', 'guidance': 'antislop-v1', 'template': 'genlab-common-v1', 'wf_set': 'v1'}}
    (workdir / 'pipeline.json').write_text(json.dumps(meta, indent=2))
    print(json.dumps(meta, indent=2))

if __name__ == '__main__':
    main()
