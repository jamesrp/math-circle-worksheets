#!/usr/bin/env python3
"""Render a judge prompt.
Usage:
  prep_judge.py abs  <outline_id> <packet_dir> <output_json> <prompt_out>
  prep_judge.py pair <outline_id> <packet_A_dir> <packet_B_dir> <output_json> <prompt_out>
"""
import sys, re, pathlib
ROOT = pathlib.Path('/home/claude/genlab')
SPEC = ROOT / 'spec'
FACTS = {'T': ROOT / 'notes/facts-T-tilings.md', 'P': ROOT / 'notes/facts-P-pegs.md', 'B': ROOT / 'notes/facts-B-bulgarian.md'}
OUTL = {'T': 'T-tilings.md', 'P': 'P-pegs.md', 'B': 'B-bulgarian.md'}

def fill(txt, **kw):
    for k, v in kw.items():
        txt = txt.replace('{{' + k + '}}', v)
    txt = re.sub(r'<!--.*?-->\n?', '', txt, flags=re.S)
    assert not re.findall(r'\{\{[A-Z_]+\}\}', txt), re.findall(r'\{\{[A-Z_]+\}\}', txt)
    return txt

def main():
    mode = sys.argv[1]; oid = sys.argv[2]
    brief = (SPEC / 'task-brief.md').read_text().strip()
    outline = (SPEC / 'outlines' / OUTL[oid]).read_text().strip()
    if mode == 'abs':
        pdir, out_json, prompt_out = sys.argv[3:6]
        txt = fill((SPEC / 'eval/judge-absolute.md').read_text(), PACKET_DIR=pdir, OUTPUT_PATH=out_json, TASK_BRIEF=brief, OUTLINE=outline, FACTS_PATH=str(FACTS[oid]))
    else:
        a, b, out_json, prompt_out = sys.argv[3:7]
        txt = fill((SPEC / 'eval/judge-pairwise.md').read_text(), PACKET_A_DIR=a, PACKET_B_DIR=b, OUTPUT_PATH=out_json, TASK_BRIEF=brief, OUTLINE=outline, FACTS_PATH=str(FACTS[oid]))
    pathlib.Path(prompt_out).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(prompt_out).write_text(txt)
    print(prompt_out)

if __name__ == '__main__':
    main()
