#!/usr/bin/env python3
"""Assign a blind id to a run's final packet and collect it into eval/packets/<id>/.
Usage: collect_all.py <outline> <workflow> <seed> [<subdir-or-snapshot-label>]
Mapping is appended to eval/packets/mapping.json (never given to judges). Re-running for the same key re-collects into the same id."""
import sys, json, random, pathlib, subprocess
ROOT = pathlib.Path('/home/claude/genlab')
MAP = ROOT / 'eval/packets/mapping.json'

def main():
    outline, wf, seed = sys.argv[1], sys.argv[2], sys.argv[3]
    sub = sys.argv[4] if len(sys.argv) > 4 else ''
    key = f'{outline}/{wf}/s{seed}' + (f'/{sub}' if sub else '')
    src = ROOT / 'runs' / outline / wf / f's{seed}' / sub
    MAP.parent.mkdir(parents=True, exist_ok=True)
    mapping = json.loads(MAP.read_text()) if MAP.exists() else {}
    if key in mapping:
        pid = mapping[key]
    else:
        used = set(mapping.values())
        rnd = random.Random(hash(key) & 0xffffffff)
        while True:
            pid = 'q%03d' % rnd.randint(100, 999)
            if pid not in used:
                break
        mapping[key] = pid
        MAP.write_text(json.dumps(mapping, indent=2, sort_keys=True))
    dst = ROOT / 'eval/packets' / pid
    if dst.exists():
        subprocess.run(['rm', '-rf', str(dst)])
    subprocess.run(['python3', str(ROOT / 'tools/collect.py'), str(src), str(dst)], check=True)
    subprocess.run(['python3', str(ROOT / 'tools/lint.py'), str(dst)], check=False)
    print(key, '->', pid)

if __name__ == '__main__':
    main()
