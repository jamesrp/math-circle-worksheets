#!/usr/bin/env bash
# Render a packet directory for evaluation: compile if needed, PNG pages at 80 dpi, extracted text, page counts.
# Usage: render.sh <packet_dir>   (expects week-k-1.tex etc.; writes <packet_dir>/render/)
set -uo pipefail
D="$1"; cd "$D" || exit 1
mkdir -p render
FILES="week-k-1 week-grades-2-3 week-grades-4-5 week-facilitator"
status="ok"
for f in $FILES; do
  if [ ! -f "$f.tex" ]; then echo "MISSING $f.tex"; status="missing"; continue; fi
  if [ ! -f "$f.pdf" ] || [ "$f.tex" -nt "$f.pdf" ]; then
    pdflatex -interaction=nonstopmode "$f.tex" >/dev/null 2>&1; pdflatex -interaction=nonstopmode "$f.tex" >/dev/null 2>&1
  fi
  if [ ! -f "$f.pdf" ]; then echo "NOPDF $f"; status="compile-fail"; continue; fi
  errs=$(grep -c "^!" "$f.log" 2>/dev/null || echo 0)
  rm -f render/$f-*.png
  pdftoppm -r 80 -png "$f.pdf" "render/$f"
  pdftotext -layout "$f.pdf" "render/$f.txt" 2>/dev/null
  pages=$(ls render/$f-*.png 2>/dev/null | wc -l)
  echo "$f pages=$pages latex_errors=$errs"
done
echo "STATUS $status"
