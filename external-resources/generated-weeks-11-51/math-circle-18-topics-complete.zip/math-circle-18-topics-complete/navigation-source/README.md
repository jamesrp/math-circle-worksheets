# Rebuild this navigation document

From the extracted archive root, run `python3 -m pip install -r navigation-source/requirements.txt`, then `python3 navigation-source/build_start_here.py`.

The builder reads topics.json and the metadata inventory/verified Drive links. Install DejaVu Sans regular and bold, or set DEJAVU_FONT_DIR to their directory. No fonts are bundled. Inspect every rendered page after editing. Rebuilding this index does not change any topic PDF or source ZIP. Do not infer that an unchanged page count makes altered prose reviewed.

File counts include the seven-page navigation PDF separately from the 72 individual teaching PDFs. Combined books are optional duplicates available in Drive and are excluded here. Each source ZIP retains its own unchanged reference PDFs for reproduction checks.
