from pathlib import Path
import json, re, argparse
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor

ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent);args=ap.parse_args();ROOT=args.root
DATA=Path(__file__).with_name('topics.json')
TOPICS=json.loads(DATA.read_text());INV=json.loads((ROOT/'metadata'/'packet-inventory.json').read_text())
LINKS={int(r['week']):r['url'] for r in json.loads((ROOT/'metadata'/'drive-topic-folders.json').read_text())}
DRIVE=json.loads((ROOT/'metadata'/'drive-delivery-manifest.json').read_text())['root_folder']
COMBINED='https://drive.google.com/drive/folders/1IdtMJafLirr4pA2XvMz1uRHHHi5xWGaP'
fontdir=Path('/usr/share/fonts/truetype/dejavu')
import os, subprocess
if os.environ.get('DEJAVU_FONT_DIR'):fontdir=Path(os.environ['DEJAVU_FONT_DIR'])
elif not (fontdir/'DejaVuSans.ttf').exists():
 fontdir=Path(subprocess.check_output(['fc-match','-f','%{file}','DejaVu Sans'],text=True)).parent
for name,f in [('Body','DejaVuSans.ttf'),('Bold','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(name,str(fontdir/f)))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold')
STYLE=ParagraphStyle('body',fontName='Body',fontSize=9.55,leading=12.4,textColor=HexColor('#17212b'),spaceAfter=0)
SMALL=ParagraphStyle('small',parent=STYLE,fontSize=8.0,leading=10.8)
HEAD=ParagraphStyle('head',parent=STYLE,fontName='Bold',fontSize=14,leading=17)
TITLE=ParagraphStyle('title',parent=STYLE,fontName='Bold',fontSize=25,leading=30)
SUB=ParagraphStyle('sub',parent=STYLE,fontName='Bold',fontSize=11.5,leading=15)
C=canvas.Canvas(str(ROOT/'START-HERE.pdf'),pagesize=(612,792));C.setTitle('Start here: 18 math-circle topics');C.setAuthor('Bellingham Math Circle');C.setSubject('Draft and unpiloted; activity-library slots 11-28; prerequisites, preparation and print navigation')
W=516;M=48

def para(text,y,style=STYLE):
 p=Paragraph(text,style);w,h=p.wrap(W,750);p.drawOn(C,M,y-h);return y-h

def safe(s):return escape(s)
def link(label,url):return f'<link href="{escape(url, {chr(34): "&quot;"})}" color="#205e89"><u>{safe(label)}</u></link>'
def header(k,label):
 C.setFont('Body',8);C.setFillColor(HexColor('#53616b'));C.drawString(M,764,'BELLINGHAM MATH CIRCLE  |  START HERE');C.drawRightString(564,764,label)
 C.setStrokeColor(HexColor('#c9ced2'));C.line(M,753,564,753)
 C.setFont('Body',8);C.drawString(M,27,'Draft and unpiloted  |  Library labels are not a schedule  |  October 3, 2026');C.drawRightString(564,27,str(k))

def inventory_line(t):
 v=INV['topics'][str(t['week'])]
 pages=' / '.join(map(str,v['student_pages']));entries=' / '.join(map(str,v['numbered_entries']))
 gp=v.get('guide_pages');return f'Student pages {pages}; numbered entries {entries}. Adult guide {gp if gp is not None else "pending"} pages.'

summary=INV['summary'];adult_total=summary.get('adult_pages')
count_sentence=f"18 topic families: 12 new topics and 6 rebuilt earlier leads. There are 54 student PDFs ({summary['student_pages']} pages, {summary['numbered_entries']} numbered entries), 18 separate adult guides"+(f" ({adult_total} pages), and 18 editable-source ZIPs." if adult_total is not None else ", and 18 editable-source ZIPs in the completed release.")
blocks=[
 ('Choose a starting point','Grade labels suggest an entry, not a placement rule. Use the concrete gates on the following pages, let an adult read, move materials or scribe, and choose one or two substantial problems. Finishing the packet is not the session goal. Page/count triples use K-1 / grades 2-3 / grades 4-5.'),
 ('Two gates to check before choosing','<b>Stable matching, slot 27:</b> K-1 is optional. A child must first apply the demonstrated rule that BOTH members of an unpaired pair prefer each other to their current partners. Otherwise choose another independent activity.<br/><b>Flat folding, slot 28:</b> the adult physical pretest is still unperformed. Try each intended valid demonstration with the actual paper before teaching. Mathematical checks and diagrams do not replace this preparation.'),
 ('Print once','In the compact complete ZIP, open a topic folder and choose its students-k-1, students-grades-2-3 or students-grades-4-5 PDF plus the separate facilitator guide. Print selected student pages single-sided on US Letter at 100% / actual size; measure manipulative fit. Do not print all bands automatically.'),
 ('Combined books are optional duplicates','The '+link('combined-downloads folder',COMBINED)+' offers four books for each six-topic set: one per student band and one adult book. Use EITHER individual packets OR their pages in a combined book. Use the combined book\'s PDF-viewer page ranges and bookmarks; printed packet numbers restart. Combined books are omitted from this compact ZIP. Source ZIPs also repeat reference PDFs for rebuilding; those copies need not be printed.'),
 ('What the counts mean',safe(count_sentence)+' Numbered entries count prompts within each band, with continuations counted once. Related adaptations across bands are not separate mathematical ideas. This seven-page navigation PDF is extra; it is excluded from student and guide page totals.'),
 ('Status and files','All 18 topics remain draft and unpiloted. Writing, review, revision, mathematical checks and reproduction checks are not classroom evidence or approval to adopt a schedule. Supply quantities and pacing are proposals, not measured stock or tested timing. Each topic guide has the detailed launch, materials, solutions, hints and sources. Source ZIP READMEs give editable builds and rights notes. The metadata folder records file counts and hashes; exact references and third-party rights remain in the guides and sources.')
]
header(1,'Navigation and preparation');C.bookmarkPage('start');C.addOutlineEntry('Start here','start',0)
y=733;y=para('18 math-circle topics',y,TITLE);y-=6;y=para('Activity-library slots 11-28',y,SUB);y-=8
y=para(link('Open the private Drive corpus',DRIVE)+'  |  Topic links on pages 2-7',y);y-=13
for title,txt in blocks:
 y=para(title,y,SUB);y-=3;y=para(txt,y);y-=12
assert y>=45,f'Page 1 overflow: {y}'
C.showPage()
for group in range(6):
 subset=TOPICS[group*3:group*3+3];header(group+2,f'Slots {subset[0]["week"]}-{subset[-1]["week"]}');y=729
 for ix,t in enumerate(subset):
  key=f'topic-{t["week"]}';C.bookmarkPage(key);C.addOutlineEntry(f'{t["week"]}. {t["title"]}',key,0)
  y=para(f'{t["week"]}. {safe(t["title"])}',y,HEAD);y-=5
  for label,field in [('Payoff','payoff'),('Entry gates','entry'),('Materials / prep','prep')]:
   y=para('<b>'+label+'.</b> '+safe(t[field]),y);y-=5
  y=para(safe(inventory_line(t)),y,SMALL);y-=3
  nav=f'Folder: {safe(t["slug"])}/'
  if t['week'] in LINKS:nav+='  |  '+link('Open private Drive topic',LINKS[t['week']])
  else:nav+='  |  Drive link pending'
  y=para(nav,y,SMALL);y-=12
  if ix<2:C.setStrokeColor(HexColor('#d3d8db'));C.line(M,y,564,y);y-=15
 assert y>=43,f'Topic page {group+2} overflow: {y}'
 C.showPage()
C.save()

md=['# Start here: 18 math-circle topics','','Bellingham Math Circle | Prepared October 3, 2026','', '**Draft and unpiloted.** Slots 11-28 are activity-library identifiers, not a meeting schedule or an approved curriculum sequence.','',f'[Open the private Drive corpus]({DRIVE}) | [Optional combined-downloads folder]({COMBINED})','']
for title,txt in blocks:
 txt=txt.replace('<br/>','\n\n').replace('<b>','**').replace('</b>','**')
 txt=re.sub(r'<link href="([^"]+)" color="[^"]+"><u>(.*?)</u></link>',r'[\2](\1)',txt)
 import html;txt=html.unescape(txt)
 md+=['## '+title,'',txt,'']
md+=['## Topic finder','','In each entry, page and numbered-entry triples are K-1 / grades 2-3 / grades 4-5. Readiness is determined by the task, not grade alone. The materials summaries flag special preparation; consult the full guide for quantities and route-specific extras.','']
for t in TOPICS:
 md+=['### '+str(t['week'])+'. '+t['title'],'',t['payoff'],'','- Entry gates: '+t['entry'],'- Materials / prep: '+t['prep'],'- '+inventory_line(t),'- Folder: `'+t['slug']+'/`'+(' | [Open private Drive topic]('+LINKS[t['week']]+')' if t['week'] in LINKS else ' | Drive link pending'),'']
(ROOT/'START-HERE.md').write_text('\n'.join(md)+'\n')
print('Built',ROOT/'START-HERE.pdf','and START-HERE.md')
