# Complete-archive validation

This compact archive contains 18 topic folders. Each has three student PDFs, a separate facilitator guide and one editable-source ZIP. The 72 teaching PDFs and 18 source ZIPs are byte-for-byte copies of their finalized delivery counterparts. Every PDF also matches its unchanged reference inside the corresponding source ZIP. All 18 source ZIP CRC checks passed; each includes its own release-validation record.

PDF page counts and Letter dimensions were read independently. Student entry counts use distinct numbered Problem labels inside each band; continued pages count once. They are not counts of distinct mathematical ideas. Navigation has 7 pages and 20 verified Drive links (the corpus, optional combined-download folder and 18 topics). The final navigation was rendered and visually reviewed page by page.

SHA256SUMS.txt covers every archive member except itself. The completed outer ZIP is checked for CRC integrity, unique safe member paths, all checksums, 73 direct PDF files and 18 direct source ZIPs, with source ZIP CRCs and teaching-PDF byte identity rechecked from inside the outer archive. The archive checksum is supplied beside the archive. Combined books and the three six-topic collection ZIPs are deliberately omitted to avoid duplicate print downloads. Source ZIP reference PDFs remain intentional reproduction copies.

These checks concern mathematical/file preparation and reproduction. No classroom pilot, physical folding test, measured material inventory or organizer approval is claimed.
